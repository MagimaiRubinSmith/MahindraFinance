/**
 * 
 */
demoMsg = {
	hello: "hi"
}
warnMsg = {
	portCode: 'Enter Port Code to Fetch',
	formNoORShipDetail: 'Enter Either the Form No / Shipping Details to Fetch',
	shippingBillNoLength: 'Shipping Bill Number should be 6 digits',
	portCodeLength: 'Port Code should be 6 digits',
	formNoLength: 'Form Number should not exceed 20',
	noOfinvoiceLength: 'Enter No. of Invoice to Proceed',
	invoiceSerialNoLength: 'Enter Invoice Serial to Proceed',
	invoiceNoLength: 'Enter Invoice No. to Proceed',
	invoiceDateLength: 'Enter Invoice Date to Proceed',
	invoiceAmtLength: 'Enter Invoice Amount to Proceed',
	invoiceCurrLength: 'Enter Invoice Currency to Proceed',
	invoiceArrLength: 'Invoice Details should match No. of Invoice',
	noOfBOELength: 'Enter No. of BOE to Proceed',
	BOESerialNoLength: 'Enter BOE Serial to Proceed',
	BOENoLength: 'Enter BOE No. to Proceed',
	BOEDateLength: 'Enter BOE Date to Proceed',
	BOEAmtLength: 'Enter BOE Amount to Proceed',
	BOECurrLength: 'Enter BOE Currency to Proceed',
	BOEArrLength: 'BOE Details should match No. of BOE',
	billRefORORMNo: 'Enter Either the Bill Reference No or ORM / DDRef No to Fetch',
	highSSNameLength: 'Enter No. of High Sea Seller Name to Proceed',
	highSSAddressLength: 'Enter No. of High Sea Seller Address to Proceed'
}