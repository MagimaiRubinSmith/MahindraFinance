function doLoad() {
	$('body').modal("hide");
	$('body').css('display', 'block');
	$('body').removeClass('removePageLoad');
	$('body').addClass('removePageLoad');
	selectAjaxlist();
	
}

function selectAjaxlist() {
	var tiListDetail = $("#repaymentBatchID").val();
	if(tiListDetail != null && tiListDetail != undefined && tiListDetail != ""){
				var dealReference = $(
						"#DealReference").val();
				console.log(dealReference);
				if (dealReference != undefined
						&& dealReference.length > 100) {
					var dealSplit = dealReference
							.split(".");
					var splitDealRef = dealSplit[1]
							.split(",");
					var len = splitDealRef.length;
					var dealReferenceJoin = "";
					for ( var i = 0; i < len; i++) {
						console
								.log(splitDealRef[i]);
						console.log(i % 4);
						if (dealReferenceJoin == "") {
							dealReferenceJoin = splitDealRef[i];
						} else {
							if (i % 4 == 0) {
								dealReferenceJoin = dealReferenceJoin
										+ ", <br />"
										+ splitDealRef[i];
							} else {
								dealReferenceJoin = dealReferenceJoin
										+ ", "
										+ splitDealRef[i];
							}

						}
					}
					$('#dealValue')
							.html(
									dealSplit[0]
											+ ".<br />"
											+ dealReferenceJoin);
				}
	$("#loadAjaxPage tbody").find("tr").remove();
	//$("#invoiceList tbody").find("tr").remove();
	//$("#loadAjaxPage > tbody").empty();
	/** Ajax setup for Batch List* */
	$.ajaxSetup({
		async : false
	});
	$.ajaxSetup ({
	    // Disable caching of AJAX responses
	    cache: false
	});
	$
			.getJSON(
					'fetchInvoiceValueList',
					{
						invoiceAjaxListval : tiListDetail
					},
					function(data) {
						if (data.invoiceAjaxDetails.length) {
							var totalLength = data.invoiceAjaxDetails.length-1; 
							//alert(totalLength);
							$
									.each(
											data.invoiceAjaxDetails,
											function(i, data) {
												
												if (data.masterRef == null) {
													data.masterRef = '';
												}
												if(data.masterRef != '')
													{
												if (data.invNumber == null) {
													data.invNumber = '';
												}
												if (data.disburseDate == null) {
													data.disburseDate = '';
												}
												if (data.dueDate == null) {
													data.dueDate = '';
												}
												if (data.principleOutstanding == null) {
													data.principleOutstanding = '';
												}
												if (data.interestOutstanding == null) {
													data.interestOutstanding = '';
												}
												if (data.chargesOutstanding == null) {
													data.chargesOutstanding = '';
												}
												if (data.penalInterest == null) {
													data.penalInterest = '';
												}
												if (data.outAmount == null) {
													data.outAmount = '';
												}
												if (data.allocAmt == null) {
													data.allocAmt = '';
												}
												if (data.gwStatus == null) {
													data.gwStatus = '';
												}
												if (data.principleTotal == null) {
													data.principleTotal = '';
												}
												if (data.tdsAmount == null) {
													data.tdsAmount = '';
												}
												if (data.tdsTotal == null) {
													data.tdsTotal = '';
												}
												if(data.totalAllocAmount==null){
													data.totalAllocAmount='';
												}
												if(data.counterPartyName==null){
													data.counterPartyName='';
												}
												
												if(i == totalLength){
													var msg_data = "<tr id='tiListDetail1'>"
														+ "<td style='width: 14%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='width: 100%'>"
														+ "<label class='' >Total Outstanding Amount</label>"
														+ "</div></td><td style='width: 9%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='width: 100%'>"
														+ ""
														+ "</td><td style='width: 10%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='width: 100%'>"
														+ ""
														+ "</td>"
														+ "<td style='width: 6%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='width: 100%'>"
														+ ""
														+ "</td><td style='width: 6%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style=''width: 100%'>"
														+ ""
														+ "</td>"
														+ "<td style='width: 7%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.principleTotal
														+ "</label>"
														+ "</td><td style='width: 7%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.interestTotal
														+ "</label>"
														+ "</td>"
														+ "</td><td style='width: 7%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.penalTotal
														+ "</label>"
														+ "</td><td style='width: 7%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.chargesTotal
														+ "</label>"
														+ "</td><td style='width:7%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.tdsTotal
														+ "</label>"
														+ "</td>"
														+ "<td style='width: 8%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.totalOutstanding
														+ "</label>"
														+ "</td>"
														+ "<td style='width: 7%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label id='allocateTotal' >"
														+data.totalAllocAmount
														+ "</label>"
														+ "</td>"
														+ "<td style='width: 4%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='width: 100%'>"
														+ ""
														+ "</td></tr><br />";
												$(msg_data).appendTo("#invoiceList tbody");
												}
												
												var msg_data = "<tr id='tiListDetail'>"
														+ "<td style='width: 14%'><div class='form-group trData' align='center' style='width: 100%'>"
														+ "<input type='text' name='tiListDetail["
														+ i
														+ "].counterPartyName' class='form-control text_box' readonly='true' value=' "
														+ data.counterPartyName
														+ " ' />"
														+ "</div></td><td style='width: 9%'><div class='form-group trData' align='center' style='width: 100%'>"
														+ "<input type='text' name='tiListDetail["
														+ i
														+ "].masterRef' class='form-control text_box' readonly='true' value=' "
														+ data.masterRef
														+ " ' />"
														+ "</div></td><td style='width: 10%'><div class='form-group trData' align='center' style='width: 100%'>"
														+ "<input type='text' name='tiListDetail["
														+ i
														+ "].invNumber' class='form-control text_box' readonly='true' value=' "
														+ data.invNumber
														+ " ' />"
														+ "</td>"
														+ "<td style='width: 6%'><div class='form-group trData' align='center' style='width: 100%'>"
														+ "<input type='text' name='tiListDetail["
														+ i
														+ "].disburseDate' class='form-control text_box' readonly='true' value=' "
														+ data.disburseDate
														+ " ' />"
														+ "</td><td style='width: 6%'><div class='form-group trData' align='center' style=''width: 100%'>"
														+ "<input type='text' class='form-control text_box' name='tiListDetail["
														+ i
														+ "].dueDate' readonly='true' value=' "
														+ data.dueDate
														+ " ' />"
														+ "</td>"
														+ "<td style='width: 7%'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<input type='text' class='form-control text_box' name='tiListDetail["
														+ i
														+ "].principleOutstanding' style='text-align: right' readonly='true' value=' "
														+ data.principleOutstanding
														+ " ' />"
														+ "</td><td style='width: 7%'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<input type='text' class='form-control text_box' name='tiListDetail["
														+ i
														+ "].interestOutstanding' style='text-align: right' readonly='true' value=' "
														+ data.interestOutstanding
														+ " ' />"
														+ "</td>"
														+ "</td><td style='width: 7%'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<input type='text' class='form-control text_box' name='tiListDetail["
														+ i
														+ "].penalInterest' style='text-align: right' readonly='true' value=' "
														+ data.penalInterest
														+ " ' />"
														+ "</td><td style='width: 7%'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<input type='text' class='form-control text_box' name='tiListDetail["
														+ i
														+ "].chargesOutstanding' style='text-align: right' readonly='true' value=' "
														+ data.chargesOutstanding
														+ " ' />"
														+ "</td><td style='width: 7%'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<input type='text' class='form-control text_box' name='tiListDetail["
														+ i
														+ "].tdsAmount' style='text-align: right' readonly='true' value=' "
														+ data.tdsAmount
														+ " ' />"
														+ "</td>"
														+ "<td style='width: 7%'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<input type='text' class='form-control text_box' name='tiListDetail["
														+ i
														+ "].outAmount' style='text-align: right' id='outAmountId"
														+ i
														+ "' readonly='true' value=' "
														+ data.outAmount
														+ " ' />"
														+ "</td>"
														+ "<td style='width: 7%'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<input type='text' class='form-control text_box prcAllcAmt' name='tiListDetail["
														+ i
														+ "].allocAmt' maxlength='20' onchange='rupeesChange(this.id)'  id='alloAmtId"
														+ i
														+ "'  style='text-align: right' value=' "
														+ data.allocAmt
														+ " ' />"
														+ "</td>"
														+ "<td style='width: 4%'><div class='form-group trData' align='center' style='width: 100%'>"
														+ "<input type='text' class='form-control text_box' name='tiListDetail["
														+ i
														+ "].gwStatus' id='gwStatusID"
														+ i
														+ "' readonly='true' value=' "
														+ data.gwStatus
														+ " ' />"
														+ "</td></tr><br />";
												$(msg_data).appendTo("#loadAjaxPage tbody");
													}
											});
							window.stop();
						}
					});
	$('input,a').removeClass('addPageLoad');
	$('input,a').removeClass('removePageLoad');
	$('body').addClass('removePageLoad');
	}
}




function programmeList() {
	// alert("fd");
	$("#formId").attr("action", "programmeList");
	$("#formId").submit();
}

function selectlist(event) {
	var vals = event.split("_");
	var value = vals[1];
	$("#batchId_val").val(value);
	$(".highlight1").removeClass('highlighted');
	$("#" + event).addClass('highlighted');
	$("#invoiceList").find("tr").remove();
	$("#tiListDetail2").remove();
	$('#batchId_val').val(value);
	$('.batchIdVal').val(value);
	$('#batchid_temp').val(value);
	$('#approved').css('display', 'inline');

	/** Ajax setup for Batch List* */
	$.ajaxSetup({
		async : false
	});
	$.ajaxSetup ({
	    // Disable caching of AJAX responses
	    cache: false
	});
	$.getJSON(
					'invoiceDetailList',
					{
						invoiceAjaxListval : value
					},
					function(data) {
						if (data.invoiceAjaxDetails.length) {
							var totalLength = data.invoiceAjaxDetails.length-1; 
							//alert(totalLength);
							$
									.each(
											data.invoiceAjaxDetails,
											function(i, data) {
												if (data.masterRef == null) {
													data.masterRef = '';
												}
												if (data.invNumber == null) {
													data.invNumber = '';
												}
												if (data.disburseDate == null) {
													data.disburseDate = '';
												}
												if (data.dueDate == null) {
													data.dueDate = '';
												}
												if (data.principleOutstanding == null) {
													data.principleOutstanding = '';
												}
												if (data.interestOutstanding == null) {
													data.interestOutstanding = '';
												}
												console.log(data.penalInterest);
												console.log(data);
												if (data.penalInterest == null) {
													data.penalInterest = '';
												}
												if (data.outAmount == null) {
													data.outAmount = '';
												}
												if (data.allocAmt == null) {
													data.allocAmt = '';
												}
												if (data.gwStatus == null) {
													data.gwStatus = '';
												}
												if (data.tdsAmount == null) {
													data.tdsAmount = '';
												}
												if (data.tdsTotal == null) {
													data.tdsTotal = '';
												}
												if(data.totalAllocAmount==null){
													data.totalAllocAmount='';
												}
												if(data.dueDateFilter==null){
													data.dueDateFilter='';
												}
												if(data.counterPartyName==null){
													data.counterPartyName='';
												}
												
												if(i == totalLength){
													var msg_data = "<tr id='tiListDetail2'>"
														+ "<td style='width: 14%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='width: 100%'>"
														+ "<label class='' >Total Outstanding Amount</label>"
														+ "</div></td><td style='width: 9%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='width: 100%'>"
														+ ""
														+ "</td>"
														+ "<td style='width: 10%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='width: 100%'>"
														+ ""
														+ "</td><td style='width: 6%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style=''width: 100%'>"
														+ ""
														+ "</td><td style='width: 6%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style=''width: 100%'>"
														+ ""
														+ "</td>"
														+ "<td style='width: 8%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.principleTotal
														+ "</label>"
														+ "</td><td style='width: 8%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.interestTotal
														+ "</label>"
														+ "</td>"
														+ "</td><td style='width: 8%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.penalTotal
														+ "</label>"
														+ "</td><td style='width: 8%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.chargesTotal
														+ "</label>"
														+ "</td><td style='width: 8%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.tdsTotal
														+ "</label>"
														+ "</td>"
														+ "<td style='width: 8%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label class='' >"
														+ data.totalOutstanding
														+ "</label>"
														+ "</td>"
														+ "<td style='width: 8%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='text-align: right;width: 100%'>"
														+ "<label id='allocateTotal' >"
														+data.totalAllocAmount
														+ "</label>"
														+ "</td>"
														+ "<td style='width: 6%;background-color:#FFF;border:none;'><div class='form-group trData' align='center' style='width: 100%'>"
														+ ""
														+ "</td></tr><br />";
												$(msg_data).appendTo("#invoiceList1 tbody");
												}
												var msg_data = "<tr id='invoiceAjaxDetails'>"
														+ "<td class='grid_alt_heading' style='width: 14%;text-align: left;'>"
														+ data.counterPartyName
														+ "</td><td class='grid_alt_heading' style='width: 9%;text-align: left;'>"
														+ data.masterRef
														+ "</td><td class='grid_alt_heading' style='width: 10%;text-align: left;'>"
														+ data.invNumber
														+ "</td>"
														+ "<td class='grid_alt_heading' style='width: 6%;text-align: left;'>"
														+ data.disburseDate
														+ "</td><td class='grid_alt_heading' style='width: 6%;text-align: left;'>"
														+ data.dueDate
														+ "</td>"
														+ "<td class='grid_alt_heading' style='width: 7%;text-align: right;'>"
														+ data.principleOutstanding
														+ "</td><td class='grid_alt_heading' style='width: 7%;text-align: right;'>"
														+ data.interestOutstanding
														+ "</td>"
														+ "</td><td class='grid_alt_heading' style='width: 7%;text-align: right;'>"
														+ data.penalInterest
														+ "</td><td class='grid_alt_heading' style='width: 7%;text-align: right;'>"
														+ data.chargesOutstanding
														+ "</td><td class='grid_alt_heading' style='width: 7%;text-align: right;'>"
														+ data.tdsAmount
														+ "</td>"
														+ "<td class='grid_alt_heading' style='width: 7%;text-align: right;' align='right' >"
														+ data.outAmount
														+ "</td>"
														+ "<td class='grid_alt_heading' style='width: 7%;text-align: right;' align='right' >"
														+ data.allocAmt
														+ "</td>"
														+ "<td class='grid_alt_heading' style='width: 4%;text-align: left;'>"
														+ data.gwStatus
														+ "</td></tr><br />";
												$(msg_data).appendTo(
														"#invoiceList tbody");
												
												
												
											});
						}
						if (data.invMatchingVO.programmeidentifier == null) {
							data.invMatchingVO.programmeidentifier = '';
						}
						if (data.invMatchingVO.debitParty == null) {
							data.invMatchingVO.debitParty = '';
						}
						if (data.invMatchingVO.debitPartyFullName == null) {
							data.invMatchingVO.debitPartyFullName = '';
						}
						if (data.invMatchingVO.counterParty == null) {
							data.invMatchingVO.counterParty = '';
						}
						if (data.invMatchingVO.repaymentMode == null) {
							data.invMatchingVO.repaymentMode = '';
						}
						if (data.invMatchingVO.payAccount == null) {
							data.invMatchingVO.payAccount = '';
						}
						if (data.invMatchingVO.valueDate == null) {
							data.invMatchingVO.valueDate = '';
						}
						if (data.invMatchingVO.payAmount == null) {
							data.invMatchingVO.payAmount = '';
						}
						if (data.invMatchingVO.allocationType == null) {
							data.invMatchingVO.allocationType = '';
						}
						if (data.invMatchingVO.repaymentAllocationType == null) {
							data.invMatchingVO.repaymentAllocationType = '';
						}
						if (data.invMatchingVO.referenceNumber == null) {
							data.invMatchingVO.referenceNumber = '';
						}
						if (data.invMatchingVO.tempRemarks == null) {
							data.invMatchingVO.tempRemarks = '';
						}
						if (data.invMatchingVO.warningMessage == null) {
							data.invMatchingVO.warningMessage = '';
						}
						//alert('hi'+data.invMatchingVO.warningMessage);
						var res = data.invMatchingVO.warningMessage.split("."); 
						//alert(res.length);
						if(res.length>1)
							{
							var FinalString=res[0]+"<br/>"+res[1];
							document.getElementById("warningMessage").innerHTML="<div style=\"background-color: #FFFF00;font-size:12px;\" >"+FinalString+"</div><div>&nbsp;</div>";
							}
							else
							{
							FinalString="";
							document.getElementById("warningMessage").innerHTML="";
							}
						$('#virtualAccount').val(
						data.invMatchingVO.virtualAccount);
						$('#repaymentTC').val(
								data.invMatchingVO.repaymentTC);
						$('#repayType').val(
								data.invMatchingVO.repayType);
						$('#programmeidentifier').val(
								data.invMatchingVO.programmeidentifier);
						$('#debitParty').val(data.invMatchingVO.debitPartyFullName);
						$('#counterParty').val(data.invMatchingVO.counterParty);
						$('#repaymentMode').val(
								data.invMatchingVO.repaymentMode);
						$('#payAccount').val(data.invMatchingVO.payAccount);
						$('#valueDate').val(data.invMatchingVO.valueDate);
						$('#payAmount').val(data.invMatchingVO.payAmount);
						$('#allocationType').val(
								data.invMatchingVO.allocationType);
						$('#repaymentAllocationType').val(
								data.invMatchingVO.repaymentAllocationType);
						$('#referenceNumber').val(
								data.invMatchingVO.referenceNumber);
						$('#checkerRemarks').val(
								data.invMatchingVO.tempRemarks);
						$('#dueDateFilter').val(
								data.invMatchingVO.dueDateFilter);
					});
}


//04Feb
function selectBatchlist(event) {
	var value = event.split("_");
	var batchID = value[1];
	$("#batchIDSeqId").val(batchID);
	$(".highlight1").removeClass('highlighted');
	$("#" + event).addClass('highlighted');
	$("#invoiceList").find("tr").remove();
	$('body').modal();
	$('body').removeClass('removePageLoad');
	$('input,a').removeClass('removePageLoad');
	$('input,a').addClass('addPageLoad');
	$('body').addClass('addPageLoad');

	$("#formId").attr("action","getPenalValueCheck");
	$("#formId").submit();
}

//11Feb
function selectBulkUploadBatchlistCheck(event) {
	var value = event.split("_");
	var batchID = value[1];
	$("#batchIDSeqId").val(batchID);
	$(".highlight1").removeClass('highlighted');
	$("#" + event).addClass('highlighted');
	$("#invoiceList").find("tr").remove();
	$('body').modal();
	$('body').removeClass('removePageLoad');
	$('input,a').removeClass('removePageLoad');
	$('input,a').addClass('addPageLoad');
	$('body').addClass('addPageLoad');

	$("#formId").attr("action","getBulkUploadValueCheck");
	$("#formId").submit();
}

//04Feb
function selectBatchlistView(event) {
	var value = event.split("_");
	var batchID = value[1];
	$("#batchIDSeqId").val(batchID);
	$(".eventrefresh").removeClass('highlighted');
	$("#" + event).addClass('highlighted');
	$("#invoiceList1 tbody").find("tr").remove();

	/** Ajax setup for Batch List* */
	$.ajaxSetup({
		async : false,
	    // Disable caching of AJAX responses
	    cache: false
	});
	$.getJSON(
		'fetchViewList',
		{
			invoiceAjaxListval : batchID
		},
		function(data) {
			if (data.invoiceAjaxDetails.length) {
				$.each(data.invoiceAjaxDetails,
					function(i, data) {
						if (data.masterRef == null) {
							data.masterRef = '';
						}
						if (data.invNumber == null) {
							data.invNumber = '';
						}
						if (data.disburseDate == null) {
							data.disburseDate = '';
						}
						if (data.dueDate == null) {
							data.dueDate = '';
						}
						if (data.loanAmount == null) {
							data.loanAmount = '';
						}
						if (data.outAmount == null) {
							data.outAmount = '';
						}
						if (data.addInterest == null) {
							data.addInterest = '';
						}
						if (data.addPenal == null) {
							data.addPenal = '';
						}

						var msg_data = "<tr id='invoiceList1' class='embedded' style='overflow-x: auto;'>"
								+ "<td class='form-group trData' style='font-size: 12px;width: 12.5%; text-align: center;'>"
								+ data.masterRef
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 12.5%; text-align: center;'>"
								+ data.invNumber
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 12.5%; text-align: center;'>"
								+ data.disburseDate
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 12.5%; text-align: center;'>"
								+ data.dueDate
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 12.5%; text-align: right;'>"
								+ data.loanAmount
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 12.5%; text-align: right;'>"
								+ data.outAmount
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 12.5%; text-align: right;'>"
								+ data.addInterest
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 12.5%; text-align: right;'>"
								+ data.addPenal
								+ "</td></tr><br />";
						$(msg_data).appendTo(
								"#invoiceList1 tbody");
					});
				}
		});
}


//11Feb
function selectBulkUploadBatchlistView(event) {
	var value = event.split("_");
	var index = value[1];

	var batchID = $('#batchIDSeq'+index).val();
	var status = $('#status'+index).val();

	$("#batchIDSeqId").val(batchID);
	var chargeType = $("#chargeTypeFilterId").val();

	var val = batchID + "_" + status + ":" + chargeType;

	$(".eventrefresh").removeClass('highlighted');
	$("#" + event).addClass('highlighted');
	$("#invoiceList1 tbody").find("tr").remove();

	/** Ajax setup for Batch List* */
	$.ajaxSetup({
		async : false,
	    // Disable caching of AJAX responses
	    cache: false
	});
	$.getJSON(
		'fetchChargesViewList',
		{
			invoiceAjaxListval : val
		},
		function(data) {
			if (data.invoiceAjaxDetails.length) {
				$.each(data.invoiceAjaxDetails,
					function(i, data) {
						if (data.loanMasterRef == null) {
							data.loanMasterRef = '';
						}
						if (data.virtualAccount == null) {
							data.virtualAccount = '';
						}
						if (data.chargeType == null) {
							data.chargeType = '';
						}
						if (data.amount == null) {
							data.amount = '';
						}
						if (data.errorDetails == null) {
							data.errorDetails = '';
						}
						var msg_data = "<tr id='invoiceList1' class='embedded' style='width: 100%; overflow-x: auto;'>"
								+ "<td class='form-group trData' style='font-size: 12px;width: 12.5%;'>"
								+ data.loanMasterRef
								+ "<td class='form-group trData' style='font-size: 12px;width: 12.5%;'>"
								+ data.virtualAccount
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 12.5%;text-align: center;'>"
								+ data.chargeType
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 12.5%;text-align: center;'>"
								+ data.amount
								+ "</td><td class='form-group trData' style='font-size: 12px;width: 50%;'>"
								+ data.errorDetails
								+ "</td></tr><br />";
						$(msg_data).appendTo(
								"#invoiceList1 tbody");
					});
				}
		});
}


function selectlist1(event) {
	$("#sessionKey").val("");
	$('#addSessionId').val("");
	$(".eventrefresh").removeClass("highlighted");
	$(event).addClass('highlighted');
}
function accountSelection() {
	// alert("fd");
	$("#formId").attr("action", "accountSelection");
	$("#formId").submit();
}
function penalAccountSelection() {
	// alert("fd");
	$("#formId").attr("action", "penalAccountSelection");
	$("#formId").submit();
}

//04Feb
function penalAccountSelectionCheck() {
	$("#formId").attr("action", "penalAccountSelectionCheck");
	$("#formId").submit();
}

//04Feb
function penalAccountSelectionView() {
	$("#formId").attr("action", "penalAccountSelectionView");
	$("#formId").submit();
}


//11Feb
function uploadSelectionCheck() {
	$("#formId").attr("action", "uploadSelectionCheck");
	$("#formId").submit();
}

//11Feb
function uploadSelectionView() {
	$("#formId").attr("action", "uploadSelectionView");
	$("#formId").submit();
}
//11Feb
function bulkUploadApprove() {
	$("#formId").attr("action", "bulkUploadApprove");
	$("#formId").submit();
}
//11Feb
function bulkUploadReject() {
	$("#formId").attr("action", "bulkUploadReject");
	$("#formId").submit();
}
//11Feb
function chargeViewList() {
	$('body').modal();
	$('body').removeClass('removePageLoad');
	$('input,a').removeClass('removePageLoad');
	$('input,a').addClass('addPageLoad');
	$('body').addClass('addPageLoad');

	$("#formId").attr("action", "chargeViewList");
	$("#formId").submit();
}


//12Feb
function chargeAccountSelection() {
	$("#formId").attr("action", "chargeAccountSelection");
	$("#formId").submit();
}
//12Feb
function confirmChargeData() {
	$("#formId").attr("action", "confirmChargeData");
	$("#formId").submit();
}

//12Feb
function setChargeCode(id, value) {
	var val = id.split("_");
	var index = val[1];
	$("#chargeCodeId_"+index).val(value);
}


function selectlister(event) {
	$(".eventrefresh").removeClass("highlighted");
	$(event).addClass('highlighted');
}

function selecthighlight(event) {
	$(".eventrefresh").removeClass("highlighted");
	$(event).addClass('highlighted');
}

function getDebitParty() {
	$('#formId').attr('action', 'getDebitParty');
	$('#formId').submit();
	/* var prgID = $('#prg').val(); */
	/*
	 * $('#prgm').val(prgID);
	 * 
	 * $.getJSON("getDebitParty.action"+"?invprogramID="+prgID,function(details) {
	 * updateComboBox(details.getdebitParty, 'debit'); });
	 */
}

function rupeesChange(event) {
	console.log(event);
	var price = $('#' + event).val();
	price = isDigit(price);
	price = price.split("_");
	var currency = price[0];

	if (price[1] != "") {
		var tempPrice = price[1];
		var splitPrice = tempPrice.split(".");
		if (splitPrice[0].length > 13) {
			$('#errorList tbody tr td').remove();
			var list = "";
			var listvalue = '<tr><td style="background-color:#a00000;color:#fff;border:1px solid #fff !important;">Error</td>'
					+ '<td style="background-color:#a00000;color:#fff;border:1px solid #fff !important;">General</td> '
					+ '<td style="background-color:#a00000;color:#fff;border:1px solid #fff !important;">Input</td>'
					+ '<td style="background-color:#a00000;color:#fff;border:1px solid #fff !important;">Limit must have maximum 15 digits only</td> '
					+ '<td style="background-color:#a00000;color:#fff;border:1px solid #fff !important;"></td>'
					+ '</tr>';
			list = list + listvalue;
			$('#availablelimit').val(splitPrice[0]);
			$('#sanctionedlimit').val(splitPrice[0]);
			$('#errorList tbody').append(list);
			
			//1March19
			$('#submit').hide();
			
			return false;
		} else {
			$('#errorList tbody tr td').remove();
			
			//1March19
			$('#submit').show();
		}
	}
	price = price[1];
	var newchar = '';
	currency = currency.replace(/,/g, newchar);

	var removeDot = price.split(".");

	var changedprice  = removeDot[0].replace(/(\d)(?=(\d\d)+\d$)/g, "$1,");
	
	//08-09-2017
	
	if (removeDot[1] == undefined) {
		removeDot[1] = "00";
	}
	if (currency == '') {
		currency = 'INR';
	}
	changedprice = changedprice.split(".");
	changedprice = changedprice[0] + "." + removeDot[1].substr(0, 2);
	$('#' + event).val(changedprice);

	if (changedprice <= 0) {
		$('#' + event).val('0');
		$('#errorList tbody').append(list);
	}
	if(event!="payAmount"){
		var sum = 0;
	    $(".prcAllcAmt").each(function(){
	    	var currentTot =($(this).val());
	    	if (currentTot == undefined) {
	    		currentTot = 0;
	    	}else{
	    		currentTot = currentTot.trim();
	    	}
	    	currentTot = currentTot.replace(/,/g,'');
	    	sum = parseFloat(Math.round(sum * 100) / 100)+parseFloat(Math.round(currentTot * 100) / 100);
	    });
	    $("#allocateTotal").html(sum);
	}
	
}
function isDigit(val) {
	var tempchar = "";
	var tempval = "";
	var result = "";
	for (i = 0; i < val.length; i++) {
		s_charcode = val.charCodeAt(i);
		if (!(s_charcode >= 48 && s_charcode <= 57 || s_charcode == 46)) {
			if (((s_charcode >= 64 && s_charcode <= 90))) {
				tempchar += val.charAt(i);
			}
		} else {
			tempval += val.charAt(i);
		}
	}
	result = tempchar + "_" + tempval;
	return result;
}

function IsAlphaNumeric(e) {
//var e = event.keyCode || event.which;
	var specialKeys = new Array();
    //specialKeys.push(8); //Backspace
    specialKeys.push(9); //Tab
    specialKeys.push(46); //Delete
    specialKeys.push(36); //Home
    specialKeys.push(35); //End
    specialKeys.push(37); //Left
    specialKeys.push(39); //Right
    
        var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
        var ret = ( (keyCode == 32) || (keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122));
        {
        }
        return ret;
}

function custlist(event) {
	var id = $('.highlighted').attr('id');
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	}
	// alert(id);
	var test = id.split('_');
	var val = test[1];
	var test1 = $("#keyvalue_" + val).attr('id');
	var anchor = $("#customername_" + val).attr('id');
	var prgtyp = $("#subtype_" + val).attr('id');

	var value_key1 = $("#" + test1).val();
	var anchor_val = $("#" + anchor).val();
	var prgtypp = $("#" + prgtyp).val();
	$('#prgidentifieer').val($.trim(value_key1));
	$('#anchorParty').val($.trim(anchor_val));
	$('#prgtypp').val($.trim(prgtypp));
	var userRole = $('#userRole').val();
	var RejectList = $('#RejectList').val();
	if (RejectList == undefined || RejectList == null || RejectList == "") {
	if (userRole == undefined || userRole == null || userRole == "") {
		$("#custList").attr("action", "makerlookup");
	} else if (userRole == "checker") {
		$("#custList").attr("action", "checker");
	} else if (userRole == "maker") {
		$("#custList").attr("action", "makerlookup");
	}
	}else{
		$("#custList").attr("action", "rejectedProgramList");
	}
	$("#custList").submit();

}

function accountList(event) {
	var id = $('.highlighted').attr('id');
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	} else {
		$('body').modal();
		$('body').removeClass('removePageLoad');
		$('input,a').removeClass('removePageLoad');
		$('input,a').addClass('addPageLoad');
		$('body').addClass('addPageLoad');
		var test = id.split('_');
		var val = test[1];
		var test1 = $("#key97_" + val).attr('id');
		var value_key1 = $("#" + test1).val();
		$('#payAcc').val($.trim(value_key1));
		
		var test2 = $("#type_" + val).attr('id');
		var value_key2 = $("#" + test2).val();
		$('#prgidentifieer').val($.trim(value_key2));
	
		var test3 = $("#customername_" + val).attr('id');
		var value_key3 = $("#" + test3).val();
		$('#anchorParty').val($.trim(value_key3));
		
		var test4 = $("#subtype_" + val).attr('id');
		var value_key4 = $("#" + test4).val();
		$('#counterParty').val($.trim(value_key4));
		
		
		var test5 = $("#customer_" + val).attr('id');
		var value_key5 = $("#" + test5).val();
		$('#debitPartyFullName').val($.trim(value_key5));
		
		
		var test6 = $("#shortName_" + val).attr('id');
		var value_key6 = $("#" + test6).val();
		$('#prgtypp').val($.trim(value_key6));
		
		$("#custList").attr("action", "accountUp");
		$("#custList").submit();
	}
}
function penalAccountList(event) {
	var id = $('.highlighted').attr('id');
	
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	} else {
		$('body').modal();
		$('body').removeClass('removePageLoad');
		$('input,a').removeClass('removePageLoad');
		$('input,a').addClass('addPageLoad');
		$('body').addClass('addPageLoad');
		var test = id.split('_');
		var val = test[1];
		var test1 = $("#key97_" + val).attr('id');
		var value_key1 = $("#" + test1).val();
		$('#payAcc').val($.trim(value_key1));
		
		var test2 = $("#type_" + val).attr('id');
		var value_key2 = $("#" + test2).val();
		$('#prgidentifieer').val($.trim(value_key2));
		
		var test3 = $("#customername_" + val).attr('id');
		var value_key3 = $("#" + test3).val();
		$('#anchorParty').val($.trim(value_key3));
		
		var test4 = $("#subtype_" + val).attr('id');
		var value_key4 = $("#" + test4).val();
		$('#counterParty').val($.trim(value_key4));
		
		var test5 = $("#customer_" + val).attr('id');
		var value_key5 = $("#" + test5).val();
		$('#debitPartyFullName').val($.trim(value_key5));
		
		var test6 = $("#shortName_" + val).attr('id');
		var value_key6 = $("#" + test6).val();
		$('#prgtypp').val($.trim(value_key6));
		
		$("#custList").attr("action", "penalAccountUp");
		$("#custList").submit();
	}
}
//04Feb
function penalAccountListCheck(event) {
	var id = $('.highlighted').attr('id');
	
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	} else {
		$('body').modal();
		$('body').removeClass('removePageLoad');
		$('input,a').removeClass('removePageLoad');
		$('input,a').addClass('addPageLoad');
		$('body').addClass('addPageLoad');
		var test = id.split('_');
		var val = test[1];
		var test1 = $("#key97_" + val).attr('id');
		var value_key1 = $("#" + test1).val();
		$('#payAcc').val($.trim(value_key1));
		
		var test2 = $("#type_" + val).attr('id');
		var value_key2 = $("#" + test2).val();
		$('#prgidentifieer').val($.trim(value_key2));
		
		var test3 = $("#customername_" + val).attr('id');
		var value_key3 = $("#" + test3).val();
		$('#anchorParty').val($.trim(value_key3));
		
		var test4 = $("#subtype_" + val).attr('id');
		var value_key4 = $("#" + test4).val();
		$('#counterParty').val($.trim(value_key4));
		
		var test5 = $("#customer_" + val).attr('id');
		var value_key5 = $("#" + test5).val();
		$('#debitPartyFullName').val($.trim(value_key5));
		
		var test6 = $("#shortName_" + val).attr('id');
		var value_key6 = $("#" + test6).val();
		$('#prgtypp').val($.trim(value_key6));
		
		$("#custList").attr("action", "penalAccountUpCheck");
		$("#custList").submit();
	}
}
//04Feb
function penalAccountListView(event) {
	var id = $('.highlighted').attr('id');
	
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	} else {
		$('body').modal();
		$('body').removeClass('removePageLoad');
		$('input,a').removeClass('removePageLoad');
		$('input,a').addClass('addPageLoad');
		$('body').addClass('addPageLoad');
		var test = id.split('_');
		var val = test[1];
		var test1 = $("#key97_" + val).attr('id');
		var value_key1 = $("#" + test1).val();
		$('#payAcc').val($.trim(value_key1));
		
		var test2 = $("#type_" + val).attr('id');
		var value_key2 = $("#" + test2).val();
		$('#prgidentifieer').val($.trim(value_key2));
		
		var test3 = $("#customername_" + val).attr('id');
		var value_key3 = $("#" + test3).val();
		$('#anchorParty').val($.trim(value_key3));
		
		var test4 = $("#subtype_" + val).attr('id');
		var value_key4 = $("#" + test4).val();
		$('#counterParty').val($.trim(value_key4));
		
		var test5 = $("#customer_" + val).attr('id');
		var value_key5 = $("#" + test5).val();
		$('#debitPartyFullName').val($.trim(value_key5));
		
		var test6 = $("#shortName_" + val).attr('id');
		var value_key6 = $("#" + test6).val();
		$('#prgtypp').val($.trim(value_key6));

		$("#custList").attr("action", "penalAccountUpView");
		$("#custList").submit();
	}
}
//11Feb
function bulkUploadAccountUpCheck(event) {
	var id = $('.highlighted').attr('id');
	
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	} else {
		$('body').modal();
		$('body').removeClass('removePageLoad');
		$('input,a').removeClass('removePageLoad');
		$('input,a').addClass('addPageLoad');
		$('body').addClass('addPageLoad');
		var test = id.split('_');
		var val = test[1];
		var test1 = $("#key97_" + val).attr('id');
		var value_key1 = $("#" + test1).val();
		$('#payAcc').val($.trim(value_key1));
		
		var test2 = $("#type_" + val).attr('id');
		var value_key2 = $("#" + test2).val();
		$('#prgidentifieer').val($.trim(value_key2));
		
		var test3 = $("#customername_" + val).attr('id');
		var value_key3 = $("#" + test3).val();
		$('#anchorParty').val($.trim(value_key3));
		
		var test4 = $("#subtype_" + val).attr('id');
		var value_key4 = $("#" + test4).val();
		$('#counterParty').val($.trim(value_key4));
		
		var test5 = $("#customer_" + val).attr('id');
		var value_key5 = $("#" + test5).val();
		$('#debitPartyFullName').val($.trim(value_key5));
		
		var test6 = $("#shortName_" + val).attr('id');
		var value_key6 = $("#" + test6).val();
		$('#prgtypp').val($.trim(value_key6));
		
		$("#custList").attr("action", "bulkUploadAccountUpCheck");
		$("#custList").submit();
	}
}
//11Feb
function bulkUploadAccountUpView(event) {
	var id = $('.highlighted').attr('id');
	
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	} else {
		$('body').modal();
		$('body').removeClass('removePageLoad');
		$('input,a').removeClass('removePageLoad');
		$('input,a').addClass('addPageLoad');
		$('body').addClass('addPageLoad');
		var test = id.split('_');
		var val = test[1];
		var test1 = $("#key97_" + val).attr('id');
		var value_key1 = $("#" + test1).val();
		$('#payAcc').val($.trim(value_key1));
		
		var test2 = $("#type_" + val).attr('id');
		var value_key2 = $("#" + test2).val();
		$('#prgidentifieer').val($.trim(value_key2));
		
		var test3 = $("#customername_" + val).attr('id');
		var value_key3 = $("#" + test3).val();
		$('#anchorParty').val($.trim(value_key3));
		
		var test4 = $("#subtype_" + val).attr('id');
		var value_key4 = $("#" + test4).val();
		$('#counterParty').val($.trim(value_key4));
		
		var test5 = $("#customer_" + val).attr('id');
		var value_key5 = $("#" + test5).val();
		$('#debitPartyFullName').val($.trim(value_key5));
		
		var test6 = $("#shortName_" + val).attr('id');
		var value_key6 = $("#" + test6).val();
		$('#prgtypp').val($.trim(value_key6));
		
		$("#custList").attr("action", "bulkUploadAccountUpView");
		$("#custList").submit();
	}
}

//12Feb
function chargeAccountListUp(event) {
	var id = $('.highlighted').attr('id');
	
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	} else {
		$('body').modal();
		$('body').removeClass('removePageLoad');
		$('input,a').removeClass('removePageLoad');
		$('input,a').addClass('addPageLoad');
		$('body').addClass('addPageLoad');
		var test = id.split('_');
		var val = test[1];
		var test1 = $("#key97_" + val).attr('id');
		var value_key1 = $("#" + test1).val();
		$('#payAcc').val($.trim(value_key1));
		
		var test2 = $("#type_" + val).attr('id');
		var value_key2 = $("#" + test2).val();
		$('#prgidentifieer').val($.trim(value_key2));
		
		var test3 = $("#customername_" + val).attr('id');
		var value_key3 = $("#" + test3).val();
		$('#anchorParty').val($.trim(value_key3));
		
		var test4 = $("#subtype_" + val).attr('id');
		var value_key4 = $("#" + test4).val();
		$('#counterParty').val($.trim(value_key4));
		
		var test5 = $("#customer_" + val).attr('id');
		var value_key5 = $("#" + test5).val();
		$('#debitPartyFullName').val($.trim(value_key5));
		
		var test6 = $("#shortName_" + val).attr('id');
		var value_key6 = $("#" + test6).val();
		$('#prgtypp').val($.trim(value_key6));
		
		$("#custList").attr("action", "chargeAccountListUp");
		$("#custList").submit();
	}
}

function custListCancel() {
	var userRole = $('#userRole').val();
	if (userRole == undefined || userRole == null || userRole == "") {
		$("#custList").attr("action", "custListCancelMaker");
	} else if (userRole == "checker") {
		$("#custList").attr("action", "checker");
	} else {
		$("#custList").attr("action", "custListCancelMaker");
	}
	$("#custList").submit();
}

function accountListCancel() {
	$("#custList").attr("action", "accountListCancelMaker");
	$("#custList").submit();
}

/**
 * 
 */
function scfCounterPartyJSON() {
	var id = document.getElementById("counter").value;
	var prg = document.getElementById("prg").value;
	var prgid = document.getElementById("prgid").value;
	$("#loadAjaxPage tbody").find("tr").remove();
	$("#tiListDetail1").remove();
	$('#prg').val("");
	$("#confirmButton").hide();
	$.ajaxSetup({
		async : false
	});
	$.getJSON('fetchAppropriationType', {
		counterPartyValue : id,
		programID : prg
	}, function(data) {
		console.log(data.repAlloType);
		var list;
		if (data.repAlloType == null || data.repAlloType == '') {
			list = "<option value=''><-----></option>";
			list += "<option value='INV'>INV</option>";
			list += "<option value='CIP'>CAIP</option>";
		}
		if (data.repAlloType == 'CAIP') {
			list = "<option value='CIP'>CAIP</option>";
			list += "<option value='INV'>INV</option>";
		}
		if (data.repAlloType == 'INV') {
			list = "<option value='INV'>INV</option>";
			list += "<option value='CIP'>CAIP</option>";
		}

		$('#repaymentAllocationTypeId').html(list);
	});
	
	$.getJSON('fetchRepayBy', {
		counterPartyValue : id,
		programID : prg
	}, function(data) {
		console.log(data.repayBy);
		var list1;
		if (data.repayBy == null || data.repayBy == '') {
			list1 = "<option value=''><-----></option>";
			list1 += "<option value='A'>Anchor</option>";
			list1 += "<option value='C'>Counter party</option>";
		}
		if (data.repayBy == 'C') {
			list1 = "<option value='C'>Counter party</option>";
			list1 += "<option value='A'>Anchor</option>";
		}
		if (data.repayBy == 'A') {
			list1 = "<option value='A'>Anchor</option>";
			list1 += "<option value='C'>Counter party</option>";
		}

		$('#repayById').html(list1);
	});
	$.getJSON('fetchVirtualAccount', {
		counterPartyValue : id,
		programID : prgid
	}, function(data) {
		console.log(data.virtualAccountNo);
		var virtualAcc = data.virtualAccountNo;
		$('#prg').val(virtualAcc);
	});
	
}
//fetchVirtualAccount
// list = "<option value=''><-----></option>";
/*
 * $.each(data, function(key, etype) { list += '<option value="' +
 * data.repaymentAllocationTypeList[key] + '">' +
 * data.repaymentAllocationTypeList[etype] + '</option>'; });
 */
/*
 * var response = []; for (var i = 0; i <
 * data.repaymentAllocationTypeList.length; ++i) { response[i]
 * =data.repaymentAllocationTypeList[i].keyId; list += '<option value="' +
 * data.repaymentAllocationTypeList[i].keyId + '">' +
 * data.repaymentAllocationTypeList[i].keyValue + '</option>'; } if (list ==
 * "") { list = "<option value=''><-----></option>"; }
 * //updateComboBox(data.repaymentAllocationTypeList,
 * 'repaymentAllocationTypeId');
 */

/**
 * 
 */
function updateComboBox(data, id, clas, select) {
	//alert("data" + data);
	//alert("id" + id);
	//alert("clas" + clas);
	//alert("select" + select);
	var list = "";
	if (!select) {
		list = "<option value=''><-----></option>";
	}

	$.each(data, function(key, etype) {
		list += '<option value="' + key + '">' + etype + '</option>';
	});

	if (list == "") {
		list = "<option value=''><-----></option>";
	}
	if (!clas) {
		$('#' + id).html(list);
		$('#' + id).val('MTH');
	} else {
		$('.' + id).html(list);
	}
};

/**
 * 
 */
function bankAccountCancel(){
	$("#bank").attr("action","bankName");
	$("#bank").submit();
}
function bankpageTCSelection(){
	//alert("hi");
	$("#formId").attr("action", "bankpageTC");
	$("#formId").submit();
	
}
function bankTCList(event) {
	var id = $('.highlighted').attr('id');
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	} else {
		$('body').modal();
		$('body').removeClass('removePageLoad');
		$('input,a').removeClass('removePageLoad');
		$('input,a').addClass('addPageLoad'); 
		$('body').addClass('addPageLoad');
		var test = id.split('_');
		var val = test[1];
		var test1 = $("#key97_" + val).attr('id');
		var value_key1 = $("#" + test1).val();
		$('#disbursementBank').val($.trim(value_key1));
		$("#bank").attr("action", "bankTCName");
		$("#bank").submit();
	}
}
function selectlist1(event) {
	$("#sessionKey").val("");
	$('#addSessionId').val("");
	$(".eventrefresh").removeClass("highlighted");
	$(event).addClass('highlighted');
}
/*function bankpageTCSelection(){
	$("#bank").attr("action", "bankpageTC");
	$("#bank").submit();
}
*/
function bankpageSelection(){
	var bank=document.getElementById("branchCode").value;	
	var branchDesc=document.getElementById("branchDesc").value;	
	var transCode=document.getElementById("transCode").value;	
	//alert("branchCode"+bank);
	//alert("bank selection");
	$('#branchCode').val($.trim(bank));
	$('#branchDesc').val($.trim(branchDesc));
	$('#transCode').val($.trim(transCode));
	//$("#branchCode").val(bank)
	$("#bank").attr("action", "bankSelection");
	$("#bank").submit();
}
function bankList(event) {
	var id = $('.highlighted').attr('id');
	if (id == undefined) {
		$('#selectrow').css('display', 'block');
	} else {
		$('body').modal();
		$('body').removeClass('removePageLoad');
		$('input,a').removeClass('removePageLoad');
		$('input,a').addClass('addPageLoad'); 
		$('body').addClass('addPageLoad');
		var test = id.split('_');
		var val = test[1];
		var test1 = $("#key97_" + val).attr('id');
		var value_key1 = $("#" + test1).val();
		$('#disbursementBank').val("HDFC");
		$('#bankList').val($.trim(value_key1));
		$('#transCode').val($.trim(value_key1));

		

		var test2 = $("#type_" + val).attr('id');
		var value_key2 = $("#" + test2).val();
		
		$('#branchCode').val($.trim(value_key2));
		//$('#prgidentifieer').val($.trim(value_key2));
		
		var test3 = $("#customername_" + val).attr('id');
		var value_key3 = $("#" + test3).val();
		//$('#anchorParty').val($.trim(value_key3));
		$('#branchDesc').val($.trim(value_key3));

		
		var test4 = $("#subtype_" + val).attr('id');
		var value_key4 = $("#" + test4).val();
		//$('#counterParty').val($.trim(value_key4));
		
		$("#bank").attr("action", "bankName");
		$("#bank").submit();
	}
}


function scfMode() {
	var id = document.getElementById("scfModeOfRepayment").value;
	$('#payAmount').removeAttr('readonly');
	if (id == "IA") {
		$('#paymentAccountLookup').css('display', 'inline');
		$('#payAccount').val("");
	} else {
		$('#paymentAccountLookup').css('display', 'none');
		if (id == "RT" || id == "NT" || id == "CH" || id == "CQ" ) {
			$.ajaxSetup({
				async : false
			});
			$.getJSON('fetchRepaymentMode', {
				paymentAmount : id
			}, function(data) {
				$('#payAccount').val(data.accountNumber);
			});
		} else if(id == "EX"  ||id == "AD"){ //mal-221 added AD
			$.ajaxSetup({
				async : false
			});
			$.ajaxSetup ({
			    // Disable caching of AJAX responses
			    cache: false
			});
			var program = document.getElementById("prgid").value;
			var anchor = document.getElementById("debit").value;
			var cparty = document.getElementById("counter").value;
			$.getJSON('fetchRepaymentMode', {
				paymentAmount : id,
				programme : program,
				anchor : anchor,
				cparty : cparty
			}, function(data) {
				console.log(data);
				$('#payAccount').val(data.accountNumber);
				$('#payAmount').val(data.excessAmount);
				rupeesChange('payAmount');
				$('#payAmount').attr('readonly','readonly');
			});
		} else if(id == "SD"){
			$.ajaxSetup({
				async : false
			});
			$.ajaxSetup ({
			    // Disable caching of AJAX responses
			    cache: false
			});
			var program = document.getElementById("prgid").value;
			var anchor = document.getElementById("debit").value;
			var cparty = document.getElementById("counter").value;
			$.getJSON('fetchRepaymentMode', {
				paymentAmount : id,
				programme : program,
				anchor : anchor,
				cparty : cparty
			}, function(data) {
				console.log(data);
				$('#payAccount').val(data.accountNumber);
				$('#payAmount').val(data.excessAmount);
				rupeesChange('payAmount');
				$('#payAmount').attr('readonly',false);
			});
		}else{
			$('#payAccount').val("");
		}
	}

}


