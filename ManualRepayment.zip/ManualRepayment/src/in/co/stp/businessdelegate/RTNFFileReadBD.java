package in.co.stp.businessdelegate;

import java.util.ArrayList;

import in.co.invoice.businessdelegate.BaseBusinessDelegate;
import in.co.invoice.businessdelegate.exception.BusinessException;
import in.co.invoice.dao.RTNFFileReadDAO;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.vo.FileReadVO;

import org.apache.log4j.Logger;

public class RTNFFileReadBD extends BaseBusinessDelegate{

	private static Logger logger = Logger.getLogger(RTNFFileReadBD.class
			.getName());
	static RTNFFileReadBD bd;

	public static RTNFFileReadBD getBD() {
		if (bd == null) {
			bd = new RTNFFileReadBD();
		}
		return bd;
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @throws BusinessException
	 */
	public ArrayList<FileReadVO> fetchRepayList(String batchID)
			throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		RTNFFileReadDAO dao = null;
		ArrayList<FileReadVO> repayList = new ArrayList<FileReadVO>();
		try {
			dao = RTNFFileReadDAO.getDAO();
			repayList = dao.fetchRepayList(batchID);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return repayList;
	}
	
	/**
	 * 
	 * @param invMatchingVO
	 * @throws BusinessException 
	 */
	public String postingCall() throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		RTNFFileReadDAO dao = null;
		String result = null;
		try {
			dao = RTNFFileReadDAO.getDAO();
			result = dao.postingCall(); 
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return result;
	}
}
