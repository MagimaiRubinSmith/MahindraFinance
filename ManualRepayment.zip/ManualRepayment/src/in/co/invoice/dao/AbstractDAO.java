package in.co.invoice.dao;

import in.co.invoice.dao.exception.DAOException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.ActionConstantsQuery;
import in.co.invoice.utility.LogHelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class AbstractDAO {
	private static Logger logger = Logger
			.getLogger(AbstractDAO.class.getName());

	protected static DataSource dataSource = null;
	public boolean logDebug = false;
	
	/*protected String userName = "root";
	protected String password = "";
	//String dbName = "myshare_retailer";
	String dbName = "demohab_myshare_feb_2014";
	protected String url = "jdbc:mysql://localhost:3306/" + dbName;
	 */
	

	/**
	 * This method is used to get the connection object from DataSource and
	 * return the connection back to the caller method.
	 * 
	 * @return Connection
	 * @throws Exception
	 */
/*	protected Connection getConnection() throws Exception {
		logger.debug(ActionConstants.ENTERING_METHOD);
		Connection conn = null;

		// Remote
		
		 * String userName = "demohab_myshare"; String password =
		 * "mysharedemo123"; String dbName = "demohab_myshare"; String url =
		 * "jdbc:mysql://localhost:3306/" + dbName;
		 

		// Localhost
		String userName = "root";
		String password = "";
		//String dbName = "myshare_retailer";
		String dbName = "demohab_myshare_feb_2014";
		String userName = "demohab_myshareb";
		String password = "myshareindia123$";
		//String dbName = "myshare_retailer";
		String dbName = "demohab_myshare80g";
		String url = "jdbc:mysql://localhost:3306/" + dbName;
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		conn = DriverManager.getConnection(url, userName, password);
		conn = getDataSource().getConnection();
		logger.debug(ActionConstants.EXITING_METHOD);
		return conn;
	}*/
	
	protected Connection getConnection() throws Exception {
		logger.debug(ActionConstants.ENTERING_METHOD);
		Connection conn = null;
		String userName = ActionConstantsQuery.userName;
		String password = ActionConstantsQuery.password;;
		//String dbName = ActionConstantsQuery.dbName;
		
		//String userName = "root";
		/*String password = "myshareindia123$";
		String dbName = "myshare_bo_new";*/
		
		/*String userName = "demohab_myshrshp";
		String password = "$FJ+WQG2=y#@";
		String dbName = "demohab_myshareshop";*/
		//String url = "jdbc:mysql://localhost:3308/" + dbName;
		/*String url = "jdbc:mysql://180.179.207.206:3308/" + dbName;*/
		String url = ActionConstantsQuery.url;
		Class.forName(ActionConstantsQuery.driver).newInstance();
		conn = DriverManager.getConnection(url, userName, password);
		
		//conn = getDataSource().getConnection();
		
		logger.debug(ActionConstants.EXITING_METHOD);
		return conn;
	}

	/*
	 * Localhost protected Connection getConnection() throws Exception {
	 * logger.debug(ActionConstants.ENTERING_METHOD); Connection conn = null;
	 * String userName = "root"; String password = ""; String dbName="myshare";
	 * String url = "jdbc:mysql://jeyasithar:3306/"+dbName; Class.forName
	 * ("com.mysql.jdbc.Driver").newInstance (); conn =
	 * DriverManager.getConnection (url, userName, password);
	 * logger.debug(ActionConstants.EXITING_METHOD); return conn; }
	 */

	/**
	 * This helper method is used to close the connection object and frees the
	 * object.
	 * 
	 * @param myConnection
	 */
	public void closeConnection(Connection myConnection) {
		try {
			if (null != myConnection) {
				myConnection.close();
			}
		} catch (Exception excepConnection) {
			logger.error(excepConnection.fillInStackTrace());
		}
	}

	/**
	 * This helper method is used to close PreparedStatement object.
	 * 
	 * @param preparedStatement
	 */
	public void closePreparedStatement(PreparedStatement preparedStatement) {
		try {
			if (null != preparedStatement) {
				preparedStatement.close();
			}
		} catch (Exception excepConnection) {
			logger.error(excepConnection.fillInStackTrace());
		}
	}

	/**
	 * This helper method is used to close ResultSet object.
	 * 
	 * @param resultSet
	 */
	public void closeResultSet(ResultSet resultSet) {
		try {
			if (null != resultSet) {
				resultSet.close();
			}
		} catch (Exception excepConnection) {
			logger.error(excepConnection.fillInStackTrace());
		}
	}

	/**
	 * This helper method is used to close Statement object.
	 * 
	 * @param statement
	 */
	public void closeStatement(Statement statement) {
		try {
			if (null != statement) {
				statement.close();
			}
		} catch (Exception excepConnection) {
			logger.error(excepConnection.fillInStackTrace());
		}
	}


	/**
	 * This helper method is used to catch the Exceptions from DAO classes &
	 * throw it to DAOException class.
	 * 
	 * @param exception
	 * @throws DAOException
	 */
	public void throwDAOException(Exception exception) throws DAOException {
		logger.error(exception.fillInStackTrace());
		LogHelper.logError(logger, exception);
		throw new DAOException(exception.getMessage());
	}

	/**
	 * This overloaded method is used to close the LoggableStatement and
	 * connection objects.
	 * 
	 * @param result
	 * @param loggableStatement
	 * @param connection
	 */
	public void closeSqlRefferance(PreparedStatement preparedStatement,
			Connection connection) {
		closePreparedStatement(preparedStatement);
		closeConnection(connection);
	}

	/**
	 * This method is used to close the resultSet, LoggableStatement and
	 * connection objects.
	 * 
	 * @param result
	 * @param loggableStatement
	 * @param connection
	 */
	public void closeSqlRefferance(ResultSet result,
			PreparedStatement preparedStatement, Connection connection) {
		closeResultSet(result);
		closePreparedStatement(preparedStatement);
		closeConnection(connection);
	}
	
	

}