package in.co.invoice.dao;

import in.co.invoice.dao.exception.DAOException;
import in.co.invoice.rtnf.FileDataRecordVO;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.ActionConstantsQuery;
import in.co.invoice.utility.CommonMethods;
import in.co.invoice.utility.DBConnectionUtility;
import in.co.invoice.utility.LoggableStatement;
import in.co.invoice.utility.PostingXMLGenerationSample;
import in.co.invoice.utility.WorkerThread;
import in.co.invoice.vo.BuyerFinanceVO;

import java.rmi.RemoteException;
import java.rmi.dgc.VMID;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;

import org.apache.log4j.Logger;
import org.aspectj.weaver.patterns.ThrowsPattern;

import com.bs.theme.migration.loader.data.handler.TFattdtoHandler;
import com.bs.theme.migration.loader.tiplus.pojos.TiattdocExtra;
import com.bs.theme.migration.loader.utility.MessageUtil;
/*import com.bs.themebridge.server.gateway.in.BridgeGateway;
 import com.bs.themebridge.server.gateway.in.BridgeGatewayImplService;

 import in.co.invoice.utility.BridgeGatewayImplServiceStub;
 import in.co.invoice.utility.BridgeGatewayImplServiceCallbackHandler;
 import in.co.invoice.utility.BridgeGatewayImplServiceStub.ProcessResponse;

 */
import com.misys.tiplus2.apps.ti.service.messages.EQ3Posting;
import com.misys.tiplus2.services.control.ServiceRequest;

/**
 * 
 * @author Habile
 * 
 */
public class STPProcessDAO extends AbstractDAO implements ActionConstantsQuery,
		ActionConstants {

	static STPProcessDAO dao;

	private static Logger logger = Logger.getLogger(STPProcessDAO.class
			.getName());
	ArrayList<FileDataRecordVO> rowList = null;

	/**
	 * 
	 * @return
	 */
	public static STPProcessDAO getDAO() {
		if (dao == null) {
			dao = new STPProcessDAO();
		}
		return dao;
	}

	public String fetch_invoices(String batchID, String payAccount)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String userTeam = null;

		ArrayList<BuyerFinanceVO> list = null;
		ArrayList<TiattdocExtra> invoiceList = null;

		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			list = new ArrayList<BuyerFinanceVO>();
			ps = new LoggableStatement(
					con,
					"SELECT * FROM ETT_STP_REPAYMENT WHERE BATCH_ID=? AND GW_STATUS IS NULL ORDER BY LOAN_MASTER_REF");
			ps.setString(1, batchID);
			rs = ps.executeQuery();

			while (rs.next()) {
				BuyerFinanceVO financevo = new BuyerFinanceVO();
				if (!rs.getString(PRC_ALLC_AMOUNT).equalsIgnoreCase("0")) {
					financevo.setInvoiceNo(rs.getString(INVOICE_NO));
					// financevo.setInvoiceAmount(rs.getString(INVOICE_AMT));
					financevo.setBatchID(rs.getString(BATCH_ID));
					financevo.setMasterRefKey(rs.getString(MASTER_REF_KEY));
					list.add(financevo);
				}
			}
			if (null != list && list.size() > 0) {
				invoiceList = transferBuyerVO(list, batchID);
				// mulitthread
				dao.threadFinancePoolRun(invoiceList, userName, batchID, con);
				// mulitthread
				// processSTPBuyerFinance(invoiceList, userName, USERTEAM_VAL,
				// "", "", batchID);
				callInvoiceApprovalProcess(batchID, payAccount, con);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs,ps,con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userTeam;
	}

	// mulitthread

	public void threadFinancePoolRun(
			final ArrayList<TiattdocExtra> financeList, final String userTeam,
			final String batchID, Connection con) throws InterruptedException,
			SQLException {

		if (null != financeList) {
			final int len = financeList.size();
			ExecutorService executor = Executors.newFixedThreadPool(5);
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			for (int i = 0; i < len;) {
				int m = i - len;
				System.out.println("length1 --->" + m);
				final ArrayList<TiattdocExtra> financeFinalList = new ArrayList<TiattdocExtra>();
				if (len >= 5 && len - i >= 5) {
					for (int k = 0; k < 5; k++) {
						financeFinalList.add(financeList.get(i + k));
						System.out.println("Finance Invoice No1:-------->count"
								+ len);
						System.out.println("Finance List No1:-------->count"
								+ financeFinalList.size());
					}
					i += 5;
				} else {
					int n = len - i;
					int p = 1;
					for (int k = 0; k < n; k++) {
						System.out.println("Finance Invoice No1:-------->count"
								+ len);
						System.out.println("Finance List No1:-------->count"
								+ financeFinalList.size());
						financeFinalList.add(financeList.get(i + k));
						p = k;
					}
					i = i + p + 1;
				}

				ServiceRequest serReq = MessageUtil.getServiceRequest("TIBulk",
						"Item", "SUPERVISOR", "FULL", "N", "N",
						new VMID().toString());
				Runnable worker = new WorkerThread(financeFinalList, batchID,
						con, serReq);
				executor.execute(worker);
			}
			executor.shutdown();
			while (!executor.isTerminated()) {
			}

		}
	}

	// mulitthread

	public void callInvoiceApprovalProcess(String batchId, String payAccount,
			Connection con) throws Exception {

		// Connection con = null;
		CallableStatement callableStatement = null;
		CallableStatement callableStatement1 = null;

		System.out.println("Entering Approval");

		String InvoiceApprovalPROC = "{call ETT_REPAY_EVT_STAT_PROC(?)}";
		String InvoiceApprovalPROC1 = "{call ETT_REPAY_UPDATE_PROC(?,?)}";

		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			callableStatement = con.prepareCall(InvoiceApprovalPROC);
			callableStatement.setString(1, batchId);
			callableStatement.executeUpdate();

			System.out.println("Passing values are -------------batchId->"
					+ batchId);
			System.out.println("Passing values are -------------payAccount->"
					+ payAccount);

			callableStatement1 = con.prepareCall(InvoiceApprovalPROC1);
			callableStatement1.setString(1, batchId);
			callableStatement1.setString(2, payAccount);
			callableStatement1.executeUpdate();

			System.out.println(" InvoiceApproval completed");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderStatement(null, callableStatement);
			closePreparedStatement(callableStatement1);
		}

	}

	// multithread

	@SuppressWarnings("unused")
	public void processSTPBuyerFinance(ArrayList<TiattdocExtra> invoiceList,
			String userName, String userTeam, String product,
			String financeFlag, String Batchid, ServiceRequest serReq)
			throws Exception {
		CommonMethods comm = new CommonMethods();
		Connection con = null;
		int ejbCount = 0;
		if (null != invoiceList) {
			int size = invoiceList.size();
			ArrayList<TiattdocExtra> temp = new ArrayList<TiattdocExtra>();
			temp = invoiceList;
			String xmlToPost = null;
			List<ServiceRequest> sRequestItems = new ArrayList<ServiceRequest>();
			TFattdtoHandler tfatt = new TFattdtoHandler();
			sRequestItems = tfatt.createTFattdtoRequestBulk(temp);
			xmlToPost = MessageUtil.xmlBulkServiceRequest(sRequestItems,
					"TFATTDOC", userName);
			System.out.println("xmlToPost" + xmlToPost);
			String lowRange = getSequenceAPISERVER(con) + "";
			// String lowRange=getSequenceAPISERVER1()+"";
			pushToAPISERVERBFIN(xmlToPost, lowRange, con);
			updateSquenceNumber(temp, lowRange, Batchid, con);

			String response = comm.fetchEJBResponse(xmlToPost);
			if (response != null) {
				String ejbStatus = comm
						.updateAPISERVER(response, lowRange, con);
				if (ejbStatus != null && ejbStatus.equalsIgnoreCase("FAILED")) {
					ejbCount = ejbCount + 1;
				}
			}

		}
		if (con != null) {
			con.close();
		}
	}

	// multithread

	/*
	 * public void processSTPBuyerFinance(ArrayList<TiattdocExtra>
	 * invoiceList,String userName,String userTeam,String product,String
	 * financeFlag, String Batchid) throws Exception { CommonMethods comm = new
	 * CommonMethods(); int ejbCount = 0; if(null != invoiceList){ int size =
	 * invoiceList.size(); for(int i=0;i<size;i++){ ArrayList<TiattdocExtra>
	 * temp = new ArrayList<TiattdocExtra>(); temp.add(invoiceList.get(i));
	 * String xmlToPost = null; List<ServiceRequest> sRequestItems = new
	 * ArrayList<ServiceRequest>(); TFattdtoHandler tfatt = new
	 * TFattdtoHandler(); sRequestItems.add(tfatt .createTFattdtoRequest(temp));
	 * xmlToPost = MessageUtil.xmlServiceRequest( sRequestItems, "TFATTDOC",
	 * userName); String lowRange=getSequenceAPISERVER()+""; //String
	 * lowRange=getSequenceAPISERVER1()+"";
	 * pushToAPISERVERBFIN(xmlToPost,lowRange);
	 * updateSquenceNumber(temp.get(0).getTheirreference(),lowRange, Batchid);
	 * 
	 * String response = comm.fetchEJBResponse(xmlToPost); if( response!=null ){
	 * String ejbStatus = comm.updateAPISERVER(response,lowRange); if (ejbStatus
	 * !=null && ejbStatus.equalsIgnoreCase("FAILED")) { ejbCount = ejbCount +
	 * 1; } } Thread.sleep(1000*20); } Thread.sleep(1000*120); boolean remain =
	 * false; while (remain == false) {
	 * System.out.println("Inside Finance While Loop"); remain =
	 * isFINAPISucceed(Batchid); Thread.sleep(1000 * 5); } } }
	 */
	/**
	 * 
	 * @param reference
	 * @param lowRange
	 * @param Batchid
	 * @return
	 * @throws DAOException
	 */

	// multtithread

	public String updateSquenceNumber(ArrayList<TiattdocExtra> temp,
			String lowRange, String Batchid, Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String branch = null;
		String insert_apiserver = "";
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			insert_apiserver = "UPDATE ETT_STP_REPAYMENT SET APISERVER_SEQ_NO='"
					+ lowRange
					+ "' ,GW_STATUS='W' WHERE BATCH_ID="
					+ Batchid
					+ "  AND LOAN_MASTER_REF IN ";
			if (temp != null && temp.size() > 0) {
				String reference = "";
				for (int i = 0; i < temp.size(); i++) {
					if (i == 0) {
						reference = reference + "?";
					} else {
						reference = reference + ",?";
					}
				}
				insert_apiserver = insert_apiserver + "(" + reference + ")";
			}

			// String insert_apiserver =
			// "UPDATE ETT_STP_REPAYMENT SET APISERVER_SEQ_NO='"+lowRange+"' ,GW_STATUS='W' WHERE LOAN_MASTER_REF='"+reference+"'  AND BATCH_ID="+Batchid;

			System.out.println("api query=============>" + insert_apiserver);
			ps = new LoggableStatement(con, insert_apiserver);
			for (int i = 1; i <= temp.size(); i++) {
				ps.setString(i, temp.get(i - 1).getTheirreference());
			}
			System.out.println("api query=============>" + ps.getQueryString());
			ps.executeUpdate();
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return branch;
	}

	// multtithread
	/*
	 * public String updateSquenceNumber(ArrayList<TiattdocExtra> temp,String
	 * lowRange, String Batchid) throws DAOException {
	 * logger.info(ActionConstants.ENTERING_METHOD); Connection con = null;
	 * ResultSet rs = null; LoggableStatement ps = null; String branch = null;
	 * try { if(con==null){ con = DBConnectionUtility.getConnection(); } String
	 * insert_apiserver =
	 * "UPDATE ETT_STP_REPAYMENT SET APISERVER_SEQ_NO='"+lowRange
	 * +"' ,GW_STATUS='W' WHERE LOAN_MASTER_REF='"
	 * +reference+"' AND BATCH_ID="+Batchid; ps = new LoggableStatement(con,
	 * insert_apiserver); ps.executeUpdate(); } catch (Exception exception) {
	 * throwDAOException(exception); } finally {
	 * DBConnectionUtility.surrenderDB(rs, ps, con); }
	 * logger.info(ActionConstants.EXITING_METHOD); return branch; }
	 */
	// multtithread
	/**
	 * 
	 * @param batchId
	 * @return
	 * @throws DAOException
	 */
	public boolean isFINAPISucceed(String batchId) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ResultSet rs = null;
		LoggableStatement ps = null;
		boolean isActive = false;
		int count = 1;
		Connection con = null;
		try {
			if (null == con) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "SELECT COUNT(*)  AS COUNT FROM ETT_CLF_APISERVER API, ETT_STP_REPAYMENT ESI WHERE SERVICE='TI' "
					+ "AND OPERATION='TFATTDOC' AND API.STATUS='WAITING' AND API.SEQUENCE=TRIM(ESI.APISERVER_SEQ_NO) AND TRIM(ESI.BATCH_ID)='"
					+ batchId + "'";
			ps = new LoggableStatement(con, query);
			// ps.setString(1, batchId);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				count = rs.getInt("COUNT");
				if (count == 0) {
					isActive = true;
				}
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return isActive;
	}

	/*
	 * public String pushToAPISERVERBFIN(String xmlToPost,String lowRange)
	 * throws DAOException { logger.info(ActionConstants.ENTERING_METHOD);
	 * Connection con = null; ResultSet rs = null; LoggableStatement ps = null;
	 * String branch = null;
	 * 
	 * try { con = DBConnectionUtility.getConnection(); String insert_apiserver
	 * =
	 * "insert into apiserver(SEQUENCE,VERSION,SERVICE,OPERATION,REQUEST,STATUS)"
	 * +
	 * " VALUES('"+lowRange+"',SYSDATE,'TI','TFATTDOC','"+xmlToPost+"','WAITING')"
	 * ; ps = new LoggableStatement(con, insert_apiserver); ps.executeUpdate();
	 * 
	 * 
	 * } catch (Exception exception) { throwDAOException(exception); } finally {
	 * DBConnectionUtility.surrenderDB(con, ps, rs); }
	 * logger.info(ActionConstants.EXITING_METHOD); return branch; }
	 */

	/**
	 * old API
	 * 
	 * @param xmlToPost
	 * @param lowRange
	 * @return
	 * @throws DAOException
	 */
	// public String pushToAPISERVERBFIN(String xmlToPost,String lowRange)
	// throws DAOException {
	// logger.info(ActionConstants.ENTERING_METHOD);
	// Connection con = null;
	// ResultSet rs = null;
	// LoggableStatement ps = null;
	// try {
	// if(con==null){ con = DBConnectionUtility.getConnection(); }
	// String insert_apiserver =
	// "insert into ett_clf_apiserver(SEQUENCE,VERSION,SERVICE,OPERATION,REQUEST,STATUS)"
	// +
	// " VALUES('"+lowRange+"',SYSDATE,'TI','TFATTDOC','"+xmlToPost+"','WAITING')";
	// ps = new LoggableStatement(con, insert_apiserver);
	// ps.executeUpdate();
	// } catch (Exception exception) {
	// throwDAOException(exception);
	// } finally {
	// DBConnectionUtility.surrenderDB(rs, ps, con);
	// }
	// logger.info(ActionConstants.EXITING_METHOD);
	// return xmlToPost;
	// }

	// thread
	public String pushToAPISERVERBFIN(String xmlToPost, String lowRange,
			Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String insert_apiserver = "insert into ett_clf_apiserver(SEQUENCE,VERSION,SERVICE,OPERATION,REQUEST,STATUS)"
					+ " VALUES('"
					+ lowRange
					+ "',SYSDATE,'TI','TFATTDOC',?,'WAITING')";
			ps = new LoggableStatement(con, insert_apiserver);
			ps.setString(1, xmlToPost);
			ps.executeUpdate();
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlToPost;
	}

	// thread

	/*
	 * private int getSequenceAPISERVER() throws DAOException {
	 * logger.info(ActionConstants.ENTERING_METHOD); Connection con = null;
	 * ResultSet rs = null; LoggableStatement ps = null; int sequenceNumber =
	 * 666666; try { con = DBConnectionUtility.getConnection(); ps = new
	 * LoggableStatement(con, "select max(to_number(SEQUENCE)) from APISERVER");
	 * rs = ps.executeQuery(); if (rs.next()) { sequenceNumber=rs.getInt(1); }
	 * 
	 * sequenceNumber++; } catch (Exception exception) {
	 * throwDAOException(exception); } finally {
	 * DBConnectionUtility.surrenderDB(con, ps, rs); }
	 * logger.info(ActionConstants.EXITING_METHOD); return sequenceNumber; }
	 */

	/**
	 * 
	 * @return
	 * @throws DAOException
	 */
	public int getSequenceAPISERVER(Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		int sequenceNumber = 0;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT ETT_CLF_APISERVER_SEQ.NEXTVAL FROM DUAL");
			rs = ps.executeQuery();
			if (rs.next()) {
				sequenceNumber = rs.getInt(1);
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return sequenceNumber;
	}

	private ArrayList<TiattdocExtra> transferBuyerVO(
			ArrayList<BuyerFinanceVO> BuyerList, String batchID)
			throws DAOException {
		TiattdocExtra docExtra = null;
		ArrayList<TiattdocExtra> list = null;

		try {
			list = new ArrayList<TiattdocExtra>();

			if (null != BuyerList) {
				int size = BuyerList.size();
				for (int i = 0; i < size; i++) {
					BuyerFinanceVO temp = BuyerList.get(i);
					docExtra = new TiattdocExtra();
					String[] branches = getBuyerBranch(temp.getMasterRefKey());
					docExtra.setBranch(branches[0]);
					docExtra.setBehalfofbranch(branches[1]);
					docExtra.setTeam("Hub");

					String programeType = getProgrameType(temp
							.getMasterRefKey());
					String eventType = "";
					if (null != programeType
							&& programeType.equalsIgnoreCase("IRF")) {
						eventType = "IRRF";
					} else {
						eventType = "IDRF";
					}
					docExtra.setProduct(programeType);
					docExtra.setCustomer(getDebitParty(temp.getMasterRefKey()));
					docExtra.setEvent(eventType);
					docExtra.setTheirreference(temp.getMasterRefKey());

					list.add(docExtra);
				}

			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {

		}
		logger.info(ActionConstants.EXITING_METHOD);
		return list;

	}

	public String[] getBuyerBranch(String MasterRefey) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String[] branch = new String[2];
		int input = 0;
		int behalf = 0;
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String getCount = "select INPUT_BRN,BHALF_BRN from MASTER WHERE MASTER_REF='"
					+ MasterRefey + "' ";
			ps = new LoggableStatement(con, getCount);
			rs = ps.executeQuery();
			System.out.println("get count " + getCount);
			rs.next();
			branch[0] = rs.getString("INPUT_BRN");
			branch[1] = rs.getString("BHALF_BRN");
			System.out.println("Input Branch : " + input);
			System.out.println("Behalf of Branch : " + behalf);
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return branch;
	}

	public String getDebitParty(String MasterRefey) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String debitParty = null;
		int input = 0;
		int behalf = 0;
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String getCount = "select mas_pricustmnm from  FIN_BASE_VIEW where MAS_master_ref = '"
					+ MasterRefey + "' ";
			ps = new LoggableStatement(con, getCount);
			rs = ps.executeQuery();

			if (rs.next()) {
				debitParty = rs.getString("mas_pricustmnm");
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return debitParty;
	}

	public String getProgrameType(String MasterRefey) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String debitParty = null;

		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String getCount = "SELECT REFNO_PFIX FROM MASTER WHERE MASTER_REF= '"
					+ MasterRefey + "' ";
			ps = new LoggableStatement(con, getCount);
			System.out.println("Executing Query" + ps.getQueryString());
			rs = ps.executeQuery();

			if (rs.next()) {
				debitParty = rs.getString("REFNO_PFIX");
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return debitParty;
	}

	/**
	 * 
	 * @return
	 */
	private static String generateRandomNumber() {
		int randomPIN = (int) (Math.random() * 9000) + 1000;
		String PINString = String.valueOf(randomPIN);
		return PINString;

	}

	public static void main(String args[]) throws Exception {
		Connection con = null;
		try {
		dao = STPProcessDAO.getDAO();
		dao.callInvoiceApprovalProcess("8627", "17910", con);
		}
		//Connection Leak
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		//Connection Leak

	}

	/**
	 * 
	 * @param batchID
	 * @return
	 * @throws DAOException
	 */
	/*
	 * public String fetch_postings(String batchID) throws DAOException {
	 * logger.info(ActionConstants.ENTERING_METHOD); Connection con = null;
	 * ResultSet rs = null; LoggableStatement ps = null; ResultSet rs1 = null;
	 * LoggableStatement ps1 = null; String userTeam = null; CommonMethods comm=
	 * null; ArrayList<EQ3Posting> list = null; ArrayList<String> seqList =
	 * null; ArrayList<TFBuyFin> financeList = null; try { if(con==null){ con =
	 * DBConnectionUtility.getConnection(); } comm = new CommonMethods();
	 * seqList = getPostingSeqNumbers(batchID);
	 * 
	 * if (null != seqList ) { int size = seqList.size(); financeList = new
	 * ArrayList<TFBuyFin>(); for(int i=0;i<size;i++){ list = new
	 * ArrayList<EQ3Posting>(); ps = new LoggableStatement(con,
	 * "SELECT APISERVERSEQNO,MASTERKEY,EVENTKEY,POSTINGBRANCH,INPUTBRANCH,PRODUCTREFERENCE,MASTERREFERENCE,EVENTREFERENCE,"
	 * +
	 * "INTERNALRECNREF,POSTINGSEQNO,ACCOUNTNUMBER,BACKOFFICEACCOUNTNO,EXTERNALACCOUNTNO,CUSTOMERMNEMONIC,ACCOUNTTYPE,"
	 * +
	 * "SPSKMNEMONIC,SPSKCATEGORYCODE,APPLICATION,DEBITCREDITFLAG,TRANSACTIONCODE,POSTINGAMOUNT,POSTINGCCY,"
	 * +
	 * "TO_CHAR(TO_DATE(VALUEDATE, 'dd-mm-yy'),'yyyy-MM-dd') AS VALUEDATE,RELATEDPARTY,BENEFICIARYNAME,ISSUEORCONTRACTDATE,BANKCODE1,SETTLEMENTACCOUNTUSED,ADDMNTDELFLAG    "
	 * + "FROM ETT_REPAY_POST WHERE BATCHNO='"+batchID+
	 * "' AND TRIM(MASTERREFERENCE) = '"+seqList.get(i)+"'");
	 * System.out.println("Executing Query"+ps.getQueryString()); rs =
	 * ps.executeQuery(); while (rs.next()) { EQ3Posting eq3Posting = new
	 * EQ3Posting();
	 * eq3Posting.setTransactionSeqNo(rs.getInt("APISERVERSEQNO"));
	 * eq3Posting.setMasterKey(rs.getLong("MASTERKEY"));
	 * eq3Posting.setEventKey(rs.getLong("EVENTKEY"));
	 * eq3Posting.setPostingBranch(rs.getString("POSTINGBRANCH"));
	 * eq3Posting.setInputBranch(rs.getString("INPUTBRANCH"));
	 * eq3Posting.setProductReference(rs.getString("PRODUCTREFERENCE"));
	 * eq3Posting.setMasterReference(rs.getString("MASTERREFERENCE"));
	 * eq3Posting.setEventReference(rs.getString("EVENTREFERENCE"));
	 * eq3Posting.setInternalRecnRef(rs.getString("INTERNALRECNREF"));
	 * eq3Posting.setPostingSeqNo(rs.getInt("POSTINGSEQNO"));
	 * eq3Posting.setAccountNumber(rs.getString("ACCOUNTNUMBER"));
	 * eq3Posting.setBackOfficeAccountNo(rs.getString("BACKOFFICEACCOUNTNO"));
	 * eq3Posting.setExternalAccountNo(rs.getString("EXTERNALACCOUNTNO"));
	 * eq3Posting.setCustomerMnemonic(rs.getString("CUSTOMERMNEMONIC"));
	 * eq3Posting.setAccountType(rs.getString("ACCOUNTTYPE"));
	 * eq3Posting.setSPSKMnemonic(rs.getString("SPSKMNEMONIC"));
	 * eq3Posting.setSPSKCategoryCode(rs.getString("SPSKCATEGORYCODE"));
	 * eq3Posting.setApplication(rs.getString("APPLICATION"));
	 * eq3Posting.setDebitCreditFlag(rs.getString("DEBITCREDITFLAG"));
	 * eq3Posting.setTransactionCode(rs.getString("TRANSACTIONCODE"));
	 * eq3Posting.setPostingAmount(rs.getLong("POSTINGAMOUNT"));
	 * eq3Posting.setPostingCcy(rs.getString("POSTINGCCY"));
	 * eq3Posting.setValueDate
	 * (stringToXMLGregorianCalendar(rs.getString("VALUEDATE")));
	 * eq3Posting.setRelatedParty(rs.getString("RELATEDPARTY"));
	 * eq3Posting.setBeneficiaryName(rs.getString("BENEFICIARYNAME"));
	 * //eq3Posting.setIssueOrContractDate(ISSUEORCONTRACTDATE);
	 * eq3Posting.setBankCode1(rs.getString("BANKCODE1"));
	 * eq3Posting.setSettlementAccountUsed
	 * (rs.getString("SETTLEMENTACCOUNTUSED")); list.add(eq3Posting); }
	 * 
	 * if(rs!=null){ rs.close(); } if(ps!=null){ ps.close(); }
	 * 
	 * 
	 * ps1 = new LoggableStatement(con,
	 * "SELECT INV.FINCE_EV AS INVOICEKEY,S.ID AS ID,S.PROG_TYPE,(SELECT CPARTY FROM SCFCPARTY WHERE "
	 * +
	 * "PROGRAMME=S.KEY97 AND ROLE=S.PROG_TYPE) AS APARTY,SP.CPARTY,REL.CUSTOMR,INV.INVOIC_REF AS INVOIC_REF,BATCHNO,"
	 * +
	 * "APISERVERSEQNO,MASTERKEY,EVENTKEY,POSTINGBRANCH,INPUTBRANCH,PRODUCTREFERENCE,"
	 * +
	 * "MASTERREFERENCE,EVENTREFERENCE,INTERNALRECNREF,POSTINGSEQNO,ACCOUNTNUMBER,"
	 * +
	 * "BACKOFFICEACCOUNTNO,EXTERNALACCOUNTNO,CUSTOMERMNEMONIC,ACCOUNTTYPE,SPSKMNEMONIC,"
	 * +
	 * "SPSKCATEGORYCODE,APPLICATION,DEBITCREDITFLAG,TRANSACTIONCODE,POSTINGAMOUNT/100 AS POSTINGAMOUNT,POSTINGCCY,"
	 * +
	 * "TO_CHAR(TO_DATE(VALUEDATE, 'dd-mm-yy'),'yyyy-MM-dd') AS VALUEDATE,RELATEDPARTY,"
	 * +
	 * "BENEFICIARYNAME,ISSUEORCONTRACTDATE,BANKCODE1,SETTLEMENTACCOUNTUSED,ADDMNTDELFLAG FROM "
	 * +
	 * "ETT_REPAY_POST,MASTER MAS,FNCEMASTER FNM,INVMASTER INV,SCFPROGRAM S,SCFCPARTY SP,"
	 * +
	 * "ETT_CLF_SELLERBUYERRELATION REL WHERE TRIM(MASTER_REF) = TRIM(MASTERREFERENCE) AND DEBITCREDITFLAG='C' AND "
	 * +
	 * "MAS.KEY97=FNM.KEY97 AND MAS.STATUS = 'LIV' AND INV.FINCE_EV=FNM.FINCEEVKEY AND "
	 * +
	 * "TRIM(REL.PROGIDN)=TRIM(S.ID) AND TRIM(REL.CUSTOMR)=TRIM(SP.CPARTY) AND "
	 * +
	 * "INV.PROGRAMME=S.KEY97 AND SP.KEY97=CASE S.PROG_TYPE WHEN 'S' THEN INV.BUYER WHEN 'B' "
	 * +
	 * "THEN INV.SELLER END AND TRIM(BACKOFFICEACCOUNTNO) IN (SELECT TRIM(BO_ACCTNO) FROM "
	 * +
	 * "ACCOUNT WHERE TRIM(SHORTNAME) LIKE UPPER('%RTGS%OUT%') OR TRIM(SHORTNAME) LIKE "
	 * +
	 * "UPPER('%NEFT%OUT%')) AND TRIM(REL.REFUND_BENEFICIARY_TYPE)='EXTERNAL' "
	 * +
	 * "AND BATCHNO='"+batchID+"' AND TRIM(MASTERREFERENCE) = '"+seqList.get(i)
	 * +"'"); System.out.println("Executing Query"+ps1.getQueryString()); rs1 =
	 * ps1.executeQuery(); while (rs1.next()) { TFBuyFin eq3Posting = new
	 * TFBuyFin();
	 * eq3Posting.setProgramme(comm.getEmptyIfNull(rs1.getString("ID")).trim());
	 * eq3Posting.setBuyer(comm.getEmptyIfNull(rs1.getString("APARTY")).trim());
	 * eq3Posting
	 * .setSeller(comm.getEmptyIfNull(rs1.getString("CPARTY")).trim());
	 * eq3Posting
	 * .setInvoiceNumber(comm.getEmptyIfNull(rs1.getString("INVOIC_REF"
	 * )).trim());
	 * eq3Posting.setOutstandingAmount(comm.getEmptyIfNull(rs1.getString
	 * ("POSTINGAMOUNT")).trim()); financeList.add(eq3Posting); }
	 * pushXMLFORPosting(list,batchID,seqList.get(i),con); }
	 * if(financeList!=null && financeList.size()>0){
	 * processNEFTRTGS(financeList, batchID); } pustTOThemebridge(batchID); }
	 * 
	 * 
	 * } catch (Exception exception) { throwDAOException(exception); } finally {
	 * DBConnectionUtility.surrenderStatement(rs1, ps1);
	 * DBConnectionUtility.surrenderDB(rs, ps, con); }
	 * logger.info(ActionConstants.EXITING_METHOD); return userTeam; }
	 */

	private boolean fetchPostingEntry(String batchID) {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		boolean result = false;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(
					con,
					"SELECT COUNT(*) AS COUNT FROM CLFBATCHPOSTING WHERE BATCHID='"
							+ batchID
							+ "' AND UPPER(ERRORDESC) LIKE '%UNIQUE CONSTRAINT%'");

			rs = ps.executeQuery();

			if (rs.next()) {
				int count = rs.getInt("COUNT");
				if (count > 0) {
					result = true;
				}
			}
		} catch (Exception exception) {
			// throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return result;
	}

	/**
	 * 
	 * @param list
	 * @param batchID
	 * @param masterRef
	 * @param con
	 * @throws TransformerConfigurationException
	 * @throws ParserConfigurationException
	 * @throws RemoteException
	 * @throws DAOException
	 * @throws SQLException
	 */
	@SuppressWarnings("unused")
	private void pushXMLFORPosting(ArrayList<EQ3Posting> list, String batchID,
			String masterRef, Connection con)
			throws TransformerConfigurationException,
			ParserConfigurationException, RemoteException, DAOException,
			SQLException {
		PostingXMLGenerationSample pxs = new PostingXMLGenerationSample();
		String[] finalXML = null;
		String endString = "";
		LoggableStatement pst = null;
		LoggableStatement pst1 = null;
		String datePosting = pxs.getTIDateForPosting();
		String xml1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ServiceRequest xmlns=\"urn:control.services.tiplus2.misys.com\" "
				+ "xmlns:ns2=\"urn:messages.service.ti.apps.tiplus2.misys.com\" xmlns:ns4=\"urn:custom.service.ti.apps.tiplus2.misys.com\" "
				+ "xmlns:ns3=\"urn:common.service.ti.apps.tiplus2.misys.com\">"
				+ "<RequestHeader><Service>BackOffice</Service>"
				+ "	<Operation>Batch</Operation><Credentials><Name>SUPERVISOR</Name></Credentials><ReplyFormat>FULL</ReplyFormat> "
				+ "<SourceSystem>Z2</SourceSystem><NoRepair>Y</NoRepair><NoOverride>Y</NoOverride>"
				+ "<TransactionControl>B-"
				+ batchID
				+ "</TransactionControl><CreationDate>"
				+ datePosting
				+ "</CreationDate></RequestHeader>" + "<ns2:BatchRequest>";
		String xml2 = "</ns2:BatchRequest></ServiceRequest>";
		endString = endString + xml1;
		try {
			if (null != list) {
				int size = list.size();
				finalXML = new String[size];
				for (int i = 0; i < size; i++) {
					String temp = null;

					temp = pxs.generatePostingTag(list.get(i));
					temp = temp.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
					finalXML[i] = temp;
					endString = endString + finalXML[i];
				}
				endString = endString + xml2;
			}
			System.out.println("endString------------>" + endString);
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			pst = new LoggableStatement(
					con,
					"Insert into THEMEBRIDGE.CLFBatchPosting(ID,MASTERREFERENCE,EVENTREFERENCE,TIREQUEST,BATCHID,PROCESS_TIME,PROCESS_FLAG) "
							+ "values(THEMEBRIDGE.CLFBatchPosting_seq.nextval,?,'RFS001',?,?,SYSDATE,'I')");
			pst.setString(1, masterRef);
			pst.setString(2, endString);
			pst.setString(3, batchID);
			System.out.println("Insert Query Thembridge-->"
					+ pst.getQueryString());
			pst.executeQuery();
			logger.info("endString------------>" + endString);
			if (pst != null) {
				pst.close();
			}
		} catch (Exception e) {
			System.out.println("BridgeGatewayImplServiceStub------------>"
					+ e.getMessage());
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			try {
				pst1 = new LoggableStatement(
						con,
						"Insert into CLFBatchPosting(ID,MASTERREFERENCE,EVENTREFERENCE,TIREQUEST,BATCHID,PROCESS_TIME,ERRORDESC) "
								+ "values(CLFBatchPosting_seq.nextval,?,'RFS001',?,?,SYSDATE,?)");
				pst1.setString(1, masterRef);
				pst1.setString(2, endString);
				pst1.setString(3, batchID);
				pst1.setString(4, e.getMessage());
				System.out.println("Insert Query-->" + pst1.getQueryString());
				pst1.executeQuery();
				if (pst1 != null) {
					pst1.close();
				}
			} catch (SQLException e1) {
				System.out
						.println("CLFBatchPosting BridgeGatewayImplServiceStub------------>"
								+ e.getMessage());
				e1.printStackTrace();
			}
			logger.info("endString------------>" + endString);
			logger.info("Calling BridgeGatewayImplService Ends");
		} finally {
			DBConnectionUtility.surrenderStatement(null, pst);
			DBConnectionUtility.surrenderStatement(null, pst1);
		}

	}

	/*
	 * private void processNEFTRTGS(ArrayList<TFBuyFin> financeList, String
	 * batchID) throws DAOException, SQLException {
	 * logger.info(ActionConstants.ENTERING_METHOD); NEFT & RTGS STARTS
	 * Connection con =null; ResultSet rs = null; LoggableStatement
	 * loggableStatement = null; LoggableStatement ps = null; CommonMethods comm
	 * = null; try { comm = new CommonMethods(); if (con == null){ con =
	 * DBConnectionUtility.getConnection();} if (null != financeList) {
	 * 
	 * ValidatorDAO validatorDAO = ValidatorDAO.getDAO(); int size =
	 * financeList.size(); String Cparty = ""; String prgtype = "";
	 * ArrayList<FileDataRecordVO> rows = new ArrayList<FileDataRecordVO>();
	 * RODDWLD rODDWLD = new RODDWLD(); String customer = ""; String anchor =
	 * ""; BigDecimal totalAmount = new BigDecimal("0.00"); for (int i = 0; i <
	 * size; i++) { prgtype = validatorDAO.buyerSeller(financeList.get(i)
	 * .getProgramme(), con); if (prgtype.equalsIgnoreCase("B")) { Cparty =
	 * financeList.get(i).getSeller(); customer =
	 * financeList.get(i).getSeller(); anchor = financeList.get(i).getSeller();
	 * } else { Cparty = financeList.get(i).getSeller(); customer =
	 * financeList.get(i).getSeller(); String exposure =
	 * validatorDAO.getExp(financeList.get(i) .getProgramme());
	 * if(exposure!=null && !exposure.equalsIgnoreCase("A")){ anchor =
	 * financeList.get(i).getSeller(); }else{ anchor =
	 * financeList.get(i).getBuyer(); }
	 * 
	 * }
	 * 
	 * String refKey = validatorDAO.getRefKey(financeList.get(i)
	 * .getInvoiceNumber(), Cparty); if (null != refKey &&
	 * !refKey.equalsIgnoreCase("")) { String financedAmount = validatorDAO
	 * .getFinancedAmount(refKey); String financedAmount =
	 * financeList.get(i).getOutstandingAmount();
	 * 
	 * if (null != financedAmount && !financedAmount.equalsIgnoreCase(".00")) {
	 * System.out .println("Inside NEFT Calling and Amount not Zero" +
	 * financedAmount); AccountHolderDetailsVO accountHolderDetailsVO =
	 * validatorDAO .getDisbursement(financeList.get(i) .getProgramme(),
	 * financeList.get(i) .getSeller()); accountHolderDetailsVO = validatorDAO
	 * .getRTGSNEFTData(accountHolderDetailsVO,
	 * financeList.get(i).getProgramme(), Cparty); accountHolderDetailsVO =
	 * validatorDAO .getRemittersDetails(accountHolderDetailsVO,anchor); if
	 * (null != accountHolderDetailsVO) { String dispMethod =
	 * accountHolderDetailsVO .getDisbMed(); if (null != dispMethod &&
	 * dispMethod.equalsIgnoreCase("RN")) { BigDecimal newmaount = new
	 * BigDecimal( financedAmount); totalAmount = totalAmount.add(newmaount);
	 * System.out.println("Total Amount" + totalAmount); FileDataRecordVO
	 * fileDataRecordVO = rODDWLD .getRowData(accountHolderDetailsVO,
	 * financedAmount, refKey); rows.add(fileDataRecordVO); int rowlength =
	 * rows.size(); loggableStatement = new LoggableStatement( con,
	 * INSERT_NEFT_RTGS); loggableStatement.setString(1, financeList
	 * .get(i).getProgramme()); loggableStatement.setString(2, financeList
	 * .get(i).getBuyer()); loggableStatement.setString(3, financeList
	 * .get(i).getSeller()); loggableStatement.setString(4, Cparty);
	 * loggableStatement.setString(5, refKey); loggableStatement.setString(6,
	 * financeList .get(i).getInvoiceNumber());
	 * loggableStatement.setBigDecimal(7, totalAmount);
	 * loggableStatement.setString(8, accountHolderDetailsVO
	 * .getBeneficiaryName()); loggableStatement .setString(9,
	 * accountHolderDetailsVO .getDisbMed()); loggableStatement .setString( 10,
	 * accountHolderDetailsVO .getBeneficiaryAccountNumber());
	 * loggableStatement.setString(11, accountHolderDetailsVO.getPhone());
	 * loggableStatement.setString(12, accountHolderDetailsVO.getEmail());
	 * loggableStatement .setString( 13, accountHolderDetailsVO
	 * .getRemitterAccountNumber()); loggableStatement.setString(14,
	 * accountHolderDetailsVO .getBeneficiaryIDFCCode());
	 * loggableStatement.setString(15, fileDataRecordVO.getDateIden());
	 * loggableStatement.setString(16, fileDataRecordVO.getSrcApp());
	 * loggableStatement.setString(17, fileDataRecordVO.getRemAccNo());
	 * loggableStatement .setString(18, fileDataRecordVO .getSenderAccTypr());
	 * loggableStatement.setString(19, financedAmount);
	 * loggableStatement.setString(20, fileDataRecordVO.getTransRef());
	 * loggableStatement.setString(21, fileDataRecordVO.getMsgType());
	 * loggableStatement.setString(22, fileDataRecordVO.getRelRefNo());
	 * loggableStatement.setString(23, fileDataRecordVO.getRemAccName());
	 * loggableStatement.setString(24, fileDataRecordVO.getCommAmt());
	 * loggableStatement.setString(25, fileDataRecordVO.getBenefName());
	 * loggableStatement.setString(26, fileDataRecordVO.getBenefAcc());
	 * loggableStatement.setString(27, fileDataRecordVO.getBenefAccType());
	 * loggableStatement.setString(28, fileDataRecordVO.getBenefIFSC());
	 * loggableStatement.setString(29, fileDataRecordVO.getCusMob_Email());
	 * loggableStatement.setString(30, prgtype); loggableStatement.setInt(31,
	 * rowlength); loggableStatement.setString(32, batchID);
	 * loggableStatement.setString(33,
	 * accountHolderDetailsVO.getRemitterAddress1());
	 * loggableStatement.setString(34,
	 * accountHolderDetailsVO.getRemitterAddress2());
	 * loggableStatement.setString(35,
	 * accountHolderDetailsVO.getRemitterAddress3());
	 * loggableStatement.setString(36,
	 * accountHolderDetailsVO.getRemitterAddress4());
	 * loggableStatement.setString(37, ""); loggableStatement.setString(38, "");
	 * loggableStatement.setString(39, ""); loggableStatement.setString(40, "");
	 * loggableStatement.setString(41, ""); loggableStatement.setString(42, "");
	 * loggableStatement.setString(43, ""); loggableStatement.setString(44, "");
	 * loggableStatement.setString(45, ""); System.out.println(loggableStatement
	 * .getQueryString()); loggableStatement.executeUpdate(); } } } }
	 * 
	 * } rowList = new ArrayList<FileDataRecordVO>(); FileDataRecordVO filevo =
	 * null; ps = new LoggableStatement( con,
	 * "select a.*,ETT_CUST_NAME(BUYER) as BUYERNAME from ETT_RTGSNEFT A where BATCHID='"
	 * + batchID + "'"); rs = ps.executeQuery(); while (rs.next()) { String
	 * CpartyVal = rs.getString("CPARTY"); String batchidVal =
	 * rs.getString("BATCHID"); String buyerName = comm.getEmptyIfNull(
	 * rs.getString("BUYERNAME")).trim();
	 * System.out.println(buyerName.length()); if (buyerName.length() > 30) {
	 * buyerName = buyerName.substring(0, 30); } String transRef =
	 * comm.getEmptyIfNull( rs.getString("TRANSREF")).trim(); //String narration
	 * = "Interest-refund-by-IDFC-BANK-on-behalf-of-buyerName; String narration
	 * = "Interest-refund-by-IDFC-BANK-"; String[] narr = narration.split("-");
	 * // String detPayment = narr[0]+" "+narr[1]; String recInfo1 = narr[0] +
	 * " " + narr[1]; String recInfo2 = narr[2] + " " + narr[3] + " " + narr[4];
	 * //String recInfo3 = narr[5] + " " + narr[6] + " " + narr[7]; String
	 * recInfo3 = " " + " " + " " + " " + " "; //String buyerNameVal = narr[8];
	 * String buyerNameVal = "  "; // String rtgsSeq =
	 * validatorDAO.rtgsNeftBatchSeq(); // String rtgsSeqVal = "UT"+rtgsSeq;
	 *//**
	 * ps1 = new LoggableStatement(con, "UPDATE ETT_RTGSNEFT SET ORDERSEQ='"
	 * +transRef+"' WHERE CPARTY='"
	 * +CpartyVal+"' and BATCHID='"+batchidVal+"'");
	 * System.out.println(ps1.getQueryString()); ps1.executeUpdate();
	 */
	/*
	 * 
	 * 
	 * filevo = new FileDataRecordVO();
	 * filevo.setDateIden(rs.getString("DATEIDEN"));
	 * filevo.setSrcApp(rs.getString("SRCAPP"));
	 * filevo.setRemAccNo(rs.getString("REMACCNO"));
	 * filevo.setSenderAccTypr(rs.getString("SENDERACCTYPE"));
	 * filevo.setTransRef(transRef); // change
	 * filevo.setMsgType(rs.getString("MSGTYPE"));
	 * filevo.setRelRefNo(rs.getString("RELREFNO"));
	 * filevo.setRemAccName(rs.getString("REMACCNAME"));
	 * filevo.setCommAmt(rs.getString("COMMAMT"));
	 * filevo.setTransAmt(rs.getString("TRANSACTIONAMT"));
	 * filevo.setBenefName(rs.getString("BENFNAME"));
	 * filevo.setBenefAcc(rs.getString("BENFACC"));
	 * filevo.setBenefAccType(rs.getString("BENFACCTYPE"));
	 * filevo.setBenefIFSC(rs.getString("BENFIFSC"));
	 * filevo.setCusMob_Email(rs.getString("CUSEMAILPHON"));
	 * filevo.setDetailOfPay(rs.getString("DETOFPAY"));
	 * filevo.setRemAddr1(rs.getString("REMADD1"));
	 * filevo.setRemAddr2(rs.getString("REMADD2"));
	 * filevo.setRemAddr3(rs.getString("REMADD3"));
	 * filevo.setRemAddr4(rs.getString("REMADD4"));
	 * filevo.setBenefAddr1(rs.getString("BENFADD1"));
	 * filevo.setBenefAddr2(rs.getString("BENFADD2"));
	 * filevo.setSenderRecInfo1(recInfo1); filevo.setSenderRecInfo2(recInfo2);
	 * filevo.setSenderRecInfo3(recInfo3);
	 * filevo.setSenderRecInfo4(buyerNameVal);
	 * filevo.setSenderRecInfo5(rs.getString("RECINFO5"));
	 * filevo.setSenderRecInfo6(rs.getString("RECINFO6")); rowList.add(filevo);
	 * 
	 * } if (null != rowList) { int len = rowList.size(); if (len > 0) {
	 * FileHeaderVO fileHeaderVO = rODDWLD.getHeaderData( totalAmount, len);
	 * rODDWLD.fileWriter(fileHeaderVO, rowList); } } } } catch (Exception e) {
	 * throwDAOException(e); }finally{
	 * DBConnectionUtility.surrenderStatement(rs, ps);
	 * DBConnectionUtility.surrenderDB(null, loggableStatement, con); }
	 * logger.info(ActionConstants.EXITING_METHOD); }
	 */

	public XMLGregorianCalendar stringToXMLGregorianCalendar(String s)

	throws ParseException, DatatypeConfigurationException {

		XMLGregorianCalendar result = null;

		Date date;

		SimpleDateFormat simpleDateFormat;

		GregorianCalendar gregorianCalendar;

		simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

		date = simpleDateFormat.parse(s);

		gregorianCalendar = (GregorianCalendar) GregorianCalendar.getInstance();

		gregorianCalendar.setTime(date);

		result = DatatypeFactory.newInstance().newXMLGregorianCalendar(

		gregorianCalendar);

		return result;

	}

	private void getXMLFORPosting(ArrayList<EQ3Posting> list)
			throws TransformerConfigurationException,
			ParserConfigurationException, RemoteException, DAOException {
		PostingXMLGenerationSample pxs = new PostingXMLGenerationSample();
		String[] finalXML = null;
		String endString = "";
		String datePosting = pxs.getTIDateForPosting();
		String xml1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ServiceRequest xmlns=\"urn:control.services.tiplus2.misys.com\" "
				+ "xmlns:ns2=\"urn:messages.service.ti.apps.tiplus2.misys.com\" xmlns:ns4=\"urn:custom.service.ti.apps.tiplus2.misys.com\" "
				+ "xmlns:ns3=\"urn:common.service.ti.apps.tiplus2.misys.com\">"
				+ "<RequestHeader><Service>BackOffice</Service>"
				+ "	<Operation>Batch</Operation><Credentials><Name>SUPERVISOR</Name></Credentials><ReplyFormat>FULL</ReplyFormat> "
				+ "<SourceSystem>Z2</SourceSystem><NoRepair>Y</NoRepair><NoOverride>Y</NoOverride>"
				+ "<TransactionControl>NONE</TransactionControl><CreationDate>"
				+ datePosting
				+ "</CreationDate></RequestHeader>"
				+ "<ns2:BatchRequest>";
		String xml2 = "</ns2:BatchRequest></ServiceRequest>";
		endString = endString + xml1;
		if (null != list) {
			int size = list.size();
			finalXML = new String[size];
			for (int i = 0; i < size; i++) {
				String temp = null;

				temp = pxs.generatePostingTag(list.get(i));
				temp = temp.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
				finalXML[i] = temp;
			}

			for (int i = 0; i < size; i++) {
				endString = endString + finalXML[i];
			}
			endString = endString + xml2;
		}

		System.out.println("Final------------>" + endString);
		logger.info("Final------------>" + endString);

		/*
		 * logger.info("Calling BridgeGatewayImplServiceStub Starts");
		 * BridgeGatewayImplServiceStub bs= new BridgeGatewayImplServiceStub();
		 * bs.bridgeGateWayProcess(endString);
		 * logger.info("Calling BridgeGatewayImplServiceStub Ends");
		 */

		logger.info("Calling BridgeGatewayImplServiceStub Starts");
		/*
		 * BridgeGatewayImplService service = new BridgeGatewayImplService();
		 * BridgeGateway bg= service.getBridgeGatewayImplPort(); String result =
		 * bg.process(endString);
		 * System.out.println("Result-------------->"+result);
		 */
		logger.info("Calling BridgeGatewayImplServiceStub Starts");

	}

	private ArrayList<String> getPostingSeqNumbers(String batchID) {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String userTeam = null;

		ArrayList<String> list = null;

		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			list = new ArrayList<String>();
			ps = new LoggableStatement(
					con,
					"select TRIM(MASTERREFERENCE) AS MASTERREFERENCE from ett_repay_post where BATCHNO='"
							+ batchID + "'  group by MASTERREFERENCE");

			rs = ps.executeQuery();

			while (rs.next()) {
				String temp = rs.getString("MASTERREFERENCE");
				list.add(temp);

			}

		} catch (Exception exception) {
			// throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return list;
	}
}
