package in.co.invoice.dao.exception;

public class ApplicationException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Throwable exceptionClass = null;

	/**
	 * constructor with one argument to handle user defined exception.
	 * 
	 * @param msg
	 */
	public ApplicationException(String msg) {
		super(msg);
	}

	/**
	 * constructor with two argument to handle user defined exception.
	 * 
	 * @param msg
	 * @param exception
	 */

	public ApplicationException(String msg, Throwable exception) {
		super(msg, exception);
		exceptionClass = exception;
	}

	/**
	 * This overridden method is used to print the exception, when exception
	 * occurs.
	 */
	public void printStackTrace() {
		if (exceptionClass != null) {
			System.err.println("An exception has caused by "
					+ exceptionClass.toString());
			exceptionClass.printStackTrace();
		}
	}
}
