package in.co.invoice.dao.exception;

public class DAOException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6677728600384808574L;

	/**
	 * default constructor used to handle exception.
	 */

	public DAOException() {
		super();
	}

	/**
	 * constructor with one argument to handle user defined exception.
	 * 
	 * @param msg
	 * 
	 * 
	 */
	public DAOException(String msg) {
		super(msg);
	}

	/**
	 * Constructor with single argument to handle user defined exception. I
	 * receives exception as an argument and handle the exception.
	 * 
	 * @param t
	 */
	public DAOException(Throwable exception) {
		super(exception);
	}

	/**
	 * constructor with two argument to handle user defined exception.
	 * 
	 * @param msg
	 * @param exception
	 */

	public DAOException(String msg, Throwable exception) {
		super(msg, exception);
	}
}
