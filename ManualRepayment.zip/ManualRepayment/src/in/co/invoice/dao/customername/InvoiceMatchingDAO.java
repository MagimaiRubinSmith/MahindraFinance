package in.co.invoice.dao.customername;

import in.co.invoice.businessdelegate.exception.BusinessException;
import in.co.invoice.businessdelegate.pricereftomanybill.InvoiceMatchingProcess;
import in.co.invoice.dao.AbstractDAO;
import in.co.invoice.dao.STPProcessDAO;
import in.co.invoice.dao.ValidatorDAO;
import in.co.invoice.dao.xmlGeneration;
import in.co.invoice.dao.exception.ApplicationException;
import in.co.invoice.dao.exception.DAOException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.ActionConstantsQuery;
import in.co.invoice.utility.CommonMethods;
import in.co.invoice.utility.DBConnectionUtility;
import in.co.invoice.utility.GenericFundTransferFinance;
import in.co.invoice.utility.LoggableStatement;
import in.co.invoice.utility.SmithThreadConcept;
import in.co.invoice.vo.AlertMessagesVO;
import in.co.invoice.vo.InvBatchVO;
import in.co.invoice.vo.InvMatchingDataVO;
import in.co.invoice.vo.InvMatchingVO;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.struts2.ServletActionContext;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.opensymphony.xwork2.ActionContext;

public class InvoiceMatchingDAO extends AbstractDAO implements
		ActionConstantsQuery, ActionConstants {

	static InvoiceMatchingDAO dao;

	private ArrayList<AlertMessagesVO> alertMsgArray = new ArrayList<AlertMessagesVO>();
	private ArrayList<AlertMessagesVO> alertWarningMsgArray = new ArrayList<AlertMessagesVO>();

	public ArrayList<AlertMessagesVO> getAlertWarningMsgArray() {
		return alertWarningMsgArray;
	}

	public void setAlertWarningMsgArray(
			ArrayList<AlertMessagesVO> alertWarningMsgArray) {
		this.alertWarningMsgArray = alertWarningMsgArray;
	}

	public ArrayList<AlertMessagesVO> getAlertMsgArray() {
		return alertMsgArray;
	}

	public void setAlertMsgArray(ArrayList<AlertMessagesVO> alertMsgArray) {
		this.alertMsgArray = alertMsgArray;
	}

	private static Logger logger = Logger.getLogger(InvoiceMatchingDAO.class
			.getName());

	/**
	 * Creating new instance for NostroReservationDAO
	 * 
	 * @return NostroReservationDAO
	 */
	public static InvoiceMatchingDAO getDAO() {
		if (dao == null) {
			dao = new InvoiceMatchingDAO();
		}
		return dao;
	}

	ArrayList<InvMatchingVO> debitlst = null;
	ArrayList<InvMatchingVO> programlst = null;
	ArrayList<InvMatchingDataVO> invList = null;
	ArrayList<InvMatchingDataVO> invList1 = null;
	ArrayList<InvMatchingVO> counterList = null;

	List<String> apista = null;

	int recordCount = 0;

	public ArrayList<InvMatchingVO> getCounterList() {
		return counterList;
	}

	public void setCounterList(ArrayList<InvMatchingVO> counterList) {
		this.counterList = counterList;
	}

	public ArrayList<InvMatchingVO> getProgramlst() {
		return programlst;
	}

	public ArrayList<InvMatchingDataVO> getInvList() {
		return invList;
	}

	public ArrayList<InvMatchingDataVO> getInvList1() {
		return invList1;
	}

	public void setProgramlst(ArrayList<InvMatchingVO> programlst) {
		this.programlst = programlst;
	}

	public void setInvList(ArrayList<InvMatchingDataVO> invList) {
		this.invList = invList;
	}

	public void setInvList1(ArrayList<InvMatchingDataVO> invList1) {
		this.invList1 = invList1;
	}

	public ArrayList<InvMatchingVO> getDebitlst() {
		return debitlst;
	}

	public void setDebitlst(ArrayList<InvMatchingVO> debitlst) {
		this.debitlst = debitlst;
	}

	public void setErrorvalues(Object[] arg) {
		CommonMethods commonMethods = new CommonMethods();
		AlertMessagesVO altMsg = new AlertMessagesVO();
		altMsg.setErrorId(((commonMethods.getEmptyIfNull(arg[1])
				.equalsIgnoreCase(W)) ? WARNING : ERROR));
		altMsg.setErrorDesc(GENERAL);
		altMsg.setErrorCode(commonMethods.getEmptyIfNull(arg[3]));
		altMsg.setErrorDetails(commonMethods.getEmptyIfNull(arg[2]));
		altMsg.setErrorMsg((((commonMethods.getEmptyIfNull(arg[1])
				.equalsIgnoreCase(W)) ? N : "")));
		alertMsgArray.add(altMsg);
	}

	/**
	 * 
	 * @param arg
	 */
	public void setWarningvalues(Object[] arg) {
		CommonMethods commonMethods = new CommonMethods();
		AlertMessagesVO altMsg = new AlertMessagesVO();
		altMsg.setErrorId(((commonMethods.getEmptyIfNull(arg[1])
				.equalsIgnoreCase(W)) ? WARNING : ERROR));
		altMsg.setErrorDesc(GENERAL);
		altMsg.setErrorCode(commonMethods.getEmptyIfNull(arg[3]));
		altMsg.setErrorDetails(commonMethods.getEmptyIfNull(arg[2]));
		altMsg.setErrorMsg((((commonMethods.getEmptyIfNull(arg[1])
				.equalsIgnoreCase(W)) ? N : "")));
		alertWarningMsgArray.add(altMsg);
	}

	public InvMatchingVO getUpdatedList(InvMatchingVO scf) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement pst = null;
		ResultSet rs = null;
		LoggableStatement pst1 = null;
		ResultSet rs1 = null;
		Connection con = null;
		String keyValue = null;
		String modeType = null;
		CommonMethods commonMethods = null;
		Locale.setDefault(Locale.US);
		try {
			con = DBConnectionUtility.getConnection();

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			// DBConnectionUtility.surrenderDB(con, pst, rs);
			DBConnectionUtility.surrenderDB(rs1, pst1, null);
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return scf;

	}

	/**
	 * 
	 * @param userName
	 * @return
	 * @throws DAOException
	 */
	public String getUserId(String userName) throws DAOException {
		Connection con = null;
		LoggableStatement pst = null;
		String userId = null;
		ResultSet rs = null;
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String getUserId = GET_TIPLUSLOGIN + "where name85 ='" + userName
					+ "'";
			pst = new LoggableStatement(con, getUserId);
			rs = pst.executeQuery();
			while (rs.next()) {
				userId = String.valueOf((rs.getInt(COLUMN_SKEY80)));
			}

		} catch (Exception exception) {
			throwDAOException(exception);

		} finally {
			// closeSqlRefferance(rs, pst, con);
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userId;
	}

	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 * @throws BusinessException
	 */
	public void isSessionAvailable() throws DAOException {
		String sessionUserName = null;
		String userId = null;
		String userName = null;
		try {
			HttpSession session = ServletActionContext.getRequest()
					.getSession();
			// userName = (String) session.getAttribute(LOGINUSER);
			logger.info("RemoteUserNameBefore Login" + sessionUserName);
			System.out.println("RemoteUserNameBefore Login" + sessionUserName);
			HttpServletRequest request = (HttpServletRequest) ActionContext
					.getContext().get(ServletActionContext.HTTP_REQUEST);
			sessionUserName = request.getRemoteUser();
			logger.info("RemoteUserNameAfter Login" + sessionUserName);
			System.out.println("RemoteUserNameAfter Login" + sessionUserName);

			if (sessionUserName == null) {
				sessionUserName = "23209690";
				//sessionUserName = "MAKER";
				//sessionUserName ="1000003471";
				//sessionUserName ="SUPERVISOR";
			}

			userId = getUserId(sessionUserName);
			session.setAttribute(LOGINUSER, userId);
		} catch (Exception exception) {
			throwDAOException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public InvMatchingVO updateRepayment(InvMatchingVO invMatchingVO,
			ArrayList<InvMatchingVO> tiListsDetail, String batchId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement pst = null;
		ResultSet rs = null;
		Connection con = null;
		CommonMethods comm = null;
		try {
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			comm.updateAllocationAmount(batchId, con);
			for (int i = 0; i < tiListsDetail.size(); i++) {
				// String
				// query="update ETT_STP_REPAYMENT set PRC_ALLC_AMOUNT =? where INVOICE_NO=? and LOAN_MASTER_REF=? and BATCH_ID=?";

				if (Double.parseDouble(CommonMethods.removeComma(tiListsDetail
						.get(i).getAllocAmt())) > 0) {
					pst = new LoggableStatement(con, UPDATE_REPAY_QUERY);
					if (Double.parseDouble(CommonMethods
							.removeComma(tiListsDetail.get(i).getAllocAmt())) > 0) {
						pst.setString(
								1,
								CommonMethods.removeComma(tiListsDetail.get(i)
										.getAllocAmt()) + "");
					} else {
						pst.setString(1, ZERO);
					}
					pst.setString(2, CommonMethods
							.nullAndTrimString(tiListsDetail.get(i)
									.getInvNumber()));
					pst.setString(3, CommonMethods
							.nullAndTrimString(tiListsDetail.get(i)
									.getMasterRef()));
					// System.out.println("BatchID" + batchId);
					pst.setString(4, batchId);
					// System.out.println("Manual updation"+
					// ((LoggableStatement) pst).getQueryString());

					int count = pst.executeUpdate();
					if (count > 0) {
						// System.out.println("Update SucessFully");
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invMatchingVO;
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 * @throws DAOException
	 */
	@SuppressWarnings("static-access")
	public InvMatchingVO getValidate(InvMatchingVO invMatchingVO)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods comm = new CommonMethods();
		Connection con = null;
		try {
			if (alertMsgArray != null) {
				if (alertMsgArray.size() > 0) {
					alertMsgArray.clear();
				}
			}

			System.out.println("prgtype -" + invMatchingVO.getTempPrgType());
			System.out.println(invMatchingVO.getCounterParty());
			if (comm.isNull(invMatchingVO.getProgId())
					|| invMatchingVO.getProgId().equalsIgnoreCase("")) {
				String errormsg = "Program id must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}else{
				String prgrmType = fetchProgramType(invMatchingVO.getProgId(),con);
				if (prgrmType != null && !prgrmType.equalsIgnoreCase("") && !prgrmType.equalsIgnoreCase("S")) {
				if (comm.isNull(invMatchingVO.getDueDateFilter()) || invMatchingVO.getDueDateFilter().equalsIgnoreCase("")) {
					String errormsg = "TXN as on due date must be needed";
					Object arg[] = { 0, E, errormsg, INPUT };
					setErrorvalues(arg);
				}
				}
			}
			if (comm.isNull(invMatchingVO.getPayAmount())
					|| invMatchingVO.getPayAmount().equalsIgnoreCase("")) {
				String errormsg = "Payment amount must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}else{
				String paymentAmount = invMatchingVO.getPayAmount();
				String paymentMode = invMatchingVO.getRepaymentMode();
				String programID = invMatchingVO.getProgId();
				String counterParty = invMatchingVO.getCounterParty();
				if (paymentMode != null && paymentMode.equalsIgnoreCase("SD")) {
					if (programID != null && counterParty != null) {
						String SDAmount = comm.fetchSecurityAmount(programID,"", counterParty);
						if(paymentAmount != null && !paymentAmount.equalsIgnoreCase("") && SDAmount != null && !SDAmount.equalsIgnoreCase("")){
							if (Double.parseDouble(CommonMethods.removeComma(paymentAmount)) > Double
									.parseDouble(SDAmount)) {
								String errormsg = "Security Deposit amount is less than payment amount";
								Object arg[] = { 0, E, errormsg, INPUT };
								setErrorvalues(arg);
							}
						
						}
					}
				}
			}

			if (comm.isNull(invMatchingVO.getValueDate())
					|| invMatchingVO.getValueDate().equalsIgnoreCase("")) {
				String errormsg = "Value Date must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}

			if (comm.isNull(invMatchingVO.getRepaymentMode())
					|| invMatchingVO.getRepaymentMode().equalsIgnoreCase("")) {
				String errormsg = "Mode of Repayment must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}
			if (comm.isNull(invMatchingVO.getPayAccount())
					|| invMatchingVO.getPayAccount().equalsIgnoreCase("")) {
				String errormsg = "Payment account must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}
			

			// System.out.println("repayment tc"+invMatchingVO.getRepaymentTC());
			if (comm.isNull(invMatchingVO.getRepaymentTC())
					|| invMatchingVO.getRepaymentTC().equalsIgnoreCase("")) {
				String errormsg = "Repayment TC must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}

			/*
			 * if (comm.isNull(invMatchingVO.getRepayBy()) ||
			 * invMatchingVO.getRepayBy().equalsIgnoreCase("")) { String
			 * errormsg = "Repay By must be needed"; Object arg[] = { 0, E,
			 * errormsg, INPUT }; setErrorvalues(arg); }
			 */
			if (invMatchingVO.getProgId() != null
					&& !invMatchingVO.getProgId().equalsIgnoreCase("")) {
				String prgrmType = fetchProgramType(invMatchingVO.getProgId(),
						con);
				if (prgrmType != null && !prgrmType.equalsIgnoreCase("")
						&& prgrmType.equalsIgnoreCase("S")) {
					if (invMatchingVO.getCounterParty() == null
							|| invMatchingVO.getCounterParty()
									.equalsIgnoreCase("") || invMatchingVO.getCounterParty().equalsIgnoreCase("-1")) {
						String errormsg = "Counter Party must be needed";
						Object arg[] = { 0, E, errormsg, INPUT };
						setErrorvalues(arg);
					}
				}
			}

			if (comm.isNull(invMatchingVO.getReferenceNumber())
					|| invMatchingVO.getReferenceNumber().equalsIgnoreCase("")) {
				String errormsg = "Reference number must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			} else {
				String referenceNumber = comm.getEmptyIfNull(
						invMatchingVO.getReferenceNumber()).trim();
				boolean fetchValidUTRNo = fetchValidUTRNo(referenceNumber, con);
				if (fetchValidUTRNo == false) {
					String errormsg = "Duplicate Reference Number";
					Object arg[] = { 0, E, errormsg, INPUT };
					setErrorvalues(arg);
				} else {
					boolean fetchUploadValidUTRNo = fetchUploadValidUTRNo(
							referenceNumber, con);
					if (fetchUploadValidUTRNo == false) {
						String errormsg = "Duplicate Reference Number";
						Object arg[] = { 0, E, errormsg, INPUT };
						setErrorvalues(arg);
					}
				}
			}

			if (comm.isNull(invMatchingVO.getRepaymentAllocationType())
					|| invMatchingVO.getRepaymentAllocationType()
							.equalsIgnoreCase("")) {
				String errormsg = "Appropriation type must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}
			// todo
			if (comm.isNull(invMatchingVO.getVirtualAccount())
					|| invMatchingVO.getVirtualAccount().equalsIgnoreCase("")) {
				String virtualAcc = invMatchingVO.getVirtualAccount();
				int count = fetchVirtualAccount(virtualAcc);
				if (count > 0) {
					String errormsg = "Virtual Number is waiting for authorization in Auto Repayment";
					Object arg[] = { 0, E, errormsg, INPUT };
					setErrorvalues(arg);
				}
			}

			if (invMatchingVO.getCounterParty().equalsIgnoreCase("-1")
					&& invMatchingVO.getTempPrgType().equalsIgnoreCase("S")) {
				ValidatorDAO valdo = new ValidatorDAO();
				String exposure = valdo.getExp(invMatchingVO.getProgId(), con);
				if (exposure != null && exposure.equalsIgnoreCase("D")) {
					/*
					 * String errormsg = UtilityGenerateCard
					 * .getErrorDesc(IN0001, N128); Object arg[] = { 0, E,
					 * errormsg, INPUT }; setErrorvalues(arg);
					 */
				}
			}

			if (!comm.isNull(invMatchingVO.getBatch_ID())
					&& !invMatchingVO.getBatch_ID().equalsIgnoreCase("")) {
				boolean isValidValueDate = checkeIfValidValueDate(
						invMatchingVO.getBatch_ID(),
						invMatchingVO.getValueDate(), con);
				if (isValidValueDate == false) {
					String errormsg = "Changes in original selection. Kindly reprocess again.";
					Object arg[] = { 0, E, errormsg, INPUT };
					setErrorvalues(arg);
				}
			}
			alertWarningMsgArray = new ArrayList<AlertMessagesVO>();

			if (alertMsgArray.size() > 0) {
				invMatchingVO.setErrorList(alertMsgArray);
			}

			if (alertWarningMsgArray.size() > 0) {
				invMatchingVO.setWarningList(alertWarningMsgArray);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			logger.info(ActionConstants.EXITING_METHOD);
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		return invMatchingVO;
	}
	
	
	
/**
 * 
 * @param prgID
 * @param con
 * @return
 * @throws DAOException
 */
	public String fetchProgramType(String prgID, Connection con)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		String result = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			comm = new CommonMethods();
			String PRGTYPE_QUERY = "SELECT TYPEOFPGM FROM ETT_CLF_PROGRAMPARAMETERS WHERE PROIDEN = '"
					+ prgID + "'";
			pst = new LoggableStatement(con, PRGTYPE_QUERY);
			rs = pst.executeQuery();

			System.out.println("Program Type Fetch Query--->"
					+ pst.getQueryString());
			while (rs.next()) {
				result = comm.getEmptyIfNull(rs.getString("TYPEOFPGM")).trim();
			}

		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		logger.info(EXITING_METHOD);
		return result;
	}

	public int fetchVirtualAccount(String virtualAcc) throws DAOException {
		int status = 0;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		try {
			con = DBConnectionUtility.getConnection();
			String VIRTUAL_ACC = "SELECT COUNT(*) FROM ETT_STP_REPAYMENT_MAKER A,ETT_STP_REPAYMENT B WHERE B.BATCH_ID=A.BATCH_ID AND B.STATUS_FLAG='MA' AND TRIM(A.VIRTUALACCT)='"
					+ virtualAcc + "' ";
			pst = new LoggableStatement(con, VIRTUAL_ACC);
			rs = pst.executeQuery();
			while (rs.next()) {
				status = rs.getInt(1);
				System.out.println("Virtual Number Count--->" + status);
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return status;
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 * @throws DAOException
	 */
	public InvMatchingVO getConfirmValidate(InvMatchingVO invMatchingVO)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods comm = new CommonMethods();
		Connection con = null;
		try {
			if (alertMsgArray != null) {
				if (alertMsgArray.size() > 0) {
					alertMsgArray.clear();
				}
			}

			System.out.println("prgtype -" + invMatchingVO.getTempPrgType());
			System.out.println(invMatchingVO.getCounterParty());
			if (comm.isNull(invMatchingVO.getProgId())
					|| invMatchingVO.getProgId().equalsIgnoreCase("")) {
				String errormsg = "Program id must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}
			if (comm.isNull(invMatchingVO.getPayAmount())
					|| invMatchingVO.getPayAmount().equalsIgnoreCase("")) {
				String errormsg = "Payment amount must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			} else {
				String paymentAmount = invMatchingVO.getPayAmount();
				String paymentMode = invMatchingVO.getRepaymentMode();
				String programID = invMatchingVO.getProgId();
				String counterParty = invMatchingVO.getCounterParty();
				if (paymentMode != null && paymentMode.equalsIgnoreCase("SD")) {
					if (programID != null && counterParty != null) {
						String SDAmount = comm.fetchSecurityAmount(programID,
								"", counterParty);
						if(paymentAmount != null && !paymentAmount.equalsIgnoreCase("") && SDAmount != null && !SDAmount.equalsIgnoreCase("")){
							if (Double.parseDouble(CommonMethods.removeComma(paymentAmount)) > Double
									.parseDouble(SDAmount)) {
								String errormsg = "Security Deposit amount is less than payment amount";
								Object arg[] = { 0, E, errormsg, INPUT };
								setErrorvalues(arg);
							}
						
						}
					}
				}

			}

			if (comm.isNull(invMatchingVO.getRepaymentMode())
					|| invMatchingVO.getRepaymentMode().equalsIgnoreCase("")) {
				String errormsg = "Mode of Repayment must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}
			if (comm.isNull(invMatchingVO.getPayAccount())
					|| invMatchingVO.getPayAccount().equalsIgnoreCase("")) {
				String errormsg = "Payment account must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}

			/*
			 * if (comm.isNull(invMatchingVO.getRepayBy()) ||
			 * invMatchingVO.getRepayBy().equalsIgnoreCase("")) { String
			 * errormsg = "Repay By must be needed"; Object arg[] = { 0, E,
			 * errormsg, INPUT }; setErrorvalues(arg); }
			 */

			/*
			 * if (comm.isNull(invMatchingVO.getReferenceNumber()) ||
			 * invMatchingVO.getReferenceNumber().equalsIgnoreCase("")) { String
			 * errormsg = "Reference number must be needed"; Object arg[] = { 0,
			 * E, errormsg, INPUT }; setErrorvalues(arg); }
			 */
			if (comm.isNull(invMatchingVO.getRepaymentAllocationType())
					|| invMatchingVO.getRepaymentAllocationType()
							.equalsIgnoreCase("")) {
				String errormsg = "Appropriation type must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}

			if (invMatchingVO.getCounterParty().equalsIgnoreCase("-1")
					&& invMatchingVO.getTempPrgType().equalsIgnoreCase("S")) {
				ValidatorDAO valdo = new ValidatorDAO();
				String exposure = valdo.getExp(invMatchingVO.getProgId(), con);
				/*
				 * if(exposure!=null && exposure.equalsIgnoreCase("D")){ String
				 * errormsg = UtilityGenerateCard .getErrorDesc(IN0001, N128);
				 * Object arg[] = { 0, E, errormsg, INPUT };
				 * setErrorvalues(arg); }
				 */
			}

			if (!comm.isNull(invMatchingVO.getBatch_ID())
					&& !invMatchingVO.getBatch_ID().equalsIgnoreCase("")) {
				boolean isValidValueDate = checkeIfValidValueDate(
						invMatchingVO.getBatch_ID(),
						invMatchingVO.getValueDate(), con);
				if (isValidValueDate == false) {
					String errormsg = "Changes in original selection. Kindly reprocess again.";
					Object arg[] = { 0, E, errormsg, INPUT };
					setErrorvalues(arg);
				}
			}

			if (!comm.isNull(invMatchingVO.getBatch_ID())
					&& !invMatchingVO.getBatch_ID().equalsIgnoreCase("")) {
				String mode = invMatchingVO.getPayAccount();
				if (mode != null && !mode.equalsIgnoreCase("")) {
					boolean isValidValueDate = checkeIfValidModeOfRepayment(
							invMatchingVO.getBatch_ID(), mode, con);
					if (isValidValueDate == false) {
						String errormsg = "Changes in original selection. Kindly reprocess again.";
						Object arg[] = { 0, E, errormsg, INPUT };
						setErrorvalues(arg);
					}
				}
			}

			if (alertMsgArray.size() > 0) {
				invMatchingVO.setErrorList(alertMsgArray);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			logger.info(ActionConstants.EXITING_METHOD);
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		return invMatchingVO;
	}

	/**
	 * 
	 * @param batchID
	 * @return
	 * @throws DAOException
	 */
	public boolean checkeIfValidValueDate(String batchID, String valueDate,
			Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		boolean result = false;
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement stmt = null;
		try {
			if (valueDate != null) {
				valueDate = valueDate.trim();
			}
			if (batchID != null) {
				batchID = batchID.trim();
			}
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			stmt = new LoggableStatement(con,
					"SELECT COUNT(VALUE_DATE) as COUNT FROM ETT_STP_REPAYMENT "
							+ "WHERE TRIM(BATCH_ID)='" + batchID
							+ "' AND VALUE_DATE <> TO_CHAR(TO_DATE('" + valueDate
							+ "','DD-MM-YY'))");
			rs = stmt.executeQuery();
			System.out.println("Checke Value Date--------->"
					+ stmt.getQueryString());
			logger.info("Checke Value Date--------->" + stmt.getQueryString());
			if (rs.next()) {
				int count = rs.getInt("COUNT");
				if (count <= 0) {
					result = true;
				}
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, stmt);
			logger.info(ActionConstants.EXITING_METHOD);
		}
		return result;

	}

	/**
	 * 
	 * @param loanAccountNumber
	 * @return
	 * @throws DAOException
	 */
	private boolean fetchValidUTRNo(String loanAccountNumber, Connection con)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		boolean result = true;
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String sql = null;
		int count = 0;
		try {
			if (con == null)
				con = DBConnectionUtility.getConnection();
			if (loanAccountNumber != null) {
				loanAccountNumber = loanAccountNumber.trim();
			}
			/* sql = CHECK_REPAY_ACCOUNT + loanAccountNumber + "' "; */
			/*
			 * sql =
			 * "select COUNT(*) as COUNT  from ett_rtnf_inward inw,ETT_STP_REPAYMENT rep where trim(upper(rep.REFERENCE_NUMBER))=trim(upper(inw.utr_number)) "
			 * +
			 * "and rep.STATUS_FLAG IN ('CA','MA') and inw.status in ('S','MA','MR') and trim(upper(rep.REFERENCE_NUMBER))='"
			 * +loanAccountNumber.trim().toUpperCase()+"' ";
			 */
			sql = "SELECT COUNT(REFERENCE_NUMBER) as COUNT FROM ETT_STP_REPAYMENT  where "
					+ "trim(upper(REFERENCE_NUMBER))='"
					+ loanAccountNumber.trim().toUpperCase()
					+ "' AND STATUS_FLAG IN ('CA','MA') ";
			pst = new LoggableStatement(con, sql);
			System.out.println("loan account number" + pst.getQueryString());
			rs = pst.executeQuery();
			if (rs.next()) {
				count = rs.getInt(COUNT);
			}
			if (count > 0) {
				result = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		logger.info(EXITING_METHOD);
		return result;
	}

	/**
	 * 
	 * @param loanAccountNumber
	 * @return
	 * @throws DAOException
	 */
	private boolean fetchUploadValidUTRNo(String loanAccountNumber,
			Connection con) throws DAOException {
		logger.info(ENTERING_METHOD);
		boolean result = true;
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String sql = null;
		int count = 0;
		try {
			if (con == null)
				con = DBConnectionUtility.getConnection();
			if (loanAccountNumber != null) {
				loanAccountNumber = loanAccountNumber.trim();
			}
			/* sql = CHECK_REPAY_ACCOUNT + loanAccountNumber + "' "; */
			/*
			 * sql =
			 * "select COUNT(*) as COUNT  from ett_rtnf_inward inw,ETT_STP_REPAYMENT rep where trim(upper(rep.REFERENCE_NUMBER))=trim(upper(inw.utr_number)) "
			 * +
			 * "and rep.STATUS_FLAG IN ('CA','MA') and inw.status in ('S','MA','MR') and trim(upper(rep.REFERENCE_NUMBER))='"
			 * +loanAccountNumber.trim().toUpperCase()+"' ";
			 */
			sql = "SELECT COUNT(utr_number) as COUNT FROM ett_rtnf_inward  where trim(upper(utr_number))='"
					+ loanAccountNumber.trim().toUpperCase()
					+ "' AND STATUS IN ('S','CA','P','MA') AND TRIM(error_description)='S' ";
			pst = new LoggableStatement(con, sql);
			System.out.println("loan account number" + pst.getQueryString());
			rs = pst.executeQuery();
			if (rs.next()) {
				count = rs.getInt(COUNT);
			}
			if (count > 0) {
				result = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		logger.info(EXITING_METHOD);
		return result;
	}

	/**
	 * 
	 * @param batchID
	 * @return
	 * @throws DAOException
	 */
	public boolean checkeIfValidModeOfRepayment(String batchID,
			String valueDate, Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		boolean result = true;
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement stmt = null;
		try {
			if (valueDate != null) {
				valueDate = valueDate.trim();
			}
			if (batchID != null) {
				batchID = batchID.trim();
			}
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			stmt = new LoggableStatement(con,
					"SELECT COUNT(REPAYMENT_ACCOUNT_NO) as COUNT FROM ETT_STP_REPAYMENT "
							+ "WHERE TRIM(BATCH_ID)='" + batchID
							+ "' AND TRIM(REPAYMENT_ACCOUNT_NO)='" + valueDate
							+ "' ");
			rs = stmt.executeQuery();
			System.out.println("Checke Value Date--------->"
					+ stmt.getQueryString());
			logger.info("Checke Value Date--------->" + stmt.getQueryString());
			if (rs.next()) {
				int count = rs.getInt("COUNT");
				if (count <= 0) {
					result = false;
				}
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, stmt);
			logger.info(ActionConstants.EXITING_METHOD);
		}
		return result;

	}

	public static void main(String args[]) throws DAOException, ParseException {
		Connection con = null;
		try {
			// InvoiceMatchingDAO dao = InvoiceMatchingDAO.getDAO();
			// dao.checkRepaymentExcess("8262", con);
			
			/*BigDecimal interestAmount = new BigDecimal("1000.0");
			BigDecimal penalAmount = new BigDecimal("00");
			System.out.println(interestAmount.compareTo(BigDecimal.ZERO));
			System.out.println(penalAmount.compareTo(BigDecimal.ZERO));
			if (interestAmount.compareTo(BigDecimal.ZERO) != 0) {

			}
			if (penalAmount.compareTo(BigDecimal.ZERO) != 0) {

			}*/
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}
	}

	public InvMatchingVO getCheckerValidate(InvMatchingVO invMatchingVO)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods comm = new CommonMethods();
		try {
			if (alertMsgArray != null) {
				if (alertMsgArray.size() > 0) {
					alertMsgArray.clear();
				}
			}

			if (!comm.isNull(invMatchingVO.getRepaymentMode())
					&& invMatchingVO.getRepaymentMode().equalsIgnoreCase(
							"Internal Account")) {
				if (!comm.isNull(invMatchingVO.getPayAccount())
						&& !invMatchingVO.getPayAccount().equalsIgnoreCase("")) {
					/**
					 * Fetch Current Account balance
					 */
					try {/*
						 * String availableBalance = GetAccountBalance
						 * .accountBalanceProcess(invMatchingVO
						 * .getPayAccount().trim(), "test"); // String
						 * availableBalance = "10000"; if
						 * (!comm.isNull(invMatchingVO.getPayAmount()) &&
						 * !invMatchingVO.getPayAmount() .equalsIgnoreCase(""))
						 * {
						 * 
						 * if (!comm.isNull(availableBalance) &&
						 * Double.parseDouble(availableBalance) < Double
						 * .parseDouble(CommonMethods .removeComma(invMatchingVO
						 * .getPayAmount()))) { String errormsg =
						 * "Current Account balance is less than payment amount"
						 * ; Object arg[] = { 0, E, errormsg, INPUT };
						 * setErrorvalues(arg); } else if
						 * (comm.isNull(availableBalance)) { String errormsg =
						 * "Insufficient Current Account Balance"; Object arg[]
						 * = { 0, E, errormsg, INPUT }; setErrorvalues(arg); }
						 * 
						 * }
						 */
					} catch (Exception e) {
						String errormsg = "Invalid Current Account";
						Object arg[] = { 0, E, errormsg, INPUT };
						setErrorvalues(arg);
					}
				}

			}

			if (alertMsgArray.size() > 0) {
				invMatchingVO.setErrorList(alertMsgArray);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			logger.info(ActionConstants.EXITING_METHOD);
		}
		return invMatchingVO;
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @param tiListsDetail
	 * @return
	 * @throws DAOException
	 */
	public InvMatchingVO getDealRefValidate(InvMatchingVO invMatchingVO,
			ArrayList<InvMatchingVO> tiListsDetail) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		String masterRef = null;
		String errorList = null;
		CommonMethods com = null;
		int dealCount = 0;
		String dealRef = null;
		Connection con = null;
		double allocatedAmount = 0;
		double allocatedSumAmount = 0;
		int force_closure_count = 0;
		double osAmount = 0;
		String force_closure_dealref = null;
		String valueDateDealref = null;
		int valueDateCount = 0;
		int dealValueCount = 0;
		try {
			con = DBConnectionUtility.getConnection();
			com = new CommonMethods();
			if (alertMsgArray != null) {
				if (alertMsgArray.size() > 0) {
					alertMsgArray.clear();
				}
			}
			int count = 0;
			String errormsg = "Repayment has been submitted already for the following loan master reference number(s) given below.\n";
			for (int i = 0; i < tiListsDetail.size(); i++) {
				masterRef = com.nullAndTrimString(tiListsDetail.get(i)
						.getMasterRef());
				allocatedAmount = Double.parseDouble(CommonMethods.removeComma(tiListsDetail
						.get(i).getAllocAmt()));
				//System.out.println("allocatedAmount--------------->"+allocatedAmount);
				allocatedSumAmount = allocatedSumAmount + allocatedAmount;
				
				/*if (Double.parseDouble(CommonMethods.removeComma(tiListsDetail
						.get(i).getAllocAmt())) > 0) {
					dealCount = com.checkDealRef(masterRef, con);
					if (dealCount > 0) {
						if (dealRef == null) {
							dealRef = masterRef;
						} else {
							dealRef = dealRef + "," + masterRef;
						}
						count = count + 1;
						System.out.println("Already repaid count" + count);
					}
				}*/
				
				/*if (Double.parseDouble(CommonMethods.removeComma(tiListsDetail
						.get(i).getAllocAmt())) > 0) {
					dealValueCount = com.checkValueDate(masterRef, con,invMatchingVO.getBatch_ID());
					if (dealValueCount > 0) {
						if (valueDateDealref == null) {
							valueDateDealref = masterRef;
						} else {
							valueDateDealref = valueDateDealref + "," + masterRef;
						}
						valueDateCount = valueDateCount + 1;
						System.out.println("Already repaid count" + count);
					}
				}*/
				
				osAmount = Double.parseDouble(CommonMethods.removeComma(tiListsDetail
						.get(i).getOutAmount()));
				if (invMatchingVO.getRepayType() != null
						&& !invMatchingVO.getRepayType().equalsIgnoreCase("RE")) {
					if (allocatedAmount > 0) {
						if (allocatedAmount != osAmount) {
							if (force_closure_dealref == null) {
								force_closure_dealref = masterRef;
							} else {
								force_closure_dealref = force_closure_dealref
										+ "," + masterRef;
							}
							force_closure_count = force_closure_count + 1;
						}
					}
				}
				
			}
			
			
			
			dealCount = com.checkDealRefAlreadyPending(invMatchingVO.getBatch_ID(), con);
			if (dealCount > 0) {
				System.out.println("Already repaid count" + errormsg);
				errormsg = errormsg + dealRef;
				Object arg[] = { 0, E, errormsg, "REPAY" };
				setErrorvalues(arg);
			}
			
			String programType = fetchProgramType(invMatchingVO.getProgId(), con);
			if (programType != null && programType.equalsIgnoreCase("S")){
			if (force_closure_count > 0) {
				Object arg[] = { 0, E, "Force capitalization repayment should be a full repayment for these loans - "+force_closure_dealref+"", "VALIDATION" };
				setErrorvalues(arg);
			}
			}

			/*
			 * valueDateCount =
			 * com.checkValueDateDisbursement(con,invMatchingVO.getBatch_ID()); if
			 * (valueDateCount > 0 ) { Object arg[] = { 0, E,
			 * "Value date should not be less than disbursement date - "+valueDateDealref+
			 * "", "VALIDATION" }; setErrorvalues(arg); }
			 */
			
			if (allocatedSumAmount <= 0 ) {
				Object arg[] = { 0, E, "Repayment Amount not allocated to any invoices", "VALIDATION" };
				setErrorvalues(arg);
			}
			
			if (alertMsgArray.size() > 0) {
				invMatchingVO.setErrorList(alertMsgArray);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} 
		//Connection Leak
		finally {
			DBConnectionUtility.surrenderDB(null, null, con);
			logger.info(ActionConstants.EXITING_METHOD);
		}
		//Connection Leak
		
		return invMatchingVO;
	}

	@SuppressWarnings("static-access")
	public InvMatchingVO getDealRefWarning(InvMatchingVO invMatchingVO,
			ArrayList<InvMatchingVO> tiListsDetail) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		String masterRef = null;
		String errorList = null;
		CommonMethods com = null;
		int dealCount = 0;
		String dealRef = null;
		ValidatorDAO valdo = null;
		String masterRefTemp = null;
		Connection con = null;
		try {
			valdo = new ValidatorDAO();
			com = new CommonMethods();
			if (alertMsgArray != null) {
				if (alertMsgArray.size() > 0) {
					alertMsgArray.clear();
				}
			}
			int count = 0;
			int excessCount = 0;
			int excessAccount = 0;
			int excessError = 0;
			con = DBConnectionUtility.getConnection();
			BigDecimal amount = new BigDecimal(0);
			BigDecimal paymentAmt = new BigDecimal(
					CommonMethods.removeComma(invMatchingVO.getPayAmount()));
			String errormsg = "Warning - Already transaction happened for the following loan master reference number(s) given below.\n";
			for (int i = 0; i < tiListsDetail.size(); i++) {
				int size = tiListsDetail.size() - 1;
				masterRef = com.nullAndTrimString(tiListsDetail.get(i)
						.getMasterRef());

				if (Double.parseDouble(CommonMethods.removeComma(tiListsDetail
						.get(i).getAllocAmt())) > 0) {

					BigDecimal allocationAmount = new BigDecimal(
							CommonMethods.removeComma(tiListsDetail.get(i)
									.getAllocAmt()));
					BigDecimal outStandingAmount = new BigDecimal(
							CommonMethods.removeComma(tiListsDetail.get(i)
									.getOutAmount()));
					/*
					 * if (masterRefTemp == null ||
					 * masterRefTemp.equalsIgnoreCase("")) {
					 */
					masterRefTemp = com.nullAndTrimString(tiListsDetail.get(i)
							.getMasterRef());
					excessAccount = excessAccount + 1;
					if (allocationAmount.compareTo(outStandingAmount) >= 0) {

					} else {
						excessError = excessError + 1;
					}
					/* } */

					double paymentAmount = Double.parseDouble(CommonMethods
							.removeComma(tiListsDetail.get(i).getAllocAmt()));
					String valueDate = invMatchingVO.getValueDate();
					java.sql.Date sqlDate = null;
					if (valueDate != null) {
						SimpleDateFormat format = new SimpleDateFormat(
								"dd-MM-yyyy");
						Date parsed = format.parse(valueDate);
						sqlDate = new java.sql.Date(parsed.getTime());
					}

					/*dealCount = com.checkDealandReference(masterRef,
							invMatchingVO.getReferenceNumber(), paymentAmount,
							sqlDate, con);
					if (dealCount > 0) {
						if (dealRef == null) {
							dealRef = masterRef;
						} else {
							dealRef = dealRef + "," + masterRef;
						}
						count = count + 1;
					}*/
					BigDecimal sumAlloc = new BigDecimal(
							CommonMethods.removeComma(tiListsDetail.get(i)
									.getAllocAmt().trim()));
					amount = amount.add(sumAlloc);
				}

			}
			if (excessCount == 0 && excessAccount > 0) {
				if (!CommonMethods.bitwiseEqualsWithCanonicalNaN(amount,
						paymentAmt)) {
					if (excessError == 0) {

						/*
						 * boolean outstanding = checkRepaymentExcess(
						 * invMatchingVO.getBatch_ID(), con);
						 */
						/*
						 * if (outstanding == false) { paymentAmt =
						 * paymentAmt.subtract(amount); Object arg[] = { 0, F,
						 * "Allocation Amount (  Rs. "+
						 * paymentAmt+")  mismatch - less than the Payment amount "
						 * ,INPUT }; setErrorvalues(arg); } else {
						 */
						paymentAmt = paymentAmt.subtract(amount);
						com.insertAuditTrail(invMatchingVO.getBatch_ID(),
								masterRefTemp, con);
						Object arg[] = {
								0,
								W,
								"Excess Amount of Rs. " + paymentAmt
										+ " allocated to " + masterRefTemp,
								"REPAY" };
						setWarningvalues(arg);
						// }
					} else {
						paymentAmt = paymentAmt.subtract(amount);
						Object arg[] = {
								0,
								F,
								"Excess Amount of Rs. " + paymentAmt
										+ " is not allocated any transactions",
								INPUT };
						setErrorvalues(arg);
					}
				}
				excessCount = excessCount + 1;
			}
			/*if (count > 0) {
				errormsg = errormsg + dealRef;
				Object arg[] = { 0, W, errormsg, "REPAY" };
				setWarningvalues(arg);
			}*/

			if (alertMsgArray.size() > 0) {
				invMatchingVO.setErrorList(alertMsgArray);
			}
			if (alertWarningMsgArray.size() > 0) {
				invMatchingVO.setWarningList(alertWarningMsgArray);
			}

		} catch (Exception exception) {
			System.out.println("Warning exception----->"
					+ exception.getMessage());
			throwDAOException(exception);
		} finally {
			logger.info(ActionConstants.EXITING_METHOD);
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		return invMatchingVO;
	}

	/**
	 * 
	 * @param batchID
	 * @return
	 * @throws DAOException
	 */
	public boolean checkRepaymentExcess(String batchID, Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		boolean result = true;
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement stmt = null;
		int count = 0;
		try {
			if (batchID != null) {
				batchID = batchID.trim();
			}
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			stmt = new LoggableStatement(
					con,
					"select sum(os_amount)-sum(prc_allc_amount) as OUTSTANDING,BATCH_ID from ett_stp_repayment where BATCH_ID='"
							+ batchID
							+ "' "
							+ "and due_date<(SELECT PROCDATE FROM DLYPRCCYCL) group by BATCH_ID");
			rs = stmt.executeQuery();
			System.out.println("Checke Value Date--------->"
					+ stmt.getQueryString());
			logger.info("Checke Value Date--------->" + stmt.getQueryString());
			if (rs.next()) {
				BigDecimal outstanding = new BigDecimal(
						rs.getInt("OUTSTANDING"));
				if (outstanding.compareTo(BigDecimal.ZERO) == 0) {
					count = count + 1;
				}
				if (count <= 0) {
					result = false;
				}
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, stmt);
			logger.info(ActionConstants.EXITING_METHOD);
		}
		return result;

	}

	public InvMatchingVO getWSDLValidate(InvMatchingVO invMatchingVO)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods comm = new CommonMethods();
		InvoiceMatchingProcess invProcess = null;
		String programType = null;
		String prgID = null;
		try {
			if (alertMsgArray != null) {
				if (alertMsgArray.size() > 0) {
					alertMsgArray.clear();
				}
			}
			invProcess = InvoiceMatchingProcess.getBD();
			prgID = invMatchingVO.getProgId().trim();
			programType = invProcess.getProgramType(prgID);
			System.out.println(invMatchingVO.getCounterParty());
			if (comm.isNull(invMatchingVO.getProgId())
					|| invMatchingVO.getProgId().equalsIgnoreCase("")) {
				String errormsg = "Program id must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}
			if (comm.isNull(invMatchingVO.getPayAmount())
					|| invMatchingVO.getPayAmount().equalsIgnoreCase("")) {
				String errormsg = "Payment amount must be needed";
				Object arg[] = { 0, E, errormsg, INPUT };
				setErrorvalues(arg);
			}
			/*
			 * System.out.println("banklist-->"+invMatchingVO.getBankList());
			 * System
			 * .out.println("repayment tc-->"+invMatchingVO.getRepaymentTC());
			 * if(comm.isNull(invMatchingVO.getRepaymentTC())||invMatchingVO.
			 * getRepaymentTC().equalsIgnoreCase("")){ String errormsg =
			 * "Repayment TC must be needed"; Object arg[] = { 0, E, errormsg,
			 * INPUT }; setErrorvalues(arg); }
			 */
			if (programType != null && programType.equalsIgnoreCase("S")) {
				/*
				 * if (invMatchingVO.getCounterParty() == null ||
				 * invMatchingVO.getCounterParty().equalsIgnoreCase("")) {
				 * String errormsg =
				 * "Counter Party is mandatory for dealer finance"; Object arg[]
				 * = { 0, E, errormsg, INPUT }; setErrorvalues(arg); }
				 */
			} else {
				invMatchingVO.setCounterParty("-1");
			}

			if (alertMsgArray.size() > 0) {
				invMatchingVO.setErrorList(alertMsgArray);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			logger.info(ActionConstants.EXITING_METHOD);
		}
		return invMatchingVO;
	}

	public String getEventListQuery(InvMatchingVO invMatchingVO) {
		CommonMethods commonMethods = null;
		String SCF_QUERY = "SELECT * FROM SCFPROGRAM,ETT_CLF_PROGRAMPARAMETERS WHERE SCFPROGRAM.ID=ETT_CLF_PROGRAMPARAMETERS.PROIDEN AND SCFPROGRAM.KEY97 = SCFPROGRAM.KEY97";
		commonMethods = new CommonMethods();

		if (invMatchingVO != null) {
			if (!commonMethods.isNull(invMatchingVO.getPrgIdentifier())) {
				SCF_QUERY += SQL_AND + " SCFPROGRAM.ID LIKE '"
						+ invMatchingVO.getPrgIdentifier().trim().toUpperCase()
						+ "%' ";
			}
			if (!commonMethods.isNull(invMatchingVO.getPrgName())) {
				SCF_QUERY += SQL_AND + " SCFPROGRAM.DESCR LIKE '"
						+ invMatchingVO.getPrgName().trim().toUpperCase()
						+ "%' ";
			}
			if (!commonMethods.isNull(invMatchingVO.getPrgCust())) {
				SCF_QUERY += SQL_AND + " SCFPROGRAM.CUSTOMER LIKE '"
						+ invMatchingVO.getPrgCust().trim().toUpperCase()
						+ "%' ";
			}
			if (!invMatchingVO.getPrgType().equalsIgnoreCase("-1")) {
				SCF_QUERY += SQL_AND + " SCFPROGRAM.PROG_TYPE ='"
						+ invMatchingVO.getPrgType().trim() + "' ";
			}
			if (!invMatchingVO.getExposure().equalsIgnoreCase("-1")) {
				SCF_QUERY += SQL_AND + " ETT_CLF_PROGRAMPARAMETERS.EXPANC ='"
						+ invMatchingVO.getExposure().trim() + "' ";
			}
			if (!invMatchingVO.getDisburse().equalsIgnoreCase("-1")) {
				SCF_QUERY += SQL_AND + " ETT_CLF_PROGRAMPARAMETERS.DISBUR ='"
						+ invMatchingVO.getDisburse().trim() + "' ";
			}
			if (!invMatchingVO.getScfProductType().equalsIgnoreCase("-1")) {
				SCF_QUERY += SQL_AND
						+ " ETT_CLF_PROGRAMPARAMETERS.SUBPRODUCTTYPE ='"
						+ invMatchingVO.getScfProductType().trim() + "'";
			}
		}
		System.out.println(SCF_QUERY);
		return SCF_QUERY;
	}

	public ArrayList<InvMatchingVO> getProgrammeList(InvMatchingVO invMatchingVO) {
		logger.info(ActionConstants.ENTERING_METHOD);
		ArrayList<InvMatchingVO> programList = new ArrayList<InvMatchingVO>();

		Connection con = null;
		CommonMethods commonMethods = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			commonMethods = new CommonMethods();
			String query = getEventListQuery(invMatchingVO);
			pst = new LoggableStatement(con, query);
			pst.getQueryString();
			rs = pst.executeQuery();

			while (rs.next()) {
				InvMatchingVO invvo = new InvMatchingVO();
				invvo.setKey(rs.getString(KEY));
				invvo.setCustomer(rs.getString(CUSTOMER));
				invvo.setProgrammename(rs.getString(PROGRAMME_NAME));
				invvo.setProgrammeidentifier(rs.getString(PROGRAMME_IDENTIFIER));
				String tempPrgType = commonMethods.getEmptyIfNull(
						rs.getString(PROGRAMME_TYPE)).trim();
				String tempSubType = commonMethods.getEmptyIfNull(
						rs.getString(SUB_TYPE)).trim();

				if (tempPrgType.equalsIgnoreCase("B")) {
					invvo.setTempPrgType("Vendor Finance");
				}
				if (tempPrgType.equalsIgnoreCase("S")) {
					invvo.setTempPrgType("Dealer Finance");
				}
				if (tempSubType.equalsIgnoreCase("R")) {
					invvo.setTempPrgSubType("Vendor Centric Finance");
				}
				if (tempSubType.equalsIgnoreCase("D")) {
					invvo.setTempPrgSubType("Dealer Centric Finance");
				}

				String subProductType = commonMethods.getEmptyIfNull(rs
						.getString("SUBPRODUCTTYPE"));

				if (subProductType.equalsIgnoreCase("BP")) {
					subProductType = "BOE-Payable";
				}
				if (subProductType.equalsIgnoreCase("IP")) {
					subProductType = "Invoice Payable";
				}

				if (subProductType.equalsIgnoreCase("PP")) {
					subProductType = "PO Payable";
				}

				if (subProductType.equalsIgnoreCase("BR")) {
					subProductType = "BOE-Receivable";
				}

				if (subProductType.equalsIgnoreCase("IR")) {
					subProductType = "Invoice Receivable";
				}

				if (subProductType.equalsIgnoreCase("PR")) {
					subProductType = "PO Receivable";
				}

				if (subProductType.equalsIgnoreCase("PO")) {
					subProductType = "PO";
				}
				if (subProductType.equalsIgnoreCase("IN")) {
					subProductType = "Invoice";
				}
				invvo.setProgrammetype(rs.getString(PROGRAMME_TYPE));
				invvo.setSubtype(rs.getString(SUB_TYPE));
				invvo.setScfProductType(subProductType);
				invvo.setExposureon(rs.getString(EXPOSURE));
				invvo.setFlagremoval(rs.getString(FLAG_REMOVAL));
				invvo.setDesc(rs.getString("DESCR"));
				programList.add(invvo);
			}
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return programList;
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 */
	public String fetchBatchListQuery(InvMatchingVO invMatchingVO) {
		CommonMethods commonMethods = null;
		String userId = null;
		HttpSession session = ServletActionContext.getRequest().getSession();
		String BATCH_QUERY = "SELECT DISTINCT BATCH_ID, PROGRAM_ID,TO_CHAR(TO_DATE(VALUE_DATE, 'dd-mm-yy'),'dd-mm-yyyy') as VALUE_DATE,"
				+ "initateby,txn_id,STATUS_FLAG,C.GFCUN COUNTER_PARTY FROM ETT_STP_REPAYMENT I,GFPF C ";

		// + "WHERE TRIM(STATUS_FLAG)='MA' ";
		commonMethods = new CommonMethods();
		String rejectList = (String) session.getAttribute(REJECTLIST);
		userId = (String) session.getAttribute(LOGINUSER);
		if (userId == null) {
			userId = "";
		} else {
			userId = userId.trim();
		}
		if (commonMethods.isNull(rejectList)
				|| !rejectList.equalsIgnoreCase(REJECT)) {
			BATCH_QUERY = BATCH_QUERY
					+ "WHERE TRIM(I.COUNTER_PARTY)=TRIM(C.GFCUS1) AND TRIM(STATUS_FLAG)='MA' AND GW_STATUS IS NULL AND"
					+ " (TRIM(MAKER_ID) IS NULL OR TRIM(MAKER_ID) !='" + userId
					+ "') ";
		} else if (rejectList.equalsIgnoreCase(REJECT)) {
			BATCH_QUERY = BATCH_QUERY
					+ "WHERE TRIM(I.COUNTER_PARTY)=TRIM(C.GFCUS1) AND STATUS_FLAG is not null ";
		}

		if (invMatchingVO != null) {
			if (!commonMethods.isNull(invMatchingVO.getProgId())) {
				BATCH_QUERY += SQL_AND + " PROGRAM_ID LIKE '"
						+ invMatchingVO.getProgId().trim().toUpperCase()
						+ "%' ";
			}
			if (!commonMethods.isNull(invMatchingVO.getFilterBatch())) {
				BATCH_QUERY += SQL_AND + " BATCH_ID LIKE '"
						+ invMatchingVO.getFilterBatch().trim() + "%' ";
			}
			if (!commonMethods.isNull(invMatchingVO.getsCounterParty())) {
				BATCH_QUERY += SQL_AND + " UPPER(C.GFCUN) LIKE '"
						+ invMatchingVO.getsCounterParty().trim().toUpperCase()
						+ "%' ";
			}
		}

		/*
		 * BATCH_QUERY +=
		 * " AND GW_STATUS IS NULL AND (TRIM(MAKER_ID) IS NULL OR TRIM(MAKER_ID) !='"
		 * + userId + "') ";
		 */
		System.out.println("BATCH_QUERY" + BATCH_QUERY);
		return BATCH_QUERY + " ORDER BY TO_NUMBER(BATCH_ID) DESC ";

	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 * @throws DAOException
	 */
	public ArrayList<InvMatchingVO> fetchInvoiceBatches(
			InvMatchingVO invMatchingVO) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ArrayList<InvMatchingVO> batchList = new ArrayList<InvMatchingVO>();
		Connection con = null;
		CommonMethods commonMethods = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			commonMethods = new CommonMethods();
			String query = fetchBatchListQuery(invMatchingVO);
			pst = new LoggableStatement(con, query);
			pst.getQueryString();
			rs = pst.executeQuery();
			while (rs.next()) {
				InvMatchingVO invvo = new InvMatchingVO();
				invvo.setTempbatchID(commonMethods.getEmptyIfNull(rs
						.getString("BATCH_ID")));
				invvo.setTempProgram(commonMethods.getEmptyIfNull(rs
						.getString("PROGRAM_ID")));
				invvo.setTempValueDate(commonMethods.getEmptyIfNull(rs
						.getString("VALUE_DATE")));
				String initiateBy = commonMethods.getEmptyIfNull(rs
						.getString("initateby"));
				if (initiateBy != null && initiateBy.equalsIgnoreCase("")) {
					initiateBy = "Manual Process";
				} else {
					initiateBy = "Auto Process";
				}
				invvo.setIntiateType(initiateBy);
				invvo.setTransBatch(commonMethods.getEmptyIfNull(rs
						.getString("txn_id")));
				String status_flag = commonMethods.getEmptyIfNull(rs
						.getString("STATUS_FLAG"));
				if (status_flag != null && status_flag.equalsIgnoreCase("MA")) {
					status_flag = "Maker Approved";
				} else if (status_flag != null
						&& status_flag.equalsIgnoreCase("CA")) {
					status_flag = "Checker Approved";
				} else if (status_flag != null
						&& status_flag.equalsIgnoreCase("MR")) {
					status_flag = "Maker Rejected";
				} else if (status_flag != null
						&& status_flag.equalsIgnoreCase("CR")) {
					status_flag = "Checker Rejected";
				} else {
					status_flag = "Checker Approved";
				}
				invvo.setStatusFlag(status_flag);
				invvo.setTempCounterParty(rs.getString("COUNTER_PARTY"));
				batchList.add(invvo);
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return batchList;
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 */
	public ArrayList<InvMatchingVO> fetchDetailedBatch(String batchID) {
		logger.info(ActionConstants.ENTERING_METHOD);
		ArrayList<InvMatchingVO> batchList = new ArrayList<InvMatchingVO>();
		try {
			batchList = fetchInvoiceList(batchID);
		} catch (Exception e) {
			System.out.println(e);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return batchList;
	}

	public InvMatchingVO fetchPenalDetailedBatch(InvMatchingVO invMatchVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		try {
			invMatchVo = fetchPenalList(invMatchVo);
		} catch (Exception e) {
			System.out.println(e);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchVo;
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 * @throws DAOException
	 */
	public String getAccountListQuery(InvMatchingVO invMatchingVO)
			throws DAOException {
		CommonMethods commonMethods = null;
		commonMethods = new CommonMethods();
		String type = "";
		if(invMatchingVO.getTempPrgType()!=null)
		{
		 type = invMatchingVO.getTempPrgType().trim();
		}
		System.out.println("typr ->"+type);
		String buyerMnemonic = null;
		String SCF_QUERY = null;
		System.out.println("-->"+invMatchingVO.getCounterParty().trim());
		SCF_QUERY = "SELECT NVL(TRIM(PRG.OEM_TYPE),'N') AS OEM_TYPE,ETT_CUST_NAME(TRIM(REL.CUSTOMR)) as CPARTYNAME,TRIM(PRG.TYPEOFPGM) as PROGTYPE,REL.REPAY_ACCT_NO AS REPAY_ACCT_NO,REL.PROGIDN PROGIDN,REL.CUSTOMR AS CPARTY,TRIM(PRG.CUSTM) AS CUSTOMR,ETT_CUST_NAME(TRIM(PRG.CUSTM)) as CUSTNAME "
				+ "FROM ETT_CLF_PROGRAMPARAMETERS PRG,ETT_CLF_SELLERBUYERRELATION REL WHERE TRIM(REL.PROGIDN)=TRIM(PRG.PROIDEN) "
				+ " AND REL.REPAY_ACCT_NO IS NOT NULL";
		if (type.equalsIgnoreCase(S)) {
			buyerMnemonic = commonMethods.getEmptyIfNull(
					invMatchingVO.getCounterParty()).trim();
		} else {
			buyerMnemonic = commonMethods.getEmptyIfNull(
					invMatchingVO.getDebitParty()).trim();
		}
		String programID = commonMethods.getEmptyIfNull(
				invMatchingVO.getProgId()).trim();
		if (programID != null && !programID.equalsIgnoreCase("")) {
			SCF_QUERY = SCF_QUERY + " AND TRIM(REL.PROGIDN) LIKE '%"
					+ invMatchingVO.getProgId().trim() + "%'";
		}
		String virtualAccount = commonMethods.getEmptyIfNull(
				invMatchingVO.getVirtualAccount()).trim();
		
		if (virtualAccount != null && !virtualAccount.equalsIgnoreCase("")) {
			SCF_QUERY = SCF_QUERY + " AND TRIM(REL.REPAY_ACCT_NO) LIKE '%"
					+ invMatchingVO.getVirtualAccount().trim() + "%'";
		}
		String customerMnemonic = commonMethods.getEmptyIfNull(
				invMatchingVO.getCustomerMnemonic()).trim();	
		if (customerMnemonic != null && !customerMnemonic.equalsIgnoreCase("")) {
			SCF_QUERY = SCF_QUERY + " AND TRIM(REL.CUSTOMR) LIKE '%"
					+ invMatchingVO.getCustomerMnemonic().trim() + "%'";
		}
		String programName = commonMethods.getEmptyIfNull(
				invMatchingVO.getProgrammename()).trim();
		
		if (programName != null && !programName.equalsIgnoreCase("")) {
			SCF_QUERY = SCF_QUERY
					+ " AND TRIM(upper(ETT_CUST_NAME(TRIM(REL.CUSTOMR)))) LIKE '%"
					+ invMatchingVO.getProgrammename().trim().toUpperCase()
					+ "%'";
		}
		String customerName = commonMethods.getEmptyIfNull(invMatchingVO.getCustomer()).trim();
		
		if (customerName != null && !customerName.equalsIgnoreCase("")) {
			SCF_QUERY = SCF_QUERY
					+ " AND TRIM(upper(ETT_CUST_NAME(TRIM(PRG.CUSTM)))) LIKE '%"
					+ customerName.trim().toUpperCase()
					+ "%'";
		}

		/*
		 * if (type.equalsIgnoreCase(S)) { buyerMnemonic =
		 * commonMethods.getEmptyIfNull(
		 * invMatchingVO.getCounterParty()).trim(); exposure =
		 * getProgramExposure(invMatchingVO.getProgId()); if
		 * (!commonMethods.isNull(exposure) && exposure.equalsIgnoreCase("A")) {
		 * SCF_QUERY = "SELECT * FROM ACCOUNT WHERE TRIM(CUS_MNM) IN ('" +
		 * buyerMnemonic + "','" + commonMethods.getEmptyIfNull(
		 * invMatchingVO.getDebitParty()).trim() + "')  AND ACC_TYPE='CA' "; }
		 * else { SCF_QUERY = "SELECT * FROM ACCOUNT WHERE TRIM(CUS_MNM)='" +
		 * buyerMnemonic + "'  AND ACC_TYPE='CA' "; } } else { buyerMnemonic =
		 * commonMethods.getEmptyIfNull( invMatchingVO.getDebitParty()).trim();
		 * SCF_QUERY = "SELECT * FROM ACCOUNT WHERE TRIM(CUS_MNM)='" +
		 * buyerMnemonic + "'  AND ACC_TYPE='CA' "; }
		 * 
		 * if (invMatchingVO != null) { if
		 * (!commonMethods.isNull(invMatchingVO.getAccountKey())) { SCF_QUERY +=
		 * SQL_AND + " BO_ACCTNO = '" + invMatchingVO.getAccountKey().trim() +
		 * "'"; } if (!commonMethods.isNull(invMatchingVO.getBranchNumber())) {
		 * SCF_QUERY += SQL_AND + " BRCH_MNM = '" +
		 * invMatchingVO.getBranchNumber().trim() + "'"; }
		 * 
		 * }
		 */
		
		if (invMatchingVO != null) {
			if (!commonMethods.isNull(invMatchingVO.getAccountKey())) {
				SCF_QUERY += SQL_AND + " REPAY_ACCT_NO LIKE '"
						+ invMatchingVO.getAccountKey().trim() + "'";
			}
		}
		
		System.out.println(SCF_QUERY);
		return SCF_QUERY;
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 * @throws DAOException
	 */
	public ArrayList<InvMatchingVO> getAccountList(InvMatchingVO invMatchingVO)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ArrayList<InvMatchingVO> accountList = new ArrayList<InvMatchingVO>();
		Connection con = null;
		CommonMethods commonMethods = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		try {
			
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			commonMethods = new CommonMethods();
			String query = getAccountListQuery(invMatchingVO);
			pst = new LoggableStatement(con, query);
			pst.getQueryString();
			rs = pst.executeQuery();
			
			while (rs.next()) {
				InvMatchingVO invvo = new InvMatchingVO();
				invvo.setAccountKey(commonMethods.getEmptyIfNull(
						rs.getString("REPAY_ACCT_NO")).trim());
				invvo.setBranchNumber(commonMethods.getEmptyIfNull(
						rs.getString("PROGIDN")).trim());
				invvo.setCustomerMnemonic(commonMethods.getEmptyIfNull(
						rs.getString("CUSTOMR")).trim());
				invvo.setAccountType(commonMethods.getEmptyIfNull(
						rs.getString("CPARTY")).trim());
				invvo.setCatagory(commonMethods.getEmptyIfNull(
						rs.getString("CPARTYNAME")).trim());
				invvo.setShortName(commonMethods.getEmptyIfNull(
						rs.getString("PROGTYPE")).trim());
				invvo.setCustomer(commonMethods.getEmptyIfNull(
						rs.getString("CUSTNAME")).trim());
				accountList.add(invvo);
			}
		} catch (Exception e) {
			
			
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountList;
	}

	public ArrayList<InvMatchingVO> getAccountList1(InvMatchingVO invMatchingVO)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ArrayList<InvMatchingVO> accountList = new ArrayList<InvMatchingVO>();
		Connection con = null;
		CommonMethods commonMethods = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		String sellerMnemonic = null;
		commonMethods = new CommonMethods();
		try {
			String query = getBankListQuery(sellerMnemonic, invMatchingVO);
			con = DBConnectionUtility.getConnection();
			pst = new LoggableStatement(con, query);
			pst.getQueryString();
			rs = pst.executeQuery();
			while (rs.next()) {
				InvMatchingVO setvo = new InvMatchingVO();
				setvo.setAccountKey(commonMethods.getEmptyIfNull(
						rs.getString("TC")).trim());
				setvo.setBranchNumber(commonMethods.getEmptyIfNull(
						rs.getString("BR_CODE")).trim());
				setvo.setSellerMnemonic(commonMethods.getEmptyIfNull(
						rs.getString("BR_DESC")).trim());
				setvo.setShortName(commonMethods.getEmptyIfNull(
						rs.getString("REC_STATUS")).trim());
				accountList.add(setvo);
			}

		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountList;
	}

	@SuppressWarnings("static-access")
	public String getBankListQuery(String sellerMnemonic,
			InvMatchingVO invMatchingVO) throws DAOException {
		String SCF_QUERY = null;
		CommonMethods CommonMethods = null;

		// InvMatchingVO inv=new InvMatchingVO();
		System.out.println("branch code" + invMatchingVO.getBranchCode());
		System.out.println("branch desc" + invMatchingVO.getBranchDesc());
		System.out.println("branch number" + invMatchingVO.getTransCode());
		try {
			SCF_QUERY = "SELECT * FROM extmfbranch B,extbranchtc TC WHERE TRIM(b.br_code)=TRIM(tc.branch) ";
			System.out.println("Query" + SCF_QUERY);
			if (!CommonMethods.isNull(invMatchingVO.getBranchCode())) {
				SCF_QUERY += SQL_AND + " trim(b.br_code) like '%"
						+ invMatchingVO.getBranchCode().trim().toUpperCase()
						+ "%' ";
			}
			if (!CommonMethods.isNull(invMatchingVO.getBranchDesc())) {
				SCF_QUERY += SQL_AND + " trim(b.br_desc) like '%"
						+ invMatchingVO.getBranchDesc().trim().toUpperCase()
						+ "%' ";
			}
			if (!CommonMethods.isNull(invMatchingVO.getTransCode())) {
				SCF_QUERY += SQL_AND + " trim(tc.tc) like '%"
						+ invMatchingVO.getTransCode().trim().toUpperCase()
						+ "%' ";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SCF_QUERY;
	}

	public String getProgramType(String programId) throws DAOException {

		Connection con = null;
		PreparedStatement ppt = null;
		ResultSet rs = null;
		debitlst = new ArrayList<InvMatchingVO>();
		CommonMethods commonMethods = null;
		String sqlQuery = null;
		String progType = null;

		try {
			commonMethods = new CommonMethods();
			if (commonMethods.isNull(programId)) {
				programId = ActionConstants.EMPTY;
			}
			sqlQuery = "SELECT * FROM SCFPROGRAM WHERE TRIM(ID)='" + programId
					+ "' ";
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ppt = con.prepareStatement(sqlQuery);
			rs = ppt.executeQuery();
			if (rs.next()) {
				progType = commonMethods.getEmptyIfNull(
						rs.getString(PROGRAMME_TYPE)).trim();
			}
		} catch (SQLException e) {

			throwDAOException(e);
		} finally {
			closeSqlRefferance(rs, ppt, con);

		}

		return progType;
	}

	/**
	 * 
	 * @param programId
	 * @return
	 * @throws DAOException
	 */
	public String getProgramExposure(String programId) throws DAOException {

		Connection con = null;
		PreparedStatement ppt = null;
		ResultSet rs = null;
		debitlst = new ArrayList<InvMatchingVO>();
		CommonMethods commonMethods = null;
		String sqlQuery = null;
		String progType = null;

		try {
			commonMethods = new CommonMethods();
			if (commonMethods.isNull(programId)) {
				programId = ActionConstants.EMPTY;
			}
			sqlQuery = "SELECT EXPANC FROM ETT_CLF_PROGRAMPARAMETERS WHERE TRIM(PROIDEN)='"
					+ programId + "' ";
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ppt = con.prepareStatement(sqlQuery);
			rs = ppt.executeQuery();
			if (rs.next()) {
				progType = commonMethods.getEmptyIfNull(rs.getString(EXPANC))
						.trim();
			}
		} catch (SQLException e) {

			throwDAOException(e);
		} finally {
			closeSqlRefferance(rs, ppt, con);

		}

		return progType;
	}

	/**
	 * 
	 * @param programId
	 * @return
	 * @throws DAOException
	 */
	public String fetchExposure(String programId) throws DAOException {
		logger.info(ENTERING_METHOD);
		Connection con = null;
		PreparedStatement ppt = null;
		ResultSet rs = null;
		debitlst = new ArrayList<InvMatchingVO>();
		CommonMethods commonMethods = null;
		String sqlQuery = null;
		String progType = null;
		try {
			commonMethods = new CommonMethods();
			if (!commonMethods.isNull(programId)
					&& !programId.equalsIgnoreCase("")) {
				programId = programId.trim();
			}
			sqlQuery = "SELECT EXPANC FROM ETT_CLF_PROGRAMPARAMETERS WHERE PROIDEN='"
					+ programId + "' ";
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ppt = con.prepareStatement(sqlQuery);
			rs = ppt.executeQuery();
			if (rs.next()) {
				progType = commonMethods.getEmptyIfNull(rs.getString(EXPANC))
						.trim();
			}
		} catch (SQLException e) {

			throwDAOException(e);
		} finally {
			closeSqlRefferance(rs, ppt, con);

		}
		logger.info(EXITING_METHOD);
		return progType;
	}

	public ArrayList<InvMatchingVO> getProgram() throws DAOException {

		Connection con = null;
		PreparedStatement ppt = null;
		ResultSet rs = null;
		programlst = new ArrayList<InvMatchingVO>();
		String debitParty = null;
		InvMatchingVO invoiceVO = null;
		String sqlQuery = null;

		try {
			System.out.println("enterdao");
			sqlQuery = "select trim(id) as ID,trim(DESCR) as DESCR from SCFPROGRAM";
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			 System.out.println("con->"+con);
			ppt = con.prepareStatement(sqlQuery);
			System.out.println("Get Program ID " + sqlQuery);
			rs = ppt.executeQuery();

			while (rs.next()) {
				invoiceVO = new InvMatchingVO();
				String id = rs.getString("ID");
				String descr = rs.getString("DESCR");
				String temp = id + "-" + descr;
				invoiceVO.setKey(id.toString());
				invoiceVO.setValue(temp.toString());
				programlst.add(invoiceVO);
			}
		} catch (SQLException e) {

			throwDAOException(e);
		} finally {
			closeSqlRefferance(rs, ppt, con);

		}

		return programlst;
	}

	/**
	 * 
	 * @param invoiceVO
	 * @return
	 * @throws Exception
	 */
	public InvMatchingVO fetchInvoiceDetails(InvMatchingVO invoiceVO,
			String batchID) throws Exception {
		Connection con = null;
		PreparedStatement ppt = null;
		ResultSet rs = null;
		String sqlQuery = null;
		CommonMethods comm = null;
		try {
			comm = new CommonMethods();
			/*
			 * sqlQuery =
			 * "SELECT * FROM ETT_STP_REPAYMENT_MAKER WHERE TRIM(BATCH_ID)='" +
			 * batchID.trim() + "'";
			 */
			sqlQuery = "SELECT DISTINCT SEARCH.BATCH_ID,SEARCH.REMARKS,CONFIRM.* FROM ETT_STP_REPAYMENT SEARCH,"
					+ "ETT_STP_REPAYMENT_MAKER CONFIRM WHERE CONFIRM.BATCH_ID = SEARCH.BATCH_ID AND "
					+ "SEARCH.BATCH_ID='" + batchID.trim() + "'";
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ppt = con.prepareStatement(sqlQuery);
			rs = ppt.executeQuery();
			if (rs.next()) {
				invoiceVO = new InvMatchingVO();
				invoiceVO.setProgrammeidentifier(comm.getEmptyIfNull(
						rs.getString("PROGRAM_ID")).trim());
				String programID = comm.getEmptyIfNull(
						rs.getString("PROGRAM_ID")).trim();
				invoiceVO.setDebitParty(comm.getEmptyIfNull(
						rs.getString("ANCHOR_PARTY")).trim());
				String counterParty = comm.getEmptyIfNull(
						rs.getString("COUNTER_PARTY")).trim();
				if (programID != null) {
					String debitFullName = fetchDebitParty(programID);
					invoiceVO.setDebitPartyFullName(debitFullName.trim());
				}
				counterParty = comm.fetchCounterPartyName(counterParty);
				invoiceVO.setCounterParty(counterParty);
				String repaymentMode = comm.getEmptyIfNull(
						rs.getString("MODE_REPAYMENT")).trim();
				if (repaymentMode != null
						&& repaymentMode.equalsIgnoreCase("RT")) {
					repaymentMode = "RTGS";
				} else if (repaymentMode.equalsIgnoreCase("NT")) {
					repaymentMode = "NEFT";
				} else if (repaymentMode.equalsIgnoreCase("IA")) {
					repaymentMode = "Internal Account";
				} else if (repaymentMode.equalsIgnoreCase("CQ")) {
					repaymentMode = "Cheque";
				}
				invoiceVO.setRepaymentMode(repaymentMode);
				invoiceVO.setPayAccount(comm.getEmptyIfNull(
						rs.getString("REPAYMENT_ACCOUNT_NO")).trim());
				invoiceVO.setValueDate(comm.getEmptyIfNull(
						rs.getString("VALUE_DATE")).trim());
				NumberFormat formatter = new DecimalFormat("#0.00");
				String payAmount = comm.getEmptyIfNull(
						rs.getString("PAYMENT_AMOUNT")).trim();
				double amount = Double.parseDouble(payAmount);
				invoiceVO.setPayAmount(comm.doubleComma(formatter
						.format(amount)));
				String allocateType = comm.getEmptyIfNull(
						rs.getString("REPAY_TYPE")).trim();
				if (allocateType != null && allocateType.equalsIgnoreCase("U")) {
					allocateType = "Upload";
				} else {
					allocateType = "Due Date";
				}
				invoiceVO.setAllocationType(allocateType);
				String repayType = comm.getEmptyIfNull(
						rs.getString("APPROPRIATION_TYPE_REPAYMENT")).trim();
				if (repayType != null && repayType.equalsIgnoreCase("CIP")) {
					repayType = "CIP";
				} else if (repayType != null && repayType.equalsIgnoreCase("PAIC")) {
					repayType = "PAIC";
				} else {
					repayType = "INV";
				}
				invoiceVO.setRepaymentAllocationType(repayType);
				invoiceVO.setReferenceNumber(comm.getEmptyIfNull(
						rs.getString("REFERENCE_NUMBER")).trim());
				invoiceVO.setTempRemarks(comm.getEmptyIfNull(
						rs.getString("REMARKS")).trim());
				invoiceVO.setWarningMessage(comm.getEmptyIfNull(
						rs.getString("WARNING_MESSAGE")).trim());
				invoiceVO.setVirtualAccount(comm.getEmptyIfNull(
						rs.getString("VIRTUALACCT")).trim());
				invoiceVO.setRepaymentTC(comm.getEmptyIfNull(
						rs.getString("REPAYMENT_TC")).trim());
				String repaymentType = comm.getEmptyIfNull(
						rs.getString("REPAYMENT_TYPE")).trim();
				if (repaymentType != null
						&& repaymentType.equalsIgnoreCase("RE")) {
					repaymentType = "Repayment";
				} else if (repaymentType != null
						&& repaymentType.equalsIgnoreCase("FC")) {
					repaymentType = "Force Capitalization";
				} else {
					repaymentType = "Repayment";
				}
				invoiceVO.setDueDateFilter(comm.getEmptyIfNull(
						rs.getString("due_DATE")).trim());
				invoiceVO.setRepayType(repaymentType);
			}
		} catch (SQLException e) {
			throwDAOException(e);
		} finally {
			closeSqlRefferance(rs, ppt, con);
		}
		return invoiceVO;
	}

	/**
	 * 
	 * @param invoiceVO
	 * @return
	 * @throws DAOException
	 */
	public InvMatchingVO gettingDebitParty(InvMatchingVO invoiceVO)
			throws DAOException {

		Connection con = null;
		PreparedStatement ppt = null;
		ResultSet rs = null;
		debitlst = new ArrayList<InvMatchingVO>();
		String debitParty = null;

		String sqlQuery = null;

		try {

			sqlQuery = "SELECT CPARTY,CPARTYNAME FROM SCFCPARTY WHERE PROGRAMME IN (SELECT KEY97 FROM SCFPROGRAM WHERE TRIM(ID)='"
					+ invoiceVO.getProgId()
					+ "') "
					+ "AND ROLE IN (SELECT PROG_TYPE FROM SCFPROGRAM WHERE TRIM(ID)='"
					+ invoiceVO.getProgId() + "') ";
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			ppt = con.prepareStatement(sqlQuery);
			System.out.println("Get Debit Party " + sqlQuery);
			rs = ppt.executeQuery();

			while (rs.next()) {
				invoiceVO = new InvMatchingVO();
				invoiceVO.setAnchorName(rs.getString("CPARTY").toString());
				invoiceVO.setAnchorFullName(rs.getString("CPARTYNAME")
						.toString());
				// debitlst.add(invoiceVO);
			}
			/*
			 * sqlQuery =
			 * "SELECT SCP.CPARTYNAME as PARTYNAME  FROM SCFCPARTY SCP WHERE CUSTOMER='"
			 * + invoiceVO.getDebitParty().trim()+ "'"; //sqlQuery =
			 * "SELECT SCP.CPARTY as CPARTY  FROM SCFCPARTY SCP,SCFPROGRAM SCF WHERE SCF.ID='"
			 * // + invoiceVO.getProgId().trim()+
			 * "' AND SCF.KEY97=SCP.PROGRAMME"; con =
			 * DBConnectionUtility.getConnection();
			 * 
			 * ppt = con.prepareStatement(sqlQuery);
			 * System.out.println("Get Debit Party " + sqlQuery); rs =
			 * ppt.executeQuery();
			 * 
			 * while (rs.next()) {
			 * //invoiceVO.setKey(rs.getString("CUSTOMER").toString());
			 * //invoiceVO.setValue(rs.getString("CUSTOMER").toString());
			 * invoiceVO.setAnchorName(rs.getString("PARTYNAME").toString());
			 * //debitlst.add(invoiceVO); }
			 */
		} catch (SQLException e) {

			throwDAOException(e);
		} finally {
			closeSqlRefferance(rs, ppt, con);

		}

		return invoiceVO;
	}

	/**
	 * 
	 * @param invoiceVO
	 * @return
	 * @throws DAOException
	 */
	public String fetchDebitParty(String programId) throws DAOException {

		Connection con = null;
		PreparedStatement ppt = null;
		ResultSet rs = null;
		debitlst = new ArrayList<InvMatchingVO>();
		String debitParty = null;
		String sqlQuery = null;

		try {

			sqlQuery = "SELECT CPARTYNAME FROM SCFCPARTY WHERE PROGRAMME IN (SELECT KEY97 FROM SCFPROGRAM WHERE TRIM(ID)='"
					+ programId.trim()
					+ "') "
					+ "AND ROLE IN (SELECT PROG_TYPE FROM SCFPROGRAM WHERE TRIM(ID)='"
					+ programId.trim() + "') ";
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			ppt = con.prepareStatement(sqlQuery);
			System.out.println("Get Debit Party " + sqlQuery);
			rs = ppt.executeQuery();
			if (rs.next()) {
				debitParty = rs.getString("CPARTYNAME");
			}
			if (debitParty == null) {
				debitParty = "";
			}
		} catch (SQLException e) {

			throwDAOException(e);
		} finally {
			closeSqlRefferance(rs, ppt, con);

		}
		return debitParty;
	}

	public static ArrayList<InvMatchingVO> fetchInvoiceDetails(String invoice,
			String refDate) {
		CallableStatement callableStatement = null;
		Connection con = null;
		String newDate = null;
		ArrayList<InvMatchingVO> invoiceList = new ArrayList<InvMatchingVO>();
		try {
			con = DBConnectionUtility.getConnection();

			/*
			 * SimpleDateFormat sdf= new SimpleDateFormat("MM/dd/yyyy"); Date d
			 * = sdf.parse(refDate); String trialDate = sdf.format(d);
			 * System.out.println(trialDate); String finalDate =
			 * trialDate.replace("/", "-");
			 * System.out.println("final Date"+finalDate);
			 */
			java.sql.Date sqlDate = null;
			if (refDate == null || refDate.equalsIgnoreCase("")) {
				newDate = getTiDate(con);
			} else {
				// SimpleDateFormat sdf = new SimpleDateFormat("DD-MM-YYYY");
				/*
				 * Date d = new Date(refDate); System.out.println("date" + d);
				 * String trialDate = sdf.format(d);
				 * System.out.println("date--->" + trialDate.replace("/", "-"));
				 * newDate = trialDate.replace("/", "-");
				 * System.out.println("new date" + newDate);
				 */
				newDate = refDate;
			}
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
			Date parsed = format.parse(newDate);
			sqlDate = new java.sql.Date(parsed.getTime());
			logger.info("newDate" + sqlDate);
			if (!invoice.equalsIgnoreCase("")) {
				System.out.println("Procedure call started");
				String getRepaymentSchedule = "{call ETT_REPAY_SCHDULE(?,?)}";
				callableStatement = con.prepareCall(getRepaymentSchedule);
				callableStatement.setString(1, invoice);
				callableStatement.setDate(2, sqlDate);
				callableStatement.executeUpdate();
				logger.info("Procedure call ended");
			}
			invoiceList = fetchInvoice(invoice);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(null, callableStatement, con);
		}
		return invoiceList;
	}

	public static String getTiDate(Connection con) {

		LoggableStatement log = null;
		String tiDate = "";
		String query = "";
		ResultSet rs = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT TO_CHAR(PROCDATE,'DD-MM-YYYY')PROCDATE FROM DLYPRCCYCL";
			log = new LoggableStatement(con, query);
			rs = log.executeQuery();
			while (rs.next()) {
				tiDate = rs.getString("PROCDATE");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(rs, log, null);
		}
		return tiDate;
	}

	public static ArrayList<InvMatchingVO> fetchInvoice(String invoice) {
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultset = null;
		InvMatchingVO invVO = null;
		String query = null;
		ArrayList<InvMatchingVO> invoiceList = new ArrayList<InvMatchingVO>();
		try {
			aConnection = DBConnectionUtility.getConnection();
			if (invoice == null || invoice.equalsIgnoreCase("")) {
				query = "SELECT PERIOD,INVOICE_REF,PAYDATE,ENDDT,OPENING,PAYMENT,INTEREST,PRINCIPAL,CLOSING, TO_CHAR(START_DATE,'DD-MM-YY')START_DATE, TO_CHAR(END_DATE,'DD-MM-YY')END_DATE,DPD  FROM  ETT_REPAY_SCHEDULE";
			} else {
				query = "SELECT PERIOD,INVOICE_REF,PAYDATE,ENDDT,OPENING,PAYMENT,INTEREST,PRINCIPAL,CLOSING, TO_CHAR(START_DATE,'DD-MM-YY')START_DATE,"
						+ "TO_CHAR(END_DATE,'DD-MM-YY')END_DATE,DPD  FROM  ETT_REPAY_SCHEDULE WHERE INVOICE_REF='"
						+ invoice.trim() + "'";
			}
			aPreparedStatement = aConnection.prepareStatement(query);
			aResultset = aPreparedStatement.executeQuery();
			logger.info("Query-->" + query);
			while (aResultset.next()) {
				invVO = new InvMatchingVO();
				invVO.setPeriod(aResultset.getString("PERIOD"));
				invVO.setPayDate(aResultset.getString("PAYDATE"));
				invVO.setEndDate(aResultset.getString("ENDDT"));
				invVO.setOpening(aResultset.getString("OPENING"));
				invVO.setPayment(aResultset.getString("PAYMENT"));
				invVO.setInterest(aResultset.getString("INTEREST"));
				invVO.setPrincipal(aResultset.getString("PRINCIPAL"));
				invVO.setClosing(aResultset.getString("CLOSING"));
				invVO.setStartDate(aResultset.getString("START_DATE"));
				invVO.setEnd_date(aResultset.getString("END_DATE"));
				invVO.setDpd(aResultset.getString("DPD"));
				invVO.setInvRefNo(aResultset.getString("INVOICE_REF"));

				invoiceList.add(invVO);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(aResultset, aPreparedStatement,
					aConnection);
		}
		return invoiceList;
	}

	public List<InvMatchingVO> gettingCounterParty(InvMatchingVO invoiceVO)
			throws DAOException {

		Connection con = null;
		PreparedStatement ppt = null;
		ResultSet rs = null;
		counterList = new ArrayList<InvMatchingVO>();
		CommonMethods com = new CommonMethods();
		String sqlQuery = null;
		InvMatchingVO invVO = null;
		try {
			System.out.println("progrm id-->" + invoiceVO.getProgId());

			if (invoiceVO != null) {
				if (!com.isNull(invoiceVO.getProgId())
						&& !invoiceVO.getProgId().equals("")) {
					sqlQuery = "SELECT CPARTY,CPARTYNAME FROM SCFCPARTY WHERE PROGRAMME IN (SELECT KEY97 FROM SCFPROGRAM WHERE TRIM(ID)='"
							+ invoiceVO.getProgId()
							+ "') "
							+ "AND ROLE NOT IN (SELECT PROG_TYPE FROM SCFPROGRAM WHERE TRIM(ID)='"
							+ invoiceVO.getProgId() + "') ";
					/*
					 * if (invoiceVO.getCounterParty() != null &&
					 * !invoiceVO.getCounterParty() .equalsIgnoreCase("")) {
					 * sqlQuery = sqlQuery + " and trim(CPARTY)='" +
					 * invoiceVO.getCounterParty().trim() + "' "; }
					 */
					/*
					 * sqlQuery =
					 * "SELECT SCP.CPARTY as CPARTY,SCF.CUSTOMER CUSTOMER  FROM SCFCPARTY SCP,SCFPROGRAM SCF WHERE SCF.ID='"
					 * + invoiceVO.getProgId().trim()+ "' AND SCF.CUSTOMER='" +
					 * invoiceVO.getDebitParty()+
					 * "' AND SCF.KEY97=SCP.PROGRAMME";
					 */
					if (con == null) {
						con = DBConnectionUtility.getConnection();
					}

					ppt = con.prepareStatement(sqlQuery);
					System.out.println("Get Counter Party " + sqlQuery);
					rs = ppt.executeQuery();
					while (rs.next()) {
						invVO = new InvMatchingVO();
						invVO.setKey1(rs.getString("CPARTY").toString().trim());
						invVO.setValue1(rs.getString("CPARTYNAME").toString());
						counterList.add(invVO);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throwDAOException(e);
		} finally {
			closeSqlRefferance(rs, ppt, con);

		}

		return counterList;
	}

	@SuppressWarnings("null")
	public InvMatchingVO getDataFromTI(InvMatchingVO invoiceVO)
			throws DAOException {

		Connection con = null;
		PreparedStatement ppt = null;
		ResultSet rs = null;
		invList = new ArrayList<InvMatchingDataVO>();
		String sqlQuery = null;
		CommonMethods commonMethods = null;
		InvMatchingDataVO invMatchingDataVO = null;
		String repayAmt = invoiceVO.getPayAmount().replaceAll(",", "");

		int reAmount = 0;
		int sum = 0;

		try {
			System.out.println(invoiceVO.getAllocationType());
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			System.out.println("repayAt " + repayAmt);

			if (!repayAmt.equals("")) {
				reAmount = Integer.parseInt(repayAmt);
				System.out.println(reAmount);
				sqlQuery = "select DISTINCT NVL(TRIM(FIN_BASE_VIEW.MAS_MASTER_REF), ' '),NVL(TRIM(BC_INV_BASE_VIEW.INVOIC_REF), ' '),TO_CHAR(TO_DATE(FIN_BASE_VIEW.FNC_STARTDATE, 'dd-mm-yy'),'dd-mm-yyyy'),TO_CHAR(TO_DATE(BC_INV_BASE_VIEW.DUEDATE, 'dd-mm-yy'),'dd-mm-yyyy')AS DUEDATE,to_char(FIN_BASE_VIEW.MAS_AMOUNT,'999,999,999,999,999.99'),to_char(FIN_BASE_VIEW.AMOUNT_OS,'999,999,999,999,999.99'),NVL(TRIM(FIN_BASE_VIEW.AMOUNT_OS), ' ') from BC_INV_BASE_VIEW,FIN_BASE_VIEW where BC_INV_BASE_VIEW.INV_FINCE_EV = FIN_BASE_VIEW.FINCEEVKEY AND BC_INV_BASE_VIEW.PROGRAM_ID ='"
						+ invoiceVO.getProgId().trim()
						+ "' AND BC_INV_BASE_VIEW.SCFP_CUSTOMER='"
						+ invoiceVO.getDebitParty().trim()
						+ "' AND BC_INV_BASE_VIEW.CPARTY='"
						+ invoiceVO.getCounterParty().trim()
						+ "'  ORDER BY DUEDATE ASC ";

				ppt = con.prepareStatement(sqlQuery);

				System.out.println("Sql Query " + sqlQuery);

				rs = ppt.executeQuery();
				while (rs.next()) {

					invMatchingDataVO = new InvMatchingDataVO();
					invMatchingDataVO.setMasterRef(rs.getString(1));
					invMatchingDataVO.setInvNumber(rs.getString(2));
					invMatchingDataVO.setDisburseDate(rs.getString(3));
					invMatchingDataVO.setDueDate(rs.getString(4));
					invMatchingDataVO.setLoanAmount(rs.getString(5));
					invMatchingDataVO.setOutAmount(rs.getString(6));
					int repay = Integer.parseInt(rs.getString(7));
					if (reAmount > repay || reAmount == repay) {
						invMatchingDataVO.setRepayAmount(rs.getString(7));
						reAmount = reAmount - repay;
					} else {
						invMatchingDataVO.setRepayAmount(String
								.valueOf(reAmount));
						reAmount = 0;
					}
					/*
					 * sum = sum+ repay; if(sum>reAmount) {
					 * invMatchingDataVO.setRepayAmount(""); }
					 */

					invList.add(invMatchingDataVO);
				}
			} else {
				// sqlQuery =
				// " select NVL(TRIM(MAS_MASTER_REF), ' '),NVL(TRIM(INVOIC_REF), ' '),TO_CHAR(TO_DATE(DUEDATE, 'dd-mm-yy'),'dd-mm-yyyy'),to_char(INV_FACE_AMT,'999,999,999,999,999.99'),to_char(INV_OUTS_AMOUNT,'999,999,999,999,999.99') from BC_INV_BASE_VIEW where PROGRAM_ID ='"+invoiceVO.getProgId().trim()+"' AND CPARTY='"+invoiceVO.getDebitParty().trim()+"'";
				sqlQuery = " select DISTINCT NVL(TRIM(FIN_BASE_VIEW.MAS_MASTER_REF), ' '),NVL(TRIM(BC_INV_BASE_VIEW.INVOIC_REF), ' '),TO_CHAR(TO_DATE(FIN_BASE_VIEW.FNC_STARTDATE, 'dd-mm-yy'),'dd-mm-yyyy'),TO_CHAR(TO_DATE(BC_INV_BASE_VIEW.DUEDATE, 'dd-mm-yy')AS DUEDATE,'dd-mm-yyyy'),to_char(FIN_BASE_VIEW.MAS_AMOUNT,'999,999,999,999,999.99'),to_char(FIN_BASE_VIEW.AMOUNT_OS,'999,999,999,999,999.99') from BC_INV_BASE_VIEW,FIN_BASE_VIEW where BC_INV_BASE_VIEW.INV_FINCE_EV = FIN_BASE_VIEW.FINCEEVKEY AND BC_INV_BASE_VIEW.PROGRAM_ID ='"
						+ invoiceVO.getProgId().trim()
						+ "' AND BC_INV_BASE_VIEW.SCFP_CUSTOMER='"
						+ invoiceVO.getDebitParty().trim()
						+ "' AND BC_INV_BASE_VIEW.CPARTY='"
						+ invoiceVO.getCounterParty().trim()
						+ "'  ORDER BY DUEDATE ASC ";
				// sqlQuery =
				// " select NVL(TRIM(FIN_BASE_VIEW.MAS_MASTER_REF), ' '),NVL(TRIM(BC_INV_BASE_VIEW.INVOIC_REF), ' '),TO_CHAR(TO_DATE(FIN_BASE_VIEW.MAS_DEACT_DATE, 'dd-mm-yy'),'dd-mm-yyyy'),TO_CHAR(TO_DATE(FIN_BASE_VIEW.MAS_CTRCT_DATE, 'dd-mm-yy'),'dd-mm-yyyy'),to_char(FIN_BASE_VIEW.MAS_AMOUNT,'999,999,999,999,999.99'),to_char(FIN_BASE_VIEW.AMOUNT_OS,'999,999,999,999,999.99') from BC_INV_BASE_VIEW,FIN_BASE_VIEW where BC_INV_BASE_VIEW.INV_FINCE_EV = FIN_BASE_VIEW.FINCEEVKEY AND BC_INV_BASE_VIEW.PROGRAM_ID ='VLDSP1' AND BC_INV_BASE_VIEW.SCFP_CUSTOMER='CP-00000017' AND BC_INV_BASE_VIEW.CPARTY='31765094'  ORDER BY FIN_BASE_VIEW.MAS_CTRCT_DATE ASC ";

				ppt = con.prepareStatement(sqlQuery);

				System.out.println("Sql Query " + sqlQuery);

				rs = ppt.executeQuery();
				while (rs.next()) {

					invMatchingDataVO = new InvMatchingDataVO();
					invMatchingDataVO.setMasterRef(rs.getString(1));
					invMatchingDataVO.setInvNumber(rs.getString(2));
					invMatchingDataVO.setDisburseDate(rs.getString(3));
					invMatchingDataVO.setDueDate(rs.getString(4));
					invMatchingDataVO.setLoanAmount(rs.getString(5));
					invMatchingDataVO.setOutAmount(rs.getString(6));
					invList.add(invMatchingDataVO);
				}

			}
			if (!invList.isEmpty()) {
				invoiceVO.setInvList(invList);
			}
			debitlst = getDebitlst();
			if (debitlst != null) {
				invoiceVO.setDebitList(debitlst);
			}
			counterList = getCounterList();
			if (counterList != null) {
				invoiceVO.setCounterList(counterList);
			}

		} catch (SQLException e) {

			throwDAOException(e);
		} finally {
			closeSqlRefferance(rs, ppt, con);

		}

		return invoiceVO;
	}

	public InvMatchingVO fetchDataFromTI(InvMatchingVO invoiceVO)
			throws DAOException {
		String batchID = "123";
		ArrayList<InvMatchingVO> invoicList = null;
		STPProcessDAO dao = null;
		String batch_ID = null;
		// Connection con = null;
		try {
			batchID = fetchDataFromTIplus(invoiceVO);

			/** Commenting Service Call Starts */
			/*
			 * dao=STPProcessDAO.getDAO(); dao.fetch_invoices(batchID);
			 */

			/** Commenting Service Call Ends */
			eliminateNegative(batchID);
			invoicList = fetchInvoiceList(batchID);
			invoiceVO.setBatchID(batchID);
			invoiceVO.setBatch_ID(batchID);

		} catch (Exception exception) {
			throwDAOException(exception);
		}
		if (!invoicList.isEmpty()) {
			invoiceVO.setInvoicList(invoicList);
		}
		debitlst = getDebitlst();
		if (debitlst != null) {
			invoiceVO.setDebitList(debitlst);
		}
		counterList = getCounterList();
		if (counterList != null) {
			invoiceVO.setCounterList(counterList);
		}
		return invoiceVO;
	}

	public void eliminateNegative(String batchid) throws DAOException {
		logger.info(ENTERING_METHOD);
		Connection con = null;
		LoggableStatement pst = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String DELETE_QUERY = "DELETE FROM ETT_STP_REPAYMENT WHERE OS_AMOUNT < = 0 AND BATCH_ID = '"
					+ batchid + "' ";
			pst = new LoggableStatement(con, DELETE_QUERY);
			pst.executeUpdate();
			System.out.println("Elimination of neative values-->"
					+ pst.getQueryString());
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(null, pst, con);
		}
		logger.info(EXITING_METHOD);
	}

	/**
	 * 
	 * @param batchId
	 * @param invoiceVO
	 * @return
	 * @throws DAOException
	 * @throws SQLException
	 */

	public InvMatchingVO approveRePayment(String batchId,
			InvMatchingVO invoiceVO) throws DAOException, SQLException {

		ArrayList<InvMatchingVO> invoicList = null;
		STPProcessDAO dao = null;
		String payAccount = null;
		CommonMethods comm = null;
		String referenceNumber = null;
		Connection con = null;
		String limitRevFlag = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			/** Commenting Service Call Starts */
			dao = STPProcessDAO.getDAO();
			comm = new CommonMethods();
			payAccount = comm.fetchPayAccount(batchId, con);
			repaymentApproval(batchId, con, "REPAY");
			//ejbCall(batchId, "REPAY");
			ejbThreadPoolCall(batchId, "REPAY");
			dao.callInvoiceApprovalProcess(batchId, payAccount, con);
			// dao.fetch_invoices(batchId, payAccount);
			/** Commenting Service Call Ends */

			/* referenceNumber = invoiceVO.getReferenceNumber(); */
			/* Posting and Limit Reversal Starts */
			limitRevFlag = comm.limitRevFlag(con);
			if (limitRevFlag != null && !limitRevFlag.equalsIgnoreCase("")
					&& limitRevFlag.equalsIgnoreCase("Y")) {
				LimitReversalAndPostings(batchId, referenceNumber, con);
			}
			/* Posting and Limit Reversal Ends */
			// fetchLimitUnBlock(batchId);
			invoiceVO.setBatchID(batchId);

		} catch (Exception e) {
			System.out.println(e);
		}finally{
			if (con != null) {
				con.close();
			}
		}
		return invoiceVO;
	}

	/**
	 * 
	 * @param checkervo
	 * @return
	 * @throws DAOException
	 */
	public void repaymentApproval(String batchID, Connection con,
			String limitService) throws DAOException {
		CallableStatement callableStatement = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			callableStatement = con
					.prepareCall("{call FETCH_DOC_ATTACH_XML(?,?)}");
			callableStatement.setString(1, limitService);
			callableStatement.setString(2, batchID);
			callableStatement.executeUpdate();
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(null, callableStatement);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/**
	 * 
	 * @param batchID
	 * @throws DAOException
	 */
	public boolean ejbCall(String batchID, String xmlType) throws DAOException {
		boolean result = false;
		final String batchID1 = batchID;
		final String xmlType1 = xmlType;
		try {
			Thread t = new Thread(new Runnable() {
				public void run() {
					CommonMethods comm = null;
					LoggableStatement loggableStatement = null;
					ResultSet rs = null;
					Connection con = null;
					try {
						con = DBConnectionUtility.getConnection();
						comm = new CommonMethods();
						loggableStatement = new LoggableStatement(
								con,
								"SELECT REQUEST,SEQUENCE,TRIM(A.MASTER_REF) MASTER_REF FROM ETT_CLF_APISERVER A,ETT_STP_REPAYMENT B WHERE "
										+ "A.API_BATCHID=B.BATCH_ID and TRIM(A.MASTER_REF)=TRIM(B.LOAN_MASTER_REF)  AND trim(B.batch_id)=?   AND trim(SMLTYPE)=? ");
						loggableStatement.setString(1,
								comm.getEmptyIfNull(batchID1).trim());
						loggableStatement.setString(2,
								comm.getEmptyIfNull(xmlType1).trim());
						rs = loggableStatement.executeQuery();
						while (rs.next()) {
							String xmlToPost = comm.getEmptyIfNull(
									rs.getString("REQUEST")).trim();
							String sequence = comm.getEmptyIfNull(
									rs.getString("SEQUENCE")).trim();
							String masterRef = comm.getEmptyIfNull(
									rs.getString("MASTER_REF")).trim();
							System.out.println("TIREQUEST--->" + xmlToPost);
							System.out.println("sequence--->" + sequence);
							if (xmlToPost != null
									&& !xmlToPost.equalsIgnoreCase("")) {
								String xmlResponse = comm
										.fetchEJBResponse(xmlToPost);
								System.out.println("TIRESPONSE--->"
										+ xmlResponse);
								comm.updateAPISERVER(xmlResponse, sequence, con);
								updateAPISequence(batchID1, sequence, con,
										masterRef);
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBConnectionUtility.surrenderDB(rs, loggableStatement,
								con);
					}

				}
			});
			t.start();
			while (t.isAlive() == true) {
				// System.out.println("Inside Invoice"+t.isAlive());
			}
			if (t.isAlive() == false) {
				result = true;
			}
		} catch (Exception exception) {
			logger.info(exception);
			throwDAOException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return result;
	}

	/**
	 * 
	 * @param batchID
	 * @throws DAOException
	 */
	public ArrayList<InvMatchingVO> ejbThreadPoolCall(String batchID, String xmlType)
			throws DAOException {
		ArrayList<InvMatchingVO> XMLList = new ArrayList<InvMatchingVO>();		
		CommonMethods comm = null;
		LoggableStatement loggableStatement = null;
		ResultSet rs = null;
		Connection con = null;
		try {
				con = DBConnectionUtility.getConnection();
				comm = new CommonMethods();
				loggableStatement = new LoggableStatement(
						con,
						"SELECT REQUEST,SEQUENCE,TRIM(A.MASTER_REF) MASTER_REF FROM ETT_CLF_APISERVER A,ETT_STP_REPAYMENT B WHERE "
										+ "A.API_BATCHID=B.BATCH_ID and TRIM(A.MASTER_REF)=TRIM(B.LOAN_MASTER_REF)  AND trim(B.batch_id)=?   AND trim(SMLTYPE)=? ");
				loggableStatement.setString(1, comm.getEmptyIfNull(batchID)
						.trim());
				loggableStatement.setString(2, comm.getEmptyIfNull(xmlType)
						.trim());
				rs = loggableStatement.executeQuery();
				while (rs.next()) {
					InvMatchingVO vo = new InvMatchingVO();
					String xmlToPost = comm.getEmptyIfNull(
							rs.getString("REQUEST")).trim();
					String masterRef = comm.getEmptyIfNull(
							rs.getString("MASTER_REF")).trim();
					if (xmlToPost != null && !xmlToPost.equalsIgnoreCase("")) {
						vo.setXmlRequest(xmlToPost);
						vo.setXmlSequence(comm.getEmptyIfNull(rs.getString("SEQUENCE")).trim());
						vo.setMasterReference(masterRef);
						XMLList.add(vo);
					}
				}
				try{
				smithThreadProcess(XMLList,batchID);
				}catch(Exception e1){
					System.out.println("Exception in EJB call"+batchID+"--->"+xmlType);		
					e1.printStackTrace();
				}
				try{
				ejbThreadPoolCallRetry(batchID, xmlType);
				}catch(Exception e2){
					System.out.println("Exception in EJB call Retry"+batchID+"--->"+xmlType);
					e2.printStackTrace();
				}
				System.out.println("Batch Process -------->"+xmlType+"----Completed for the batch------>"+batchID);
		} catch (Exception exception) {
			logger.info(exception);
			throwDAOException(exception);
		}finally {
			DBConnectionUtility.surrenderDB(rs, loggableStatement, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return XMLList;
	}
	
	/**
	 * 
	 * @param batchID
	 * @throws DAOException
	 */
	public ArrayList<InvMatchingVO> ejbThreadPoolCallRetry(String batchID, String xmlType)
			throws DAOException {
		ArrayList<InvMatchingVO> XMLList = new ArrayList<InvMatchingVO>();		
		CommonMethods comm = null;
		LoggableStatement loggableStatement = null;
		ResultSet rs = null;
		Connection con = null;
		try {
				con = DBConnectionUtility.getConnection();
				comm = new CommonMethods();
				loggableStatement = new LoggableStatement(
						con,
						"SELECT REQUEST,SEQUENCE,TRIM(A.MASTER_REF) MASTER_REF FROM ETT_CLF_APISERVER A,ETT_STP_REPAYMENT B WHERE "
										+ "A.API_BATCHID=B.BATCH_ID and TRIM(A.MASTER_REF)=TRIM(B.LOAN_MASTER_REF)  AND trim(B.batch_id)=?   AND trim(SMLTYPE)=? AND A.STATUS='WAITING' ");
				loggableStatement.setString(1, comm.getEmptyIfNull(batchID)
						.trim());
				loggableStatement.setString(2, comm.getEmptyIfNull(xmlType)
						.trim());
				rs = loggableStatement.executeQuery();
				while (rs.next()) {
					InvMatchingVO vo = new InvMatchingVO();
					String xmlToPost = comm.getEmptyIfNull(
							rs.getString("REQUEST")).trim();
					if (xmlToPost != null && !xmlToPost.equalsIgnoreCase("")) {
						vo.setXmlRequest(xmlToPost);
						vo.setXmlSequence(comm.getEmptyIfNull(rs.getString("SEQUENCE")).trim());
					}
					XMLList.add(vo);
				}
				smithThreadProcess(XMLList,batchID);
		} catch (Exception exception) {
			logger.info(exception);
			throwDAOException(exception);
		}finally {
			DBConnectionUtility.surrenderDB(rs, loggableStatement, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return XMLList;
	}
	
	/**
	 * 
	 * @param XMLList
	 * @throws InterruptedException
	 */
	public void smithThreadProcess(ArrayList<InvMatchingVO> XMLList,String batchID) throws InterruptedException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ExecutorService executor = Executors.newFixedThreadPool(50);
		Connection con = null;
		try {
			con = DBConnectionUtility.getConnection();
			for (int j = 0; j < XMLList.size(); j++) {
				ArrayList<InvMatchingVO> XMLListTemp = new ArrayList<InvMatchingVO>();
				XMLListTemp.add(XMLList.get(j)); 
				Runnable worker = new SmithThreadConcept(XMLListTemp, con,XMLListTemp.size(),batchID);
				executor.execute(worker);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			System.out.println("Executor service shutdown in progress");
			executor.shutdown();
			while (!executor.isTerminated()) {
				Thread.sleep(3000);
			}
			System.out.println("Executor service shutdown completed");
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String updateAPISequence(String Batchid, String sequence,
			Connection con, String masterRef) throws Exception {
		LoggableStatement pst = null;
		String query = null;
		String status = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "UPDATE ETT_STP_REPAYMENT SET APISERVER_SEQ_NO='"
					+ sequence + "',GW_STATUS='W' WHERE BATCH_ID='" + Batchid
					+ "'  AND trim(LOAN_MASTER_REF) ='" + masterRef + "'";
			pst = new LoggableStatement(con, query);
			pst.executeUpdate();
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, pst);
		}
		return status;
	}

	/**
	 * 
	 * @param batchID
	 * @throws DAOException
	 */
	public void fetchLimitUnBlock(String batchID) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement stmt = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		String dealRef = null;
		String valueDate = null;
		String tempBatch = "";
		try {
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String batchId = getLimitBatch(con) + "";
			System.out.println("batchID " + batchId);
			logger.info("batchID " + batchId);
			if (batchID != null) {
				batchID = batchID.trim();
				System.out.println("batchID " + batchID);
				logger.info("batchID " + batchID);
			}
			stmt = new LoggableStatement(
					con,
					"SELECT LOAN_MASTER_REF,TO_CHAR(TO_DATE(VALUE_DATE, 'dd-mm-yy'),'dd-mm-yy') AS VALUE_DATE FROM ETT_STP_REPAYMENT WHERE TRIM(BATCH_ID)='"
							+ batchID
							+ "' AND "
							+ "TRIM(GW_STATUS)='S' AND PRC_ALLC_AMOUNT > 0");
			logger.info("fetchLimitUnBlock----->" + stmt.getQueryString());
			System.out.println("fetchLimitUnBlock----->"
					+ stmt.getQueryString());
			rs = stmt.executeQuery();
			if (rs.next()) {
				dealRef = comm.getEmptyIfNull(rs.getString(MASTER_REF_KEY))
						.trim();
				valueDate = comm.getEmptyIfNull(rs.getString("VALUE_DATE"))
						.trim();
				System.out.println("dealRef" + dealRef);
				if (dealRef != null && !dealRef.equalsIgnoreCase(EMPTY)) {
					tempBatch = unBlockLimit(batchID, batchId, valueDate, con);

					System.out.println("tempBatch " + tempBatch);
					logger.info("tempBatch " + tempBatch);
				}
			}
			limitFreezeCall(batchId, con);
			logger.info("limitFreezeCall " + batchId);
			System.out.println("limitFreezeCall " + batchId);
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, stmt, con);
		}
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public int getLimitBatch(Connection con) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		int sequenceNumber = 0;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT ETT_LIMIT_BATCH.NEXTVAL FROM DUAL");
			rs = ps.executeQuery();
			if (rs.next()) {
				sequenceNumber = rs.getInt(1);
			}
		} catch (Exception exception) {
			throw exception;
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return sequenceNumber;
	}

	/**
	 * 
	 * @param dealRef
	 * @throws DAOException
	 */
	public String unBlockLimit(String dealRef, String batchId,
			String valueDate, Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		CallableStatement callableStatement = null;
		String BatchID = "";
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			/*
			 * java.sql.Date sqlDate = null; if (valueDate != null) {
			 * SimpleDateFormat format = new SimpleDateFormat("DD-MM-yyyy");
			 * Date parsed = format.parse(valueDate); sqlDate = new
			 * java.sql.Date(parsed.getTime());
			 * System.out.println("Value date-->"+sqlDate); }
			 */
			String ETT_LIMT_UNBLOCK = "{call ETT_LIMIT_UNBLOCK(?,?,?,?)}";
			callableStatement = con.prepareCall(ETT_LIMT_UNBLOCK);
			callableStatement.setString(1, dealRef);
			callableStatement.setString(2, batchId);
			callableStatement.setString(3, valueDate);
			callableStatement.registerOutParameter(4, java.sql.Types.INTEGER);
			callableStatement.executeUpdate();
			BatchID = callableStatement.getString(4);
			logger.info("After calling procedure--->" + BatchID
					+ "-valueDate--->" + valueDate);
			System.out.println("After calling procedure--->" + BatchID
					+ "-valueDate--->" + valueDate);
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, callableStatement);
		}
		return BatchID;
	}

	/**
	 * 
	 * @param batchID
	 */
	public void limitFreezeCall(String batchID, Connection con) {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String limitAccountNo = null;
		String sequence = null;
		String exposure = null;
		String program = null;
		String cparty = null;
		CommonMethods comm = null;
		try {
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "SELECT LIMITACCNO,SEQUENCE,EXPANC,PRGRMID,CPARTY FROM ETT_LIMIT_TRANSACTIONDETAILS WHERE TRIM(BATCHID)='"
					+ batchID + "'";
			ps = new LoggableStatement(con, query);
			logger.info("limitFreezeCall----->" + ps.getQueryString());
			rs = ps.executeQuery();
			while (rs.next()) {
				limitAccountNo = comm
						.getEmptyIfNull(rs.getString("LIMITACCNO")).trim();
				sequence = comm.getEmptyIfNull(rs.getString("SEQUENCE")).trim();
				exposure = comm.getEmptyIfNull(rs.getString("EXPANC")).trim();
				program = comm.getEmptyIfNull(rs.getString("PRGRMID")).trim();
				cparty = comm.getEmptyIfNull(rs.getString("CPARTY")).trim();
				System.out.println("limitAccountNo--->" + limitAccountNo);
				logger.info("limitAccountNo--->" + limitAccountNo);
				if (limitAccountNo != null
						&& !limitAccountNo.equalsIgnoreCase("")) {
					String request = fetchUnFreezeXML(limitAccountNo);
					System.out.println("fetchUnFreezeXML--->" + request);
					logger.info("fetchUnFreezeXML--->" + request);
					/*
					 * String response = callingThemeTransportClient(request);
					 * System.out.println("fetchUnFreezeXML res--->"+response);
					 * logger.info("fetchUnFreezeXML res--->"+response);
					 * updateTransaction(batchID,sequence,request,response);
					 */
					updateProgram(program, exposure, cparty, con);
				}
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			System.out.println("Exception-->" + exception.getMessage());
			System.out.println("EOD JOB FOR CLF limitFreezeCall");
			exception.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/**
	 * 
	 * @param limitAccountNo
	 * @return
	 * @throws ParserConfigurationException
	 */
	public String fetchUnFreezeXML(String limitAccountNo)
			throws ParserConfigurationException {
		String xml1 = "<?xml version=\"1.0\" standalone=\"yes\"?>";
		String endString = "";
		endString = endString + xml1;

		DocumentBuilderFactory documentFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
		Document document = documentBuilder.newDocument();

		Element rootElement = document.createElement("ServiceRequest");
		document.appendChild(rootElement);

		Attr attr = document.createAttribute("xmlns");
		attr.setValue("urn:control.services.tiplus2.misys.com");
		rootElement.setAttributeNode(attr);

		Attr attr1 = document.createAttribute("xmlns:ns2");
		attr1.setValue("urn:model.freeze.account.themebridge.bs.com");
		rootElement.setAttributeNode(attr1);

		Element rocdochead = document.createElement("RequestHeader");
		rootElement.appendChild(rocdochead);

		Element pch = document.createElement("Service");
		pch.appendChild(document.createTextNode("Account"));
		rocdochead.appendChild(pch);

		Element pch1 = document.createElement("Operation");
		pch1.appendChild(document.createTextNode("UnFreeze"));
		rocdochead.appendChild(pch1);

		Element rocdocred = document.createElement("Credentials");
		rocdochead.appendChild(rocdocred);

		Element pcna = document.createElement("Name");
		pcna.appendChild(document.createTextNode("SUPERVISOR"));
		rocdocred.appendChild(pcna);

		Element pcso = document.createElement("SourceSystem");
		pcso.appendChild(document.createTextNode("Z2"));
		rocdochead.appendChild(pcso);

		Element pcsy = document.createElement("CorrelationId");
		pcsy.appendChild(document.createTextNode("CorrelationId"));
		rocdochead.appendChild(pcsy);

		Element rocdocmain = document
				.createElement("ns2:AccountUnFreezeRequest");
		rootElement.appendChild(rocdocmain);

		Element rocdoc1 = document.createElement("ns2:FreezeAccounts");
		rocdocmain.appendChild(rocdoc1);

		String Idval = String.valueOf(limitAccountNo);
		if (Idval == null) {
			Element et = document.createElement("ns2:AccountNumber");
			et.appendChild(document.createTextNode(""));
			rocdoc1.appendChild(et);
		} else {
			Element et = document.createElement("ns2:AccountNumber");
			et.appendChild(document.createTextNode(Idval));
			rocdoc1.appendChild(et);
		}
		Element pc = document.createElement("ns2:CreditDebitFlag");
		pc.appendChild(document.createTextNode("D"));
		rocdoc1.appendChild(pc);

		Element pc1 = document.createElement("ns2:FreezeUnfreezeFlag");
		pc1.appendChild(document.createTextNode("R"));
		rocdoc1.appendChild(pc1);

		/******* Convert XML Document to String File *************/

		String str = xmlGeneration.convertDocumentToString(document);
		str = endString + str;
		return str;
	}

	/**
	 * 
	 * @param endString
	 * @return
	 * @throws MessagingException
	 */
	/*
	 * public String callingThemeTransportClient(String endString) {
	 * logger.info(ActionConstants.ENTERING_METHOD); String result = null; try{
	 * logger.info("Calling BridgeGatewayImplServiceStub Starts");
	 * BridgeGatewayImplService service = new BridgeGatewayImplService();
	 * BridgeGateway bg= service.getBridgeGatewayImplPort(); result =
	 * bg.process(endString);
	 * System.out.println("Result-------------->"+result);
	 * logger.info("Calling BridgeGatewayImplServiceStub Starts"); } catch
	 * (Exception exception) { exception.printStackTrace();
	 * System.out.println("Exception-->"+exception.getMessage());
	 * System.out.println("EOD JOB FOR CLF callingThemeTransportClient");
	 * exception.printStackTrace(); }
	 * logger.info(ActionConstants.EXITING_METHOD); return result; }
	 */

	/**
	 * 
	 * @param batchID
	 * @param sequence
	 * @param request
	 * @param response
	 */
	public void updateTransaction(String batchID, String sequence,
			String request, String response) {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String sql = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			sql = "UPDATE ETT_LIMIT_TRANSACTIONDETAILS SET TIREQUEST='"
					+ request
					+ "',TIRESPONSE='"
					+ response
					+ "',STATUS='SUBMITTED',"
					+ "PROCESSTIME=CAST(SYSDATE AS TIMESTAMP) WHERE TRIM(BATCHID)='"
					+ batchID + "' AND TRIM(SEQUENCE)='" + sequence + "' ";
			ps = new LoggableStatement(con, sql);
			System.out.println("updateTransaction--->" + sql);
			logger.info("updateTransaction--->" + sql);
			ps.executeUpdate();
		} catch (Exception exception) {
			exception.printStackTrace();
			System.out.println("Exception-->" + exception.getMessage());
			System.out.println("EOD JOB FOR CLF updateTransaction");
			exception.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/**
	 * 
	 * @param program
	 * @param exposure
	 * @param cparty
	 * @throws SQLException
	 */
	public void updateProgram(String program, String exposure, String cparty,
			Connection con) throws SQLException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		LoggableStatement ps = null;
		LoggableStatement ps1 = null;
		ResultSet rs = null;
		String sql = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			if (exposure != null && exposure.equalsIgnoreCase("A")) {
				sql = "UPDATE ETT_CLF_PROGRAMPARAMETERS SET PROGRAMFREEZE='N' WHERE PROIDEN='"
						+ program + "'";
				String sql1 = "UPDATE ETT_CLF_SELLERBUYERRELATION SET LIMIT_FREEZE='N' WHERE PROGIDN='"
						+ program + "' ";
				System.out.println("UPDATE ANCHOR ----->" + sql1);
				ps1 = new LoggableStatement(con, sql1);
				ps1.executeUpdate();
			} else {
				sql = "UPDATE ETT_CLF_SELLERBUYERRELATION SET LIMIT_FREEZE='N' WHERE PROGIDN='"
						+ program + "' AND CUSTOMR='" + cparty + "'";
			}
			System.out.println("UPDATE PROGRAM----->" + sql);
			ps = new LoggableStatement(con, sql);
			ps.executeUpdate();
		} catch (Exception exception) {
			exception.printStackTrace();
			System.out.println("Exception-->" + exception.getMessage());
			System.out.println("EOD JOB FOR CLF updateProgram");
			exception.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
			if (ps1 != null) {
				ps1.close();
			}
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/**
	 * 
	 * @param batchId
	 * @param invoiceVO
	 * @return
	 * @throws DAOException
	 * @throws SQLException
	 */
	public InvMatchingVO processRePayment(String batchId,
			InvMatchingVO invoiceVO) throws DAOException, SQLException {

		ArrayList<InvMatchingVO> invoicList = null;
		STPProcessDAO dao = null;
		String payAccount = null;
		CommonMethods comm = null;

		try {
			/* DB Connectivity */

			/** Commenting Service Call Starts */
			dao = STPProcessDAO.getDAO();
			comm = new CommonMethods();
			payAccount = comm.getEmptyIfNull(invoiceVO.getPayAccount()).trim();
			dao.fetch_invoices(batchId, payAccount);
			/** Commenting Service Call Ends */

			invoicList = fetchInvoiceList(batchId);

			/* Posting and Limit Reversal Starts */
			// LimitReversalAndPostings(batchId);
			/* Posting and Limit Reversal Ends */
			invoiceVO.setBatchID(batchId);

		} catch (Exception e) {
			System.out.println(e);
		}
		if (!invoicList.isEmpty()) {
			invoiceVO.setInvoicList(invoicList);
		}
		debitlst = getDebitlst();
		if (debitlst != null) {
			invoiceVO.setDebitList(debitlst);
		}
		counterList = getCounterList();
		if (counterList != null) {
			invoiceVO.setCounterList(counterList);
		}

		return invoiceVO;
	}

	private void LimitReversalAndPostings(String batchid,
			String referenceNumber, Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String exposure = null;
		String prgm = null;
		STPProcessDAO dao = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			dao = STPProcessDAO.getDAO();
			ps = new LoggableStatement(
					con,
					"select EXPANC,proiden from ett_clf_programparameters where trim(proiden) in "
							+ "(select TRIM(program_id) from ett_stp_repayment where batch_id='"
							+ batchid + "')");
			logger.info("Executing Query---------->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				exposure = (rs.getString(1) == null) ? "" : rs.getString(1);
				prgm = (rs.getString(2) == null) ? "" : rs.getString(2);

				if (null != exposure) {
					exposure = exposure.trim();
				}
				if (null != prgm) {
					prgm = prgm.trim();
				}

				String customer = getCustomer(prgm);

				GenericFundTransferFinance gd = new GenericFundTransferFinance();
				gd.doGenericFundTransfer(batchid, exposure, prgm, customer,
						referenceNumber, con);
				// dao.fetch_postings(batchid);

			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);

	}

	public String getCustomer(String programID) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String branch = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT CUSTOMER FROM SCFPROGRAM WHERE ID = '"
							+ programID.trim() + "'");
			rs = ps.executeQuery();
			if (rs.next()) {
				branch = (rs.getString(1) == null) ? "" : rs.getString(1);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return branch;
	}

	public String fetchPaymentAmount(String programID) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String branch = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT CUSTOMER FROM SCFPROGRAM WHERE ID = '"
							+ programID.trim() + "'");
			rs = ps.executeQuery();
			if (rs.next()) {
				branch = (rs.getString(1) == null) ? "" : rs.getString(1);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return branch;
	}

	@SuppressWarnings("unchecked")
	public void setDate() throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement pst = null;
		ResultSet rs = null;
		Connection con = null;
		try {
			CommonMethods commonMethods = null;
			commonMethods = new CommonMethods();
			Map session = ActionContext.getContext().getSession();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "SELECT TO_CHAR(TO_DATE(PROCDATE, 'dd-mm-yy'),'dd-mm-yyyy') as PROCDATE FROM dlyprccycl";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				session.put("processDate",
						commonMethods.getEmptyIfNull(rs.getString("PROCDATE"))
								.trim());
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}
	
	/**
	 * 
	 * @return
	 * @throws DAOException
	 */
	public String fetchTXNDueDate() throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement pst = null;
		ResultSet rs = null;
		Connection con = null;
		String result = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "SELECT to_char(TO_DATE(PROCDATE+365,'DD-MM-YY'),'DD-MM-YYYY') AS  P_DUE_DATE FROM DLYPRCCYCL";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				//result = String.valueOf(rs.getDate("P_DUE_DATE"));
				result = rs.getString("P_DUE_DATE");
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return result;
	}

	private String fetchDataFromTIplus(InvMatchingVO invoiceVO)
			throws DAOException, ParseException {
		Connection con = null;
		CallableStatement callableStatement = null;
		ResultSet rs = null;
		invList = new ArrayList<InvMatchingDataVO>();
		String sqlQuery = null;
		CommonMethods commonMethods = null;
		InvMatchingDataVO invMatchingDataVO = null;
		String repayAmt = invoiceVO.getPayAmount().replaceAll(",", "");
		String BatchID = "";
		double reAmount = 0;
		int sum = 0;
		String CP_ID = "";
		String programType = null;
		String ETT_REPAY_AUTO_PROC = null;
		String projectType = null;
		int outputColumn = 0;
		String referenceNumber = null;
		String payAccount = null;
		NumberFormat formatter = new DecimalFormat("#0.00");
		try {
			commonMethods = new CommonMethods();
			if (invoiceVO.getProjectType() == null) {
				HttpSession httpSession = ServletActionContext.getRequest()
						.getSession();
				projectType = (String) httpSession.getAttribute(SESSION_MANUAL);
			}
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			referenceNumber = invoiceVO.getReferenceNumber().trim();
			payAccount = invoiceVO.getPayAccount().trim();
			if (projectType != null && projectType.equalsIgnoreCase(MANUAL)) {
				ETT_REPAY_AUTO_PROC = "{call ETT_REPAY_AUTO_PROC_MANUAL(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			} else {
				ETT_REPAY_AUTO_PROC = "{call ETT_REPAY_AUTO_PROC(?,?,?,?,?,?,?,?,?,?)}";
			}
			System.out.println("repayAt " + repayAmt);
			System.out.println(invoiceVO.getCounterParty());
			System.out.println("INR");
			System.out.println(invoiceVO.getProgId());
			System.out.println(invoiceVO.getAllocationType());

			String allocationType = invoiceVO.getAllocationType();
			String repayBy = "A";
			/*
			 * if (!commonMethods.isNull(invoiceVO.getRepayBy())) { repayBy =
			 * invoiceVO.getRepayBy(); }
			 */
			if (!commonMethods.isNull(invoiceVO.getVirtualAccount())) {
				repayBy = invoiceVO.getVirtualAccount();
			}
			String CIF_ID = "";
			if (null != allocationType && allocationType.equalsIgnoreCase("MF")) {
				CIF_ID = invoiceVO.getCounterParty();
				CP_ID = "-1";
			} else {
				CIF_ID = invoiceVO.getDebitParty();
				CP_ID = invoiceVO.getCounterParty();
			}

			String RepaymentAmt = repayAmt;
			logger.info("VALUE DATE---->" + invoiceVO.getValueDate());
			java.sql.Date sqlDate = null;
			java.sql.Date dueDate = null;
			if (!commonMethods.isNull(invoiceVO.getValueDate())) {
				SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
				Date parsed = format.parse(invoiceVO.getValueDate());
				sqlDate = new java.sql.Date(parsed.getTime());
			}
			if (!commonMethods.isNull(invoiceVO.getDueDateFilter())) {
				SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
				Date parsed = format.parse(invoiceVO.getDueDateFilter());
				dueDate = new java.sql.Date(parsed.getTime());
			}

			programType = getProgramType(invoiceVO.getProgId());
			// if(commonMethods.)
			logger.info("CIF_ID -->"+CIF_ID);
			logger.info("payAccount -->"+payAccount);
			
			logger.info("RepaymentAmt -->"+Double.parseDouble(RepaymentAmt));
			logger.info("allocationType -->"+allocationType);
			logger.info("CP_ID -->"+CP_ID);
			logger.info("invoiceVO.getRepaymentAllocationType()t -->"+invoiceVO.getRepaymentAllocationType());
			logger.info("sqlDate -->"+sqlDate);
			logger.info("repayBy -->"+repayBy);
			logger.info("repayType -->"+invoiceVO.getRepayType());
			logger.info("repayBy -->"+repayBy);
			logger.info("14, dueDate -->"+ dueDate);
			if (!repayAmt.equals("")) {
				if (projectType != null && projectType.equalsIgnoreCase(MANUAL)) {
					reAmount = Double.parseDouble(repayAmt);
					RepaymentAmt = formatter.format(reAmount);
					System.out.println(reAmount);
					System.out.println("PASSING VALUE" + CIF_ID);
					callableStatement = con.prepareCall(ETT_REPAY_AUTO_PROC);
					callableStatement.setString(1, CIF_ID);
					callableStatement.setString(2, payAccount);
					callableStatement.setString(3, referenceNumber);
					callableStatement.setDouble(4,
							Double.parseDouble(RepaymentAmt));
					callableStatement.setString(5, "INR");
					callableStatement.setString(6, invoiceVO.getProgId());
					callableStatement.setString(7, allocationType);
					callableStatement.setString(8, CP_ID);
					callableStatement.setString(9,
							invoiceVO.getRepaymentAllocationType());
					callableStatement.setDate(10, sqlDate);
					// callableStatement.setDate(10
					callableStatement.registerOutParameter(11,
							java.sql.Types.INTEGER);
					callableStatement.setString(12, repayBy);
					callableStatement.setString(13, invoiceVO.getRepayType());
					callableStatement.setDate(14, dueDate);
					outputColumn = 11;
				} else {
					reAmount = Double.parseDouble(repayAmt);
					RepaymentAmt = formatter.format(reAmount);
					System.out.println(formatter.format(reAmount));
					System.out.println("PASSING VALUE" + CIF_ID);
					callableStatement = con.prepareCall(ETT_REPAY_AUTO_PROC);
					callableStatement.setString(1, CIF_ID);
					callableStatement.setString(2, payAccount);
					callableStatement.setString(3, referenceNumber);
					callableStatement.setDouble(4,
							Double.parseDouble(RepaymentAmt));
					callableStatement.setString(5, "INR");
					callableStatement.setString(6, invoiceVO.getProgId());
					callableStatement.setString(7, allocationType);
					callableStatement.setString(8, CP_ID);
					callableStatement.setString(9,
							invoiceVO.getRepaymentAllocationType());
					callableStatement.registerOutParameter(10,
							java.sql.Types.INTEGER);
					outputColumn = 10;
				}
				// execute ETT_REPAY_AUTO_PROC store procedure
				logger.info("Before calling procedure");
				logger.info("Procedure name" + ETT_REPAY_AUTO_PROC);
				callableStatement.executeUpdate();
				logger.info("After calling procedure");
				BatchID = callableStatement.getString(outputColumn);
				logger.info("BatchID--->" + BatchID);
			}
			if (!allocationType.isEmpty()) {
				invoiceVO.setAllocationType(allocationType);
			}
			if (!invList.isEmpty()) {
				invoiceVO.setInvList(invList);
			}
			debitlst = getDebitlst();
			if (debitlst != null) {
				invoiceVO.setDebitList(debitlst);
			}
			counterList = getCounterList();
			if (counterList != null) {
				invoiceVO.setCounterList(counterList);
			}
		} catch (SQLException e) {

			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, callableStatement, con);
		}

		return BatchID;
	}

	public InvMatchingVO fetchPenalList(InvMatchingVO invMatchVo)
			throws DAOException {
		ArrayList<InvMatchingVO> invoicList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			invoicList = new ArrayList<InvMatchingVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			String virtualAccNo = invMatchVo.getVirtualAccount();
			String loanMasterRef = invMatchVo.getLoanMasterRef();
			String FETCH_QUERY = "SELECT DISTINCT DEALREF,INVOIC_REF,LOANAMT,OS_AMT,TO_CHAR(TO_DATE(DISBDT, 'dd-mm-yy'),'dd-mm-yyyy') as DISBDT,TO_CHAR(TO_DATE(DUEDT, 'dd-mm-yy'),'dd-mm-yyyy') as DUEDT,REPAY_ACCT_NO,PROGIDN,ETT_CUST_NAME(CPARTY) as CPARTY,ETT_CUST_NAME(ANCHID) as ANCHORPARTY  FROM ETT_PROG_RELATION_CAP WHERE REPAY_ACCT_NO = REPAY_ACCT_NO ";
			/* REPAY_ACCT_NO */

			if (loanMasterRef != null && !loanMasterRef.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND trim(DEALREF)  LIKE '%"
						+ loanMasterRef.trim() + "%' ";
			}
			if (virtualAccNo != null && !virtualAccNo.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND trim(REPAY_ACCT_NO)  LIKE '%"
						+ virtualAccNo.trim() + "%' ";
			}
			FETCH_QUERY += " AND OS_AMT<>0 ORDER BY TO_DATE(DUEDT, 'dd-mm-yy') ASC";
			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvMatchingVO invvo = new InvMatchingVO();
				invvo.setMasterRef(comm.getEmptyIfNull(rs.getString("DEALREF"))
						.trim());
				invvo.setInvNumber(comm.getEmptyIfNull(
						rs.getString("INVOIC_REF")).trim());
				invvo.setDisburseDate(comm.getEmptyIfNull(
						rs.getString("DISBDT")).trim());
				invvo.setDueDate(comm.getEmptyIfNull(rs.getString("DUEDT"))
						.trim());
				invvo.setLoanAmount(comm
						.getEmptyIfNull(rs.getString("LOANAMT")).trim());
				invvo.setOutAmount(comm.getEmptyIfNull(rs.getString("OS_AMT"))
						.trim());
				//MAH-882
				invMatchVo.setVirtualAccount(comm.getEmptyIfNull(rs.getString("REPAY_ACCT_NO")).trim());
				invMatchVo.setDebitPartyFullName(comm.getEmptyIfNull(rs.getString("ANCHORPARTY")).trim());
				invMatchVo.setCounterParty(comm.getEmptyIfNull(rs.getString("CPARTY")).trim());
				invMatchVo.setProgId(comm.getEmptyIfNull(rs.getString("PROGIDN")).trim());
				//MAH-882
				
				invoicList.add(invvo);
			}
			
			invMatchVo.setTiList(invoicList);
		System.out.println("REPAY_ACCT_NO -->"+invMatchVo.getVirtualAccount());
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invMatchVo;
	}
	
	//12Feb
	public InvMatchingVO fetchChargePenalDetails(InvMatchingVO invMatchVo)
			throws DAOException {
		ArrayList<InvMatchingVO> invoicList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			invoicList = new ArrayList<InvMatchingVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			String virtualAccNo = invMatchVo.getVirtualAccount();
			String loanMasterRef = invMatchVo.getLoanMasterRef();
			String FETCH_QUERY = "SELECT DISTINCT DEALREF,INVOIC_REF,LOANAMT,OS_AMT,TO_CHAR(TO_DATE(DISBDT, 'dd-mm-yy'),'dd-mm-yyyy') as DISBDT,TO_CHAR(TO_DATE(DUEDT, 'dd-mm-yy'),'dd-mm-yyyy') as DUEDT  FROM ETT_PROG_RELATION_CAP WHERE REPAY_ACCT_NO = REPAY_ACCT_NO ";

			if (loanMasterRef != null && !loanMasterRef.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND trim(DEALREF)  LIKE '%"
						+ loanMasterRef.trim() + "%' ";
			}
			if (virtualAccNo != null && !virtualAccNo.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND trim(REPAY_ACCT_NO) LIKE '%"
						+ virtualAccNo.trim() + "%' ";
			}
			FETCH_QUERY += " ORDER BY TO_DATE(DUEDT, 'dd-mm-yy') ASC";
			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvMatchingVO invvo = new InvMatchingVO();
				invvo.setMasterRef(comm.getEmptyIfNull(rs.getString("DEALREF"))
						.trim());
				invvo.setInvNumber(comm.getEmptyIfNull(
						rs.getString("INVOIC_REF")).trim());
				invvo.setDisburseDate(comm.getEmptyIfNull(
						rs.getString("DISBDT")).trim());
				invvo.setDueDate(comm.getEmptyIfNull(rs.getString("DUEDT"))
						.trim());
				invvo.setLoanAmount(comm
						.getEmptyIfNull(rs.getString("LOANAMT")).trim());
				invvo.setOutAmount(comm.getEmptyIfNull(rs.getString("OS_AMT"))
						.trim());
				invoicList.add(invvo);
			}
			invMatchVo.setTiList(invoicList);
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invMatchVo;
	}
	
	
	//04Feb
	public InvMatchingVO fetchPenalListCheck(InvMatchingVO invMatchVo)
			throws DAOException {
		ArrayList<InvMatchingVO> invoicList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			invoicList = new ArrayList<InvMatchingVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "2";
			}

			String virtualAccNo = invMatchVo.getVirtualAccount();
			String loanMasterRef = invMatchVo.getLoanMasterRef();
			String batchIDSeq = invMatchVo.getBatchIDSeq();
			String FETCH_QUERY = "SELECT DISTINCT PROG.DEALREF,PROG.INVOIC_REF,PROG.LOANAMT,PROG.OS_AMT,"
					+ "TO_CHAR(TO_DATE(PROG.DISBDT, 'dd-mm-yy'),'dd-mm-yyyy') as DISBDT,"
					+ "TO_CHAR(TO_DATE(PROG.DUEDT, 'dd-mm-yy'),'dd-mm-yyyy') as DUEDT,"
					+ "ETT.ADD_INTEREST, ETT.ADD_PENAL "
					+ "FROM ETT_PROG_RELATION_CAP PROG, ETT_ADD_INTEREST ETT "
					+ "WHERE PROG.DEALREF = ETT.DEALREF "
					+ "AND ETT.STATUS='MA' AND ETT.MAKER_ID NOT IN ('"+userID+"')";

			if (loanMasterRef != null && !loanMasterRef.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND PROG.DEALREF LIKE '%"
						+ loanMasterRef.trim() + "%' ";
			}
			if (virtualAccNo != null && !virtualAccNo.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND PROG.REPAY_ACCT_NO LIKE '%"
						+ virtualAccNo.trim() + "%' ";
			}
			if (batchIDSeq != null && !batchIDSeq.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND ETT.BATCH_ID LIKE UPPER('%"
						+ batchIDSeq.trim() + "%') ";
			}
			FETCH_QUERY += " AND ETT.BATCH_ID IS NOT NULL";
			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvMatchingVO invvo = new InvMatchingVO();
				invvo.setMasterRef(comm.getEmptyIfNull(rs.getString("DEALREF"))
						.trim());
				invvo.setInvNumber(comm.getEmptyIfNull(
						rs.getString("INVOIC_REF")).trim());
				invvo.setDisburseDate(comm.getEmptyIfNull(
						rs.getString("DISBDT")).trim());
				invvo.setDueDate(comm.getEmptyIfNull(rs.getString("DUEDT"))
						.trim());
				invvo.setLoanAmount(comm
						.getEmptyIfNull(rs.getString("LOANAMT")).trim());
				invvo.setOutAmount(comm.getEmptyIfNull(rs.getString("OS_AMT"))
						.trim());
				invvo.setAddInterest(comm.getEmptyIfNull(rs.getString("ADD_INTEREST"))
						.trim());
				invvo.setAddPenal(comm.getEmptyIfNull(rs.getString("ADD_PENAL"))
						.trim());
				invoicList.add(invvo);
			}
			invMatchVo.setTiList(invoicList);
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invMatchVo;
	}
	
	
	//11Feb
	public InvMatchingVO getBulkUploadValueCheck(InvMatchingVO invMatchVo)
			throws DAOException {
		ArrayList<InvMatchingVO> invoicList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			invoicList = new ArrayList<InvMatchingVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "2";
			}

			String loanMasterRef = invMatchVo.getLoanMasterRef();
			String virtualAccount = invMatchVo.getVirtualAccount();
			String batchIDSeq = invMatchVo.getBatchIDSeq();
			String FETCH_QUERY = "SELECT LOAN_REFERENCE,VIRTUAL_ACCOUNT,CHARGE_CODE,CHARGE_TYPE,AMOUNT"
					+ " FROM ETT_CHARGE_UPLOAD_TBL "
					+ " WHERE STATUS='MA' AND MAKER_ID NOT IN ('"+userID+"')";

			if (loanMasterRef != null && !loanMasterRef.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND LOAN_REFERENCE LIKE '%"
						+ loanMasterRef.trim() + "%' ";
			}
			if (virtualAccount != null && !virtualAccount.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND VIRTUAL_ACCOUNT LIKE '%"
						+ virtualAccount.trim() + "%' ";
			}
			if (batchIDSeq != null && !batchIDSeq.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND BATCH_ID LIKE UPPER('%"
						+ batchIDSeq.trim() + "%') ";
			}
			FETCH_QUERY += " AND BATCH_ID IS NOT NULL";
			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvMatchingVO invvo = new InvMatchingVO();
				invvo.setLoanMasterRef(comm.getEmptyIfNull(
						rs.getString("LOAN_REFERENCE")).trim());
				invvo.setVirtualAccount(comm.getEmptyIfNull(
						rs.getString("VIRTUAL_ACCOUNT")).trim());
				invvo.setChargeCode(comm.getEmptyIfNull(
						rs.getString("CHARGE_CODE")).trim());
				invvo.setChargeType(comm.getEmptyIfNull(
						rs.getString("CHARGE_TYPE")).trim());
				invvo.setAmount(comm.getEmptyIfNull(rs.getString("AMOUNT"))
						.trim());
				invoicList.add(invvo);
			}
			TotalValuesChecker(invMatchVo, con, batchIDSeq);
			invMatchVo.setTiList(invoicList);
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invMatchVo;
	}
	
	
	//04Feb
	public InvMatchingVO getBatchList(InvMatchingVO invMatchingVo) throws DAOException {
		ArrayList<InvBatchVO> batchList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			batchList = new ArrayList<InvBatchVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "2";
			}

			String virtualAccNo = invMatchingVo.getVirtualAccount();
			String loanMasterRef = invMatchingVo.getLoanMasterRef();
			String batchIDSeq = invMatchingVo.getBatchIDSeq();
			String FETCH_QUERY = "SELECT DISTINCT REPAY_ACCT_NO, BATCH_ID, "
					+ "TRIM((SELECT NAME85 FROM SECAGE88 WHERE SKEY80=MAKER_ID)) AS MAKER_ID "
					+ "FROM ETT_ADD_INTEREST WHERE STATUS='MA' AND MAKER_ID NOT IN ('"+userID+"')";

			if (loanMasterRef != null && !loanMasterRef.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND DEALREF LIKE '%"
						+ loanMasterRef.trim() + "%' ";
			}
			if (virtualAccNo != null && !virtualAccNo.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND REPAY_ACCT_NO LIKE '%"
						+ virtualAccNo.trim() + "%' ";
			}
			if (batchIDSeq != null && !batchIDSeq.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND BATCH_ID LIKE UPPER('%"
						+ batchIDSeq.trim() + "%') ";
			}
			FETCH_QUERY += " AND BATCH_ID IS NOT NULL";
			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvBatchVO invvo = new InvBatchVO();
				invvo.setVirtualAccNo(comm.getEmptyIfNull(rs.getString("REPAY_ACCT_NO"))
						.trim());
				invvo.setBatchIDSeq(comm.getEmptyIfNull(rs.getString("BATCH_ID"))
						.trim());
				invvo.setMakerID(comm.getEmptyIfNull(rs.getString("MAKER_ID"))
						.trim());
				batchList.add(invvo);
			}
			invMatchingVo.setBatchList(batchList);
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invMatchingVo;
	}
	
	
	//04Feb
	public ArrayList<InvMatchingVO> viewList(String batchIDSeq)
			throws DAOException {
		ArrayList<InvMatchingVO> invoicList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			invoicList = new ArrayList<InvMatchingVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			String FETCH_QUERY = "SELECT DISTINCT PROG.DEALREF,PROG.INVOIC_REF,PROG.LOANAMT,PROG.OS_AMT,"
					+ "TO_CHAR(TO_DATE(PROG.DISBDT, 'dd-mm-yy'),'dd-mm-yyyy') as DISBDT,"
					+ "TO_CHAR(TO_DATE(PROG.DUEDT, 'dd-mm-yy'),'dd-mm-yyyy') as DUEDT,"
					+ "ETT.ADD_INTEREST, ETT.ADD_PENAL "
					+ "FROM ETT_PROG_RELATION_CAP PROG, ETT_ADD_INTEREST ETT "
					+ "WHERE PROG.DEALREF = ETT.DEALREF ";

			if (batchIDSeq != null && !batchIDSeq.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND ETT.BATCH_ID LIKE UPPER('%"
						+ batchIDSeq.trim() + "%') ";
			}

			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvMatchingVO invvo = new InvMatchingVO();
				invvo.setMasterRef(comm.getEmptyIfNull(rs.getString("DEALREF"))
						.trim());
				invvo.setInvNumber(comm.getEmptyIfNull(
						rs.getString("INVOIC_REF")).trim());
				invvo.setDisburseDate(comm.getEmptyIfNull(
						rs.getString("DISBDT")).trim());
				invvo.setDueDate(comm.getEmptyIfNull(rs.getString("DUEDT"))
						.trim());
				invvo.setLoanAmount(comm
						.getEmptyIfNull(rs.getString("LOANAMT")).trim());
				invvo.setOutAmount(comm.getEmptyIfNull(rs.getString("OS_AMT"))
						.trim());
				invvo.setAddInterest(comm.getEmptyIfNull(rs.getString("ADD_INTEREST"))
						.trim());
				invvo.setAddPenal(comm.getEmptyIfNull(rs.getString("ADD_PENAL"))
						.trim());
				invoicList.add(invvo);
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invoicList;
	}
	
	
	//11Feb
	public InvMatchingVO getChargesBatchListCheck(InvMatchingVO invMatchingVo) throws DAOException {
		ArrayList<InvBatchVO> batchList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			batchList = new ArrayList<InvBatchVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			//String userID = (String) httpSession.getAttribute(LOGINUSER);
			String userID = null;
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "1000003471";
			}
System.out.println("userID-->"+userID);
			String virtualAccount = invMatchingVo.getVirtualAccount();
			String batchIDSeq = invMatchingVo.getBatchIDSeq();
			String FETCH_QUERY = "SELECT MAX(VIRTUAL_ACCOUNT) AS VIRTUAL_ACCOUNT, BATCH_ID,"
					+ " TRIM((SELECT NAME85 FROM SECAGE88 WHERE SKEY80=MAKER_ID)) AS MAKER_ID"
					+ " FROM ETT_CHARGE_UPLOAD_TBL WHERE STATUS='MA' AND MAKER_ID NOT IN ('"+userID+"')";

			if (virtualAccount != null && !virtualAccount.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND VIRTUAL_ACCOUNT LIKE '%"
						+ virtualAccount.trim() + "%' ";
			}
			if (batchIDSeq != null && !batchIDSeq.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND BATCH_ID LIKE UPPER('%"
						+ batchIDSeq.trim() + "%') ";
			}
			FETCH_QUERY += " AND BATCH_ID IS NOT NULL GROUP BY BATCH_ID,MAKER_ID";
			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query -->" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvBatchVO invvo = new InvBatchVO();
				invvo.setVirtualAccNo(comm.getEmptyIfNull(rs.getString("VIRTUAL_ACCOUNT"))
						.trim());
				invvo.setBatchIDSeq(comm.getEmptyIfNull(rs.getString("BATCH_ID"))
						.trim());
				invvo.setMakerID(comm.getEmptyIfNull(rs.getString("MAKER_ID"))
						.trim());
				batchList.add(invvo);
			}
			invMatchingVo.setBatchList(batchList);
			TotalValuesChecker(invMatchingVo, con, batchIDSeq);
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invMatchingVo;
	}
	
	
	//04Feb
	public InvMatchingVO getBatchListView(InvMatchingVO invMatchingVo) throws DAOException {
		ArrayList<InvBatchVO> batchList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			batchList = new ArrayList<InvBatchVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			String virtualAccNo = invMatchingVo.getVirtualAccount();
			String loanMasterRef = invMatchingVo.getLoanMasterRef();
			String batchIDSeq = invMatchingVo.getBatchIDSeq();
			String statusFilter = invMatchingVo.getStatusFilter();
			String FETCH_QUERY = "SELECT DISTINCT REPAY_ACCT_NO, BATCH_ID, "
					+ "TRIM((SELECT NAME85 FROM SECAGE88 WHERE SKEY80=MAKER_ID)) AS MAKER_ID,"
					+ "DECODE(STATUS,'MA','MAKER APPROVED','CA','CHECKER APPROVED','CR','CHECKER REJECTED',STATUS) AS STATUS "
					+ "FROM ETT_ADD_INTEREST WHERE 1=1 ";

			if (loanMasterRef != null && !loanMasterRef.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND DEALREF LIKE '%"
						+ loanMasterRef.trim() + "%' ";
			}
			if (virtualAccNo != null && !virtualAccNo.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND REPAY_ACCT_NO LIKE '%"
						+ virtualAccNo.trim() + "%' ";
			}
			if (batchIDSeq != null && !batchIDSeq.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND BATCH_ID LIKE UPPER('%"
						+ batchIDSeq.trim() + "%') ";
			}
			if (statusFilter != null && !statusFilter.equals("-1")) {
				FETCH_QUERY += " AND STATUS = '"
						+ statusFilter.trim() + "' ";
			}
			FETCH_QUERY += " AND BATCH_ID IS NOT NULL";
			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvBatchVO invvo = new InvBatchVO();
				invvo.setVirtualAccNo(comm.getEmptyIfNull(rs.getString("REPAY_ACCT_NO"))
						.trim());
				invvo.setBatchIDSeq(comm.getEmptyIfNull(rs.getString("BATCH_ID"))
						.trim());
				invvo.setMakerID(comm.getEmptyIfNull(rs.getString("MAKER_ID"))
						.trim());
				invvo.setStatus(comm.getEmptyIfNull(rs.getString("STATUS"))
						.trim());
				batchList.add(invvo);
			}
			invMatchingVo.setBatchList(batchList);
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invMatchingVo;
	}
	
	
	//11Feb
	public InvMatchingVO getBulkUploadBatchListView(InvMatchingVO invMatchingVo) throws DAOException {
		ArrayList<InvBatchVO> batchList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		try {
			batchList = new ArrayList<InvBatchVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			String loanMasterRef = invMatchingVo.getLoanMasterRef();
			String virtualAccount = invMatchingVo.getVirtualAccount();
			String batchIDSeq = invMatchingVo.getBatchIDSeq();
			String statusFilter = invMatchingVo.getStatusFilter();
			String chargeFilter = invMatchingVo.getChargeType();

			String FETCH_QUERY = "SELECT DISTINCT BATCH_ID, "
					+ "TRIM((SELECT NAME85 FROM SECAGE88 WHERE SKEY80=MAKER_ID)) AS MAKER_ID,"
					+ "DECODE(STATUS,'MA','MAKER APPROVED','CA','CHECKER APPROVED','CR','CHECKER REJECTED','ERROR DATA') AS STATUS "
					+ "FROM ETT_CHARGE_UPLOAD_TBL WHERE 1=1 ";

			if (loanMasterRef != null && !loanMasterRef.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND LOAN_REFERENCE LIKE '%"
						+ loanMasterRef.trim() + "%' ";
			}
			if (virtualAccount != null && !virtualAccount.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND VIRTUAL_ACCOUNT LIKE '%"
						+ virtualAccount.trim() + "%' ";
			}
			if (batchIDSeq != null && !batchIDSeq.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND BATCH_ID LIKE UPPER('%"
						+ batchIDSeq.trim() + "%') ";
			}
			if(statusFilter == null || statusFilter.trim().length() == 0) {
				FETCH_QUERY += " AND TRIM(STATUS) IS NULL ";
			} else if (statusFilter != null && !statusFilter.equals("-1")) {
				FETCH_QUERY += " AND STATUS = '"
						+ statusFilter.trim() + "' AND TRIM(STATUS) IS NOT NULL ";
			}
			if (chargeFilter != null && !chargeFilter.equals("-1")) {
				FETCH_QUERY += " AND CHARGE_CODE = '"
						+ chargeFilter.trim() + "' ";
			}
			FETCH_QUERY += " AND BATCH_ID IS NOT NULL"
					+ " ORDER BY CAST((SUBSTR(BATCH_ID, 6, 10)) AS NUMBER) DESC";
			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvBatchVO invvo = new InvBatchVO();
				invvo.setBatchIDSeq(comm.getEmptyIfNull(rs.getString("BATCH_ID"))
						.trim());
				invvo.setMakerID(comm.getEmptyIfNull(rs.getString("MAKER_ID"))
						.trim());
				invvo.setStatus(comm.getEmptyIfNull(rs.getString("STATUS"))
						.trim());
				batchList.add(invvo);
			}
			invMatchingVo.setBatchList(batchList);
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invMatchingVo;
	}
	
	
	//11Feb
	public ArrayList<InvMatchingVO> fetchChargesViewList(String invoiceAjaxListval)
			throws DAOException {
		ArrayList<InvMatchingVO> invoicList = null;
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		CommonMethods comm = null;
		String chargeFilter = "";
		String batchIDSeq = "";
		String statusFilter = "";
		try {
			invoicList = new ArrayList<InvMatchingVO>();
			comm = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			if(invoiceAjaxListval != null && invoiceAjaxListval.trim().length()>0) {
				if(invoiceAjaxListval.contains("_")) {
					statusFilter = invoiceAjaxListval.split("_")[1];
					batchIDSeq = invoiceAjaxListval.split("_")[0];
					if(statusFilter.contains(":")) {
						chargeFilter = statusFilter.split(":")[1];
						statusFilter = statusFilter.split(":")[0];
					}
				}
			}

			String FETCH_QUERY = "SELECT LOAN_REFERENCE,VIRTUAL_ACCOUNT,CHARGE_CODE,CHARGE_TYPE,AMOUNT,ERROR_DETAILS"
					+ " FROM ETT_CHARGE_UPLOAD_TBL WHERE 1=1 ";

			if (batchIDSeq != null && !batchIDSeq.equalsIgnoreCase("")) {
				FETCH_QUERY += " AND BATCH_ID LIKE UPPER('%"
						+ batchIDSeq.trim() + "%') ";
			}
			if (chargeFilter != null && !chargeFilter.equals("-1")) {
				FETCH_QUERY += " AND CHARGE_CODE = '"
						+ chargeFilter.trim() + "' ";
			}
			if(statusFilter != null && statusFilter.equals("ERROR DATA")) {
				FETCH_QUERY += " AND TRIM(STATUS) IS NULL";
			} else if (statusFilter != null && !statusFilter.equals("ERROR DATA")) {
				FETCH_QUERY += " AND TRIM(STATUS) IS NOT NULL";
			}

			pst = new LoggableStatement(con, FETCH_QUERY);
			System.out.println("Fetch Query" + pst.getQueryString());
			rs = pst.executeQuery();

			while (rs.next()) {
				InvMatchingVO invvo = new InvMatchingVO();
				invvo.setLoanMasterRef(comm.getEmptyIfNull(
						rs.getString("LOAN_REFERENCE")).trim());
				invvo.setVirtualAccount(comm.getEmptyIfNull(
						rs.getString("VIRTUAL_ACCOUNT")).trim());
				invvo.setChargeCode(comm.getEmptyIfNull(
						rs.getString("CHARGE_CODE")).trim());
				invvo.setChargeType(comm.getEmptyIfNull(
						rs.getString("CHARGE_TYPE")).trim());
				invvo.setAmount(comm.getEmptyIfNull(rs.getString("AMOUNT"))
						.trim());
				invvo.setErrorDetails(comm.getEmptyIfNull(
						rs.getString("ERROR_DETAILS")).trim());
				invoicList.add(invvo);
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return invoicList;
	}


	public ArrayList<InvMatchingVO> fetchInvoiceList(String batchid)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ArrayList<InvMatchingVO> invoicList = null;
		InvMatchingVO invvo = null;
		LoggableStatement pst = null;
		/*
		 * LoggableStatement loggableStatement = null; LoggableStatement
		 * loggableStatement1 = null;
		 */
		ResultSet rs = null;
		/*
		 * ResultSet rs1 = null; ResultSet rs2 = null;
		 */
		STPProcessDAO dao = null;
		Connection con = null;
		CommonMethods comm = new CommonMethods();
		NumberFormat formatter = new DecimalFormat("#0.00");
		HttpSession httpSession = null;
		String query = null;
		String userRole = null;
		/*
		 * double principalOutStanding = 0; double interestOutStanding = 0;
		 * double chargesOutStanding = 0; double penalOutStanding = 0; double
		 * totalOutStanding = 0;
		 */
		BigDecimal principalOutStanding = new BigDecimal("0.00");
		BigDecimal interestOutStanding = new BigDecimal("0.00");
		BigDecimal chargesOutStanding = new BigDecimal("0.00");
		BigDecimal penalOutStanding = new BigDecimal("0.00");
		BigDecimal totalOutStanding = new BigDecimal("0.00");
		BigDecimal tdsOutStanding = new BigDecimal("0.00");
		BigDecimal prcAllocationTotal = new BigDecimal("0.00");
		try {
			dao = STPProcessDAO.getDAO();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			invoicList = new ArrayList<InvMatchingVO>();
			httpSession = ServletActionContext.getRequest().getSession();
			userRole = (String) httpSession.getAttribute(SESSION_ROLE);
			/*
			 * if (comm.isNull(userRole) || !userRole.equalsIgnoreCase(CHECKER))
			 * { query =
			 * "SELECT '0'LOAN_MASTER_REF,'0'INVOICE_NO,sysdate DISBURSEMENT_DATE,to_date('05-01-2001','dd-mm-yyyy') DUE_DATE,sum(PRC_ALLC_AMOUNT) PRC_ALLC_AMOUNT,"
			 * +
			 * "SUM(OS_AMOUNT)OS_AMOUNT,'0'GW_STATUS,SUM(PRIN_OS_AMT)PRIN_OS_AMT,SUM(INT_OS_AMT)INT_OS_AMT,SUM(PNL_OS_AMT)PNL_OS_AMT,sum(nvl(CHG_OS_AMT,0))CHG_OS_AMT,'0' DEALORDER "
			 * + "FROM ETT_STP_REPAYMENT WHERE BATCH_ID='"+batchid+
			 * "' UNION ALL  SELECT LOAN_MASTER_REF,INVOICE_NO,DISBURSEMENT_DATE,DUE_DATE,PRC_ALLC_AMOUNT,"
			 * +
			 * "OS_AMOUNT,GW_STATUS,PRIN_OS_AMT,INT_OS_AMT,PNL_OS_AMT,CHG_OS_AMT,SUBSTR(TRIM(LOAN_MASTER_REF),-5) DEALORDER"
			 * + " FROM ETT_STP_REPAYMENT WHERE BATCH_ID='" + batchid +
			 * "' ORDER BY DUE_DATE,DEALORDER"; } else { query =
			 * "SELECT '0'LOAN_MASTER_REF,'0'INVOICE_NO,sysdate DISBURSEMENT_DATE,to_date('05-01-2001','dd-mm-yyyy') DUE_DATE,sum(PRC_ALLC_AMOUNT) PRC_ALLC_AMOUNT,"
			 * +
			 * "SUM(OS_AMOUNT)OS_AMOUNT,'0'GW_STATUS,SUM(PRIN_OS_AMT)PRIN_OS_AMT,SUM(INT_OS_AMT)INT_OS_AMT,SUM(PNL_OS_AMT)PNL_OS_AMT,sum(nvl(CHG_OS_AMT,0))CHG_OS_AMT,'0' DEALORDER "
			 * + "FROM ETT_STP_REPAYMENT WHERE BATCH_ID='"+batchid+
			 * "' UNION ALL  SELECT LOAN_MASTER_REF,INVOICE_NO,DISBURSEMENT_DATE,DUE_DATE,PRC_ALLC_AMOUNT,"
			 * +
			 * "OS_AMOUNT,GW_STATUS,PRIN_OS_AMT,INT_OS_AMT,PNL_OS_AMT,CHG_OS_AMT,SUBSTR(TRIM(LOAN_MASTER_REF),-5) DEALORDER"
			 * + " FROM ETT_STP_REPAYMENT WHERE BATCH_ID='" + batchid +
			 * "' ORDER BY PRC_ALLC_AMOUNT DESC,DUE_DATE,DEALORDER"; }
			 */
			if (comm.isNull(userRole) || !userRole.equalsIgnoreCase(CHECKER)) {
				query = "SELECT ETT_CUST_NAME(COUNTER_PARTY) CPARTY,LOAN_MASTER_REF,INVOICE_NO,DISBURSEMENT_DATE,DUE_DATE,PRC_ALLC_AMOUNT,"
						+ "OS_AMOUNT,GW_STATUS,PRIN_OS_AMT,INT_OS_AMT,PNL_OS_AMT,CHG_OS_AMT,SUBSTR(TRIM(LOAN_MASTER_REF),-5) DEALORDER,TDSAMT "
						+ " FROM ETT_STP_REPAYMENT WHERE BATCH_ID='"
						+ batchid
						+ "' ORDER BY DUE_DATE,DEALORDER";
			} else {
				query = "SELECT ETT_CUST_NAME(COUNTER_PARTY) CPARTY,LOAN_MASTER_REF,INVOICE_NO,DISBURSEMENT_DATE,DUE_DATE,PRC_ALLC_AMOUNT,"
						+ "OS_AMOUNT,GW_STATUS,PRIN_OS_AMT,INT_OS_AMT,PNL_OS_AMT,CHG_OS_AMT,SUBSTR(TRIM(LOAN_MASTER_REF),-5) DEALORDER,TDSAMT "
						+ " FROM ETT_STP_REPAYMENT WHERE BATCH_ID='"
						+ batchid
						+ "' ORDER BY PRC_ALLC_AMOUNT DESC,DUE_DATE,DEALORDER";
			}
			System.out.println(query);
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			int i = 1;
			while (rs.next()) {
				i++;
				// LogHelper.logError(logger,String.valueOf(i));
/*				logger.error(query);
				logger.error(batchid + "@" + String.valueOf(i));
*/				invvo = new InvMatchingVO();
				invvo.setMasterRef(rs.getString(LOAN_MASTER_REF));
				invvo.setCounterPartyName(rs.getString(CPARTY));
				invvo.setInvNumber(rs.getString(INVOICE_NO));
				invvo.setDisburseDate(comm.getCurrentDate(rs
						.getString(DISBURSEMENT_DATE)));
				invvo.setDueDate(comm.getCurrentDate(rs.getString(DUE_DATE)));
				/*
				 * invvo.setAllocAmt(comm.doubleComma(rs
				 * .getString(PRC_ALLC_AMOUNT)));
				 */
				String allocate = rs.getString(PRC_ALLC_AMOUNT);
				double alocate = Double.parseDouble(allocate.trim());
				invvo.setAllocAmt(comm.doubleComma(formatter.format(alocate)));
				//System.out.println("setAllocAmt------>" + comm.doubleComma(formatter.format(alocate)) );
				if (null == allocate)
					allocate = "0.00";
				double totalAllocate = Double.parseDouble(allocate.trim());
				BigDecimal prcTotal = new BigDecimal(totalAllocate);
				prcAllocationTotal = prcAllocationTotal.add(prcTotal);
				invvo.setTotalAllocAmount(comm.doubleComma(formatter
						.format(prcAllocationTotal)));
				String outstanding = rs.getString(OS_AMOUNT);
				double format = Double.parseDouble(outstanding.trim());
				// totalOutStanding = Double.sum(totalOutStanding,format);
				BigDecimal outStanding = new BigDecimal(outstanding);
				totalOutStanding = totalOutStanding.add(outStanding);
				invvo.setOutAmount(comm.doubleComma(formatter.format(format)));
				invvo.setTotalOutstanding(comm.doubleComma(formatter
						.format(totalOutStanding)));

				String status = comm.getEmptyIfNull(rs.getString(GW_STATUS))
						.trim();
				if (status != null && status.equalsIgnoreCase(S)) {
					status = "Success";
				} else if (status.equalsIgnoreCase(F)) {
					status = "Failed";
				} else {
					status = "";
				}
				invvo.setGwStatus(status);
				invvo.setBatchID(batchid);
				String principle = rs.getString("PRIN_OS_AMT");
				if (null == principle)
					principle = "0.00";

				double dPrinciple = Double.parseDouble(principle.trim());
				BigDecimal principal = new BigDecimal(dPrinciple);
				principalOutStanding = principalOutStanding.add(principal);
				invvo.setPrincipleOutstanding(comm.doubleComma(formatter
						.format(dPrinciple)));
				invvo.setPrincipleTotal(comm.doubleComma(formatter
						.format(principalOutStanding)));
				// principalOS = Double.sum(principalOS, dPrinciple);
				// invvo.setPrincipleOutstanding(comm.doubleComma(rs.getString("PRIN_OS_AMT")));

				String interest = rs.getString("INT_OS_AMT");
				if (null == interest)
					interest = "0.00";

				double dInterest = Double.parseDouble(interest.trim());
				BigDecimal dInterest1 = new BigDecimal(dInterest);
				interestOutStanding = interestOutStanding.add(dInterest1);
				invvo.setInterestOutstanding(comm.doubleComma(formatter
						.format(dInterest)));
				invvo.setInterestTotal(comm.doubleComma(formatter
						.format(interestOutStanding)));

				String charges = rs.getString("CHG_OS_AMT");
				if (null == charges)
					charges = "0.00";

				double dcharges = Double.parseDouble(charges.trim());
				BigDecimal charge = new BigDecimal(dcharges);
				chargesOutStanding = chargesOutStanding.add(charge);
				invvo.setChargesOutstanding(comm.doubleComma(formatter
						.format(dcharges)));
				invvo.setChargesTotal(comm.doubleComma(formatter
						.format(chargesOutStanding)));

				String tdsAmount = rs.getString("TDSAMT");
				if (null == tdsAmount)
					tdsAmount = "0.00";
				double dtdsAmount = Double.parseDouble(tdsAmount.trim());
				BigDecimal tdsTotal = new BigDecimal(dtdsAmount);
				tdsOutStanding = tdsOutStanding.add(tdsTotal);
				invvo.setTdsAmount(comm.doubleComma(formatter
						.format(dtdsAmount)));
				invvo.setTdsTotal(comm.doubleComma(formatter
						.format(tdsOutStanding)));

				String penalInterest = rs.getString("PNL_OS_AMT");
				if (null == penalInterest)
					penalInterest = "0.00";

				double dPenalInterest = Double
						.parseDouble(penalInterest.trim());
				BigDecimal penal = new BigDecimal(dPenalInterest);
				penalOutStanding = penalOutStanding.add(penal);
				invvo.setPenalInterest(comm.doubleComma(formatter
						.format(dPenalInterest)));
				invvo.setPenalTotal(comm.doubleComma(formatter
						.format(penalOutStanding)));
				// invvo.setInterestOutstanding(comm.doubleComma(rs.getString("INT_OS_AMT")));

				invoicList.add(invvo);
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoicList;
	}

	@SuppressWarnings({ "unused" })
	public InvMatchingDataVO getStoreInvoiceData(
			InvMatchingDataVO invMatchingData, int lst) throws DAOException,
			SQLException, ParseException {

		Connection con = null;
		PreparedStatement pstt = null;
		ResultSet rs = null;
		String sqlQuery = null;
		String result = "error";
		PreparedStatement st = null;
		ResultSet maxseq = null;
		int count = 0;
		int batchId = 0;
		CommonMethods commonMethods = null;
		System.out.println("Repay Amount " + invMatchingData.getRepayAmount());
		if (!invMatchingData.getRepayAmount().equals("0")) {
			try {

				if (con == null) {
					con = DBConnectionUtility.getConnection();
				}
				commonMethods = new CommonMethods();
				int maxSeqId1 = 0;
				int maxSeqId = 0;

				String getApiSequence = "select max(to_number(SEQUENCE)) from APISERVER";
				st = con.prepareStatement(getApiSequence);
				maxseq = st.executeQuery();
				maxseq.next();
				maxSeqId = maxseq.getInt(1);

				String getSCISequence = "select max(to_number(BATCHID)) from ETT_INVOICE_MATCHING";
				PreparedStatement sst = con.prepareStatement(getSCISequence);
				maxseq = sst.executeQuery();
				maxseq.next();
				maxSeqId1 = maxseq.getInt(1);

				if (maxSeqId1 > maxSeqId) {
					maxSeqId = maxSeqId1;
				}

				System.out.println("Max Seq No : " + maxSeqId);

				int input = 0;
				int behalf = 0;
				try {
					if (con == null) {
						con = DBConnectionUtility.getConnection();
					}
					String getCount = "select INPUT_BRN,BHALF_BRN from MASTER WHERE MASTER_REF='"
							+ invMatchingData.getMasRef() + "' ";
					PreparedStatement ppt = con.prepareStatement(getCount);
					ResultSet rst = ppt.executeQuery();
					System.out.println("get count " + getCount);
					rst.next();
					input = rst.getInt(1);
					behalf = rst.getInt(2);
					System.out.println("Input Branch : " + input);
					System.out.println("Behalf of Branch : " + behalf);
				} catch (Exception e) {

				}
				sqlQuery = "INSERT INTO ETT_INVOICE_MATCHING(PROGRAM_ID,"
						+ "DEBIT_PARTY," + "VALUE_DATE," + "PAYMENT_AMOUNT,"
						+ "MAS_REF," + "INV_NUMBER," + "DISBURSE_DATE,"
						+ "DUE_DATE," + "LOAN_AMOUNT," + "OUT_AMOUNT,"
						+ "REPAY_AMOUNT," + "BATCHID," + "INPUTBRN,"
						+ "BEHALFBRN)"
						+ " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				pstt = con.prepareStatement(sqlQuery);
				pstt.setString(
						1,
						commonMethods.getEmptyIfNull(
								invMatchingData.getProgId()).trim());
				pstt.setString(
						2,
						commonMethods.getEmptyIfNull(
								invMatchingData.getDebitParty()).trim());
				pstt.setString(
						3,
						commonMethods.getEmptyIfNull(
								invMatchingData.getValueDate()).trim());
				pstt.setString(
						4,
						commonMethods
								.getEmptyIfNull(
										invMatchingData.getPayAmount().replace(
												",", "")).trim());
				pstt.setString(
						5,
						commonMethods.getEmptyIfNull(
								invMatchingData.getMasRef()).trim());
				pstt.setString(
						6,
						commonMethods.getEmptyIfNull(
								invMatchingData.getInvNumber()).trim());
				pstt.setString(
						7,
						commonMethods.getEmptyIfNull(
								invMatchingData.getDisburseDate()).trim());
				pstt.setString(
						8,
						commonMethods.getEmptyIfNull(
								invMatchingData.getDueDate()).trim());
				pstt.setString(
						9,
						commonMethods.getEmptyIfNull(
								invMatchingData.getLoanAmount()
										.replace(",", "")).trim());
				pstt.setString(
						10,
						commonMethods
								.getEmptyIfNull(
										invMatchingData.getOutAmount().replace(
												",", "")).trim());
				pstt.setString(
						11,
						commonMethods.getEmptyIfNull(
								invMatchingData.getRepayAmount()).trim());
				pstt.setInt(12, ++maxSeqId);
				pstt.setInt(13, input);
				pstt.setInt(14, behalf);
				++recordCount;
				count = pstt.executeUpdate();
				System.out.println("Sql is " + sqlQuery);

				try {
					if (con == null) {
						con = DBConnectionUtility.getConnection();
					}
					String getBatchId = "select max(to_number(BATCHID)) from ETT_INVOICE_MATCHING";
					PreparedStatement pppt = con.prepareStatement(getBatchId);
					ResultSet rsst = pppt.executeQuery();
					rsst.next();
					batchId = rsst.getInt(1);
					System.out.println("Max Seq No : " + batchId);
				} catch (Exception e) {

				}
				for (int i = batchId; i <= batchId; i++) {
					String[] param = { "INVPENDING", batchId + "",
							batchId + "", userName, "", "", "" };
					try {
						/*
						 * FGBDataMigration dataMigration = new
						 * FGBDataMigration(); dataMigration.migration(param);
						 * new FGBDataMigration().migration(param);
						 */
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				debitlst = getDebitlst();
				if (debitlst != null) {
					invMatchingData.setDebitList(debitlst);
				}

				counterList = getCounterList();
				if (counterList != null) {
					invMatchingData.setCounterList(counterList);
				}
				if (count == 1) {
					result = "success";
				}

				System.out.println("Records Inserted ");
			} catch (Exception e) {
				throwDAOException(e);

			} finally {
				closeSqlRefferance(rs, pstt, con);
			}

			try {
				Thread.sleep(1000 * 10 * recordCount);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Connection conn = null;
			PreparedStatement ppst = null;
			ResultSet rsst = null;
			String apiStatus = "";
			InvMatchingDataVO invMatchingDataVO = null;
			try {
				String status = "";
				String invoiceBatchId = "";
				System.out.println("Record count " + recordCount);
				int firstData = batchId - (recordCount - 1);
				conn = DBConnectionUtility.getConnection();
				String getResponse = "select aps.sequence,aps.status "
						+ "FROM ett_invoice_matching inv JOIN apiserver aps "
						+ "ON (aps.sequence=inv.batchid) AND aps.sequence>='"
						+ firstData + "'";

				ppst = conn.prepareStatement(getResponse);
				rsst = ppst.executeQuery();

				while (rsst.next()) {
					invoiceBatchId = rsst.getString(1);
					status = rsst.getString(2);

					String updateQry = "update ett_invoice_matching set STATUS='"
							+ status
							+ "' where BATCHID = '"
							+ invoiceBatchId
							+ "'";
					ppst = conn.prepareStatement(updateQry);
					ppst.executeUpdate();
					// System.out.println("Status : " + status);
				}
				apista = new ArrayList<String>();
				invList.clear();
				String resultGrid = "select MAS_REF,INV_NUMBER,DISBURSE_DATE,DUE_DATE,to_char(LOAN_AMOUNT,'999,999,999,999,999.99'),to_char(OUT_AMOUNT,'999,999,999,999,999.99'),REPAY_AMOUNT,STATUS from ett_invoice_matching where to_number(batchid)>="
						+ firstData;
				ppst = conn.prepareStatement(resultGrid);
				rsst = ppst.executeQuery();
				int i = 0;

				while (rsst.next()) {
					invMatchingDataVO = new InvMatchingDataVO();
					invMatchingDataVO.setMasterRef(rsst.getString(1));
					invMatchingDataVO.setInvNumber(rsst.getString(2));
					invMatchingDataVO.setDisburseDate(rsst.getString(3));
					invMatchingDataVO.setDueDate(rsst.getString(4));
					invMatchingDataVO.setLoanAmount(rsst.getString(5));
					invMatchingDataVO.setOutAmount(rsst.getString(6));
					invMatchingDataVO.setRepayAmount(rsst.getString(7));
					invMatchingDataVO
							.setStatus(rsst.getString(8).toUpperCase());
					invList.add(invMatchingDataVO);

					invMatchingData.setInvList1(invList);
					/*
					 * apiStatus = rsst.getString(1); apista.add(apiStatus);
					 * //invMatchingDataVO.setStatus(apiStatus); for(int
					 * j=0;j<recordCount;j++) {
					 * invList.get(i).setStatus(apiStatus); }
					 */
				}
				// System.out.println("Result Grid "+resultGrid);
				// System.out.println("Api Status : " + apiStatus);
			} catch (Exception e) {
				throwDAOException(e);
			} finally {
				closeSqlRefferance(rs, pstt, conn);
			}

		}

		return invMatchingData;
	}

	public ArrayList<InvMatchingVO> getAccountTCList(InvMatchingVO invMatchingVO)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ArrayList<InvMatchingVO> accountList = new ArrayList<InvMatchingVO>();
		Connection con = null;
		CommonMethods commonMethods = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		commonMethods = new CommonMethods();
		try {
			String query = getBankTCListQuery(invMatchingVO);
			con = DBConnectionUtility.getConnection();
			pst = new LoggableStatement(con, query);
			pst.getQueryString();
			rs = pst.executeQuery();
			while (rs.next()) {
				InvMatchingVO setvo = new InvMatchingVO();
				setvo.setAccountKey(commonMethods.getEmptyIfNull(
						rs.getString("TC")).trim());
				setvo.setBranchNumber(commonMethods.getEmptyIfNull(
						rs.getString("BRANCH")).trim());
				setvo.setSellerMnemonic(commonMethods.getEmptyIfNull(
						rs.getString("BR_DESC")).trim());
				setvo.setShortName(commonMethods.getEmptyIfNull(
						rs.getString("REC_STATUS")).trim());
				accountList.add(setvo);
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountList;
	}

	public String getBankTCListQuery(InvMatchingVO invMatchingVO)
			throws DAOException {
		CommonMethods com = new CommonMethods();
		String SCF_QUERY = "SELECT * FROM extmfbranch B,extbranchtc TC WHERE TRIM(b.br_code)=TRIM(tc.branch) ";
		if (!com.isNull(invMatchingVO.getBranchCode())) {
			SCF_QUERY += SQL_AND + " trim(b.br_code) like '%"
					+ invMatchingVO.getBranchCode().trim().toUpperCase()
					+ "%' ";
		}
		if (!com.isNull(invMatchingVO.getBranchDesc())) {
			SCF_QUERY += SQL_AND + " trim(b.br_desc) like '%"
					+ invMatchingVO.getBranchDesc().trim().toUpperCase()
					+ "%' ";
		}
		if (!com.isNull(invMatchingVO.getTransCode())) {
			SCF_QUERY += SQL_AND + " trim(tc.tc) like '%"
					+ invMatchingVO.getTransCode().trim().toUpperCase() + "%' ";
		}

		return SCF_QUERY;
	}

	public String insertFetchData(ArrayList<InvMatchingVO> lst, String virtualAccNo)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		Connection con = null;
		String addInterest = null;
		String addPenal = null;
		String masterRef = null;
		String osAmt = null;
		String BatchID = "";
		try {
			con = DBConnectionUtility.getConnection();
			String tiDate = getTiDate(con);
			
			BatchID = getBatchIDSeq(con);//04Feb
			
			for (int i = 0; i < lst.size(); i++) {
				addInterest = CommonMethods.removeComma(lst.get(i)
						.getAddInterest());
				addPenal = CommonMethods.removeComma(lst.get(i).getAddPenal());
				masterRef = lst.get(i).getMasterRef();
				osAmt = CommonMethods.removeComma(lst.get(i).getOutAmount());
			//	virtualAccNo=CommonMethods.removeComma(lst.get(i).getVirtualAccount());
			//	System.out.println("Inside List to check Virtual Acc:"+virtualAccNo);
				if (null == addInterest || addInterest.equalsIgnoreCase("")) {
					addInterest = "0";
				}
				if (null == addPenal || addPenal.equalsIgnoreCase("")) {
					addPenal = "0";
				}

				double addIntrst = Double.parseDouble(addInterest.replaceAll(",", ""));
				double addPnl = Double.parseDouble(addPenal.replaceAll(",", ""));

				if(addIntrst != 0 || addPnl != 0){
					insertAddInterest(masterRef, tiDate, addInterest, addPenal,
						osAmt, con, virtualAccNo, BatchID);
				}
			}
		//	System.out.println("Inside List to check Virtual Acc:"+virtualAccNo);

			//04Feb
			/*System.out.println("Procedure call started");
			String addInterestandPenal = "{call ETT_ADD_INT_PNL( )}";
			callableStatement = con.prepareCall(addInterestandPenal);
			callableStatement.executeUpdate();
			System.out.println("Procedure call ended");*/

		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		logger.info(EXITING_METHOD);
		return BatchID;
	}
	//17 sept 2019
	public int fetchBatchIdCountDAO(String BatchID) throws DAOException
	{
		logger.info(ENTERING_METHOD);
		Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		int BatchIDcount=0;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
		String BATCHCOUNT_INTEREST = "Select count(*) as batchcount from ETT_ADD_INTEREST WHERE Batch_Id='"+BatchID+"'";
		pst = new LoggableStatement(con, BATCHCOUNT_INTEREST);
		System.out.println("Select BatchID count Query-->" + pst.getQueryString());
		rs = pst.executeQuery();
			while(rs.next()) {
				BatchIDcount = rs.getInt("batchcount");
			}
		}		
		catch(Exception e)
		{
			throwDAOException(e);
		}
		finally
		{
			DBConnectionUtility.surrenderDB(rs,pst, con);
		}
		logger.info(EXITING_METHOD);
		return BatchIDcount;
	}
	
	//12Feb
	public String confirmChargeData(ArrayList<InvMatchingVO> lst, String virtualAccNo)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		Connection con = null;
		String chargeCode = null;
		String amount = null;
		String osAmt = null;
		String masterRef = null;
		String BatchID = "";
		try {
			con = DBConnectionUtility.getConnection();
			String tiDate = getTiDate(con);
			
			BatchID = getUploadBatchIDSeq(con);

			for (int i = 0; i < lst.size(); i++) {
				chargeCode = lst.get(i).getChargeCode();
				amount = CommonMethods.removeComma(lst.get(i).getAmount());
				masterRef = lst.get(i).getMasterRef();
				osAmt = CommonMethods.removeComma(lst.get(i).getOutAmount());

				if(chargeCode != null && chargeCode.trim().length()>0 
						&& amount != null && amount.trim().length()>0){
					insertCharge(masterRef, tiDate, chargeCode, amount,
						osAmt, con, virtualAccNo, BatchID);
				}
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		logger.info(EXITING_METHOD);
		return BatchID;
	}
	
	
	//04Feb
	public void confirmDataChecker(ArrayList<InvMatchingVO> lst, String batchIDSeq) throws DAOException {
		logger.info(ENTERING_METHOD);
		Connection con = null;
		CallableStatement callableStatement = null;

		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String tiDate = getTiDate(con);

			for (int i = 0; i < lst.size(); i++) {
				updateDataChecker(batchIDSeq, tiDate, con, "CA");
			}

			System.out.println("Procedure call started");
			String addInterestandPenal = "{call ETT_ADD_INT_PNL(?)}";
			callableStatement = con.prepareCall(addInterestandPenal);
			callableStatement.setString(1, batchIDSeq);
			callableStatement.executeUpdate();
			System.out.println("Procedure call ended");

		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		logger.info(EXITING_METHOD);
	}
	
	
	//04Feb
	public void rejectDataChecker(ArrayList<InvMatchingVO> lst, String batchIDSeq) throws DAOException {
		logger.info(ENTERING_METHOD);
		Connection con = null;

		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String tiDate = getTiDate(con);

			for (int i = 0; i < lst.size(); i++) {
				updateDataChecker(batchIDSeq, tiDate, con, "CR");
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		logger.info(EXITING_METHOD);
	}
	
	
	
	//11Feb
	public void bulkUploadApprove(ArrayList<InvMatchingVO> lst, String batchIDSeq) throws DAOException {
		logger.info(ENTERING_METHOD);
		Connection con = null;
		CallableStatement callableStatement = null;

		try {
			con = DBConnectionUtility.getConnection();
			String tiDate = getTiDate(con);

			if(lst.size() > 0) {
				updateBulkUploadData(batchIDSeq, tiDate, con, "CA");
				String chargeUploadValidate = "{call ETT_CHARGE_UPLOAD_VALIDATE(?)}";
				callableStatement = con.prepareCall(chargeUploadValidate);
				callableStatement.setString(1, batchIDSeq);
				callableStatement.executeUpdate();
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		logger.info(EXITING_METHOD);
	}
	
	
	//11Feb
	public void bulkUploadReject(ArrayList<InvMatchingVO> lst, String batchIDSeq) throws DAOException {
		logger.info(ENTERING_METHOD);
		Connection con = null;
		try {
			con = DBConnectionUtility.getConnection();
			String tiDate = getTiDate(con);

			if(lst.size() > 0) {
				updateBulkUploadData(batchIDSeq, tiDate, con, "CR");
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		logger.info(EXITING_METHOD);
	}
	
	
	
	//11Feb
	/**
	 * 
	 * @param masterRef
	 * @param tiDate
	 * @param addInterest
	 * @param osAmt
	 * @param con
	 * @throws DAOException
	 */
	public void updateBulkUploadData(String batchIDSeq, String tiDate, Connection con, String status)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		LoggableStatement pst = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "2";
			}
			String UPDATE_INTEREST = "UPDATE ETT_CHARGE_UPLOAD_TBL SET CHECKER_ID=?,CHECKER_TIMESTAMP=CAST (SYSDATE AS TIMESTAMP),"
					+ "STATUS=? WHERE BATCH_ID=?";
			pst = new LoggableStatement(con, UPDATE_INTEREST);
			pst.setString(1, userID);
			pst.setString(2, status);
			pst.setString(3, batchIDSeq);
			System.out.println("Update Data Checker Query-->" + pst.getQueryString());
			pst.executeUpdate();
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, pst);
		}
		logger.info(EXITING_METHOD);
	}
	
	

	/**
	 * 
	 * @param masterRef
	 * @param tiDate
	 * @param addInterest
	 * @param osAmt
	 * @param con
	 * @throws DAOException
	 */
	public void insertAddInterest(String masterRef, String tiDate,
			String addInterest, String addPenal, String osAmt, Connection con, String virtualAccNo, String BatchID)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		LoggableStatement pst = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "2";
			}
			String INSERT_INTEREST = "INSERT INTO ETT_ADD_INTEREST (DEALREF,PROCESS_DATE,OS_AMOUNT,ADD_INTEREST,ADD_PENAL,"
					+ "MAKER_ID,MAKER_TSTAMP,BATCH_ID,REPAY_ACCT_NO,STATUS) "
					+ "VALUES(?,TO_DATE(?,'DD-MM-YY'),?,?,?,?,(CAST (SYSDATE AS TIMESTAMP)),?,?,'MA')";//04Feb
			pst = new LoggableStatement(con, INSERT_INTEREST);
			pst.setString(1, masterRef);
			pst.setString(2, tiDate);
			pst.setString(3, osAmt);
			pst.setString(4, addInterest);
			pst.setString(5, addPenal);
			pst.setString(6, userID);
			pst.setString(7, BatchID);
			pst.setString(8, virtualAccNo);
			System.out.println("Add Interest Query-->" + pst.getQueryString());
			pst.executeUpdate();
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, pst);
		}
		logger.info(EXITING_METHOD);
	}
	
	
	//12Feb
	/**
	 * 
	 * @param masterRef
	 * @param tiDate
	 * @param addInterest
	 * @param osAmt
	 * @param con
	 * @throws DAOException
	 */
	public void insertCharge(String masterRef, String tiDate,
			String chargeCode, String amount, String osAmt, Connection con, String virtualAccNo, String BatchID)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		LoggableStatement pst = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "2";
			}
			String INSERT_CHARGE = "INSERT INTO ETT_CHARGE_UPLOAD_TBL "
					+ "(LOAN_REFERENCE,VIRTUAL_ACCOUNT,CHARGE_CODE,CHARGE_TYPE,AMOUNT,MAKER_ID,MAKER_TIMESTAMP,BATCH_ID,STATUS) "
					+ "VALUES(?,?,?,(SELECT CHARGE_TYPE FROM ETT_CHARGE_TYPES WHERE CHARGE_CODE=?),?,?,(CAST (SYSDATE AS TIMESTAMP)),?,'MA')";
			pst = new LoggableStatement(con, INSERT_CHARGE);
			pst.setString(1, masterRef);
			pst.setString(2, virtualAccNo);
			pst.setString(3, chargeCode);
			pst.setString(4, chargeCode);
			pst.setString(5, amount);
			pst.setString(6, userID);
			pst.setString(7, BatchID);
			System.out.println("Charge Query-->" + pst.getQueryString());
			pst.executeUpdate();
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, pst);
		}
		logger.info(EXITING_METHOD);
	}
	
	
	//04Feb
	private String getBatchIDSeq(Connection con) throws DAOException {
		logger.info(ENTERING_METHOD);
		String batchIDSeq = "";
		LoggableStatement pst = null;
		ResultSet rs = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String BATCH_ID_SEQUENCE = "SELECT 'BATCH'||LPAD(ETT_ADD_INTEREST_SEQ.NEXTVAL, 5, 0) AS BATCH_ID_SEQ FROM DUAL";
			pst = new LoggableStatement(con, BATCH_ID_SEQUENCE);
			rs = pst.executeQuery();
			while(rs.next()) {
				batchIDSeq = rs.getString("BATCH_ID_SEQ");
			}
		} catch(Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		logger.info(EXITING_METHOD);
		return batchIDSeq;
	}
	
	//04Feb
	/**
	 * 
	 * @param masterRef
	 * @param tiDate
	 * @param addInterest
	 * @param osAmt
	 * @param con
	 * @throws DAOException
	 */
	public void updateDataChecker(String batchIDSeq, String tiDate, Connection con, String status)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		LoggableStatement pst = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "2";
			}
			String UPDATE_INTEREST = "UPDATE ETT_ADD_INTEREST SET CHECKER_ID=?,CHECKER_TSTAMP=CAST (SYSDATE AS TIMESTAMP),"
					+ "STATUS=? WHERE BATCH_ID=?";
			pst = new LoggableStatement(con, UPDATE_INTEREST);
			pst.setString(1, userID);
			pst.setString(2, status);
			pst.setString(3, batchIDSeq);
			System.out.println("Update Data Checker Query-->" + pst.getQueryString());
			pst.executeUpdate();
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, pst);
		}
		logger.info(EXITING_METHOD);
	}
	

	/**
	 * 
	 * @param masterRef
	 * @param tiDate
	 * @param addPenal
	 * @param osAmt
	 * @param con
	 * @throws DAOException
	 */
	public void insertAddPenal(String masterRef, String tiDate,
			String addPenal, String addInterest, String osAmt, Connection con)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		LoggableStatement pst = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String INSERT_PENAL = "INSERT INTO ETT_ADD_PENAL (DEALREF,PROCESS_DATE,OS_AMOUNT,ADD_PENAL,ADD_INTEREST)VALUES(?,TO_DATE(?,'DD-MM-YY'),?,?,?)";
			pst = new LoggableStatement(con, INSERT_PENAL);
			pst.setString(1, masterRef);
			pst.setString(2, tiDate);
			pst.setString(3, osAmt);
			pst.setString(4, addPenal);
			pst.setString(5, addInterest);
			System.out.println("Add Interest Query-->" + pst.getQueryString());
			pst.executeUpdate();
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, pst);
		}
		logger.info(EXITING_METHOD);
	}

	public void getStoreInvoiceData(InvMatchingVO invMatchingVO, String batchId)
			throws DAOException {
		Connection conn = null;
		PreparedStatement ppst = null;
		ResultSet rsst = null;
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			String sqlQuery = "INSERT INTO ETT_STP_REPAYMENT_MAKER(BATCH_ID,PROGRAM_ID,VALUE_DATE,"
					+ "ANCHOR_PARTY,COUNTER_PARTY,PAYMENT_AMOUNT,"
					+ "REPAY_TYPE,MODE_REPAYMENT,APPROPRIATION_TYPE_REPAYMENT,REPAYMENT_ACCOUNT_NO,REFERENCE_NUMBER,WARNING_MESSAGE,VIRTUALACCT,REPAYMENT_TC,REPAYMENT_TYPE,due_DATE)"
					+ " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			conn = DBConnectionUtility.getConnection();
			ppst = conn.prepareStatement(sqlQuery);
			ppst.setString(1, commonMethods.getEmptyIfNull(batchId).trim());
			ppst.setString(2,
					commonMethods.getEmptyIfNull(invMatchingVO.getProgId())
							.trim());
			ppst.setString(3,
					commonMethods.getEmptyIfNull(invMatchingVO.getValueDate())
							.trim());
			ppst.setString(4,
					commonMethods.getEmptyIfNull(invMatchingVO.getDebitParty())
							.trim());
			ppst.setString(
					5,
					commonMethods.getEmptyIfNull(
							invMatchingVO.getCounterParty()).trim());
			ppst.setString(
					6,
					commonMethods.getEmptyIfNull(
							invMatchingVO.getPayAmount().replace(",", ""))
							.trim());
			ppst.setString(
					7,
					commonMethods.getEmptyIfNull(
							invMatchingVO.getAllocationType()).trim());
			ppst.setString(
					8,
					commonMethods.getEmptyIfNull(
							invMatchingVO.getRepaymentMode()).trim());
			ppst.setString(
					9,
					commonMethods.getEmptyIfNull(
							invMatchingVO.getRepaymentAllocationType()).trim());
			ppst.setString(10,
					commonMethods.getEmptyIfNull(invMatchingVO.getPayAccount())
							.trim());
			ppst.setString(
					11,
					commonMethods.getEmptyIfNull(
							invMatchingVO.getReferenceNumber()).trim());
			AlertMessagesVO alertMessagesVO = null;
			ArrayList<AlertMessagesVO> warningList = invMatchingVO
					.getWarningList();// .get(0);
			if (warningList == null) {
				alertMessagesVO = new AlertMessagesVO();
			} else {
				alertMessagesVO = invMatchingVO.getWarningList().get(0);
				if (alertMessagesVO == null) {
					alertMessagesVO = new AlertMessagesVO();
				}
			}
			// alertMessagesVO =;
			ppst.setString(
					12,
					commonMethods.getEmptyIfNull(
							alertMessagesVO.getErrorDetails()).trim());
			ppst.setString(
					13,
					commonMethods.getEmptyIfNull(
							invMatchingVO.getVirtualAccount()).trim());
			ppst.setString(14,
					commonMethods
							.getEmptyIfNull(invMatchingVO.getRepaymentTC())
							.trim());
			ppst.setString(15,
					commonMethods.getEmptyIfNull(invMatchingVO.getRepayType())
							.trim());
			ppst.setString(16,
					commonMethods.getEmptyIfNull(invMatchingVO.getDueDateFilter())
							.trim());
			ppst.executeUpdate();
			System.out.println("query would be-->" + sqlQuery);
		} catch (Exception e) {
			e.printStackTrace();
			throwDAOException(e);
		} finally {
			closeSqlRefferance(rsst, ppst, conn);
		}
	}


	public String bulkUploadValidate(InvMatchingVO invMatchingVO) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);

		HSSFCell LOAN_REFERENCE = null, VIRTUAL_ACCOUNT = null, AMOUNT = null, CHARGE_TYPE = null;
		String LOAN_REFERENCE1 = EMPTY, VIRTUAL_ACCOUNT1 = EMPTY, AMOUNT1 = EMPTY, CHARGE_TYPE1 = EMPTY;
		ArrayList<InvMatchingVO> invoicList = null;
		Connection con = null;
		CallableStatement callableStatement = null;
		String batchID = null;
		try {
			con = DBConnectionUtility.getConnection();
			invoicList = new ArrayList<InvMatchingVO>();
			File file = invMatchingVO.getInputFile();

			if (null != file) {
				String ext = invMatchingVO.getFileName().substring(invMatchingVO.getFileName().length() - 3,
						invMatchingVO.getFileName().length());
				int i = 1;
				if (ext.equalsIgnoreCase("xls")) {
					FileInputStream fileStream = new FileInputStream(file);
					HSSFWorkbook workbook = new HSSFWorkbook(fileStream);
					HSSFSheet sheet = workbook.getSheetAt(0);
					Iterator<Row> rows = sheet.rowIterator();
					HSSFRow rowObject;
					while (rows.hasNext()) {
						if (i == 1) {
							rowObject = (HSSFRow) rows.next();
						} else {
							rowObject = (HSSFRow) rows.next();
							LOAN_REFERENCE = rowObject.getCell(0);
							VIRTUAL_ACCOUNT = rowObject.getCell(1);
							CHARGE_TYPE = rowObject.getCell(2);
							AMOUNT = rowObject.getCell(3);

							if (null == LOAN_REFERENCE 
									|| LOAN_REFERENCE.toString().trim().length() == 0) {
								LOAN_REFERENCE1 = "";
							} else if (null != LOAN_REFERENCE
									&& LOAN_REFERENCE.toString()
											.trim().length()>0) {
								LOAN_REFERENCE.setCellType(Cell.CELL_TYPE_STRING);
								LOAN_REFERENCE1 = LOAN_REFERENCE.toString().trim();
							}
							
							if (null == VIRTUAL_ACCOUNT 
									|| VIRTUAL_ACCOUNT.toString().trim().length() == 0) {
								VIRTUAL_ACCOUNT1 = "";
							} else if (null != VIRTUAL_ACCOUNT
									&& VIRTUAL_ACCOUNT.toString()
											.trim().length()>0) {
								VIRTUAL_ACCOUNT.setCellType(Cell.CELL_TYPE_STRING);
								VIRTUAL_ACCOUNT1 = VIRTUAL_ACCOUNT.toString().trim();
							}
							
							if (null == AMOUNT 
									|| AMOUNT.toString().trim().length() == 0) {
								AMOUNT1 = "";
							} else if (null != AMOUNT
									&& AMOUNT.toString()
											.trim().length()>0) {
								AMOUNT.setCellType(Cell.CELL_TYPE_STRING);
								AMOUNT1 = AMOUNT.toString().trim();
							}
							
							if (null == CHARGE_TYPE 
									|| CHARGE_TYPE.toString().trim().length() == 0) {
								CHARGE_TYPE1 = "";
							} else if (null != CHARGE_TYPE
									&& CHARGE_TYPE.toString()
											.trim().length()>0) {
								CHARGE_TYPE
										.setCellType(Cell.CELL_TYPE_STRING);
								CHARGE_TYPE1 = CHARGE_TYPE.toString().trim();
							}

							InvMatchingVO inv = new InvMatchingVO();
							inv.setLoanMasterRef(LOAN_REFERENCE1);
							inv.setVirtualAccount(VIRTUAL_ACCOUNT1);
							inv.setChargeType(CHARGE_TYPE1);
							inv.setAmount(AMOUNT1);

							int uploadSeq = i - 1;
							inv.setUploadSeq(uploadSeq);

							invoicList.add(inv);
						}
						i++;
					} workbook.close();
				} else if(ext.equalsIgnoreCase("csv")) {
					BufferedReader br = new BufferedReader(new FileReader(file));
					Map<String, Integer> map = new HashMap<String, Integer>();
					String line = null;
					String splitby = ",";
					while ((line = br.readLine()) != null) {
						if (i == 1) {
							String[] text = line.split(splitby);
							for (int j = 0; j < 4; j++) {
								map.put(text[j], j);
							}
						} else {
							String[] text = line.split(splitby);
							LOAN_REFERENCE1 = text[map.get("LOAN_REFERENCE")];
							VIRTUAL_ACCOUNT1 = text[map.get("VIRTUAL_ACCOUNT")];
							CHARGE_TYPE1 = text[map.get("CHARGE_TYPE")];
							AMOUNT1 = text[map.get("AMOUNT")];

							InvMatchingVO inv = new InvMatchingVO();
							inv.setLoanMasterRef(LOAN_REFERENCE1);
							inv.setVirtualAccount(VIRTUAL_ACCOUNT1);
							inv.setChargeType(CHARGE_TYPE1);
							inv.setAmount(AMOUNT1);

							int uploadSeq = i - 1;
							inv.setUploadSeq(uploadSeq);

							invoicList.add(inv);
						}
						i++;
					} br.close();
				}
			}
			if(invoicList != null && invoicList.size()>0) {
				batchID = bulkUploadSubmit(invMatchingVO, invoicList);
				TotalValues(invMatchingVO,con,batchID);
				String chargeUploadValidate = "{call ETT_CHARGE_UPLOAD_VALIDATE(?)}";
				callableStatement = con.prepareCall(chargeUploadValidate);
				callableStatement.setString(1, batchID);
				callableStatement.executeUpdate();
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
			try {
				if(con != null)
					con.close();
				if(callableStatement != null)
					callableStatement.close();
			} catch (SQLException e) {}
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return batchID;
	}
	//18NOV
	
	
	public void TotalValuesChecker(InvMatchingVO invMatchingVO,Connection con,String Batchid)
	{
		String TotalRowcount="";
		String TotalAmount="";
		PreparedStatement ps1=null;
		ResultSet rs1=null;
		String Count_Query="Select COUNT(*) as TotalRowcount,SUM(AMOUNT) as TotalAmount from ETT_CHARGE_UPLOAD_TBL where BATCH_ID='"+Batchid+"' and UPLOAD_STATUS='S'";
		try {
		ps1 = con.prepareStatement(Count_Query);
		rs1=ps1.executeQuery();
		while(rs1.next())
		{
			TotalRowcount=invMatchingVO.setTotalRowCount(rs1.getString("TotalRowcount"));
			TotalAmount=invMatchingVO.setTotalAmount(rs1.getString("TotalAmount"));
		}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(rs1 != null)
					rs1.close();
				if(ps1 != null)
					ps1.close();
			} catch (SQLException e) {}
	}
	}
		public void TotalValues(InvMatchingVO invMatchingVO,Connection con,String Batchid)
		{
			String TotalRowcount="";
			String TotalAmount="";
			PreparedStatement ps=null;
			ResultSet rs=null;
			String Count_Query="Select COUNT(*) as TotalRowcount,SUM(AMOUNT) as TotalAmount from ETT_CHARGE_UPLOAD_TBL where BATCH_ID='"+Batchid+"'";
			try {
			ps = con.prepareStatement(Count_Query);
			rs=ps.executeQuery();
			while(rs.next())
			{
				TotalRowcount=invMatchingVO.setTotalRowCount(rs.getString("TotalRowcount"));
				TotalAmount=invMatchingVO.setTotalAmount(rs.getString("TotalAmount"));
			}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					if(rs != null)
						rs.close();
					if(ps != null)
						ps.close();
				} catch (SQLException e) {}
		}
		}
	
	//14Feb
	public ArrayList<InvMatchingVO> fetchUploadDetails(String batchID) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<InvMatchingVO> invoicList = null;
		try {
			invoicList = new ArrayList<InvMatchingVO>();
			con = DBConnectionUtility.getConnection();
			String query = "SELECT LOAN_REFERENCE, VIRTUAL_ACCOUNT, CHARGE_TYPE,"
					+ " AMOUNT, DECODE(UPLOAD_STATUS,'E','ERROR','S','SUCCESS',UPLOAD_STATUS) AS UPLOAD_STATUS,"
					+ " ERROR_DETAILS FROM ETT_CHARGE_UPLOAD_TBL WHERE BATCH_ID='"+batchID+"'";
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while(rs.next()) {
				InvMatchingVO vo = new InvMatchingVO();
				vo.setLoanMasterRef(rs.getString("LOAN_REFERENCE"));
				vo.setVirtualAccount(rs.getString("VIRTUAL_ACCOUNT"));
				vo.setChargeType(rs.getString("CHARGE_TYPE"));
				vo.setAmount(rs.getString("AMOUNT"));
				vo.setUploadStatus(rs.getString("UPLOAD_STATUS"));
				vo.setErrorDetails(rs.getString("ERROR_DETAILS"));
				invoicList.add(vo);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		//Connection Leak
		finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		//Connection Leak
		return invoicList;
	}
	
	
	//11Feb
	public String bulkUploadSubmit(InvMatchingVO invMatchingVO,
			ArrayList<InvMatchingVO> invoicList) {
		logger.info(ActionConstants.ENTERING_METHOD);

		LoggableStatement loggableStatement = null;
		Connection con = null;
		ResultSet rs = null;
		String uploadBatch = "";
		try {
			con = DBConnectionUtility.getConnection();
			con.setAutoCommit(false);
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "2";
			}
			uploadBatch = getUploadBatchIDSeq(con);

			String bulk_upload_insert_query = "INSERT INTO ETT_CHARGE_UPLOAD_TBL(LOAN_REFERENCE, VIRTUAL_ACCOUNT,"
					+ " CHARGE_TYPE, AMOUNT, BATCH_ID, MAKER_ID, MAKER_TIMESTAMP, UPLOAD_SEQ, ERROR_DETAILS)"
					+ " VALUES(?,?,?,?,?,?,(CAST (SYSDATE AS TIMESTAMP)),?,?)";

			loggableStatement = new LoggableStatement(con,
					bulk_upload_insert_query);

			for (int i = 0; i < invoicList.size(); i++) {
				loggableStatement.setString(1, invoicList.get(i).getLoanMasterRef());
				loggableStatement.setString(2, invoicList.get(i).getVirtualAccount());
				loggableStatement.setString(3, invoicList.get(i).getChargeType());
				loggableStatement.setString(4, invoicList.get(i).getAmount());
				loggableStatement.setString(5, uploadBatch);
				loggableStatement.setString(6, userID);
				loggableStatement.setInt(7, invoicList.get(i).getUploadSeq());
				loggableStatement.setString(8, invoicList.get(i).getErrorDetails());
				loggableStatement.addBatch();
			}
			loggableStatement.executeBatch();

		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
			try {
				if(con != null)
					con.commit();
			} catch(Exception e) {}
			DBConnectionUtility.surrenderDB(rs, loggableStatement, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return uploadBatch;
	}
	
	
	//13Feb
	public int bulkUploadUpdate(InvMatchingVO invMatchingVO,
			ArrayList<InvMatchingVO> invoicList) {
		logger.info(ActionConstants.ENTERING_METHOD);

		LoggableStatement loggableStatement = null;
		Connection con = null;
		ResultSet rs = null;
		int updateCount = 0;
		try {
			con = DBConnectionUtility.getConnection();
			HttpSession httpSession = ServletActionContext.getRequest().getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			if(userID == null || userID.equalsIgnoreCase("")){
				userID = "2";
			}
			String bulk_upload_update_query = "UPDATE ETT_CHARGE_UPLOAD_TBL SET STATUS='MA'"
					+ " WHERE BATCH_ID='"+invMatchingVO.getBatchIDSeq()+"' AND UPLOAD_STATUS='S'";

			loggableStatement = new LoggableStatement(con, bulk_upload_update_query);
			updateCount = loggableStatement.executeUpdate();

		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(rs, loggableStatement, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return updateCount;
	}
	
	
	
	//11Feb
	private String getUploadBatchIDSeq(Connection con) throws DAOException {
		logger.info(ENTERING_METHOD);
		String batchIDSeq = "";
		LoggableStatement pst = null;
		ResultSet rs = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String BATCH_ID_SEQUENCE = "SELECT 'BATCH'||LPAD(ETT_BATCH_UPLOAD_SEQ.NEXTVAL, 5, 0) AS BATCH_UPLOAD_SEQ FROM DUAL";
			pst = new LoggableStatement(con, BATCH_ID_SEQUENCE);
			rs = pst.executeQuery();
			while(rs.next()) {
				batchIDSeq = rs.getString("BATCH_UPLOAD_SEQ");
			}
		} catch(Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		logger.info(EXITING_METHOD);
		return batchIDSeq;
	}
	
	
}
