package in.co.invoice.dao;

import in.co.invoice.dao.customername.InvoiceMatchingDAO;
import in.co.invoice.dao.exception.DAOException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.ActionConstantsQuery;
import in.co.invoice.utility.CommonMethods;
import in.co.invoice.utility.DBConnectionUtility;
import in.co.invoice.utility.FundTransferPostEOD;
import in.co.invoice.utility.LoggableStatement;
import in.co.invoice.vo.AccrualPostingVO;
import in.co.invoice.vo.CAPEODVO;
import in.co.invoice.vo.FileReadVO;
import in.co.invoice.vo.PostingXMLGenerationSample;
import in.co.invoice.rtnf.FileDataRecordVO;
import in.co.invoice.rtnf.FileHeaderVO;

import java.io.StringWriter;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class RTNFFileReadDAO extends AbstractDAO implements
		ActionConstantsQuery, ActionConstants {

	static RTNFFileReadDAO dao;

	private static Logger logger = Logger.getLogger(RTNFFileReadDAO.class
			.getName());

	/*
	 * public static void main(String args[]) throws DAOException{
	 * RTNFFileReadDAO vf = new RTNFFileReadDAO(); vf.postingCall(); }
	 */

	/**
	 * 
	 * @return DAO object
	 */
	public static RTNFFileReadDAO getDAO() {
		if (dao == null) {
			dao = new RTNFFileReadDAO();
		}
		return dao;
	}

	/**
	 * 
	 * @throws DAOException
	 */
	public ArrayList<FileReadVO> fetchRepayList(String batchID)
			throws DAOException {
		logger.info(ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		ArrayList<FileReadVO> repayList = null;
		CommonMethods commonMethods = null;
		try {

			commonMethods = new CommonMethods();
			repayList = new ArrayList<FileReadVO>();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			/*
			 * query = SELECT_FROM_ETT_RTNF_INWARD + " WHERE BATCH_ID='" +
			 * batchID + "' AND TXTFLG='T' AND NVL(STATUS,'N') = 'S' ";
			 */
			query = SELECT_FROM_ETT_RTNF_INWARD
					+ " WHERE NVL(STATUS,'N') = 'P' ";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				FileReadVO fileVO = new FileReadVO();
				fileVO.setMsgType(commonMethods.getEmptyIfNull(rs
						.getString(MSG_TYPE)));
				fileVO.setUtrNumber(commonMethods.getEmptyIfNull(rs
						.getString(UTR_NUMBER)));
				fileVO.setBeneficiaryAccNo(commonMethods.getEmptyIfNull(rs
						.getString(BENEF_ACCNO)));
				fileVO.setBeneficiaryAccType(commonMethods.getEmptyIfNull(rs
						.getString(BENEF_ACCTYPE)));
				fileVO.setBeneficiaryName(commonMethods.getEmptyIfNull(rs
						.getString(BENEF_NAME)));
				fileVO.setAmount(commonMethods.getEmptyIfNull(rs
						.getString(TRANS_AMT)));
				fileVO.setSenderIFSC(commonMethods.getEmptyIfNull(rs
						.getString(SENDER_IFSC)));
				fileVO.setSenderAccNo(commonMethods.getEmptyIfNull(rs
						.getString(SENDER_ACCNO)));
				fileVO.setSenderAccName(commonMethods.getEmptyIfNull(rs
						.getString(SENDER_NAME)));
				fileVO.setSequence(commonMethods.getEmptyIfNull(rs
						.getString(SEQUENCE)));
				fileVO.setBatchID(commonMethods.getEmptyIfNull(rs
						.getString(BATCH_ID)));
				fileVO.setRecordIndicatorH(commonMethods.getEmptyIfNull(rs
						.getString(RECORDINDICATORH)));
				fileVO.setProcessingDate(commonMethods.getEmptyIfNull(rs
						.getString(PROCESSINGDATE)));
				fileVO.setRecordIndicatorT(commonMethods.getEmptyIfNull(rs
						.getString(RECORDINDICATORT)));
				fileVO.setNoOfRecords(commonMethods.getEmptyIfNull(rs
						.getString(TRANS_COUNT)));
				fileVO.setFileName(commonMethods.getEmptyIfNull(rs
						.getString(FILENAME)));
				repayList.add(fileVO);
			}
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(EXITING_METHOD);
		return repayList;
	}

	public void updateDailyRecords(String idVal, Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		LoggableStatement ps = null;
		LoggableStatement loggableStatement = null;
		LoggableStatement ps1 = null;
		CommonMethods comm = null;
		String query = "";
		String query1 = "";
		try {
			comm = new CommonMethods();
			System.out.println("uyte");
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			loggableStatement = new LoggableStatement(con,
					INSERT_INVOICES_TBL_EOD);
			loggableStatement.setString(1, "updateDailyRecords");
			loggableStatement.executeUpdate();
			if (!comm.isNull(idVal)) {
				query = "UPDATE ETT_STP_VALIDATION_XML SET STATUS='UPDATED' WHERE STATUS IS NULL AND ID='"
						+ idVal + "'";
				logger.info("query------------------>" + query);
				ps = new LoggableStatement(con, query);
				ps.executeUpdate();

				query1 = "UPDATE ETT_INTCAP_POST SET STATUS='UPDATED' WHERE STATUS IS NULL";
				System.out
						.println("UPDATE ETT_INTCAP_POST SET STATUS='UPDATED' WHERE STATUS IS NULL");
				logger.info("query------------------>" + query1);
				ps1 = new LoggableStatement(con, query1);
				ps1.executeUpdate();
			}

		} catch (Exception exception) {
			exception.printStackTrace();
			System.out.println(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(null, ps1);
			DBConnectionUtility.surrenderStatement(null, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/**
	 * @return
	 * @throws DAOException
	 */
	public String postingCall() throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;

		ResultSet rs1 = null;
		LoggableStatement ps1 = null;

		ResultSet rs = null;
		LoggableStatement ps = null;

		/*
		 * ResultSet rsval = null; LoggableStatement ps2 = null;
		 */

		/*
		 * LoggableStatement loggableStatement = null; ResultSet rset = null;
		 */

		/*
		 * LoggableStatement loggableStatement1 = null; ResultSet rset1 = null;
		 * 
		 * LoggableStatement loggableStatement2 = null; ResultSet rset2 = null;
		 */
		/*
		 * String endString = null; String idVal = null;
		 */
		CommonMethods comm = null;
		ValidatorDAO vdao = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			comm = new CommonMethods();
			vdao = new ValidatorDAO();
			String temp = "Y";
			logger.info("Connection Calling for Generic fund transfer-------------------------------------->");
			int i = 0;

			ps1 = new LoggableStatement(
					con,
					"SELECT to_char(to_date(procdate,'dd-mm-yy'),'dd-mm-yy') as procdate,to_char(to_date(last_day(procdate),'dd-mm-yy'),'dd-mm-yy')  as cdate FROM DLYPRCCYCL");
			System.out.println("Executing Query" + ps1.getQueryString());
			rs1 = ps1.executeQuery();
			if (rs1.next()) {
				/*
				 * String prdate =
				 * comm.getEmptyIfNull(rs1.getString("procdate")).trim();
				 * //String prdate = "23-02-16"; String prdateVal =
				 * comm.getEmptyIfNull(rs1.getString("cdate")).trim();
				 */

				// String prdate="31-03-16";
				// String prdateVal="31-03-16";
				/*
				 * if(!comm.isNull(prdate) && !comm.isNull(prdateVal)) {
				 * if(prdateVal.equals(prdate)){
				 */

				int stat = vdao.getEodStat();
				if (stat > 0) { /*
								 * ps = new LoggableStatement(con,
								 * "SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID,TRIM(CAP_INT_AMT) as CAP_INT_AMT,TRIM(CAP_CPARTY) as CAP_CPARTY,"
								 * +
								 * "to_char(to_date(TRIM(CAP_DT),'dd-mm-yy'),'dd-mm-yy') as CAP_DT,TRIM(CAP_DEAL_REF) as CAP_DEAL_REF FROM ETT_MTH_CAP WHERE"
								 * + " TRIM(CAP_DT) = to_date('"+prdate+
								 * "','dd-mm-yy')  and CAP_INT_CONS='MTH' AND CAP_STATUS IS NULL ORDER BY CAP_DEAL_REF"
								 * );
								 */

					ps = new LoggableStatement(
							con,
							"SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID,PROG_EXPOSURE, to_char(to_date(CAP_DT,'dd-mm-yy'),'dd-mm-yy') as CAP_DT, SUM(TRIM(CAP_INT_AMT)) as CAP_INT_AMT,CASE "
									+ "WHEN PROG_EXPOSURE='A' THEN PROG_NOR_LMNO  WHEN PROG_EXPOSURE!='A' THEN PROG_CP_NOR_LMNO END PROG_CP_NOR_LMNO "
									+ "FROM ETT_MTH_CAP A,ETT_PROG_CP_LM B WHERE (CAP_INT_CONS='MTH' OR CAP_INT_CONS='MTU') "
									+ "AND CAP_STATUS IS NULL AND TRIM(B.PROG_ID)=CAP_PRG_ID AND TRIM(PROG_CP)=CAP_CPARTY GROUP BY PROG_CP_NOR_LMNO,"
									+ "PROG_NOR_LMNO,CAP_PRG_ID,PROG_EXPOSURE,CAP_DT");

					System.out
							.println("SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID, PROG_EXPOSURE,to_char(to_date(CAP_DT,'dd-mm-yy'),'dd-mm-yy') as CAP_DT, SUM(TRIM(CAP_INT_AMT)) as CAP_INT_AMT,CASE "
									+ "WHEN PROG_EXPOSURE='A' THEN PROG_NOR_LMNO  WHEN PROG_EXPOSURE!='A' THEN PROG_CP_NOR_LMNO END PROG_CP_NOR_LMNO "
									+ "FROM ETT_MTH_CAP A,ETT_PROG_CP_LM B WHERE (CAP_INT_CONS='MTH' OR CAP_INT_CONS='MTU') "
									+ "AND CAP_STATUS IS NULL AND TRIM(B.PROG_ID)=CAP_PRG_ID AND TRIM(PROG_CP)=CAP_CPARTY GROUP BY PROG_CP_NOR_LMNO,"
									+ "PROG_NOR_LMNO,CAP_PRG_ID,PROG_EXPOSURE,CAP_DT");

					rs = ps.executeQuery();
					int j = 0;
					vdao.deleteEodRecords(con);
					vdao.updateRemRecords(con);
					while (rs.next()) {
						String prgrmID = comm.getEmptyIfNull(
								rs.getString("CAP_PRG_ID")).trim();
						String financeAmt = comm.getEmptyIfNull(
								rs.getString("CAP_INT_AMT")).trim();
						String limitAccountNumber = comm.getEmptyIfNull(
								rs.getString("PROG_CP_NOR_LMNO")).trim();
						String capDt = comm.getEmptyIfNull(
								rs.getString("CAP_DT")).trim();
						String prgExp = comm.getEmptyIfNull(
								rs.getString("PROG_EXPOSURE")).trim();
						// String Cparty =
						// comm.getEmptyIfNull(rs.getString("CAP_CPARTY")).trim();
						// String capDate =
						// comm.getEmptyIfNull(rs.getString("CAP_DT")).trim();
						// String dealNo =
						// comm.getEmptyIfNull(rs.getString("CAP_DEAL_REF")).trim();
						if (!comm.isNull(prgrmID)) {
							String customr = vdao.getCustomer(prgrmID, con);
							String batchID = "batch" + i;
							if (!comm.isNull(customr)
									&& !comm.isNull(limitAccountNumber)
									&& !comm.isNull(financeAmt)) {
								// String limitAccountNumber =
								// vdao.getCpartyLimitAccount(prgrmID,Cparty,con);
								logger.info("Limit value - -- "
										+ limitAccountNumber + "uiui");

								FundTransferPostEOD.fundPosting(
										limitAccountNumber, financeAmt,
										customr, batchID, capDt, con, prgrmID,
										prgExp);
								if (!comm.isNull(capDt)) {
									vdao.updateDealStatus(con, capDt, prgrmID,
											limitAccountNumber, prgExp);
								}

							}
						}
						System.out
								.println("Connection JSON-------------------------------------->");
						i++;
					}
					temp = "N";

					// interestAccrualPosting();

					logger.info("Calling Method callPostingThemeBridge");
					// callPostingThemeBridge(null);
					// fetch_postings();
					logger.info("Calling Method callPostingThemeBridge Ends");
				}

				/*
				 * ps2 = new LoggableStatement(con,
				 * "SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID, CAP_DT, SUM(TRIM(CAP_INT_AMT)) as CAP_INT_AMT,CASE WHEN PROG_EXPOSURE='A' THEN PROG_NOR_LMNO  WHEN PROG_EXPOSURE!='A' THEN PROG_CP_NOR_LMNO END PROG_CP_NOR_LMNO FROM ETT_MTH_CAP A,ETT_PROG_CP_LM B WHERE TRIM(CAP_DT) = to_date('"
				 * +prdate+
				 * "','dd-mm-yy') and CAP_INT_CONS='MTU' AND CAP_STATUS IS NULL AND TRIM(B.PROG_ID)=CAP_PRG_ID AND TRIM(PROG_CP)=CAP_CPARTY GROUP BY PROG_CP_NOR_LMNO,PROG_NOR_LMNO,CAP_PRG_ID,PROG_EXPOSURE,CAP_DT"
				 * ); System.out.println(
				 * "SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID, CAP_DT, SUM(TRIM(CAP_INT_AMT)) as CAP_INT_AMT,CASE WHEN PROG_EXPOSURE='A' THEN PROG_NOR_LMNO  WHEN PROG_EXPOSURE!='A' THEN PROG_CP_NOR_LMNO END PROG_CP_NOR_LMNO FROM ETT_MTH_CAP A,ETT_PROG_CP_LM B WHERE TRIM(CAP_DT) = to_date('"
				 * +prdate+
				 * "','dd-mm-yy') and CAP_INT_CONS='MTU' AND CAP_STATUS IS NULL AND TRIM(B.PROG_ID)=CAP_PRG_ID AND TRIM(PROG_CP)=CAP_CPARTY GROUP BY PROG_CP_NOR_LMNO,PROG_NOR_LMNO,CAP_PRG_ID,PROG_EXPOSURE,CAP_DT"
				 * ); ps2 = new LoggableStatement(con,
				 * "SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID,TRIM(CAP_INT_AMT) as CAP_INT_AMT,TRIM(CAP_CPARTY) as CAP_CPARTY,to_char(to_date(TRIM(CAP_DT),'dd-mm-yy'),'dd-mm-yy') as CAP_DT,TRIM(CAP_DEAL_REF) as CAP_DEAL_REF FROM ETT_MTH_CAP WHERE TRIM(CAP_DT) = to_date('"
				 * +prdate+
				 * "','dd-mm-yy') and CAP_INT_CONS='MTU' AND CAP_STATUS IS NULL ORDER BY CAP_DEAL_REF"
				 * ); rsval = ps2.executeQuery(); while(rsval.next()){ String
				 * prgrmID =
				 * comm.getEmptyIfNull(rsval.getString("CAP_PRG_ID")).trim();
				 * String financeAmt =
				 * comm.getEmptyIfNull(rsval.getString("CAP_INT_AMT")).trim();
				 * String limitAccountNumber =
				 * comm.getEmptyIfNull(rsval.getString
				 * ("PROG_CP_NOR_LMNO")).trim(); //String Cparty =
				 * comm.getEmptyIfNull(rs.getString("CAP_CPARTY")).trim();
				 * //String capDate =
				 * comm.getEmptyIfNull(rs.getString("CAP_DT")).trim(); //String
				 * dealNo =
				 * comm.getEmptyIfNull(rs.getString("CAP_DEAL_REF")).trim();
				 * if(!comm.isNull(prgrmID)){ String customr =
				 * vdao.getCustomer(prgrmID,con); String batchID = "batch"+i;
				 * if(!comm.isNull(customr) && !comm.isNull(limitAccountNumber)
				 * && !comm.isNull(financeAmt)){ //String limitAccountNumber =
				 * vdao.getCpartyLimitAccount(prgrmID,Cparty,con);
				 * logger.info("Limit value - -- "+limitAccountNumber+"uiui");
				 * 
				 * FundTransferPostEOD.fundPosting(limitAccountNumber,
				 * financeAmt, customr,batchID); vdao.updateDealStatus(con);
				 * 
				 * } } System.out.println(
				 * "Connection JSON-------------------------------------->");
				 * i++; }
				 * 
				 * }
				 * 
				 * for(int k=1;k<=366;k++){ loggableStatement = new
				 * LoggableStatement
				 * (con,"SELECT ETT_BUSN_WORK_YN(procdate + "+k+
				 * ") as busDay, to_char(to_date(procdate + "
				 * +k+",'dd-mm-yy'),'dd-mm-yy') as counterdate, " +
				 * "to_char(to_date(last_day(procdate),'dd-mm-yy'),'dd-mm-yy') as cdate FROM DLYPRCCYCL"
				 * ); System.out.println("Executing Query" +
				 * loggableStatement.getQueryString()); rset =
				 * loggableStatement.executeQuery(); if(rset.next()){ String
				 * dateVal = rset.getString("counterdate"); String businessDate
				 * = rset.getString("busDay"); String lastDay =
				 * rset.getString("cdate"); if(!comm.isNull(businessDate)){
				 * if(businessDate.equalsIgnoreCase("N")){
				 * System.out.println("3"); ; loggableStatement1 = new
				 * LoggableStatement(con,
				 * "SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID,TRIM(CAP_INT_AMT) as CAP_INT_AMT,TRIM(CAP_CPARTY) as CAP_CPARTY,to_char(to_date(TRIM(CAP_DT),'dd-mm-yy'),'dd-mm-yy') as CAP_DT,TRIM(CAP_DEAL_REF) as CAP_DEAL_REF FROM ETT_MTH_CAP WHERE TRIM(CAP_DT) = to_date('"
				 * +dateVal+
				 * "','dd-mm-yy') and CAP_INT_CONS='MTU' AND CAP_STATUS IS NULL ORDER BY CAP_DEAL_REF"
				 * ); loggableStatement1 = new LoggableStatement(con,
				 * "SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID, CAP_DT, SUM(TRIM(CAP_INT_AMT)) as CAP_INT_AMT,CASE WHEN PROG_EXPOSURE='A' THEN PROG_NOR_LMNO  WHEN PROG_EXPOSURE!='A' THEN PROG_CP_NOR_LMNO END PROG_CP_NOR_LMNO FROM ETT_MTH_CAP A,ETT_PROG_CP_LM B WHERE TRIM(CAP_DT) = to_date('"
				 * +dateVal+
				 * "','dd-mm-yy') and CAP_INT_CONS='MTU' AND CAP_STATUS IS NULL AND TRIM(B.PROG_ID)=CAP_PRG_ID AND TRIM(PROG_CP)=CAP_CPARTY GROUP BY PROG_CP_NOR_LMNO,PROG_NOR_LMNO,CAP_PRG_ID,PROG_EXPOSURE,CAP_DT"
				 * ); rset1 = loggableStatement1.executeQuery();
				 * while(rset1.next()){
				 * 
				 * String prgrmID =
				 * comm.getEmptyIfNull(rset1.getString("CAP_PRG_ID")).trim();
				 * String financeAmt =
				 * comm.getEmptyIfNull(rset1.getString("CAP_INT_AMT")).trim();
				 * String limitAccountNumber =
				 * comm.getEmptyIfNull(rset1.getString
				 * ("PROG_CP_NOR_LMNO")).trim(); //String Cparty =
				 * comm.getEmptyIfNull(rs.getString("CAP_CPARTY")).trim();
				 * //String capDate =
				 * comm.getEmptyIfNull(rs.getString("CAP_DT")).trim(); //String
				 * dealNo =
				 * comm.getEmptyIfNull(rs.getString("CAP_DEAL_REF")).trim();
				 * if(!comm.isNull(prgrmID)){ String customr =
				 * vdao.getCustomer(prgrmID,con); String batchID = "batch"+i;
				 * if(!comm.isNull(customr) && !comm.isNull(limitAccountNumber)
				 * && !comm.isNull(financeAmt)){ //String limitAccountNumber =
				 * vdao.getCpartyLimitAccount(prgrmID,Cparty,con);
				 * logger.info("Limit value - -- "+limitAccountNumber+"uiui");
				 * 
				 * FundTransferPostEOD.fundPosting(limitAccountNumber,
				 * financeAmt, customr,batchID); vdao.updateDealStatus(con);
				 * 
				 * } } System.out.println(
				 * "Connection JSON-------------------------------------->");
				 * i++;
				 * 
				 * } if(!comm.isNull(lastDay) && !comm.isNull(dateVal)){
				 * if(lastDay.equals(dateVal) && temp.equalsIgnoreCase("Y")){
				 * System.out.println("4"); loggableStatement2 = new
				 * LoggableStatement(con,
				 * "SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID,TRIM(CAP_INT_AMT) as CAP_INT_AMT,TRIM(CAP_CPARTY) as CAP_CPARTY,to_char(to_date(TRIM(CAP_DT),'dd-mm-yy'),'dd-mm-yy') as CAP_DT,TRIM(CAP_DEAL_REF) as CAP_DEAL_REF FROM ETT_MTH_CAP WHERE TRIM(CAP_DT) = to_date('"
				 * +lastDay+
				 * "','dd-mm-yy') and CAP_INT_CONS='MTH' AND CAP_STATUS IS NULL ORDER BY CAP_DEAL_REF"
				 * ); loggableStatement2 = new LoggableStatement(con,
				 * "SELECT TRIM(CAP_PRG_ID) as CAP_PRG_ID, CAP_DT, SUM(TRIM(CAP_INT_AMT)) as CAP_INT_AMT,CASE WHEN PROG_EXPOSURE='A' THEN PROG_NOR_LMNO  WHEN PROG_EXPOSURE!='A' THEN PROG_CP_NOR_LMNO END PROG_CP_NOR_LMNO FROM ETT_MTH_CAP A,ETT_PROG_CP_LM B WHERE TRIM(CAP_DT) = to_date('"
				 * +lastDay+
				 * "','dd-mm-yy') and CAP_INT_CONS='MTH' AND CAP_STATUS IS NULL AND TRIM(B.PROG_ID)=CAP_PRG_ID AND TRIM(PROG_CP)=CAP_CPARTY GROUP BY PROG_CP_NOR_LMNO,PROG_NOR_LMNO,CAP_PRG_ID,PROG_EXPOSURE,CAP_DT"
				 * ); rset2 = loggableStatement2.executeQuery();
				 * while(rset2.next()){
				 * 
				 * String prgrmID =
				 * comm.getEmptyIfNull(rset2.getString("CAP_PRG_ID")).trim();
				 * String financeAmt =
				 * comm.getEmptyIfNull(rset2.getString("CAP_INT_AMT")).trim();
				 * String limitAccountNumber =
				 * comm.getEmptyIfNull(rset2.getString
				 * ("PROG_CP_NOR_LMNO")).trim(); //String Cparty =
				 * comm.getEmptyIfNull(rs.getString("CAP_CPARTY")).trim();
				 * //String capDate =
				 * comm.getEmptyIfNull(rs.getString("CAP_DT")).trim(); //String
				 * dealNo =
				 * comm.getEmptyIfNull(rs.getString("CAP_DEAL_REF")).trim();
				 * if(!comm.isNull(prgrmID)){ String customr =
				 * vdao.getCustomer(prgrmID,con); String batchID = "batch"+i;
				 * if(!comm.isNull(customr) && !comm.isNull(limitAccountNumber)
				 * && !comm.isNull(financeAmt)){ //String limitAccountNumber =
				 * vdao.getCpartyLimitAccount(prgrmID,Cparty,con);
				 * logger.info("Limit value - -- "+limitAccountNumber+"uiui");
				 * 
				 * FundTransferPostEOD.fundPosting(limitAccountNumber,
				 * financeAmt, customr,batchID); vdao.updateDealStatus(con);
				 * 
				 * } } System.out.println(
				 * "Connection JSON-------------------------------------->");
				 * i++;
				 * 
				 * }
				 * 
				 * temp = "N"; } } } else{ break; } } }
				 */

			}

		} catch (Exception exception) {
			exception.printStackTrace();
			throwDAOException(exception);
		} finally {
			// DBConnectionUtility.surrenderStatement(rset,loggableStatement2);
			// DBConnectionUtility.surrenderStatement(rset1,loggableStatement1);
			// DBConnectionUtility.surrenderStatement(rset,loggableStatement);
			// DBConnectionUtility.surrenderStatement(rsval,ps2);
			DBConnectionUtility.surrenderStatement(rs1, ps1);
			DBConnectionUtility.surrenderDB(rs, ps, con);

		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	public String getTIDateIntAccrual() throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String prg_type = "";

		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(
					con,
					"SELECT TO_CHAR(TO_DATE(PROCDATE, 'dd-mm-yy'),'yyyy-MM-dd') AS  PROCDATE FROM DLYPRCCYCL");
			rs = ps.executeQuery();
			if (rs.next()) {
				prg_type = rs.getString(1);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return prg_type;
	}

	public static void main(String[] args) throws DAOException,
			TransformerConfigurationException, RemoteException,
			ParserConfigurationException {
		RTNFFileReadDAO rtnfFileReadDAO = new RTNFFileReadDAO();
		// rtnfFileReadDAO.interestAccrualPosting();
		// rtnfFileReadDAO.callPostingThemeBridge(null);
		rtnfFileReadDAO.fetch_postings();
	}

	private void interestAccrualPosting() throws DAOException,
			TransformerConfigurationException, RemoteException,
			ParserConfigurationException {

		Connection con = null;
		ArrayList<AccrualPostingVO> list = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		InvoiceMatchingDAO invoiceMatchingDAO = null;
		CommonMethods commonMethods = null;
		String query = null;
		try {
			String datePosting = getTIDateIntAccrual();
			commonMethods = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			list = new ArrayList<AccrualPostingVO>();
			query = "SELECT TransactionId,TransactionSeqNo,MasterKey,PostingBranch,InputBranch,ProductReference,"
					+ "MasterReference,PostingSeqNo,BackOfficeAccountNo,ACCOUNTNUMBER,ACCOUNTTYPE,ExternalAccountNo,"
					+ " SPSKMnemonic,SPSKCategoryCode,DebitCreditFlag,TransactionCode,PostingAmount,PostingCcy,"
					+ "TO_CHAR(TO_DATE(ValueDate, 'yy-mm-dd'),'yyyy-MM-dd') AS ValueDate,RelatedParty,SettlementAccountUsed,SWIFTmessageType,ServiceLevel,SWIFTChargesFor,"
					+ "AddMntDelFlag,ID  FROM ett_stp_accrual_post where status='N'";// and
																						// id='274063'";
			// and valuedate=to_date('"+datePosting+"','DD-MM-YYYY')";

			logger.info("Execting Query------>" + query);
			System.out.println("Execting Query------>" + query);
			ps = new LoggableStatement(con, query);
			rs = ps.executeQuery();
			while (rs.next()) {
				AccrualPostingVO accrualPostingVO = new AccrualPostingVO();
				accrualPostingVO.setTransactionId(commonMethods.getEmptyIfNull(
						rs.getString("TransactionId")).trim());
				accrualPostingVO.setTransactionSeqNo(commonMethods
						.getEmptyIfNull(rs.getString("TransactionSeqNo"))
						.trim());
				accrualPostingVO.setMasterKey(commonMethods.getEmptyIfNull(
						rs.getString("MasterKey")).trim());
				accrualPostingVO.setPostingBranch(commonMethods.getEmptyIfNull(
						rs.getString("PostingBranch")).trim());
				accrualPostingVO.setInputBranch(commonMethods.getEmptyIfNull(
						rs.getString("InputBranch")).trim());
				accrualPostingVO.setProductReference(commonMethods
						.getEmptyIfNull(rs.getString("ProductReference"))
						.trim());
				accrualPostingVO
						.setMasterReference(commonMethods.getEmptyIfNull(
								rs.getString("MasterReference")).trim());
				accrualPostingVO.setPostingSeqNo(commonMethods.getEmptyIfNull(
						rs.getString("PostingSeqNo")).trim());
				accrualPostingVO.setBackOfficeAccountNo(commonMethods
						.getEmptyIfNull(rs.getString("BackOfficeAccountNo"))
						.trim());
				accrualPostingVO.setAccountNumber(commonMethods.getEmptyIfNull(
						rs.getString("ACCOUNTNUMBER")).trim());
				accrualPostingVO.setAccountType(commonMethods.getEmptyIfNull(
						rs.getString("ACCOUNTTYPE")).trim());
				accrualPostingVO.setExternalAccountNo(commonMethods
						.getEmptyIfNull(rs.getString("ExternalAccountNo"))
						.trim());
				accrualPostingVO.setsPSKMnemonic(commonMethods.getEmptyIfNull(
						rs.getString("SPSKMnemonic")).trim());
				accrualPostingVO.setsPSKCategoryCode(commonMethods
						.getEmptyIfNull(rs.getString("SPSKCategoryCode"))
						.trim());
				accrualPostingVO
						.setDebitCreditFlag(commonMethods.getEmptyIfNull(
								rs.getString("DebitCreditFlag")).trim());
				accrualPostingVO
						.setTransactionCode(commonMethods.getEmptyIfNull(
								rs.getString("TransactionCode")).trim());
				accrualPostingVO.setPostingAmount(commonMethods.getEmptyIfNull(
						rs.getString("PostingAmount")).trim());
				accrualPostingVO.setPostingCcy(commonMethods.getEmptyIfNull(
						rs.getString("PostingCcy")).trim());
				accrualPostingVO.setValueDate(commonMethods.getEmptyIfNull(
						rs.getString("ValueDate")).trim());
				accrualPostingVO.setRelatedParty(commonMethods.getEmptyIfNull(
						rs.getString("RelatedParty")).trim());
				accrualPostingVO.setSettlementAccountUsed(commonMethods
						.getEmptyIfNull(rs.getString("SettlementAccountUsed"))
						.trim());
				accrualPostingVO.setsWIFTmessageType(commonMethods
						.getEmptyIfNull(rs.getString("SWIFTmessageType"))
						.trim());
				accrualPostingVO.setServiceLevel(commonMethods.getEmptyIfNull(
						rs.getString("ServiceLevel")).trim());
				accrualPostingVO
						.setsWIFTChargesFor(commonMethods.getEmptyIfNull(
								rs.getString("SWIFTChargesFor")).trim());
				accrualPostingVO.setAddMntDelFlag(commonMethods.getEmptyIfNull(
						rs.getString("AddMntDelFlag")).trim());
				accrualPostingVO.setId(commonMethods.getEmptyIfNull(
						rs.getString("ID")).trim());
				// accrualPostingVO.setAccountNumber(commonMethods.getEmptyIfNull(rs.getString("ID")).trim());
				list.add(accrualPostingVO);
			}
			getInterestAccrualXMLForPosting(list);
		} catch (SQLException exception) {
			exception.printStackTrace();
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}

	}

	private void updateStatusInterestAccrual(AccrualPostingVO accrualPostingVO)
			throws DAOException, TransformerConfigurationException,
			RemoteException, ParserConfigurationException {

		Connection con = null;
		ArrayList<AccrualPostingVO> list = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		InvoiceMatchingDAO invoiceMatchingDAO = null;
		CommonMethods commonMethods = null;
		String query = null;
		try {
			commonMethods = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			list = new ArrayList<AccrualPostingVO>();
			query = "update ett_stp_accrual_post set status='Y' where trim(ID)='"
					+ accrualPostingVO.getId() + "'";
			// and valuedate=to_date('"+datePosting+"','DD-MM-YYYY')";
			ps = new LoggableStatement(con, query);
			ps.executeUpdate();
		} catch (SQLException exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}

	}

	void getInterestAccrualXMLForPosting(ArrayList<AccrualPostingVO> list)
			throws TransformerConfigurationException,
			ParserConfigurationException, DAOException, RemoteException {
		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				try {
					AccrualPostingVO accrualPostingVO = list.get(i);
					String finalXML = generateInterestAccrualPostingXML(accrualPostingVO);
					// BridgeGatewayImplServiceStub bs= new
					// BridgeGatewayImplServiceStub();
					// bs.bridgeGateWayProcess(finalXML);

					logger.info("Final XML for Accural " + finalXML);
					logger.info("Calling BridgeGatewayImplServiceStub Accrual Starts");

					System.out.println("Before War");
					/*
					 * BridgeGatewayImplService service = new
					 * BridgeGatewayImplService(); System.out.println("11111");
					 * BridgeGateway bg = service.getBridgeGatewayImplPort();
					 * System.out.println("22222"); bg.process(finalXML);
					 */

					logger.info("Calling BridgeGatewayImplServiceStub Accrual Ends");

					/*
					 * logger.info("Calling BridgeGatewayImplServiceStub Starts")
					 * ; BridgeGatewayImplServiceStub bs= new
					 * BridgeGatewayImplServiceStub();
					 * bs.bridgeGateWayProcess(finalXML);
					 * logger.info("Calling BridgeGatewayImplServiceStub Ends");
					 */

					System.out.println("33333");
					updateStatusInterestAccrual(accrualPostingVO);
					System.out.println("55555");
				} catch (Exception exception) {
					throwDAOException(exception);
				}
			}
		}

	}

	public XMLGregorianCalendar stringToXMLGregorianCalendar(String s)

	throws ParseException, DatatypeConfigurationException {

		XMLGregorianCalendar result = null;

		Date date;

		SimpleDateFormat simpleDateFormat;

		GregorianCalendar gregorianCalendar;

		simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

		date = simpleDateFormat.parse(s);

		gregorianCalendar = (GregorianCalendar) GregorianCalendar.getInstance();

		gregorianCalendar.setTime(date);

		result = DatatypeFactory.newInstance().newXMLGregorianCalendar(

		gregorianCalendar);

		return result;

	}

	public String generateInterestAccrualPostingXML(
			AccrualPostingVO accrualPostingVO)
			throws TransformerConfigurationException,
			ParserConfigurationException, DAOException {
		// ValidatorDAO validatorDao = new ValidatorDAO();
		String datePosting = getTIDateIntAccrual();
		String xml1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ServiceRequest xmlns=\"urn:control.services.tiplus2.misys.com\" "
				+ "xmlns:ns2=\"urn:messages.service.ti.apps.tiplus2.misys.com\" xmlns:ns4=\"urn:custom.service.ti.apps.tiplus2.misys.com\" "
				+ "xmlns:ns3=\"urn:common.service.ti.apps.tiplus2.misys.com\"><RequestHeader><Service>BackOffice</Service><Operation>Batch</Operation>"
				+ "<Credentials><Name>SUPERVISOR</Name></Credentials><ReplyFormat>FULL</ReplyFormat>"
				+ "<SourceSystem>Z2</SourceSystem><NoRepair>Y</NoRepair><NoOverride>Y</NoOverride><TransactionControl>NONE</TransactionControl>"
				+ "<CreationDate>"
				+ datePosting
				+ "</CreationDate>"
				+ "</RequestHeader>";
		String xml2 = "</ServiceRequest>";

		DocumentBuilderFactory documentFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
		Document document = documentBuilder.newDocument();

		Element roothead = document.createElement("ns2:BatchRequest");
		document.appendChild(roothead);

		Element roothead1 = document.createElement("ServiceRequest");
		roothead.appendChild(roothead1);

		Element roothead2 = document.createElement("RequestHeader");
		roothead1.appendChild(roothead2);

		Element service = document.createElement("Service");
		service.appendChild(document.createTextNode("BackOffice"));
		roothead2.appendChild(service);

		Element operation = document.createElement("Operation");
		operation.appendChild(document.createTextNode("Posting"));
		roothead2.appendChild(operation);

		Element roothead3 = document.createElement("Credentials");
		roothead2.appendChild(roothead3);

		Element namecred = document.createElement("Name");
		namecred.appendChild(document.createTextNode("SUPERVISOR"));
		roothead3.appendChild(namecred);

		Element replyFormat = document.createElement("ReplyFormat");
		replyFormat.appendChild(document.createTextNode("FULL"));
		roothead2.appendChild(replyFormat);

		Element sourceSys = document.createElement("SourceSystem");
		sourceSys.appendChild(document.createTextNode("Z2"));
		roothead2.appendChild(sourceSys);

		Element noRepair = document.createElement("NoRepair");
		noRepair.appendChild(document.createTextNode("Y"));
		roothead2.appendChild(noRepair);

		Element noOverRide = document.createElement("NoOverride");
		noOverRide.appendChild(document.createTextNode("Y"));
		roothead2.appendChild(noOverRide);

		Element corrId = document.createElement("CorrelationId");
		corrId.appendChild(document
				.createTextNode("273ace37-fd39-465d-a2e7-8ee3903eb739--1"));
		roothead2.appendChild(corrId);

		Element tranCtrl = document.createElement("TransactionControl");
		tranCtrl.appendChild(document.createTextNode("NONE"));
		roothead2.appendChild(tranCtrl);

		Element creatDat = document.createElement("CreationDate");
		creatDat.appendChild(document.createTextNode(datePosting));
		roothead2.appendChild(creatDat);

		Element roothead4 = document.createElement("ns2:Posting");
		roothead1.appendChild(roothead4);

		Element transID = document.createElement("ns2:TransactionId");
		transID.appendChild(document
				.createTextNode("273ace37-fd39-465d-a2e7-8ee3903eb739"));
		roothead4.appendChild(transID);

		Element transNo = document.createElement("ns2:TransactionSeqNo");
		transNo.appendChild(document.createTextNode(accrualPostingVO
				.getTransactionSeqNo()));
		roothead4.appendChild(transNo);

		Element masterKey = document.createElement("ns2:MasterKey");
		masterKey.appendChild(document.createTextNode(accrualPostingVO
				.getMasterKey()));
		roothead4.appendChild(masterKey);

		Element postingBranch = document.createElement("ns2:PostingBranch");
		postingBranch.appendChild(document.createTextNode(accrualPostingVO
				.getPostingBranch()));
		roothead4.appendChild(postingBranch);

		Element inputBranch = document.createElement("ns2:InputBranch");
		inputBranch.appendChild(document.createTextNode(accrualPostingVO
				.getInputBranch()));
		roothead4.appendChild(inputBranch);

		Element prdtRef = document.createElement("ns2:ProductReference");
		prdtRef.appendChild(document.createTextNode(accrualPostingVO
				.getProductReference()));
		roothead4.appendChild(prdtRef);

		Element masterRef = document.createElement("ns2:MasterReference");
		masterRef.appendChild(document.createTextNode(accrualPostingVO
				.getMasterReference()));
		roothead4.appendChild(masterRef);

		Element postingSeq = document.createElement("ns2:PostingSeqNo");
		postingSeq.appendChild(document.createTextNode(accrualPostingVO
				.getPostingSeqNo()));
		roothead4.appendChild(postingSeq);

		Element accNo = document.createElement("ns2:AccountNumber");
		accNo.appendChild(document.createTextNode(accrualPostingVO
				.getAccountNumber()));
		roothead4.appendChild(accNo);

		Element bakOff = document.createElement("ns2:BackOfficeAccountNo");
		bakOff.appendChild(document.createTextNode(accrualPostingVO
				.getBackOfficeAccountNo()));
		roothead4.appendChild(bakOff);

		Element extAcc = document.createElement("ns2:ExternalAccountNo");
		extAcc.appendChild(document.createTextNode(accrualPostingVO
				.getExternalAccountNo()));
		roothead4.appendChild(extAcc);

		Element accType = document.createElement("ns2:AccountType");
		accType.appendChild(document.createTextNode(accrualPostingVO
				.getAccountType()));
		roothead4.appendChild(accType);

		Element spMneumonic = document.createElement("ns2:SPSKMnemonic");
		spMneumonic.appendChild(document.createTextNode(accrualPostingVO
				.getsPSKMnemonic()));
		roothead4.appendChild(spMneumonic);

		Element spCat = document.createElement("ns2:SPSKCategoryCode");
		spCat.appendChild(document.createTextNode(accrualPostingVO
				.getsPSKCategoryCode()));
		roothead4.appendChild(spCat);

		Element dbtCrFlag = document.createElement("ns2:DebitCreditFlag");
		dbtCrFlag.appendChild(document.createTextNode(accrualPostingVO
				.getDebitCreditFlag()));
		roothead4.appendChild(dbtCrFlag);

		Element trCode = document.createElement("ns2:TransactionCode");
		trCode.appendChild(document.createTextNode(accrualPostingVO
				.getTransactionCode()));
		roothead4.appendChild(trCode);

		Element postingAmt = document.createElement("ns2:PostingAmount");
		postingAmt.appendChild(document.createTextNode(accrualPostingVO
				.getPostingAmount()));
		roothead4.appendChild(postingAmt);

		Element postingCcy = document.createElement("ns2:PostingCcy");
		postingCcy.appendChild(document.createTextNode(accrualPostingVO
				.getPostingCcy()));
		roothead4.appendChild(postingCcy);

		Element valueDate = document.createElement("ns2:ValueDate");
		valueDate.appendChild(document.createTextNode(accrualPostingVO
				.getValueDate()));
		roothead4.appendChild(valueDate);

		Element relatedParty = document.createElement("ns2:RelatedParty");
		relatedParty.appendChild(document.createTextNode(accrualPostingVO
				.getRelatedParty()));
		roothead4.appendChild(relatedParty);

		Element settlAcc = document.createElement("ns2:SettlementAccountUsed");
		settlAcc.appendChild(document.createTextNode(accrualPostingVO
				.getSettlementAccountUsed()));
		roothead4.appendChild(settlAcc);

		Element swiftMess = document.createElement("ns2:SWIFTmessageType");
		swiftMess.appendChild(document.createTextNode(accrualPostingVO
				.getsWIFTmessageType()));
		roothead4.appendChild(swiftMess);

		Element serviceLevel = document.createElement("ns2:ServiceLevel");
		serviceLevel.appendChild(document.createTextNode(accrualPostingVO
				.getServiceLevel()));
		roothead4.appendChild(serviceLevel);

		Element swiftCharges = document.createElement("ns2:SWIFTChargesFor");
		swiftCharges.appendChild(document.createTextNode(accrualPostingVO
				.getsWIFTChargesFor()));
		roothead4.appendChild(swiftCharges);

		Element addFlag = document.createElement("ns2:AddMntDelFlag");
		addFlag.appendChild(document.createTextNode(accrualPostingVO
				.getAddMntDelFlag()));
		roothead4.appendChild(addFlag);

		Element roothead5 = document.createElement("ns2:ExtraData");
		roothead4.appendChild(roothead5);

		Element posta = document.createElement("ns4:POSTA");
		roothead5.appendChild(posta);

		/******* Convert XML Document to String File *************/

		String str = convertDocumentToString(document);

		String finalXML = xml1 + str + xml2;
		System.out.println("XML File-------->" + finalXML);
		return finalXML;
	}

	private String convertDocumentToString(Document doc) {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer;
		try {
			transformer = tf.newTransformer();
			// below code to remove XML declaration
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,
					"yes");
			StringWriter writer = new StringWriter();
			transformer.transform(new DOMSource(doc), new StreamResult(writer));
			String output = writer.getBuffer().toString();
			return output;
		} catch (TransformerException e) {
			e.printStackTrace();
		}

		return null;
	}

	public String callPostingThemeBridge(Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;

		ResultSet rs = null;
		LoggableStatement ps = null;

		// LoggableStatement loggableStatement = null;
		// ResultSet rset = null;

		String endString = null;
		String idVal = null;
		CommonMethods comm = null;
		// ValidatorDAO vdao = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			comm = new CommonMethods();
			// vdao = new ValidatorDAO();
			System.out
					.println("Connection Calling for Posting-------------------------------------->");

			logger.info("Connection Calling for CAP Posting-------------------------------------->");

			ps = new LoggableStatement(con,
					"select ID,REQUEST from ETT_STP_VALIDATION_XML where STATUS IS NULL");
			rs = ps.executeQuery();
			logger.info("select ID,REQUEST from ETT_STP_VALIDATION_XML where STATUS IS NULL");
			System.out
					.println("select ID,REQUEST from ETT_STP_VALIDATION_XML where STATUS IS NULL");
			while (rs.next()) {
				endString = comm.getEmptyIfNull(rs.getString("REQUEST")).trim();
				idVal = comm.getEmptyIfNull(rs.getString("ID")).trim();
				try {
					if (!comm.isNull(endString)) {
						/*
						 * loggableStatement = new
						 * LoggableStatement(con,INSERT_INVOICES_TBL_EOD);
						 * loggableStatement.setString(1, "Insertpostingtype1");
						 * loggableStatement.executeUpdate();
						 * 
						 * BridgeGatewayImplServiceStub bs= new
						 * BridgeGatewayImplServiceStub();
						 * 
						 * loggableStatement = new
						 * LoggableStatement(con,INSERT_INVOICES_TBL_EOD);
						 * loggableStatement.setString(1,
						 * "Insertpostingtype1afterinitilization");
						 * loggableStatement.executeUpdate();
						 * 
						 * bs.bridgeGateWayProcess(endString);
						 */

						logger.info("CAP Post Start");
						/*
						 * loggableStatement = new
						 * LoggableStatement(con,INSERT_INVOICES_TBL_EOD);
						 * loggableStatement.setString(1, "Hello1");
						 * loggableStatement.executeUpdate();
						 */

						/*
						 * BridgeGatewayImplService service = new
						 * BridgeGatewayImplService();
						 * 
						 * loggableStatement = new
						 * LoggableStatement(con,INSERT_INVOICES_TBL_EOD);
						 * loggableStatement.setString(1, "Hello2");
						 * loggableStatement.executeUpdate();
						 * 
						 * BridgeGateway bg =
						 * service.getBridgeGatewayImplPort();
						 * 
						 * loggableStatement = new
						 * LoggableStatement(con,INSERT_INVOICES_TBL_EOD);
						 * loggableStatement.setString(1, "Hello3");
						 * loggableStatement.executeUpdate();
						 * 
						 * String result = bg.process(endString);
						 * 
						 * logger.info("Result for CAP Post"+result);
						 */

						logger.info("CAP Posting to Themebridge is Success");

						System.out.println("Stub done");

						updateDailyRecords(idVal, null);
					}

				} catch (Exception exception) {
					logger.info("CAP Posting to Themebridge is Failed");
					logger.info(exception.getMessage());
					exception.printStackTrace();
				}

			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	public String fetch_postings() throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;

		String userTeam = null;
		CommonMethods comm = null;
		// ArrayList<EQ3Posting> list = null;
		ArrayList<CAPEODVO> list = null;
		ArrayList<String> seqList = null;

		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			seqList = getPostingSeqNumbers(con);

			comm = new CommonMethods();
			if (!seqList.isEmpty()) {

				int size = seqList.size();
				logger.info("Size-------------> " + size);

				for (int i = 0; i < size; i++) {

					list = null;
					logger.info("seqList.get(i)=" + seqList.get(i));
					list = new ArrayList<CAPEODVO>();
					ps = new LoggableStatement(
							con,
							"SELECT APISERVERSEQNO,MASTERKEY,EVENTKEY,POSTINGBRANCH,INPUTBRANCH,PRODUCTREFERENCE,MASTERREFERENCE,EVENTREFERENCE,"
									+ "INTERNALRECNREF,POSTINGSEQNO,ACCOUNTNUMBER,BACKOFFICEACCOUNTNO,EXTERNALACCOUNTNO,CUSTOMERMNEMONIC,ACCOUNTTYPE,"
									+ "SPSKMNEMONIC,SPSKCATEGORYCODE,APPLICATION,DEBITCREDITFLAG,TRANSACTIONCODE,POSTINGAMOUNT,POSTINGCCY,"
									+ "TO_CHAR(TO_DATE(VALUEDATE, 'yy-mm-dd'),'yyyy-MM-dd') AS VALUEDATE ,RELATEDPARTY,BENEFICIARYNAME,ISSUEORCONTRACTDATE,BANKCODE1,SETTLEMENTACCOUNTUSED,ADDMNTDELFLAG    "
									+ "FROM ETT_INTCAP_POST WHERE TRIM(MASTERREFERENCE) = '"
									+ seqList.get(i) + "' and STATUS IS NULL");
					System.out.println("Executing Query" + ps.getQueryString());

					logger.info("Query" + ps.getQueryString());
					rs = ps.executeQuery();
					while (rs.next()) {
						// EQ3Posting eq3Posting = new EQ3Posting();
						CAPEODVO eq3Posting = new CAPEODVO();
						eq3Posting.setTransactionSeqNo(rs
								.getInt("APISERVERSEQNO"));
						eq3Posting.setMasterKey(rs.getLong("MASTERKEY"));
						eq3Posting.setEventKey(rs.getLong("EVENTKEY"));

						if (!comm.isNull(rs.getString("POSTINGBRANCH"))) {
							eq3Posting.setPostingBranch(rs.getString(
									"POSTINGBRANCH").trim());
						} else {
							eq3Posting.setPostingBranch("");
						}
						if (!comm.isNull(rs.getString("INPUTBRANCH"))) {
							eq3Posting.setInputBranch(rs.getString(
									"INPUTBRANCH").trim());
						} else {
							eq3Posting.setInputBranch("");
						}
						if (!comm.isNull(rs.getString("PRODUCTREFERENCE"))) {
							eq3Posting.setProductReference(rs.getString(
									"PRODUCTREFERENCE").trim());
						} else {
							eq3Posting.setProductReference("");
						}
						if (!comm.isNull(rs.getString("MASTERREFERENCE"))) {
							eq3Posting.setMasterReference(rs.getString(
									"MASTERREFERENCE").trim());
						} else {
							eq3Posting.setMasterReference("");
						}
						if (!comm.isNull(rs.getString("EVENTREFERENCE"))) {
							eq3Posting.setEventReference(rs.getString(
									"EVENTREFERENCE").trim());
						} else {
							eq3Posting.setEventReference("");
						}
						if (!comm.isNull(rs.getString("INTERNALRECNREF"))) {
							eq3Posting.setInternalRecnRef(rs.getString(
									"INTERNALRECNREF").trim());
						} else {
							eq3Posting.setInternalRecnRef("");
						}

						eq3Posting.setPostingSeqNo(rs.getInt("POSTINGSEQNO"));

						if (!comm.isNull(rs.getString("ACCOUNTNUMBER"))) {
							eq3Posting.setAccountNumber(rs.getString(
									"ACCOUNTNUMBER").trim());
						} else {
							eq3Posting.setAccountNumber("");
						}

						if (!comm.isNull(rs.getString("BACKOFFICEACCOUNTNO"))) {
							eq3Posting.setBackOfficeAccountNo(rs.getString(
									"BACKOFFICEACCOUNTNO").trim());
						} else {
							eq3Posting.setBackOfficeAccountNo("");
						}
						if (!comm.isNull(rs.getString("EXTERNALACCOUNTNO"))) {
							eq3Posting.setExternalAccountNo(rs.getString(
									"EXTERNALACCOUNTNO").trim());
						} else {
							eq3Posting.setExternalAccountNo("");
						}
						if (!comm.isNull(rs.getString("CUSTOMERMNEMONIC"))) {
							eq3Posting.setCustomerMnemonic(rs.getString(
									"CUSTOMERMNEMONIC").trim());
						} else {
							eq3Posting.setCustomerMnemonic("");
						}
						if (!comm.isNull(rs.getString("ACCOUNTTYPE"))) {
							eq3Posting.setAccountType(rs.getString(
									"ACCOUNTTYPE").trim());
						} else {
							eq3Posting.setAccountType("");
						}
						if (!comm.isNull(rs.getString("SPSKMNEMONIC"))) {
							eq3Posting.setSPSKMnemonic(rs.getString(
									"SPSKMNEMONIC").trim());
						} else {
							eq3Posting.setSPSKMnemonic("");
						}
						if (!comm.isNull(rs.getString("SPSKCATEGORYCODE"))) {
							eq3Posting.setSPSKCategoryCode(rs.getString(
									"SPSKCATEGORYCODE").trim());
						} else {
							eq3Posting.setSPSKCategoryCode("");
						}
						if (!comm.isNull(rs.getString("APPLICATION"))) {
							eq3Posting.setApplication(rs.getString(
									"APPLICATION").trim());
						} else {
							eq3Posting.setApplication("");
						}
						if (!comm.isNull(rs.getString("DEBITCREDITFLAG"))) {
							eq3Posting.setDebitCreditFlag(rs.getString(
									"DEBITCREDITFLAG").trim());
						} else {
							eq3Posting.setDebitCreditFlag("");
						}
						if (!comm.isNull(rs.getString("TRANSACTIONCODE"))) {
							eq3Posting.setTransactionCode(rs.getString(
									"TRANSACTIONCODE").trim());
						} else {
							eq3Posting.setTransactionCode("");
						}

						eq3Posting
								.setPostingAmount(rs.getLong("POSTINGAMOUNT"));
						if (!comm.isNull(rs.getString("POSTINGCCY"))) {
							eq3Posting.setPostingCcy(rs.getString("POSTINGCCY")
									.trim());
						} else {
							eq3Posting.setPostingCcy("");
						}

						if (!comm.isNull(rs.getString("VALUEDATE"))) {
							eq3Posting.setValueDate(rs.getString("VALUEDATE")
									.trim());
						} else {
							eq3Posting.setValueDate("");
						}

						// eq3Posting.setValueDate(VALUEDATE);
						if (!comm.isNull(rs.getString("RELATEDPARTY"))) {
							eq3Posting.setRelatedParty(rs.getString(
									"RELATEDPARTY").trim());
						} else {
							eq3Posting.setRelatedParty("");
						}
						if (!comm.isNull(rs.getString("BENEFICIARYNAME"))) {
							eq3Posting.setBeneficiaryName(rs.getString(
									"BENEFICIARYNAME").trim());
						} else {
							eq3Posting.setBeneficiaryName("");
						}
						// eq3Posting.setIssueOrContractDate(ISSUEORCONTRACTDATE);
						if (!comm.isNull(rs.getString("BANKCODE1"))) {
							eq3Posting.setBankCode1(rs.getString("BANKCODE1")
									.trim());
						} else {
							eq3Posting.setBankCode1("");
						}

						if (!comm.isNull(rs.getString("SETTLEMENTACCOUNTUSED"))) {
							eq3Posting.setSettlementAccountUsed(rs.getString(
									"SETTLEMENTACCOUNTUSED").trim());
						} else {
							eq3Posting.setSettlementAccountUsed("");
						}

						// eq3Posting.setSettlementAccountUsed(rs.getString("SETTLEMENTACCOUNTUSED").trim());
						list.add(eq3Posting);

					}

					logger.info("calling getXMLFORPosting Starts");
					getXMLFORPosting(list);
					logger.info("calling getXMLFORPosting Ends");

					updateCapEOD(seqList.get(i), con);

				}

			}

		} catch (Exception exception) {
			logger.info(exception.getMessage());
			System.out.println(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userTeam;
	}

	private ArrayList<String> getPostingSeqNumbers(Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		// ResultSet rs = null;
		ResultSet rs1 = null;
		LoggableStatement ps = null;

		ArrayList<String> list = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			list = new ArrayList<String>();
			ps = new LoggableStatement(
					con,
					"select TRIM(MASTERREFERENCE) AS MASTERREFERENCE from ETT_INTCAP_POST "
							+ "where STATUS IS NULL group by TRIM(MASTERREFERENCE)");

			logger.info("CAP getPostingSeqNumbers " + ps.getQueryString());
			rs1 = ps.executeQuery();
			System.out
					.println("select TRIM(MASTERREFERENCE) AS MASTERREFERENCE from ETT_INTCAP_POST "
							+ "where STATUS IS NULL group by TRIM(MASTERREFERENCE)");

			while (rs1.next()) {
				String temp = rs1.getString("MASTERREFERENCE");
				list.add(temp);
				logger.info("CAP Master Ref " + temp);
			}

		} catch (Exception exception) {
			System.out.println(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs1, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return list;
	}

	private static void getXMLFORPosting(ArrayList<CAPEODVO> list)
			throws TransformerConfigurationException,
			ParserConfigurationException, RemoteException, DAOException {

		try {

			PostingXMLGenerationSample pxs = new PostingXMLGenerationSample();
			String[] finalXML = null;
			String endString = "";

			String xml1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ServiceRequest xmlns=\"urn:control.services.tiplus2.misys.com\" "
					+ "xmlns:ns2=\"urn:messages.service.ti.apps.tiplus2.misys.com\" xmlns:ns4=\"urn:custom.service.ti.apps.tiplus2.misys.com\" "
					+ "xmlns:ns3=\"urn:common.service.ti.apps.tiplus2.misys.com\">"
					+ "<RequestHeader><Service>BackOffice</Service>"
					+ "	<Operation>Batch</Operation><Credentials><Name>SUPERVISOR</Name></Credentials><ReplyFormat>FULL</ReplyFormat> "
					+ "<SourceSystem>Z2</SourceSystem><NoRepair>Y</NoRepair><NoOverride>Y</NoOverride>"
					+ "<TransactionControl>NONE</TransactionControl><CreationDate>2015-10-19+05:30</CreationDate></RequestHeader>"
					+ "<ns2:BatchRequest>";
			String xml2 = "</ns2:BatchRequest></ServiceRequest>";
			endString = endString + xml1;
			if (null != list) {

				int size = list.size();
				finalXML = new String[size];
				for (int i = 0; i < size; i++) {
					String temp = null;

					temp = pxs.generatePostingTag(list.get(i));
					temp = temp.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
					finalXML[i] = temp;
				}

				for (int i = 0; i < size; i++) {
					endString = endString + finalXML[i];
				}
				endString = endString + xml2;
			}

			System.out.println("Final XML---------->" + endString);

			logger.info("endString" + endString);

			/*
			 * ogger.info("CAP3"); BridgeGatewayImplService service = new
			 * BridgeGatewayImplService(); logger.info("CAP2"); BridgeGateway bg
			 * = service.getBridgeGatewayImplPort();
			 * 
			 * String result = bg.process(endString); logger.info("CAP4");
			 * 
			 * logger.info(result);
			 */
			/*
			 * BridgeGatewayImplServiceStub bs= new
			 * BridgeGatewayImplServiceStub();
			 * bs.bridgeGateWayProcess(endString);
			 * System.out.println("Stub done");
			 */

			// logger.info("Calling BridgeGatewayImplServiceStub Ends");
		} catch (Exception exception) {
			exception.printStackTrace();
			System.out.println(exception);
		}

	}

	public void updateCapEOD(String masterRef, Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		// LoggableStatement ps = null;
		LoggableStatement loggableStatement = null;

		try {

			logger.info("updateCapEOD-------------->");
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			loggableStatement = new LoggableStatement(con,
					"UPDATE ETT_INTCAP_POST SET STATUS='UPDATED' WHERE  TRIM(MASTERREFERENCE) = '"
							+ masterRef + "' AND STATUS IS NULL");
			logger.info("updateCap 1EOD-------------->"
					+ loggableStatement.getQueryString());
			loggableStatement.executeUpdate();

		} catch (Exception exception) {
			logger.info(exception.getMessage());
			exception.printStackTrace();
			System.out.println(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(null, loggableStatement);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/**
	 * 
	 * @param fileVO
	 * @param recordVO
	 * @return
	 * @throws DAOException
	 * @throws SQLException
	 */
	public int createRTNFData(FileHeaderVO fileVO, FileDataRecordVO recordVO)
			throws DAOException, SQLException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		String query = "";
		int result = 0;
		CommonMethods commonMethods = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			commonMethods = new CommonMethods();
			query = "INSERT INTO ETT_RTNF_TBL(FILENAME,GENDATE,UPLOADTYPE,TRANS_COUNT,TRANS_AMT,TRANS_REFNO,"
					+ "MSG_TYPE,REM_ACCNO,REM_ACCNAME,REM_ADDR1,REM_ADDR2,SENDER_TYPE,COMM_AMT,"
					+ "BENEF_NAME,BENEF_ACCNO,BENEF_ACCTYPE,BENEF_ADDR1,BENEF_ADDR2,BENEF_IFSC,FILENUMBER) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			ps = new LoggableStatement(con, query);
			ps.setString(1, commonMethods.getEmptyIfNull(fileVO.getFileName())
					.trim());
			ps.setString(2, commonMethods.getEmptyIfNull(fileVO.getGenDate())
					.trim());
			ps.setString(3, commonMethods
					.getEmptyIfNull(fileVO.getUploadType()).trim());
			ps.setString(4, commonMethods
					.getEmptyIfNull(fileVO.getTransCount()).trim());
			ps.setString(5, commonMethods
					.getEmptyIfNull(recordVO.getTransAmt()).trim());
			ps.setString(6, commonMethods
					.getEmptyIfNull(recordVO.getTransRef()).trim());
			ps.setString(7, commonMethods.getEmptyIfNull(recordVO.getMsgType())
					.trim());
			ps.setString(8, commonMethods
					.getEmptyIfNull(recordVO.getRemAccNo()).trim());
			ps.setString(9,
					commonMethods.getEmptyIfNull(recordVO.getRemAccName())
							.trim());
			ps.setString(10,
					commonMethods.getEmptyIfNull(recordVO.getRemAddr1()).trim());
			ps.setString(11,
					commonMethods.getEmptyIfNull(recordVO.getRemAddr2()).trim());
			ps.setString(12,
					commonMethods.getEmptyIfNull(recordVO.getSenderAccTypr())
							.trim());
			ps.setString(13, commonMethods
					.getEmptyIfNull(recordVO.getCommAmt()).trim());
			ps.setString(14,
					commonMethods.getEmptyIfNull(recordVO.getBenefName())
							.trim());
			ps.setString(15,
					commonMethods.getEmptyIfNull(recordVO.getBenefAcc()).trim());
			ps.setString(16,
					commonMethods.getEmptyIfNull(recordVO.getBenefAccType())
							.trim());
			ps.setString(17,
					commonMethods.getEmptyIfNull(recordVO.getBenefAddr1())
							.trim());
			ps.setString(18,
					commonMethods.getEmptyIfNull(recordVO.getBenefAddr2())
							.trim());
			ps.setString(19,
					commonMethods.getEmptyIfNull(recordVO.getBenefIFSC())
							.trim());
			ps.setString(20, commonMethods.getEmptyIfNull(fileVO.getFileSeq())
					.trim());
			System.out.println(ps.getQueryString());
			result = ps.executeUpdate();

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			/*
			 * ps.close(); con.close();
			 */
			DBConnectionUtility.surrenderDB(null, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return result;

	}

}
