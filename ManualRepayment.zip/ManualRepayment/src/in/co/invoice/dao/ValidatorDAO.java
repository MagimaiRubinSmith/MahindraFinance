package in.co.invoice.dao;

import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.log4j.Logger;

import in.co.invoice.dao.exception.DAOException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.ActionConstantsQuery;
import in.co.invoice.utility.CommonMethods;
import in.co.invoice.utility.DBConnectionUtility;
import in.co.invoice.utility.LoggableStatement;
import in.co.invoice.rtnf.AccountHolderDetailsVO;

public class ValidatorDAO extends AbstractDAO implements ActionConstantsQuery,
		ActionConstants {

	static ValidatorDAO dao;

	private static Logger logger = Logger.getLogger(ValidatorDAO.class
			.getName());

	/**
	 * 
	 * @return
	 */
	public static ValidatorDAO getDAO() {
		if (dao == null) {
			dao = new ValidatorDAO();
		}
		return dao;
	}

	/**
	 * 
	 * @param programID
	 * @return
	 * @throws DAOException
	 */
	public String getCustomer(String programID, Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ResultSet rs = null;
		LoggableStatement ps = null;
		String branch = null;
		// Connection con = null;
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT CUSTOMER FROM SCFPROGRAM WHERE ID = '"
							+ programID.trim() + "'");
			rs = ps.executeQuery();
			if (rs.next()) {
				branch = (rs.getString(1) == null) ? "" : rs.getString(1);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return branch;
	}

	/**
	 * 
	 * @param programeID
	 * @param con
	 * @return
	 * @throws DAOException
	 */
	public String buyerSeller(String programeID, Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ResultSet rs = null;
		LoggableStatement ps = null;
		String financeType = "";
		try {
			// if (con == null)
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"select trim(prog_type) from scfprogram where id = '"
							+ programeID.trim() + "'");
			rs = ps.executeQuery();
			if (rs.next()) {
				financeType = (rs.getString(1) == null) ? "" : rs.getString(1);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			// DBConnectionUtility.surrenderDB(con, ps, rs);
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return financeType;
	}

	/**
	 * 
	 * @param invoice_ref
	 * @param cParty
	 * @return
	 * @throws DAOException
	 */
	public String getRefKey(String invoice_ref, String cParty)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String RefKey = "";
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(
					con,
					"select inv.FINCE_EV from master mas, invmaster inv,SCFPROGRAM S,SCFCPARTY SP where "
							+ "mas.key97=inv.key97 AND mas.STATUS = 'LIV' and inv.invoic_ref='"
							+ invoice_ref
							+ "' AND SP.CPARTY='"
							+ cParty
							+ "' and "
							+ "inv.PROGRAMME=S.KEY97 AND SP.KEY97=CASE S.PROG_TYPE WHEN 'S' THEN inv.BUYER WHEN 'B' "
							+ "THEN inv.SELLER END");
			rs = ps.executeQuery();
			if (rs.next()) {
				RefKey = (rs.getString(1) == null) ? "" : rs.getString(1);
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}

		logger.info(ActionConstants.EXITING_METHOD);
		return RefKey;
	}

	/**
	 * 
	 * @param finkey
	 * @return
	 * @throws DAOException
	 */
	public String getFinancedAmount(String finkey) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String amount = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			logger.info("finkey" + finkey);
			if (null != finkey) {
				finkey = finkey.trim();

			}
			String query = " select ETT_NEFTRTGS_AMT('" + finkey
					+ "' ) AS FIN_AMOUNT from DUAL";

			ps = new LoggableStatement(con, query);
			logger.info("Executing Query" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				logger.info("Returning Amount-->" + rs.getDouble("FIN_AMOUNT"));
				amount = rs.getString("FIN_AMOUNT");
				logger.info("Returning Amount" + amount);
				System.out.println("NEFT Amount ---->" + amount);
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}

		logger.info(ActionConstants.EXITING_METHOD);
		return amount;
	}

	/**
	 * 
	 * @param programeId
	 * @param seller
	 * @return
	 * @throws DAOException
	 */
	public AccountHolderDetailsVO getDisbursement(String programeId,
			String seller) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		AccountHolderDetailsVO accountHolderDetailsVO = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			accountHolderDetailsVO = new AccountHolderDetailsVO();
			String query = "SELECT CPARTY,ROLE,CPARTYNAME,PHONE,EMAIL,CPARTYXM FROM SCFCPARTY "
					+ "WHERE PROGRAMME=(SELECT KEY97 FROM SCFPROGRAM WHERE ID='"
					+ programeId
					+ "') AND ROLE='S' AND CPARTY='"
					+ seller
					+ "'";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				accountHolderDetailsVO.setBeneficiaryName(rs
						.getString("CPARTYNAME"));
				accountHolderDetailsVO.setDisbMed(rs.getString("CPARTYXM"));
				accountHolderDetailsVO.setPhone(rs.getString("PHONE"));
				accountHolderDetailsVO.setEmail(rs.getString("EMAIL"));

			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountHolderDetailsVO;
	}

	/**
	 * 
	 * @param accountHolderDetailsVO
	 * @param programeId
	 * @param customer
	 * @return
	 * @throws DAOException
	 */
	public AccountHolderDetailsVO getRTGSNEFTData(
			AccountHolderDetailsVO accountHolderDetailsVO, String programeId,
			String customer) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "select LOAN_ACCT_NO,REFUND_BENEFICIARY,REFUND_IFSC from ETT_CLF_SELLERBUYERRELATION "
					+ "where PROGIDN='"
					+ programeId
					+ "' AND CUSTOMR='"
					+ customer + "'";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				accountHolderDetailsVO.setBeneficiaryAccountNumber(rs
						.getString("REFUND_BENEFICIARY"));
				accountHolderDetailsVO.setRemitterAccountName("");
				accountHolderDetailsVO.setRemitterAccountNumber(rs
						.getString("LOAN_ACCT_NO"));
				accountHolderDetailsVO.setRemitterAddress1("");
				accountHolderDetailsVO.setRemitterAddress2("");
				accountHolderDetailsVO.setBeneficiaryIDFCCode(rs
						.getString("REFUND_IFSC"));
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountHolderDetailsVO;
	}

	/**
	 * 
	 * @param vo
	 * @return
	 * @throws DAOException
	 */
	public String setTIDate() throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement pst = null;
		ResultSet rs = null;
		Connection con = null;
		String tiDate = null;
		try {
			CommonMethods commonMethods = null;
			commonMethods = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "SELECT TO_CHAR(TO_DATE(PROCDATE, 'dd-mm-yy'),'yyyyMMdd') as PROCDATE FROM dlyprccycl";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				tiDate = commonMethods.getEmptyIfNull(rs.getString("PROCDATE"))
						.trim();
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return tiDate;
	}

	/**
	 * 
	 * @param vo
	 * @return
	 * @throws DAOException
	 */
	public String fetchDate() throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement pst = null;
		ResultSet rs = null;
		Connection con = null;
		String tiDate = null;
		try {
			CommonMethods commonMethods = null;
			commonMethods = new CommonMethods();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "SELECT TO_CHAR(TO_DATE(PROCDATE, 'dd-mm-yy'),'dd-mm-yyyy') as PROCDATE FROM dlyprccycl";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				tiDate = commonMethods.getEmptyIfNull(rs.getString("PROCDATE"))
						.trim();
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return tiDate;
	}

	public int getEodStat() throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ResultSet rs = null;
		LoggableStatement ps = null;
		int stat = 0;
		Connection con = null;
		try {
			//
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT COUNT(STATUS) as STATUS FROM ETT_STATUS_TEMPCHECK WHERE STATUS ='END'");
			rs = ps.executeQuery();
			if (rs.next()) {
				stat = rs.getInt("STATUS");
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return stat;
	}

	public String sequenceXML() throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ResultSet rs = null;
		Connection con = null;
		LoggableStatement ps = null;
		String vals = "";
		try {
			// if (con == null)
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con, "SELECT EODSEQ.nextval FROM dual");
			rs = ps.executeQuery();
			if (rs.next()) {
				vals = rs.getString("nextval");
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return vals;
	}

	public String sequenceEOD(Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ResultSet rs = null;
		// Connection con = null;
		LoggableStatement ps = null;
		String vals = "";
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT ETT_CAPEOD_SEQ.nextval FROM dual");
			rs = ps.executeQuery();
			if (rs.next()) {
				vals = rs.getString("nextval");
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return vals;
	}

	public String getExp(String prgm,Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		//Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String exposure = "";
		try {
			if (prgm != null) {
				prgm = prgm.trim();
			}
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"select EXPANC from ett_clf_programparameters where trim(proiden)='"
							+ prgm + "'");
			rs = ps.executeQuery();
			if (rs.next()) {
				exposure = rs.getString("EXPANC").trim();
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs,ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return exposure;
	}

	public String getAnchorLimitAccount(String programeId) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String limitNumber = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "select distinct PROG_NOR_LMNO AS PROG_NOR_LMNO from ETT_PROG_CP_LM where PROG_ID='"
					+ programeId + "'";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				limitNumber = rs.getString("PROG_NOR_LMNO");
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return limitNumber;

	}

	public String getCpartyLimitAccount(String programeId, String cParty,
			Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String limitNumber = null;
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "select CASE WHEN PROG_EXPOSURE='A' THEN PROG_NOR_LMNO  WHEN PROG_EXPOSURE!='A' THEN PROG_CP_NOR_LMNO END"
					+ " PROG_CP_NOR_LMNO  from ETT_PROG_CP_LM where PROG_ID='"
					+ programeId + "' AND PROG_CP='" + cParty + "'";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				limitNumber = rs.getString("PROG_CP_NOR_LMNO");

				if (null != limitNumber) {
					limitNumber = limitNumber.trim();
				}
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return limitNumber;

	}

	public String updateDealStatus(Connection con, String capDt,
			String prgrmID, String limitaccNo, String prgExp)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		// ResultSet rs = null;
		ResultSet rs1 = null;
		CommonMethods com = null;
		LoggableStatement ps = null;
		// LoggableStatement ps1 = null;
		LoggableStatement ps2 = null;
		String prdate = null;
		String dealNo = null;
		String capDat = null;
		String date_query = null;
		try {
			com = new CommonMethods();

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			/*
			 * ps1 = new LoggableStatement(con,
			 * "select to_char(to_date(procdate,'dd-mm-yy'),'dd-mm-yy') as procdate from dlyprccycl"
			 * ); rs = ps1.executeQuery(); if (rs.next()) { prdate =
			 * rs.getString("procdate"); }
			 */
			if (!com.isNull(capDt)) {

				/*
				 * String date_query =
				 * "SELECT to_char(to_date(CAP_DT,'dd-mm-yy'),'dd-mm-yy') as CAP_DT,CAP_DEAL_REF FROM ETT_MTH_CAP "
				 * +
				 * "WHERE CAP_DT = to_date('"+capDt+"','dd-mm-yy') AND CAP_PRG_ID='"
				 * +
				 * prgrmID+"' AND  and CAP_STATUS IS NULL ORDER BY CAP_DEAL_REF"
				 * ;
				 */

				if (prgExp.equalsIgnoreCase("A")) {
					date_query = "SELECT CAP_DEAL_REF,to_char(to_date(CAP_DT,'dd-mm-yy'),'dd-mm-yy') as CAP_DT "
							+ "FROM ETT_MTH_CAP A,ETT_PROG_CP_LM B WHERE PROG_NOR_LMNO= '"
							+ limitaccNo
							+ "' AND CAP_DT = to_date('"
							+ capDt
							+ "','dd-mm-yy') "
							+ "AND CAP_PRG_ID='"
							+ prgrmID
							+ "' AND CAP_STATUS IS NULL and  TRIM(B.PROG_ID)=CAP_PRG_ID AND TRIM(PROG_CP)=CAP_CPARTY ORDER BY CAP_DEAL_REF";
				} else {
					date_query = "SELECT CAP_DEAL_REF,to_char(to_date(CAP_DT,'dd-mm-yy'),'dd-mm-yy') as CAP_DT "
							+ "FROM ETT_MTH_CAP A,ETT_PROG_CP_LM B WHERE PROG_CP_NOR_LMNO= '"
							+ limitaccNo
							+ "' AND CAP_DT = to_date('"
							+ capDt
							+ "','dd-mm-yy') "
							+ "AND CAP_PRG_ID='"
							+ prgrmID
							+ "' AND CAP_STATUS IS NULL and  TRIM(B.PROG_ID)=CAP_PRG_ID AND TRIM(PROG_CP)=CAP_CPARTY ORDER BY CAP_DEAL_REF";
				}
				/*
				 * String date_query =
				 * "SELECT CAP_DEAL_REF,to_char(to_date(CAP_DT,'dd-mm-yy'),'dd-mm-yy') as CAP_DT "
				 * +
				 * "FROM ETT_MTH_CAP A,ETT_PROG_CP_LM B WHERE CASE WHEN PROG_EXPOSURE='A' THEN PROG_NOR_LMNO= '"
				 * +limitaccNo+"' WHEN " +
				 * "PROG_EXPOSURE!='A' THEN PROG_CP_NOR_LMNO='"
				 * +limitaccNo+"' END AND CAP_DT = to_date('"
				 * +capDt+"','dd-mm-yy') " + "AND CAP_PRG_ID='"+prgrmID+
				 * "' AND CAP_STATUS IS NULL ORDER BY CAP_DEAL_REF" ;
				 */

				System.out.println(date_query);
				// to_date('"+prdate+"','dd-mm-yy')
				ps2 = new LoggableStatement(con, date_query);
				rs1 = ps2.executeQuery();
				while (rs1.next()) {
					dealNo = rs1.getString("CAP_DEAL_REF");
					capDat = rs1.getString("CAP_DT");
					if (!com.isNull(dealNo)) {
						String query = "UPDATE ETT_MTH_INT_CAP SET STATUS='P' WHERE DEALREF ='"
								+ dealNo
								+ "' and INTDATE =  TO_DATE('"
								+ capDat + "','dd-mm-yy')";
						System.out.println("Update Query --->" + query);

						ps = new LoggableStatement(con, query);
						logger.info("Executing Query " + ps.getQueryString());
						ps.executeUpdate();
					}
				}

			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs1, ps2);
			DBConnectionUtility.surrenderStatement(null, ps);
		}

		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	public String updateRemRecords(Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement ps = null;
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "UPDATE ETT_MTH_INT_CAP SET STATUS = 'P' WHERE STATUS IS NULL";
			System.out.println(query);
			ps = new LoggableStatement(con, query);
			logger.info("Result Query - " + ps.getQueryString());
			ps.executeUpdate();
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, ps);
		}

		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	public String deleteEodRecords(Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement ps = null;
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "DELETE FROM ETT_STATUS_TEMPCHECK";
			System.out.println(query);
			ps = new LoggableStatement(con, query);
			logger.info("Result Query - " + ps.getQueryString());
			ps.executeUpdate();
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, ps);
		}

		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	public AccountHolderDetailsVO getRemittersDetails(
			AccountHolderDetailsVO accountHolderDetailsVO, String customer)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			if (customer != null) {
				customer = customer.trim();
			}
			String query = "select s.SVNA1 as SVNA1,s.SVNA2 as SVNA2,s.SVNA3 as SVNA3,s.SVNA4 as SVNA4,g.gfcun as gfcun"
					+ " from sx20lf s,gfpf g where s.sxcus1 = g.gfcus1 and trim(s.sxcus1)='"
					+ customer + "'";
			ps = new LoggableStatement(con, query);
			logger.info("Select Customer Remitter Address Executing Query->"
					+ ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				accountHolderDetailsVO.setRemitterAccountName(rs
						.getString("gfcun"));
				accountHolderDetailsVO.setRemitterAddress1(rs
						.getString("SVNA1"));
				accountHolderDetailsVO.setRemitterAddress2(rs
						.getString("SVNA2"));
				accountHolderDetailsVO.setRemitterAddress3(rs
						.getString("SVNA3"));
				accountHolderDetailsVO.setRemitterAddress4(rs
						.getString("SVNA4"));
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountHolderDetailsVO;

	}

	public String insertTempRecords(Connection con, String seqVal,
			String limitNo, String finAmt, String batchId, String custmr,
			String capDt, String request, String response, String prgrmId,
			String expOn) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement ps = null;
		try {

			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con, CapQuery);
			ps.setString(1, seqVal);
			ps.setString(2, limitNo);
			ps.setString(3, finAmt);
			ps.setString(4, batchId);
			ps.setString(5, custmr);
			ps.setString(6, capDt);
			ps.setString(7, request);
			ps.setString(8, response);
			ps.setString(9, prgrmId);
			ps.setString(10, expOn);
			logger.info("Result Query - " + ps.getQueryString());
			ps.executeUpdate();
		} catch (Exception e) {
			throwDAOException(e);
		} finally {
			DBConnectionUtility.surrenderStatement(null, ps);
		}

		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	/*
	 * public static void main(String args[]) throws DAOException{ ValidatorDAO
	 * va = new ValidatorDAO(); Connection con = null; va.updateDealStatus(con);
	 * }
	 */

}