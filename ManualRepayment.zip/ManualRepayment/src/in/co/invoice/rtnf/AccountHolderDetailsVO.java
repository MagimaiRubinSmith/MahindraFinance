package in.co.invoice.rtnf;


/**
 * 
 * @author Arul.Selvan
 * 
 */
public class AccountHolderDetailsVO {

	String email;

	String phone;

	String disbMed;

	String remitterAccountNumber;
	
	String remitterAccountName;
	
	String remitterAddress1;
	
	String remitterAddress2;
	
	String remitterAddress3;
	
	String remitterAddress4;
	
	String beneficiaryName;
	
	public String getRemitterAddress3() {
		return remitterAddress3;
	}

	public void setRemitterAddress3(String remitterAddress3) {
		this.remitterAddress3 = remitterAddress3;
	}

	public String getRemitterAddress4() {
		return remitterAddress4;
	}

	public void setRemitterAddress4(String remitterAddress4) {
		this.remitterAddress4 = remitterAddress4;
	}

	String beneficiaryAccountNumber;
	
	String beneficiaryIDFCCode;

	
	/**
	 * @return the remitterAccountNumber
	 */
	public String getRemitterAccountNumber() {
		return remitterAccountNumber;
	}

	/**
	 * @param remitterAccountNumber the remitterAccountNumber to set
	 */
	public void setRemitterAccountNumber(String remitterAccountNumber) {
		this.remitterAccountNumber = remitterAccountNumber;
	}

	/**
	 * @return the remitterAccountName
	 */
	public String getRemitterAccountName() {
		return remitterAccountName;
	}

	/**
	 * @param remitterAccountName the remitterAccountName to set
	 */
	public void setRemitterAccountName(String remitterAccountName) {
		this.remitterAccountName = remitterAccountName;
	}

	/**
	 * @return the remitterAddress1
	 */
	public String getRemitterAddress1() {
		return remitterAddress1;
	}

	/**
	 * @param remitterAddress1 the remitterAddress1 to set
	 */
	public void setRemitterAddress1(String remitterAddress1) {
		this.remitterAddress1 = remitterAddress1;
	}

	/**
	 * @return the remitterAddress2
	 */
	public String getRemitterAddress2() {
		return remitterAddress2;
	}

	/**
	 * @param remitterAddress2 the remitterAddress2 to set
	 */
	public void setRemitterAddress2(String remitterAddress2) {
		this.remitterAddress2 = remitterAddress2;
	}

	/**
	 * @return the beneficiaryName
	 */
	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	/**
	 * @param beneficiaryName the beneficiaryName to set
	 */
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	/**
	 * @return the beneficiaryAccountNumber
	 */
	public String getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}

	/**
	 * @param beneficiaryAccountNumber the beneficiaryAccountNumber to set
	 */
	public void setBeneficiaryAccountNumber(String beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}

	/**
	 * @return the beneficiaryIDFCCode
	 */
	public String getBeneficiaryIDFCCode() {
		return beneficiaryIDFCCode;
	}

	/**
	 * @param beneficiaryIDFCCode the beneficiaryIDFCCode to set
	 */
	public void setBeneficiaryIDFCCode(String beneficiaryIDFCCode) {
		this.beneficiaryIDFCCode = beneficiaryIDFCCode;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone
	 *            the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the disbMed
	 */
	public String getDisbMed() {
		return disbMed;
	}

	/**
	 * @param disbMed
	 *            the disbMed to set
	 */
	public void setDisbMed(String disbMed) {
		this.disbMed = disbMed;
	}

}
