package in.co.invoice.rtnf;



/**
 * 
 * @author Arul.Selvan
 * 
 */
public class FileDataRecordVO {

	public String dateIden;
	public String srcApp;
	public String transRef;
	public String msgType;
	public String relRefNo;
	public String remAccNo;
	public String remAccName;
	public String remAddr1;
	public String remAddr2;
	public String remAddr3;
	public String remAddr4;
	public String senderAccTypr;
	public String commAmt;
	public String transAmt;
	public String benefName;
	public String benefAcc;
	public String benefAccType;
	public String benefAddr1;
	public String benefAddr2;
	public String benefIFSC;
	public String detailOfPay;
	public String senderRecCode;
	public String senderRecInfo1;
	public String senderRecInfo2;
	public String senderRecInfo3;
	public String senderRecInfo4;
	public String senderRecInfo5;
	public String senderRecInfo6;
	public String cusMob_Email;

	public String getDateIden() {
		return dateIden;
	}

	public void setDateIden(String dateIden) {
		this.dateIden = dateIden;
	}

	public String getSrcApp() {
		return srcApp;
	}

	public void setSrcApp(String srcApp) {
		this.srcApp = srcApp;
	}

	public String getTransRef() {
		return transRef;
	}

	public void setTransRef(String transRef) {
		this.transRef = transRef;
	}

	public String getMsgType() {
		return msgType;
	}

	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	public String getRelRefNo() {
		return relRefNo;
	}

	public void setRelRefNo(String relRefNo) {
		this.relRefNo = relRefNo;
	}

	public String getRemAccNo() {
		return remAccNo;
	}

	public void setRemAccNo(String remAccNo) {
		this.remAccNo = remAccNo;
	}

	public String getRemAccName() {
		return remAccName;
	}

	public void setRemAccName(String remAccName) {
		this.remAccName = remAccName;
	}

	public String getRemAddr1() {
		return remAddr1;
	}

	public void setRemAddr1(String remAddr1) {
		this.remAddr1 = remAddr1;
	}

	public String getRemAddr2() {
		return remAddr2;
	}

	public void setRemAddr2(String remAddr2) {
		this.remAddr2 = remAddr2;
	}

	public String getRemAddr3() {
		return remAddr3;
	}

	public void setRemAddr3(String remAddr3) {
		this.remAddr3 = remAddr3;
	}

	public String getRemAddr4() {
		return remAddr4;
	}

	public void setRemAddr4(String remAddr4) {
		this.remAddr4 = remAddr4;
	}

	public String getSenderAccTypr() {
		return senderAccTypr;
	}

	public void setSenderAccTypr(String senderAccTypr) {
		this.senderAccTypr = senderAccTypr;
	}

	public String getCommAmt() {
		return commAmt;
	}

	public void setCommAmt(String commAmt) {
		this.commAmt = commAmt;
	}

	public String getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}

	public String getBenefName() {
		return benefName;
	}

	public void setBenefName(String benefName) {
		this.benefName = benefName;
	}

	public String getBenefAcc() {
		return benefAcc;
	}

	public void setBenefAcc(String benefAcc) {
		this.benefAcc = benefAcc;
	}

	public String getBenefAccType() {
		return benefAccType;
	}

	public void setBenefAccType(String benefAccType) {
		this.benefAccType = benefAccType;
	}

	public String getBenefAddr1() {
		return benefAddr1;
	}

	public void setBenefAddr1(String benefAddr1) {
		this.benefAddr1 = benefAddr1;
	}

	public String getBenefAddr2() {
		return benefAddr2;
	}

	public void setBenefAddr2(String benefAddr2) {
		this.benefAddr2 = benefAddr2;
	}

	public String getBenefIFSC() {
		return benefIFSC;
	}

	public void setBenefIFSC(String benefIFSC) {
		this.benefIFSC = benefIFSC;
	}

	public String getDetailOfPay() {
		return detailOfPay;
	}

	public void setDetailOfPay(String detailOfPay) {
		this.detailOfPay = detailOfPay;
	}

	public String getSenderRecCode() {
		return senderRecCode;
	}

	public void setSenderRecCode(String senderRecCode) {
		this.senderRecCode = senderRecCode;
	}

	public String getSenderRecInfo1() {
		return senderRecInfo1;
	}

	public void setSenderRecInfo1(String senderRecInfo1) {
		this.senderRecInfo1 = senderRecInfo1;
	}

	public String getSenderRecInfo2() {
		return senderRecInfo2;
	}

	public void setSenderRecInfo2(String senderRecInfo2) {
		this.senderRecInfo2 = senderRecInfo2;
	}

	public String getSenderRecInfo3() {
		return senderRecInfo3;
	}

	public void setSenderRecInfo3(String senderRecInfo3) {
		this.senderRecInfo3 = senderRecInfo3;
	}

	public String getSenderRecInfo4() {
		return senderRecInfo4;
	}

	public void setSenderRecInfo4(String senderRecInfo4) {
		this.senderRecInfo4 = senderRecInfo4;
	}

	public String getSenderRecInfo5() {
		return senderRecInfo5;
	}

	public void setSenderRecInfo5(String senderRecInfo5) {
		this.senderRecInfo5 = senderRecInfo5;
	}

	public String getSenderRecInfo6() {
		return senderRecInfo6;
	}

	public void setSenderRecInfo6(String senderRecInfo6) {
		this.senderRecInfo6 = senderRecInfo6;
	}

	public String getCusMob_Email() {
		return cusMob_Email;
	}

	public void setCusMob_Email(String cusMob_Email) {
		this.cusMob_Email = cusMob_Email;
	}

}
