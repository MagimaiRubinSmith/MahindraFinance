package in.co.invoice.rtnf;

import java.util.ArrayList;


/**
 * 
 * @author Arul.Selvan
 *
 */
public class FileHeaderVO {

	
	public String headerIdn;
	public String fileName;
	public String genDate;
	public String uploadType;
	public String masRef;
	public String eventRef;
	public String timeStmp;
	public String journalNo;
	public String remAccNo;
	public String transCount;
	public String transAmt;	
	/**
	 * @return the fileSeq
	 */
	public String getFileSeq() {
		return fileSeq;
	}
	/**
	 * @param fileSeq the fileSeq to set
	 */
	public void setFileSeq(String fileSeq) {
		this.fileSeq = fileSeq;
	}
	public String fileSeq;	
	
	ArrayList<FileDataRecordVO> dataRecordList = null;
	
	public String getHeaderIdn() {
		return headerIdn;
	}
	public void setHeaderIdn(String headerIdn) {
		this.headerIdn = headerIdn;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getGenDate() {
		return genDate;
	}
	public void setGenDate(String genDate) {
		this.genDate = genDate;
	}
	public String getUploadType() {
		return uploadType;
	}
	public void setUploadType(String uploadType) {
		this.uploadType = uploadType;
	}
	public String getJournalNo() {
		return journalNo;
	}
	public void setJournalNo(String journalNo) {
		this.journalNo = journalNo;
	}
	public String getRemAccNo() {
		return remAccNo;
	}
	public void setRemAccNo(String remAccNo) {
		this.remAccNo = remAccNo;
	}
	public String getTransCount() {
		return transCount;
	}
	public void setTransCount(String transCount) {
		this.transCount = transCount;
	}
	public String getTransAmt() {
		return transAmt;
	}
	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}	
	public String getMasRef() {
		return masRef;
	}
	public void setMasRef(String masRef) {
		this.masRef = masRef;
	}
	public String getEventRef() {
		return eventRef;
	}
	public void setEventRef(String eventRef) {
		this.eventRef = eventRef;
	}
	public String getTimeStmp() {
		return timeStmp;
	}
	public void setTimeStmp(String timeStmp) {
		this.timeStmp = timeStmp;
	}
	public ArrayList<FileDataRecordVO> getDataRecordList() {
		return dataRecordList;
	}
	public void setDataRecordList(ArrayList<FileDataRecordVO> dataRecordList) {
		this.dataRecordList = dataRecordList;
	}
	
	
	
	
	
}
