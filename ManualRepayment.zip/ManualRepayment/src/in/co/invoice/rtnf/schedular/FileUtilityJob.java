package in.co.invoice.rtnf.schedular;

import in.co.invoice.action.RTNFFileReadAction;
import in.co.invoice.businessdelegate.exception.BusinessException;
import in.co.invoice.dao.exception.ApplicationException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.CommonMethods;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;

/**
 * This class defines a quartz job
 * @author Encore
 *
 */

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
public class FileUtilityJob implements Job{
	static String schedularOn=ActionConstants.N;
	public void execute(JobExecutionContext context)
			throws JobExecutionException {	 
		RTNFFileReadAction m = null; 
		CommonMethods commonMethods=null;
		try {
			commonMethods=new CommonMethods();
			if(!commonMethods.isNull(schedularOn) && schedularOn.equals(ActionConstants.N))
			{
			schedularOn=ActionConstants.Y;
			m = new RTNFFileReadAction(); 
			try {
					m.execute();
			} catch (ApplicationException e) {
				schedularOn=ActionConstants.N;
				e.printStackTrace();
			}
			schedularOn=ActionConstants.N;
			}
			} catch (BusinessException e) {
			schedularOn=ActionConstants.N;
			e.printStackTrace();
		}
	}
	
}
