package in.co.invoice.rtnf.schedular;

import in.co.invoice.utility.ActionConstants;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

/**
 * This class is used for executing quartz job 
 * using CronTrigger.
 * @author Encore
 *
 */
public class FileUtilityListener implements ServletContextListener {
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		
	}
	
	
	private static Logger logger = Logger.getLogger(FileUtilityListener.class
			.getName());
	
	
	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		logger.info(ActionConstants.ENTERING_METHOD);
		
		try{
    		//Set job details.
			System.out.println("Job Scheduling...................starts");
    		JobDetail job = JobBuilder.newJob(FileUtilityJob.class)
    				.withIdentity("FileUtilityJob", "group1").build();
        	
        	//Set the scheduler timings.
    		Trigger trigger = TriggerBuilder.newTrigger()
    			.withIdentity("cronTrigger", "group1")
    			.withSchedule(CronScheduleBuilder
    			  .cronSchedule("0 0/1 * * * ?")).build();
    	
	        	//Execute the job.
	    		Scheduler scheduler = 
	    				new StdSchedulerFactory().getScheduler();
	        	scheduler.start();
	        	scheduler.scheduleJob(job, trigger);
	 
        	System.out.println("Job Scheduling...................ends");
    	} catch(Exception e){
    		e.printStackTrace();
    	}    
		logger.info(ActionConstants.ENTERING_METHOD);
	}
	  
	

}
