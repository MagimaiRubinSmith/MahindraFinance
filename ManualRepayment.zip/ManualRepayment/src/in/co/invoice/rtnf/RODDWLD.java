package in.co.invoice.rtnf;

import in.co.invoice.dao.AbstractDAO;
import in.co.invoice.dao.RTNFFileReadDAO;
import in.co.invoice.dao.ValidatorDAO;
import in.co.invoice.dao.exception.DAOException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.ActionConstantsQuery;
import in.co.invoice.utility.CommonMethods;
import in.co.invoice.utility.DBConnectionUtility;
import in.co.invoice.utility.LoggableStatement;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;


/**
 * 
 * @author Arul.Selvan
 * 
 */
public class RODDWLD extends AbstractDAO implements ActionConstantsQuery,
		ActionConstants {

	static RODDWLD dao;

	private static Logger logger = Logger.getLogger(RODDWLD.class.getName());

	/**
	 * 
	 * @return
	 */
	public static RODDWLD getDAO() {
		if (dao == null) {
			dao = new RODDWLD();
		}
		return dao;
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// fileWriter();
	}

	/**
	 * 
	 * @return
	 * @throws DAOException
	 */
	public String fileWriter(FileHeaderVO fileVO,
			ArrayList<FileDataRecordVO> rows) throws DAOException {
		String headerFieldValue = null;
		String fileName = null;
		CommonMethods commonMethods = null;
		RTNFFileReadDAO dao = null;
		FileDataRecordVO recordVO = null;
		try {
			commonMethods = new CommonMethods();
			if (fileVO != null) {

				String headerValue = commonMethods.getEmptyIfNull(fileVO.getHeaderIdn()).trim();
				fileName = commonMethods.getEmptyIfNull(fileVO.getFileName()).trim();
				String valDate = commonMethods.getEmptyIfNull(fileVO.getGenDate()).trim();
				String upldType = commonMethods.getEmptyIfNull(fileVO.getUploadType()).trim();
				String jNo = commonMethods.getEmptyIfNull(fileVO.getJournalNo()).trim();
				String remNo = commonMethods.getEmptyIfNull(fileVO.getRemAccNo()).trim();
				String transCount = commonMethods.getEmptyIfNull(fileVO.getTransCount()).trim();
				String transAmt = commonMethods.getEmptyIfNull(fileVO.getTransAmt()).trim();

				headerFieldValue = headerValue + "|" + fileName + "|" + valDate
						+ "|" + upldType + "|" + jNo + "|" + remNo + "|"
						+ transCount + "|" + transAmt;

			}			
			
			//String transType = recordVO.getMsgType();
			String filePath = null;
			//if(null != transType && transType.equalsIgnoreCase(MSG_TYPE2)){
			//	filePath = RTGS_INPUT;
		//	}else{
				filePath=NEFT_INPUT;
		//	}
			
			
			FileWriter writer = new FileWriter(filePath + fileName, true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(headerFieldValue);
			
			Date date = new Date() ;
			SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyy") ;
			String backDir = dateFormat.format(date);
			
			String backFinal = BACKUP_INPUT+backDir+"/";
			File file = new File(backFinal);
			
			if (!file.exists()) {
				if (file.mkdir()) {
					System.out.println("Directory is created!");
				} else {
					System.out.println("Failed to create directory!");
				}
			}
			
			
			FileWriter writerbck = new FileWriter(backFinal+fileName, true);
			BufferedWriter bufferedWriterbck = new BufferedWriter(writerbck);
			bufferedWriterbck.write(headerFieldValue);
			
			dao = new RTNFFileReadDAO();
			
			
			

			for(int i=0;i<rows.size();i++)
			{
				recordVO=rows.get(i);	
			if(fileVO != null && recordVO != null){
				dao.createRTNFData(fileVO,recordVO);
			}						
			
			if (recordVO != null) {
					String dataIdn = commonMethods.getDataSign(recordVO.getDateIden()).trim();
					String srcApp = commonMethods.getDataSign(recordVO.getSrcApp()).trim();
					String transRefNo = commonMethods.getDataSign(recordVO.getTransRef()).trim();
					String msgType = commonMethods.getDataSign(recordVO.getMsgType()).trim();
					String relRefNo = commonMethods.getEmptyIfNull(recordVO.getRelRefNo()).trim();
					String remAccNo = commonMethods.getDataSign(recordVO.getRemAccNo()).trim();
					//remAccNo="98171102055";
					String remName = commonMethods.getEmptyIfNull(recordVO.getRemAccName()).trim();
					//remName="HORIZON";
					String remAdd1 = commonMethods.getEmptyIfNull(recordVO.getRemAddr1()).trim();
					String remAdd2 = commonMethods.getEmptyIfNull(recordVO.getRemAddr2()).trim();
					String remAdd3 = commonMethods.getEmptyIfNull(recordVO.getRemAddr3()).trim();
					String remAdd4 = commonMethods.getEmptyIfNull(recordVO.getRemAddr4()).trim();
					String senAccTyp = commonMethods.getDataSign(recordVO.getSenderAccTypr()).trim();
					//senAccTyp="11";
					String transAmt = commonMethods.getDataSign(recordVO.getTransAmt()).trim();
					String commAmt = commonMethods.getDataSign(recordVO.getCommAmt()).trim();
					String benfName = commonMethods.getDataSign(recordVO.getBenefName()).trim();
					String benfAcc = commonMethods.getDataSign(recordVO.getBenefAcc()).trim();
					String benfAccType = commonMethods.getDataSign(recordVO.getBenefAccType()).trim();
					String benfAdd1 = commonMethods.getDataSign(recordVO.getBenefAddr1()).trim();
					String benfAdd2 = commonMethods.getDataSign(recordVO.getBenefAddr2()).trim();
					String benfIFSC = commonMethods.getDataSign(recordVO.getBenefIFSC()).trim();
					String detOfPay = commonMethods.getEmptyIfNull(recordVO.getDetailOfPay()).trim();
					String senderRecCode = commonMethods.getEmptyIfNull(recordVO.getSenderRecCode()).trim();
					String senRecInfo1 = commonMethods.getEmptyIfNull(recordVO.getSenderRecInfo1()).trim();
					String senRecInfo2 = commonMethods.getEmptyIfNull(recordVO.getSenderRecInfo2()).trim();
					String senRecInfo3 = commonMethods.getEmptyIfNull(recordVO.getSenderRecInfo3()).trim();
					String senRecInfo4 = commonMethods.getEmptyIfNull(recordVO.getSenderRecInfo4()).trim();
					String senRecInfo5 = commonMethods.getEmptyIfNull(recordVO.getSenderRecInfo5()).trim();
					String senRecInfo6 = commonMethods.getEmptyIfNull(recordVO.getSenderRecInfo6()).trim();
					String cusMob = commonMethods.getDataSign(recordVO.getCusMob_Email()).trim();

					String DataValue = dataIdn + "|" + srcApp + "|"
							+ transRefNo + "|" + msgType + "|" + relRefNo + "|"
							+ remAccNo + "|" + remName + "|" + remAdd1 + "|"
							+ remAdd2 + "|" + remAdd3 + "|" + remAdd4 + "|"
							+ senAccTyp + "|" + transAmt + "|" + commAmt + "|"
							+ benfName + "|" + benfAcc + "|" + benfAccType
							+ "|" + benfAdd1 + "|" + benfAdd2 + "|" + benfIFSC
							+ "|" + detOfPay + "|" + senderRecCode + "|"
							+ senRecInfo1 + "|" + senRecInfo2 + "|"
							+ senRecInfo3 + "|" + senRecInfo4 + "|"
							+ senRecInfo5 + "|" + senRecInfo6 + "|" + cusMob;

					bufferedWriter.newLine();
					bufferedWriter.write(DataValue);
					
					bufferedWriterbck.newLine();
					bufferedWriterbck.write(DataValue);
				}
		}

			bufferedWriter.close();
			
			bufferedWriterbck.close();
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			logger.info(ActionConstants.EXITING_METHOD);
		}		
		return "SUCCESS";

	}
	
	
	/**
	 * 
	 * @param finkey
	 * @return
	 * @throws DAOException
	 */
	private  String getFinancedReference(String finkey) throws DAOException{
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String finanaceRef = null;
		try{
		if(con==null){		con = DBConnectionUtility.getConnection(); }              
			ps = new LoggableStatement(con,
					"SELECT MASTER_REF FROM MASTER,FNCEMASTER WHERE MASTER.KEY97=FNCEMASTER.KEY97 AND FNCEMASTER.FINCEEVKEY='"
							+ finkey + "' AND MASTER.STATUS='LIV' ");
			rs = ps.executeQuery();
			if (rs.next()) {
				finanaceRef = (rs.getString(1) == null) ? "" : rs.getString(1);
			}
		}catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
	
		logger.info(ActionConstants.EXITING_METHOD);
		return finanaceRef;
	}
	

	private boolean isRTGSTime(){
		
		boolean isRTGS = false;
		
		try {
			
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("h:mm:ss:a");
			String formattedDate = sdf.format(date);
			System.out.println(formattedDate); // 12/01/2011 4:48:16 PM
			
			
		    String string1 = "09:00:00:AM";
		    Date time1 = new SimpleDateFormat("HH:mm:ss:a").parse(string1);
		    Calendar calendar1 = Calendar.getInstance();
		    calendar1.setTime(time1);

		    String string2 = "03:30:00:PM";
		    Date time2 = new SimpleDateFormat("HH:mm:ss:a").parse(string2);
		    Calendar calendar2 = Calendar.getInstance();
		    calendar2.setTime(time2);
		    calendar2.add(Calendar.DATE, 1);

		    String someRandomTime = formattedDate;
		    Date d = new SimpleDateFormat("HH:mm:ss:a").parse(someRandomTime);
		    Calendar calendar3 = Calendar.getInstance();
		    calendar3.setTime(d);
		    calendar3.add(Calendar.DATE, 1);

		    Date x = calendar3.getTime();
		    if (x.after(calendar1.getTime()) && x.before(calendar2.getTime())) {
		        //checkes whether the current time is between 14:49:00 and 20:11:13.
		        System.out.println(true);
		        isRTGS = true;
		    }
		} catch (ParseException e) {
		    e.printStackTrace();
		}
		return isRTGS;
	
	}
	/**
	 * 
	 * @return
	 */
	public FileDataRecordVO getRowData(AccountHolderDetailsVO accountHolderDetailsVO,String amount,String refKey) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		FileDataRecordVO dataRecordVO = null;
		CommonMethods commonMethods = null;
		try {
		if(con==null){		con = DBConnectionUtility.getConnection(); }              
			commonMethods = new CommonMethods();
			if (dataRecordVO == null) {
				dataRecordVO = new FileDataRecordVO();
				dataRecordVO.setDateIden(AUDIT_ACTION_ONE);
				dataRecordVO.setSrcApp(TIPLUS);
				dataRecordVO.setTransRef(getFinancedReference(refKey));
				 
				logger.info("Amount Inside"+amount);
				double tempAmt = commonMethods.toDouble(amount);
				
				/*if(tempAmt >= AMOUNT && isRTGSTime()==true){
					dataRecordVO.setMsgType(MSG_TYPE2);
					dataRecordVO.setRemAccNo("98170102055");
					
				}else{
					dataRecordVO.setRemAccNo("98171102055");
					dataRecordVO.setMsgType(MSG_TYPE1);
				}	*/			
				
				dataRecordVO.setRemAccNo("98171102055");
				dataRecordVO.setMsgType(MSG_TYPE1);
				
				dataRecordVO.setRelRefNo("0");
				//dataRecordVO.setRemAccNo(accountHolderDetailsVO.getRemitterAccountNumber());
				
				dataRecordVO.setRemAccName("MBWW BANK");
				dataRecordVO.setRemAddr1("");
				dataRecordVO.setRemAddr2("");
				dataRecordVO.setRemAddr3("");
				dataRecordVO.setRemAddr4("");
				dataRecordVO.setSenderAccTypr("11");
				dataRecordVO.setTransAmt(amount);
				dataRecordVO.setCommAmt("0");
				dataRecordVO.setBenefName(accountHolderDetailsVO.getBeneficiaryName());
				dataRecordVO.setBenefAcc(accountHolderDetailsVO.getBeneficiaryAccountNumber());
				dataRecordVO.setBenefAccType("11");
				dataRecordVO.setBenefAddr1("");
				dataRecordVO.setBenefAddr2("");
				dataRecordVO.setBenefIFSC(accountHolderDetailsVO.getBeneficiaryIDFCCode());
				dataRecordVO.setDetailOfPay("");
				dataRecordVO.setSenderRecCode("");
				dataRecordVO.setSenderRecInfo1("");
				dataRecordVO.setSenderRecInfo2("");
				dataRecordVO.setSenderRecInfo3("");
				dataRecordVO.setSenderRecInfo4("");
				dataRecordVO.setSenderRecInfo5("");
				dataRecordVO.setSenderRecInfo6("");
				String email = commonMethods.getEmptyIfNull(accountHolderDetailsVO.getEmail()).trim();
				String phNo = commonMethods.getEmptyIfNull(accountHolderDetailsVO.getPhone()).trim();
				String data = "TradeAlerts@idfcbank.com";
				//dataRecordVO.setCusMob_Email( phNo + "/" + email);
				dataRecordVO.setCusMob_Email(data);
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);

		return dataRecordVO;

	}

	/**
	 * 
	 * @param totalAmount
	 * @return
	 * @throws DAOException
	 */
	public FileHeaderVO getHeaderData(BigDecimal totalAmount,int len) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		FileHeaderVO fileVO = null;
		ValidatorDAO dao = null;
		/*SimpleDateFormat sdf =  null;
		SimpleDateFormat sdf1 =  null;*/
		try{		
		if(con==null){		con = DBConnectionUtility.getConnection(); }              
		/*	sdf = new SimpleDateFormat("yyyy-MM-dd");
			sdf1 = new SimpleDateFormat("yyyyMMdd");*/
			
			if (fileVO == null) {
				fileVO = new FileHeaderVO();			
				fileVO.setHeaderIdn(AUDIT_ACTION_ZERO);
				
				SimpleDateFormat df = new SimpleDateFormat("yyyyMMddhhmmss");
			    String createdDate = "";
				 
				 String sq = "SELECT LPAD(OUTWRD_SEQNO.NEXTVAL,6,'0') as ID FROM DUAL";
			     ps = new LoggableStatement(con,sq);
			     rs = ps.executeQuery();
				 String seq = "";
				while (rs.next()) {
					seq = rs.getString("ID");
				}	
				System.out.println("SEQUENCE" + seq);	
	
				String fileName = "OUTWRD_NEFT_FEED_" + createdDate + seq;
				
				fileVO.setFileSeq(createdDate + seq);
				   
				fileVO.setFileName(fileName);				
				
			/*	HttpSession session = ServletActionContext.getRequest()
						.getSession();
				String tempDate = (String) session.getAttribute("PROCDATE");			
				
				
				
				Date convertedCurrentDate = sdf.parse(tempDate);
				String prodate=sdf1.format(convertedCurrentDate ); */
				dao = new ValidatorDAO();
				String prodate = dao.setTIDate();
				
				fileVO.setGenDate(prodate);
				fileVO.setUploadType(UPLDTYPE);
				fileVO.setJournalNo(JNO);
				fileVO.setRemAccNo(REMACCNO);
				//fileVO.setTransCount(AUDIT_ACTION_ONE);
				fileVO.setTransCount(String.valueOf(len));
				fileVO.setTransAmt(String.valueOf(totalAmount));
			}
		}catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return fileVO;

	}
	
	private  String getNEFTAccount() throws DAOException{
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String NEFT = null;
		try{
		if(con==null){		con = DBConnectionUtility.getConnection(); }              
			ps = new LoggableStatement(con,
					"select TRIM(BO_ACCTNO) from ACCOUNT WHERE SHORTNAME LIKE '%NEFT%OUTWARD%'");
			rs = ps.executeQuery();
			if (rs.next()) {
				NEFT = (rs.getString(1) == null) ? "" : rs.getString(1);
			}
		}catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
	
		logger.info(ActionConstants.EXITING_METHOD);
		return NEFT;
	}

}
