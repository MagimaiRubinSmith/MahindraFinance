
package in.co.invoice.vo;




public class BankLimitVO {
	
	
	private String FROM_DATE;	
	private String TO_DATE;
	private String RPT_FILENAME;
	private String STATUS;
	private String FROM_EMAIL;
	private String TO_EMAIL;
	private String CC_EMAIL;
	private String BCC_EMAIL;
	private String SUBJECT_EMAIL;
	private String BODY_EMAIL;
	private String REPORT_NAME_DESC;
	private String PROGRAM_NAME;
	
	
	public String getREPORT_NAME_DESC(){
		return REPORT_NAME_DESC;
	}

	public void setREPORT_NAME_DESC(String rEPORT_NAME_DESC){
		 REPORT_NAME_DESC = rEPORT_NAME_DESC;
	}
	public String getPROGRAM_NAME(){
		return PROGRAM_NAME;
	}

	public void setPROGRAM_NAME(String pROGRAM_NAME){
		 PROGRAM_NAME = pROGRAM_NAME;
	}

	
	
	public String getSUBJECT_EMAIL() {
		return SUBJECT_EMAIL;
	}

	public void setSUBJECT_EMAIL(String sUBJECT_EMAIL) {
		SUBJECT_EMAIL = sUBJECT_EMAIL;
	}

	public String getBODY_EMAIL() {
		return BODY_EMAIL;
	}

	public void setBODY_EMAIL(String bODY_EMAIL) {
		BODY_EMAIL = bODY_EMAIL;
	}

	public String getCC_EMAIL() {
		return CC_EMAIL;
	}

	public void setCC_EMAIL(String cC_EMAIL) {
		CC_EMAIL = cC_EMAIL;
	}

	public String getBCC_EMAIL() {
		return BCC_EMAIL;
	}

	public void setBCC_EMAIL(String bCC_EMAIL) {
		BCC_EMAIL = bCC_EMAIL;
	}
	private String FILE_NAME;
	private String FILE_TYPE;
	private String FILE_PATH;
	
	private String PROGRAM_ID;
	private String CUSTOMER_ID;
	private String BATCH_ID;
	
	public String filetochange;
	
	

	public String getFROM_DATE() {
		return FROM_DATE;
	}
	
	public String getPROGRAM_ID() {
		return PROGRAM_ID;
	}

	public void setPROGRAM_ID(String pROGRAM_ID) {
		PROGRAM_ID = pROGRAM_ID;
	}

	public String getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}

	public void setCUSTOMER_ID(String cUSTOMER_ID) {
		CUSTOMER_ID = cUSTOMER_ID;
	}

	public String getBATCH_ID() {
		return BATCH_ID;
	}

	public void setBATCH_ID(String bATCH_ID) {
		BATCH_ID = bATCH_ID;
	}

	public void setFROM_DATE(String fROM_DATE) {
		FROM_DATE = fROM_DATE;
	}
	public String getTO_DATE() {
		return TO_DATE;
	}
	public void setTO_DATE(String tO_DATE) {
		TO_DATE = tO_DATE;
	}
	public String getRPT_FILENAME() {
		filetochange = RPT_FILENAME;
		
		return RPT_FILENAME;
	}
	public void setRPT_FILENAME(String rPT_FILENAME) {
		RPT_FILENAME = rPT_FILENAME;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
		
	public String getTO_EMAIL() {
		return TO_EMAIL;
	}
	public void setTO_EMAIL(String tO_EMAIL) {
		TO_EMAIL = tO_EMAIL;
	}
	
	public String getFILE_NAME() {
		return FILE_NAME;
	}
	public void setFILE_NAME(String fILE_NAME) {
		FILE_NAME = fILE_NAME;
	}
	public String getFILE_TYPE() {
		return FILE_TYPE;
	}
	public void setFILE_TYPE(String fILE_TYPE) {
		FILE_TYPE = fILE_TYPE;
	}
	
	public String getFILE_PATH() {
		return FILE_PATH;
	}

	public void setFILE_PATH(String fILE_PATH) {
		FILE_PATH = fILE_PATH;
	}

	public String getFROM_EMAIL() {
		return FROM_EMAIL;
	}
	public void setFROM_EMAIL(String fROM_EMAIL) {
		FROM_EMAIL = fROM_EMAIL;
	}
	
}
