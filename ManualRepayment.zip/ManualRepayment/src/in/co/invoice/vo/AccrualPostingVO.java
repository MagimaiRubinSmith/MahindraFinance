package in.co.invoice.vo;

public class AccrualPostingVO {
		 
	
	String id;
	
	String TransactionId;
	 
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	String TransactionSeqNo;
	
	String masterKey;
	 
	String postingBranch;

	String inputBranch;
	
	String productReference;
	
	String masterReference;
	  
	String postingSeqNo;
	 
	String accountNumber;
	
	String backOfficeAccountNo;
	
	String externalAccountNo;
	
	String accountType;
	
	String sPSKMnemonic;
	
	String sPSKCategoryCode;
	
	String debitCreditFlag;
	
	String transactionCode;

	String postingAmount;
	  
	String postingCcy;

	String valueDate;
	 
	String relatedParty;
	
	String settlementAccountUsed;
	 
	String sWIFTmessageType;

	String serviceLevel;
 
	String sWIFTChargesFor;
	
	String addMntDelFlag;

	public String getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}

	public String getTransactionSeqNo() {
		return TransactionSeqNo;
	}

	public void setTransactionSeqNo(String transactionSeqNo) {
		TransactionSeqNo = transactionSeqNo;
	}

	public String getMasterKey() {
		return masterKey;
	}

	public void setMasterKey(String masterKey) {
		this.masterKey = masterKey;
	}

	public String getPostingBranch() {
		return postingBranch;
	}

	public void setPostingBranch(String postingBranch) {
		this.postingBranch = postingBranch;
	}

	public String getInputBranch() {
		return inputBranch;
	}

	public void setInputBranch(String inputBranch) {
		this.inputBranch = inputBranch;
	}

	public String getProductReference() {
		return productReference;
	}

	public void setProductReference(String productReference) {
		this.productReference = productReference;
	}

	public String getMasterReference() {
		return masterReference;
	}

	public void setMasterReference(String masterReference) {
		this.masterReference = masterReference;
	}

	public String getPostingSeqNo() {
		return postingSeqNo;
	}

	public void setPostingSeqNo(String postingSeqNo) {
		this.postingSeqNo = postingSeqNo;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBackOfficeAccountNo() {
		return backOfficeAccountNo;
	}

	public void setBackOfficeAccountNo(String backOfficeAccountNo) {
		this.backOfficeAccountNo = backOfficeAccountNo;
	}

	public String getExternalAccountNo() {
		return externalAccountNo;
	}

	public void setExternalAccountNo(String externalAccountNo) {
		this.externalAccountNo = externalAccountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getsPSKMnemonic() {
		return sPSKMnemonic;
	}

	public void setsPSKMnemonic(String sPSKMnemonic) {
		this.sPSKMnemonic = sPSKMnemonic;
	}

	public String getsPSKCategoryCode() {
		return sPSKCategoryCode;
	}

	public void setsPSKCategoryCode(String sPSKCategoryCode) {
		this.sPSKCategoryCode = sPSKCategoryCode;
	}

	public String getDebitCreditFlag() {
		return debitCreditFlag;
	}

	public void setDebitCreditFlag(String debitCreditFlag) {
		this.debitCreditFlag = debitCreditFlag;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getPostingAmount() {
		return postingAmount;
	}

	public void setPostingAmount(String postingAmount) {
		this.postingAmount = postingAmount;
	}

	public String getPostingCcy() {
		return postingCcy;
	}

	public void setPostingCcy(String postingCcy) {
		this.postingCcy = postingCcy;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getRelatedParty() {
		return relatedParty;
	}

	public void setRelatedParty(String relatedParty) {
		this.relatedParty = relatedParty;
	}

	public String getSettlementAccountUsed() {
		return settlementAccountUsed;
	}

	public void setSettlementAccountUsed(String settlementAccountUsed) {
		this.settlementAccountUsed = settlementAccountUsed;
	}

	public String getsWIFTmessageType() {
		return sWIFTmessageType;
	}

	public void setsWIFTmessageType(String sWIFTmessageType) {
		this.sWIFTmessageType = sWIFTmessageType;
	}

	public String getServiceLevel() {
		return serviceLevel;
	}

	public void setServiceLevel(String serviceLevel) {
		this.serviceLevel = serviceLevel;
	}

	public String getsWIFTChargesFor() {
		return sWIFTChargesFor;
	}

	public void setsWIFTChargesFor(String sWIFTChargesFor) {
		this.sWIFTChargesFor = sWIFTChargesFor;
	}

	public String getAddMntDelFlag() {
		return addMntDelFlag;
	}

	public void setAddMntDelFlag(String addMntDelFlag) {
		this.addMntDelFlag = addMntDelFlag;
	}

}
