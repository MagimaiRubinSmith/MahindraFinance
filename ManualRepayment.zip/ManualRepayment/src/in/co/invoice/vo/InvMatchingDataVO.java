package in.co.invoice.vo;

import java.util.ArrayList;

public class InvMatchingDataVO {
	
		private String custName;
		private String payCurr;
		private String payAmount;
		private String custCIF;
		private String prgName;
		private String masRef;
		private String invNumber;
		private String loanStartDate;
		private String loanCurr;
		private String loanVal;
		private String outAmount;
		private String repayAmount;
		private String balAmount;
		
		
		private String progId;
		private String debitParty;
		private String valueDate;
		private String masterRef;
		private String disburseDate;
		private String dueDate;
		private String loanAmount;
		private String status;
		private String dueDateFilter;
		
		
		
		public String getDueDateFilter() {
			return dueDateFilter;
		}
		public void setDueDateFilter(String dueDateFilter) {
			this.dueDateFilter = dueDateFilter;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		ArrayList<InvMatchingVO> debitList = null;
		ArrayList<InvMatchingVO> counterList = null;
		ArrayList<InvMatchingDataVO> invList1 = null;
		
		
		public ArrayList<InvMatchingDataVO> getInvList1() {
			return invList1;
		}
		public void setInvList1(ArrayList<InvMatchingDataVO> invList1) {
			this.invList1 = invList1;
		}
		public ArrayList<InvMatchingVO> getDebitList() {
			return debitList;
		}
		public void setDebitList(ArrayList<InvMatchingVO> debitList) {
			this.debitList = debitList;
		}
		public ArrayList<InvMatchingVO> getCounterList() {
			return counterList;
		}
		public void setCounterList(ArrayList<InvMatchingVO> counterList) {
			this.counterList = counterList;
		}
		public String getProgId() {
			return progId;
		}
		public String getDebitParty() {
			return debitParty;
		}
		public String getValueDate() {
			return valueDate;
		}
		public String getMasterRef() {
			return masterRef;
		}
		public String getDisburseDate() {
			return disburseDate;
		}
		public String getDueDate() {
			return dueDate;
		}
		public String getLoanAmount() {
			return loanAmount;
		}
		public void setProgId(String progId) {
			this.progId = progId;
		}
		public void setDebitParty(String debitParty) {
			this.debitParty = debitParty;
		}
		public void setValueDate(String valueDate) {
			this.valueDate = valueDate;
		}
		public void setMasterRef(String masterRef) {
			this.masterRef = masterRef;
		}
		public void setDisburseDate(String disburseDate) {
			this.disburseDate = disburseDate;
		}
		public void setDueDate(String dueDate) {
			this.dueDate = dueDate;
		}
		public void setLoanAmount(String loanAmount) {
			this.loanAmount = loanAmount;
		}
		public String getCustName() {
			return custName;
		}
		public void setCustName(String custName) {
			this.custName = custName;
		}
		public String getPayCurr() {
			return payCurr;
		}
		public void setPayCurr(String payCurr) {
			this.payCurr = payCurr;
		}
		public String getPayAmount() {
			return payAmount;
		}
		public void setPayAmount(String payAmount) {
			this.payAmount = payAmount;
		}
		
		public String getCustCIF() {
			return custCIF;
		}
		public void setCustCIF(String custCIF) {
			this.custCIF = custCIF;
		}
		public String getPrgName() {
			return prgName;
		}
		public void setPrgName(String prgName) {
			this.prgName = prgName;
		}
		public String getMasRef() {
			return masRef;
		}
		public void setMasRef(String masRef) {
			this.masRef = masRef;
		}
		public String getInvNumber() {
			return invNumber;
		}
		public void setInvNumber(String invNumber) {
			this.invNumber = invNumber;
		}
		public String getLoanStartDate() {
			return loanStartDate;
		}
		public void setLoanStartDate(String loanStartDate) {
			this.loanStartDate = loanStartDate;
		}
		public String getLoanCurr() {
			return loanCurr;
		}
		public void setLoanCurr(String loanCurr) {
			this.loanCurr = loanCurr;
		}
		public String getLoanVal() {
			return loanVal;
		}
		public void setLoanVal(String loanVal) {
			this.loanVal = loanVal;
		}
		public String getOutAmount() {
			return outAmount;
		}
		public void setOutAmount(String outAmount) {
			this.outAmount = outAmount;
		}
		public String getRepayAmount() {
			return repayAmount;
		}
		public void setRepayAmount(String repayAmount) {
			this.repayAmount = repayAmount;
		}
		public String getBalAmount() {
			return balAmount;
		}
		public void setBalAmount(String balAmount) {
			this.balAmount = balAmount;
		}

	}

