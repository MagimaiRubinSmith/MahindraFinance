package in.co.invoice.vo;

public class InvBatchVO {
	String virtualAccNo;
	String batchIDSeq;
	String makerID;
	String status;

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVirtualAccNo() {
		return virtualAccNo;
	}
	public void setVirtualAccNo(String virtualAccNo) {
		this.virtualAccNo = virtualAccNo;
	}
	public String getBatchIDSeq() {
		return batchIDSeq;
	}
	public void setBatchIDSeq(String batchIDSeq) {
		this.batchIDSeq = batchIDSeq;
	}
	public String getMakerID() {
		return makerID;
	}
	public void setMakerID(String makerID) {
		this.makerID = makerID;
	}
}
