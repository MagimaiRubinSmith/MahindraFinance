package in.co.invoice.vo;



public class CAPEODVO {
	
	private int TransactionSeqNo;
	private long MasterKey;
	private long EventKey;
	private String PostingBranch;
	private String InputBranch;
	private String ProductReference;
	private String MasterReference;
	private String EventReference;
	private String InternalRecnRef;
	private int PostingSeqNo;
	private String AccountNumber;
	private String BackOfficeAccountNo;
	private String ExternalAccountNo;
	private String CustomerMnemonic;
	private String AccountType;
	private String SPSKMnemonic;
	private String SPSKCategoryCode;
	private String Application;
	private String DebitCreditFlag;
	private String TransactionCode;
	private long PostingAmount;
	private String PostingCcy;
	private String RelatedParty;
	private String BeneficiaryName;
	private String BankCode1;
	private String SettlementAccountUsed;
	private String TransactionId;
	
	private String valueDate;
	
	
	public String getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}
	public int getTransactionSeqNo() {
		return TransactionSeqNo;
	}
	public void setTransactionSeqNo(int transactionSeqNo) {
		TransactionSeqNo = transactionSeqNo;
	}
	public long getMasterKey() {
		return MasterKey;
	}
	public void setMasterKey(long masterKey) {
		MasterKey = masterKey;
	}
	public long getEventKey() {
		return EventKey;
	}
	public void setEventKey(long eventKey) {
		EventKey = eventKey;
	}
	public String getPostingBranch() {
		return PostingBranch;
	}
	public void setPostingBranch(String postingBranch) {
		PostingBranch = postingBranch;
	}
	public String getInputBranch() {
		return InputBranch;
	}
	public void setInputBranch(String inputBranch) {
		InputBranch = inputBranch;
	}
	public String getProductReference() {
		return ProductReference;
	}
	public void setProductReference(String productReference) {
		ProductReference = productReference;
	}
	public String getMasterReference() {
		return MasterReference;
	}
	public void setMasterReference(String masterReference) {
		MasterReference = masterReference;
	}
	public String getEventReference() {
		return EventReference;
	}
	public void setEventReference(String eventReference) {
		EventReference = eventReference;
	}
	public String getInternalRecnRef() {
		return InternalRecnRef;
	}
	public void setInternalRecnRef(String internalRecnRef) {
		InternalRecnRef = internalRecnRef;
	}
	public int getPostingSeqNo() {
		return PostingSeqNo;
	}
	public void setPostingSeqNo(int postingSeqNo) {
		PostingSeqNo = postingSeqNo;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public String getBackOfficeAccountNo() {
		return BackOfficeAccountNo;
	}
	public void setBackOfficeAccountNo(String backOfficeAccountNo) {
		BackOfficeAccountNo = backOfficeAccountNo;
	}
	public String getExternalAccountNo() {
		return ExternalAccountNo;
	}
	public void setExternalAccountNo(String externalAccountNo) {
		ExternalAccountNo = externalAccountNo;
	}
	public String getCustomerMnemonic() {
		return CustomerMnemonic;
	}
	public void setCustomerMnemonic(String customerMnemonic) {
		CustomerMnemonic = customerMnemonic;
	}
	public String getAccountType() {
		return AccountType;
	}
	public void setAccountType(String accountType) {
		AccountType = accountType;
	}
	public String getSPSKMnemonic() {
		return SPSKMnemonic;
	}
	public void setSPSKMnemonic(String sPSKMnemonic) {
		SPSKMnemonic = sPSKMnemonic;
	}
	public String getSPSKCategoryCode() {
		return SPSKCategoryCode;
	}
	public void setSPSKCategoryCode(String sPSKCategoryCode) {
		SPSKCategoryCode = sPSKCategoryCode;
	}
	public String getApplication() {
		return Application;
	}
	public void setApplication(String application) {
		Application = application;
	}
	public String getDebitCreditFlag() {
		return DebitCreditFlag;
	}
	public void setDebitCreditFlag(String debitCreditFlag) {
		DebitCreditFlag = debitCreditFlag;
	}
	public String getTransactionCode() {
		return TransactionCode;
	}
	public void setTransactionCode(String transactionCode) {
		TransactionCode = transactionCode;
	}
	public long getPostingAmount() {
		return PostingAmount;
	}
	public void setPostingAmount(long postingAmount) {
		PostingAmount = postingAmount;
	}
	public String getPostingCcy() {
		return PostingCcy;
	}
	public void setPostingCcy(String postingCcy) {
		PostingCcy = postingCcy;
	}
	public String getRelatedParty() {
		return RelatedParty;
	}
	public void setRelatedParty(String relatedParty) {
		RelatedParty = relatedParty;
	}
	public String getBeneficiaryName() {
		return BeneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		BeneficiaryName = beneficiaryName;
	}
	public String getBankCode1() {
		return BankCode1;
	}
	public void setBankCode1(String bankCode1) {
		BankCode1 = bankCode1;
	}
	public String getSettlementAccountUsed() {
		return SettlementAccountUsed;
	}
	public void setSettlementAccountUsed(String settlementAccountUsed) {
		SettlementAccountUsed = settlementAccountUsed;
	}
	public String getValueDate() {
		return valueDate;
	}
	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}
	
	
	
	
}
