package in.co.invoice.vo;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

public class InvMatchingVO {

	private String progId;
	private String debitParty;
	public String counterParty;
	private String valueDate;
	private String TotalRowCount;
	private String TotalAmount;
	public String getTotalRowCount() {
		return TotalRowCount;
	}

	public String setTotalRowCount(String totalRowCount) {
		return TotalRowCount = totalRowCount;
	}

	public String getTotalAmount() {
		return TotalAmount;
	}

	public String setTotalAmount(String totalAmount) {
		return TotalAmount = totalAmount;
	}

	private String payAmount;
	private String masterRef;
	private String invNumber;
	private String disburseDate;
	private String dueDate;
	private String loanAmount;
	private String outAmount;
	private String repayAmount;
	private String anchorName;
	private String gwStatus;
	private String allocAmt;
	private String allocationType;
	private String batchID;
	private String customer;
	private String tempPrgType;
	private String tempPrgSubType;
	private String xml;
	private String error;
	private String repaymentMode;
	private String payAccount;
	private String referenceNumber;
	String repayBy;
	private String virtualAccount;
	private String repaymentTC;
	private String branchCode;
	private String sellerMnemonic;
	private String bankList;
	private String repayType;
	private String refDate;

	private String invoiceNumber;
	private String period;
	private String payDate;
	private String endDate;
	private String opening;
	private String payment;
	private String interest;
	private String principal;
	private String closing;
	private String startDate;
	private String end_date;
	private String dpd;
	private String invRefNo;
	private String sCounterParty;
	private String tempCounterParty;
	private String loanMasterRef;
	private String addInterest;
	private String addPenal;
	private String dueDateFilter;
	private String counterPartyName;

	// 04Feb
	private String batchIDSeq;
	private String statusFilter;

	// 11Feb
	private File inputFile;
	private String fileName;
	private String amount;
	private String chargeCode;
	private String chargeType;
	private int uploadSeq;
	private ArrayList<InvBatchVO> batchList;

	// 12Feb
	private String makerID;
	private String status;

	// 14Feb
	private String uploadStatus;
	private String errorDetails;

	private String xmlRequest;
	private String xmlResponse;
	private String xmlSequence;
	private String masterReference;

	
	public String getMasterReference() {
		return masterReference;
	}

	public void setMasterReference(String masterReference) {
		this.masterReference = masterReference;
	}

	public String getXmlRequest() {
		return xmlRequest;
	}

	public void setXmlRequest(String xmlRequest) {
		this.xmlRequest = xmlRequest;
	}

	public String getXmlResponse() {
		return xmlResponse;
	}

	public void setXmlResponse(String xmlResponse) {
		this.xmlResponse = xmlResponse;
	}

	public String getXmlSequence() {
		return xmlSequence;
	}

	public void setXmlSequence(String xmlSequence) {
		this.xmlSequence = xmlSequence;
	}

	public String getUploadStatus() {
		return uploadStatus;
	}

	public void setUploadStatus(String uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	public int getUploadSeq() {
		return uploadSeq;
	}

	public void setUploadSeq(int uploadSeq) {
		this.uploadSeq = uploadSeq;
	}

	public ArrayList<InvBatchVO> getBatchList() {
		return batchList;
	}

	public void setBatchList(ArrayList<InvBatchVO> batchList) {
		this.batchList = batchList;
	}

	public String getMakerID() {
		return makerID;
	}

	public void setMakerID(String makerID) {
		this.makerID = makerID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getChargeCode() {
		return chargeCode;
	}

	public void setChargeCode(String chargeCode) {
		this.chargeCode = chargeCode;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public File getInputFile() {
		return inputFile;
	}

	public void setInputFile(File inputFile) {
		this.inputFile = inputFile;
	}

	public String getStatusFilter() {
		return statusFilter;
	}

	public void setStatusFilter(String statusFilter) {
		this.statusFilter = statusFilter;
	}

	public String getBatchIDSeq() {
		return batchIDSeq;
	}

	public void setBatchIDSeq(String batchIDSeq) {
		this.batchIDSeq = batchIDSeq;
	}

	public String getCounterPartyName() {
		return counterPartyName;
	}

	public void setCounterPartyName(String counterPartyName) {
		this.counterPartyName = counterPartyName;
	}

	public String getDueDateFilter() {
		return dueDateFilter;
	}

	public void setDueDateFilter(String dueDateFilter) {
		this.dueDateFilter = dueDateFilter;
	}

	public String getAddInterest() {
		return addInterest;
	}

	public void setAddInterest(String addInterest) {
		this.addInterest = addInterest;
	}

	public String getAddPenal() {
		return addPenal;
	}

	public void setAddPenal(String addPenal) {
		this.addPenal = addPenal;
	}

	public String getLoanMasterRef() {
		return loanMasterRef;
	}

	public void setLoanMasterRef(String loanMasterRef) {
		this.loanMasterRef = loanMasterRef;
	}

	public String getTempCounterParty() {
		return tempCounterParty;
	}

	public void setTempCounterParty(String tempCounterParty) {
		this.tempCounterParty = tempCounterParty;
	}

	public String getsCounterParty() {
		return sCounterParty;
	}

	public void setsCounterParty(String sCounterParty) {
		this.sCounterParty = sCounterParty;
	}

	public String getInvRefNo() {
		return invRefNo;
	}

	public void setInvRefNo(String invRefNo) {
		this.invRefNo = invRefNo;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public String getDpd() {
		return dpd;
	}

	public void setDpd(String dpd) {
		this.dpd = dpd;
	}

	public String getRefDate() {
		return refDate;
	}

	public void setRefDate(String refDate) {
		this.refDate = refDate;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getPayDate() {
		return payDate;
	}

	public void setPayDate(String payDate) {
		this.payDate = payDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getOpening() {
		return opening;
	}

	public void setOpening(String opening) {
		this.opening = opening;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public String getInterest() {
		return interest;
	}

	public void setInterest(String interest) {
		this.interest = interest;
	}

	public String getPrincipal() {
		return principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

	public String getClosing() {
		return closing;
	}

	public void setClosing(String closing) {
		this.closing = closing;
	}

	public String getRepayType() {
		return repayType;
	}

	public void setRepayType(String repayType) {
		this.repayType = repayType;
	}

	public String getBankList() {
		return bankList;
	}

	public void setBankList(String bankList) {
		this.bankList = bankList;
	}

	public String getSellerMnemonic() {
		return sellerMnemonic;
	}

	public void setSellerMnemonic(String sellerMnemonic) {
		this.sellerMnemonic = sellerMnemonic;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchDesc() {
		return branchDesc;
	}

	public void setBranchDesc(String branchDesc) {
		this.branchDesc = branchDesc;
	}

	public String getTransCode() {
		return transCode;
	}

	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}

	private String branchDesc;
	private String transCode;

	public String getVirtualAccount() {
		return virtualAccount;
	}

	public void setVirtualAccount(String virtualAccount) {
		this.virtualAccount = virtualAccount;
	}

	private String appuserid;
	private String appremark;

	public String getAppremark() {
		return appremark;
	}

	public String getRepaymentTC() {
		return repaymentTC;
	}

	public void setRepaymentTC(String repaymentTC) {
		this.repaymentTC = repaymentTC;
	}

	public void setAppremark(String appremark) {
		this.appremark = appremark;
	}

	public String getAppuserid() {
		return appuserid;
	}

	public void setAppuserid(String appuserid) {
		this.appuserid = appuserid;
	}

	public String getRepayBy() {
		return repayBy;
	}

	public void setRepayBy(String repayBy) {
		this.repayBy = repayBy;
	}

	/* Manual */
	private String projectType;
	/* Manual */
	private String accountKey;
	private String branchNumber;
	private String customerMnemonic;
	private String accountType;
	private String catagory;
	private String shortName;

	private String principleOutstanding;

	private String interestOutstanding;

	private String chargesOutstanding;

	private String principleTotal;
	private String interestTotal;
	private String chargesTotal;
	private String penalTotal;
	private String totalOutstanding;
	private String tdsAmount;
	private String tdsTotal;
	private String totalAllocAmount;

	public String getTotalAllocAmount() {
		return totalAllocAmount;
	}

	public void setTotalAllocAmount(String totalAllocAmount) {
		this.totalAllocAmount = totalAllocAmount;
	}

	public String getTdsTotal() {
		return tdsTotal;
	}

	public void setTdsTotal(String tdsTotal) {
		this.tdsTotal = tdsTotal;
	}

	public String getTdsAmount() {
		return tdsAmount;
	}

	public void setTdsAmount(String tdsAmount) {
		this.tdsAmount = tdsAmount;
	}

	public String getPrincipleTotal() {
		return principleTotal;
	}

	public void setPrincipleTotal(String principleTotal) {
		this.principleTotal = principleTotal;
	}

	public String getInterestTotal() {
		return interestTotal;
	}

	public void setInterestTotal(String interestTotal) {
		this.interestTotal = interestTotal;
	}

	public String getChargesTotal() {
		return chargesTotal;
	}

	public void setChargesTotal(String chargesTotal) {
		this.chargesTotal = chargesTotal;
	}

	public String getPenalTotal() {
		return penalTotal;
	}

	public void setPenalTotal(String penalTotal) {
		this.penalTotal = penalTotal;
	}

	public String getTotalOutstanding() {
		return totalOutstanding;
	}

	public void setTotalOutstanding(String totalOutstanding) {
		this.totalOutstanding = totalOutstanding;
	}

	String warningMessage;

	/* MAker checker */

	public String getWarningMessage() {
		return warningMessage;
	}

	public String getChargesOutstanding() {
		return chargesOutstanding;
	}

	public void setChargesOutstanding(String chargesOutstanding) {
		this.chargesOutstanding = chargesOutstanding;
	}

	public void setWarningMessage(String warningMessage) {
		this.warningMessage = warningMessage;
	}

	private String filterBatch;
	private String tempbatchID;
	private String tempProgram;
	private String tempRemarks;
	private String tempValueDate;
	private String debitPartyFullName;
	private String penalInterest;
	private String intiateType;
	private String transBatch;
	private String statusFlag;

	public String getStatusFlag() {
		return statusFlag;
	}

	public void setStatusFlag(String statusFlag) {
		this.statusFlag = statusFlag;
	}

	public String getIntiateType() {
		return intiateType;
	}

	public void setIntiateType(String intiateType) {
		this.intiateType = intiateType;
	}

	public String getTransBatch() {
		return transBatch;
	}

	public void setTransBatch(String transBatch) {
		this.transBatch = transBatch;
	}

	public String getPenalInterest() {
		return penalInterest;
	}

	public void setPenalInterest(String penalInterest) {
		this.penalInterest = penalInterest;
	}

	public String getDebitPartyFullName() {
		return debitPartyFullName;
	}

	public void setDebitPartyFullName(String debitPartyFullName) {
		this.debitPartyFullName = debitPartyFullName;
	}

	public String getTempValueDate() {
		return tempValueDate;
	}

	public void setTempValueDate(String tempValueDate) {
		this.tempValueDate = tempValueDate;
	}

	public String getTempbatchID() {
		return tempbatchID;
	}

	public void setTempbatchID(String tempbatchID) {
		this.tempbatchID = tempbatchID;
	}

	public String getTempProgram() {
		return tempProgram;
	}

	public void setTempProgram(String tempProgram) {
		this.tempProgram = tempProgram;
	}

	public String getTempRemarks() {
		return tempRemarks;
	}

	public void setTempRemarks(String tempRemarks) {
		this.tempRemarks = tempRemarks;
	}

	public String getFilterBatch() {
		return filterBatch;
	}

	public void setFilterBatch(String filterBatch) {
		this.filterBatch = filterBatch;
	}

	/**
	 * 
	 * @return
	 */
	public String getAccountKey() {
		return accountKey;
	}

	/**
	 * 
	 * @param accountKey
	 */
	public void setAccountKey(String accountKey) {
		this.accountKey = accountKey;
	}

	/**
	 * 
	 * @return
	 */
	public String getBranchNumber() {
		return branchNumber;
	}

	/**
	 * 
	 * @param branchNumber
	 */
	public void setBranchNumber(String branchNumber) {
		this.branchNumber = branchNumber;
	}

	/**
	 * 
	 * @return
	 */
	public String getCustomerMnemonic() {
		return customerMnemonic;
	}

	/**
	 * 
	 * @param customerMnemonic
	 */
	public void setCustomerMnemonic(String customerMnemonic) {
		this.customerMnemonic = customerMnemonic;
	}

	/**
	 * 
	 * @return
	 */
	public String getAccountType() {
		return accountType;
	}

	/**
	 * 
	 * @param accountType
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/**
	 * 
	 * @return
	 */
	public String getCatagory() {
		return catagory;
	}

	/**
	 * 
	 * @param catagory
	 */
	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}

	/**
	 * 
	 * @return
	 */
	public String getShortName() {
		return shortName;
	}

	/**
	 * 
	 * @param shortName
	 */
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepaymentMode() {
		return repaymentMode;
	}

	/**
	 * 
	 * @param repaymentMode
	 */
	public void setRepaymentMode(String repaymentMode) {
		this.repaymentMode = repaymentMode;
	}

	/**
	 * 
	 * @return
	 */
	public String getPayAccount() {
		return payAccount;
	}

	/**
	 * 
	 * @param payAccount
	 */
	public void setPayAccount(String payAccount) {
		this.payAccount = payAccount;
	}

	/**
	 * 
	 * @return
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}

	/**
	 * 
	 * @param referenceNumber
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/**
	 * 
	 * @return
	 */
	public String getProjectType() {
		return projectType;
	}

	/**
	 * 
	 * @param projectType
	 */
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public String getXml() {
		return xml;
	}

	public void setXml(String xml) {
		this.xml = xml;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	private String repaymentAllocationType;

	public String getRepaymentAllocationType() {
		return repaymentAllocationType;
	}

	public void setRepaymentAllocationType(String repaymentAllocationType) {
		this.repaymentAllocationType = repaymentAllocationType;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getTempPrgType() {
		return tempPrgType;
	}

	public void setTempPrgType(String tempPrgType) {
		this.tempPrgType = tempPrgType;
	}

	public String getTempPrgSubType() {
		return tempPrgSubType;
	}

	public void setTempPrgSubType(String tempPrgSubType) {
		this.tempPrgSubType = tempPrgSubType;
	}

	/** Programme **/
	private String prgIdentifier;
	private String prgName;
	private String prgCust;
	private String prgType;
	private String prgSubtype;
	private String exposureOn;
	private String disburse;
	private String exposure;
	private String scfProductType;
	private String programmename;
	private String programmeidentifier;
	private String programmetype;
	private String subtype;
	private String flagremoval;
	private String typelist;
	private String exposureon;
	private String anchorFullName;
	private String desc;

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getAnchorFullName() {
		return anchorFullName;
	}

	public void setAnchorFullName(String anchorFullName) {
		this.anchorFullName = anchorFullName;
	}

	private String batch_ID;

	public String getBatch_ID() {
		return batch_ID;
	}

	public void setBatch_ID(String batch_ID) {
		this.batch_ID = batch_ID;
	}

	public String getProgrammename() {
		return programmename;
	}

	public void setProgrammename(String programmename) {
		this.programmename = programmename;
	}

	public String getProgrammeidentifier() {
		return programmeidentifier;
	}

	public void setProgrammeidentifier(String programmeidentifier) {
		this.programmeidentifier = programmeidentifier;
	}

	public String getProgrammetype() {
		return programmetype;
	}

	public void setProgrammetype(String programmetype) {
		this.programmetype = programmetype;
	}

	public String getSubtype() {
		return subtype;
	}

	public void setSubtype(String subtype) {
		this.subtype = subtype;
	}

	public String getFlagremoval() {
		return flagremoval;
	}

	public void setFlagremoval(String flagremoval) {
		this.flagremoval = flagremoval;
	}

	public String getTypelist() {
		return typelist;
	}

	public void setTypelist(String typelist) {
		this.typelist = typelist;
	}

	public String getExposureon() {
		return exposureon;
	}

	public void setExposureon(String exposureon) {
		this.exposureon = exposureon;
	}

	public String getPrgIdentifier() {
		return prgIdentifier;
	}

	public void setPrgIdentifier(String prgIdentifier) {
		this.prgIdentifier = prgIdentifier;
	}

	public String getPrgName() {
		return prgName;
	}

	public void setPrgName(String prgName) {
		this.prgName = prgName;
	}

	public String getPrgCust() {
		return prgCust;
	}

	public void setPrgCust(String prgCust) {
		this.prgCust = prgCust;
	}

	public String getPrgType() {
		return prgType;
	}

	public void setPrgType(String prgType) {
		this.prgType = prgType;
	}

	public String getPrgSubtype() {
		return prgSubtype;
	}

	public void setPrgSubtype(String prgSubtype) {
		this.prgSubtype = prgSubtype;
	}

	public String getExposureOn() {
		return exposureOn;
	}

	public void setExposureOn(String exposureOn) {
		this.exposureOn = exposureOn;
	}

	public String getDisburse() {
		return disburse;
	}

	public void setDisburse(String disburse) {
		this.disburse = disburse;
	}

	public String getExposure() {
		return exposure;
	}

	public void setExposure(String exposure) {
		this.exposure = exposure;
	}

	public String getScfProductType() {
		return scfProductType;
	}

	public void setScfProductType(String scfProductType) {
		this.scfProductType = scfProductType;
	}

	public String getBatchID() {
		return batchID;
	}

	public void setBatchID(String batchID) {
		this.batchID = batchID;
	}

	ArrayList<InvMatchingVO> invoicList;
	ArrayList<InvMatchingVO> tiList;
	ArrayList<InvMatchingVO> accountList;

	public ArrayList<InvMatchingVO> getAccountList() {
		return accountList;
	}

	public void setAccountList(ArrayList<InvMatchingVO> accountList) {
		this.accountList = accountList;
	}

	public String getAllocAmt() {
		return allocAmt;
	}

	public void setAllocAmt(String allocAmt) {
		this.allocAmt = allocAmt;
	}

	public String getGwStatus() {
		return gwStatus;
	}

	public void setGwStatus(String gwStatus) {
		this.gwStatus = gwStatus;
	}

	public ArrayList<InvMatchingVO> getTiList() {
		return tiList;
	}

	public void setTiList(ArrayList<InvMatchingVO> tiList) {
		this.tiList = tiList;
	}

	public ArrayList<InvMatchingVO> getInvoicList() {
		return invoicList;
	}

	public void setInvoicList(ArrayList<InvMatchingVO> invoicList) {
		this.invoicList = invoicList;
	}

	public String getAllocationType() {
		return allocationType;
	}

	public void setAllocationType(String allocationType) {
		this.allocationType = allocationType;
	}

	public String getAnchorName() {
		return anchorName;
	}

	public void setAnchorName(String anchorName) {
		this.anchorName = anchorName;
	}

	private Date valDate;

	private String key;
	private String value;

	private String key1;
	private String value1;

	ArrayList<InvMatchingVO> debitList = null;
	ArrayList<InvMatchingVO> pgmList = null;
	ArrayList<InvMatchingDataVO> invList = null;

	ArrayList<InvMatchingVO> counterList = null;

	ArrayList<AlertMessagesVO> errorList = null;
	ArrayList<AlertMessagesVO> warningList = null;

	public ArrayList<AlertMessagesVO> getWarningList() {
		return warningList;
	}

	public void setWarningList(ArrayList<AlertMessagesVO> warningList) {
		this.warningList = warningList;
	}

	public ArrayList<AlertMessagesVO> getErrorList() {
		return errorList;
	}

	public void setErrorList(ArrayList<AlertMessagesVO> errorList) {
		this.errorList = errorList;
	}

	public Date getValDate() {
		return valDate;
	}

	public void setValDate(Date valDate) {
		this.valDate = valDate;
	}

	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

	public String getKey1() {
		return key1;
	}

	public void setKey1(String key1) {
		this.key1 = key1;
	}

	public String getValue1() {
		return value1;
	}

	public void setValue1(String value1) {
		this.value1 = value1;
	}

	public ArrayList<InvMatchingVO> getPgmList() {
		return pgmList;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void setPgmList(ArrayList<InvMatchingVO> pgmList) {
		this.pgmList = pgmList;
	}

	public ArrayList<InvMatchingVO> getDebitList() {
		return debitList;
	}

	public ArrayList<InvMatchingDataVO> getInvList() {
		return invList;
	}

	public void setDebitList(ArrayList<InvMatchingVO> debitList) {
		this.debitList = debitList;
	}

	public void setInvList(ArrayList<InvMatchingDataVO> invList) {
		this.invList = invList;
	}

	public ArrayList<InvMatchingVO> getCounterList() {
		return counterList;
	}

	public void setCounterList(ArrayList<InvMatchingVO> counterList) {
		this.counterList = counterList;
	}

	public String getProgId() {
		return progId;
	}

	public void setProgId(String progId) {
		this.progId = progId;
	}

	public String getDebitParty() {
		return debitParty;
	}

	public void setDebitParty(String debitParty) {
		this.debitParty = debitParty;
	}

	public String getCounterParty() {
		return counterParty;
	}

	public void setCounterParty(String counterParty) {
		this.counterParty = counterParty;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(String payAmount) {
		this.payAmount = payAmount;
	}

	public String getMasterRef() {
		return masterRef;
	}

	public void setMasterRef(String masterRef) {
		this.masterRef = masterRef;
	}

	public String getInvNumber() {
		return invNumber;
	}

	public void setInvNumber(String invNumber) {
		this.invNumber = invNumber;
	}

	public String getDisburseDate() {
		return disburseDate;
	}

	public void setDisburseDate(String disburseDate) {
		this.disburseDate = disburseDate;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(String loanAmount) {
		this.loanAmount = loanAmount;
	}

	public String getOutAmount() {
		return outAmount;
	}

	public void setOutAmount(String outAmount) {
		this.outAmount = outAmount;
	}

	public String getRepayAmount() {
		return repayAmount;
	}

	public void setRepayAmount(String repayAmount) {
		this.repayAmount = repayAmount;
	}

	/**
	 * @return the principleOutstanding
	 */
	public String getPrincipleOutstanding() {
		return principleOutstanding;
	}

	/**
	 * @param principleOutstanding
	 *            the principleOutstanding to set
	 */
	public void setPrincipleOutstanding(String principleOutstanding) {
		this.principleOutstanding = principleOutstanding;
	}

	/**
	 * @return the interestOutstanding
	 */
	public String getInterestOutstanding() {
		return interestOutstanding;
	}

	/**
	 * @param interestOutstanding
	 *            the interestOutstanding to set
	 */
	public void setInterestOutstanding(String interestOutstanding) {
		this.interestOutstanding = interestOutstanding;
	}

}
