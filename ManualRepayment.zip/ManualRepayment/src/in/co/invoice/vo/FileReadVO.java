package in.co.invoice.vo;

import java.util.ArrayList;

/**
 * 
 * @author RubinSmith.M_Enc
 * 
 */
public class FileReadVO {

	public String fileName;
	public String status;
	public String msg;
	public String refNo;
	public String checkNo;

	public String recordIndicatorH;
	public String recordIndicatorT;
	public String processingDate;
	public String msgType;
	public String utrNumber;
	public String beneficiaryAccNo;
	public String beneficiaryAccType;
	public String beneficiaryName;
	public String amount;
	public String senderIFSC;
	public String senderAccNo;
	public String senderAccName;
	public String noOfRecords;
	public String sequence;
	public String batchID;

	
	public String dr_cr;
	public String entryamount;
	public String value_date;
	public String product;
	public String partycode;
	public String partyname;
	public String virtualno;
	public String remittingbank;
	
	public String getDr_cr() {
		return dr_cr;
	}

	public void setDr_cr(String dr_cr) {
		this.dr_cr = dr_cr;
	}

	public String getEntryamount() {
		return entryamount;
	}

	public void setEntryamount(String entryamount) {
		this.entryamount = entryamount;
	}

	public String getValue_date() {
		return value_date;
	}

	public void setValue_date(String value_date) {
		this.value_date = value_date;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getPartycode() {
		return partycode;
	}

	public void setPartycode(String partycode) {
		this.partycode = partycode;
	}

	public String getPartyname() {
		return partyname;
	}

	public void setPartyname(String partyname) {
		this.partyname = partyname;
	}

	public String getVirtualno() {
		return virtualno;
	}

	public void setVirtualno(String virtualno) {
		this.virtualno = virtualno;
	}

	public String getRemittingbank() {
		return remittingbank;
	}

	public void setRemittingbank(String remittingbank) {
		this.remittingbank = remittingbank;
	}

	ArrayList<FileReadVO> list = null;
	ArrayList<FileReadVO> headerList = null;
	ArrayList<FileReadVO> tailerList = null;

	/**
	 * 
	 * @return
	 */
	public ArrayList<FileReadVO> getList() {
		return list;
	}

	/**
	 * 
	 * @param list
	 */
	public void setList(ArrayList<FileReadVO> list) {
		this.list = list;
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<FileReadVO> getHeaderList() {
		return headerList;
	}

	/**
	 * 
	 * @param headerList
	 */
	public void setHeaderList(ArrayList<FileReadVO> headerList) {
		this.headerList = headerList;
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<FileReadVO> getTailerList() {
		return tailerList;
	}

	/**
	 * 
	 * @param tailerList
	 */
	public void setTailerList(ArrayList<FileReadVO> tailerList) {
		this.tailerList = tailerList;
	}

	/**
	 * 
	 * @return
	 */
	public String getBatchID() {
		return batchID;
	}

	/**
	 * 
	 * @param batchID
	 */
	public void setBatchID(String batchID) {
		this.batchID = batchID;
	}

	/**
	 * 
	 * @return
	 */
	public String getSequence() {
		return sequence;
	}

	/**
	 * 
	 * @param sequence
	 */
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	/**
	 * 
	 * @return
	 */
	public String getRecordIndicatorH() {
		return recordIndicatorH;
	}

	/**
	 * 
	 * @param recordIndicatorH
	 */
	public void setRecordIndicatorH(String recordIndicatorH) {
		this.recordIndicatorH = recordIndicatorH;
	}

	/**
	 * 
	 * @return
	 */
	public String getRecordIndicatorT() {
		return recordIndicatorT;
	}

	/**
	 * 
	 * @param recordIndicatorT
	 */
	public void setRecordIndicatorT(String recordIndicatorT) {
		this.recordIndicatorT = recordIndicatorT;
	}

	/**
	 * 
	 * @return
	 */
	public String getProcessingDate() {
		return processingDate;
	}

	/**
	 * 
	 * @param processingDate
	 */
	public void setProcessingDate(String processingDate) {
		this.processingDate = processingDate;
	}

	/**
	 * 
	 * @return
	 */
	public String getMsgType() {
		return msgType;
	}

	/**
	 * 
	 * @param msgType
	 */
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	/**
	 * 
	 * @return
	 */
	public String getBeneficiaryAccNo() {
		return beneficiaryAccNo;
	}

	/**
	 * 
	 * @param beneficiaryAccNo
	 */
	public void setBeneficiaryAccNo(String beneficiaryAccNo) {
		this.beneficiaryAccNo = beneficiaryAccNo;
	}

	/**
	 * 
	 * @return
	 */
	public String getBeneficiaryAccType() {
		return beneficiaryAccType;
	}

	/**
	 * 
	 * @param beneficiaryAccType
	 */
	public void setBeneficiaryAccType(String beneficiaryAccType) {
		this.beneficiaryAccType = beneficiaryAccType;
	}

	/**
	 * 
	 * @return
	 */
	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	/**
	 * 
	 * @param beneficiaryName
	 */
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	/**
	 * 
	 * @return
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * 
	 * @param amount
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * 
	 * @return
	 */
	public String getSenderIFSC() {
		return senderIFSC;
	}

	/**
	 * 
	 * @param senderIFSC
	 */
	public void setSenderIFSC(String senderIFSC) {
		this.senderIFSC = senderIFSC;
	}

	/**
	 * 
	 * @return
	 */
	public String getSenderAccNo() {
		return senderAccNo;
	}

	/**
	 * 
	 * @param senderAccNo
	 */
	public void setSenderAccNo(String senderAccNo) {
		this.senderAccNo = senderAccNo;
	}

	/**
	 * 
	 * @return
	 */
	public String getSenderAccName() {
		return senderAccName;
	}

	/**
	 * 
	 * @param senderAccName
	 */
	public void setSenderAccName(String senderAccName) {
		this.senderAccName = senderAccName;
	}

	/**
	 * 
	 * @return
	 */
	public String getNoOfRecords() {
		return noOfRecords;
	}

	/**
	 * 
	 * @param noOfRecords
	 */
	public void setNoOfRecords(String noOfRecords) {
		this.noOfRecords = noOfRecords;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName
	 *            the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the msg
	 */
	public String getMsg() {
		return msg;
	}

	/**
	 * @param msg
	 *            the msg to set
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the utrNumber
	 */
	public String getUtrNumber() {
		return utrNumber;
	}

	/**
	 * @param utrNumber
	 *            the utrNumber to set
	 */
	public void setUtrNumber(String utrNumber) {
		this.utrNumber = utrNumber;
	}

	/**
	 * @return the refNo
	 */
	public String getRefNo() {
		return refNo;
	}

	/**
	 * @param refNo
	 *            the refNo to set
	 */
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	/**
	 * @return the checkNo
	 */
	public String getCheckNo() {
		return checkNo;
	}

	/**
	 * @param checkNo
	 *            the checkNo to set
	 */
	public void setCheckNo(String checkNo) {
		this.checkNo = checkNo;
	}

}
