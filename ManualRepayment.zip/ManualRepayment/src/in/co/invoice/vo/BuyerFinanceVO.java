package in.co.invoice.vo;

import java.io.File;
import java.util.ArrayList;

public class BuyerFinanceVO {

	private String repayNo;
	private String repayAmt;
	private String InvoiceNo;
	private String InvoiceAmount;
	private String outStandingAmt;
	private String MasterRefKey;
	private String CIFNo;
	private String BatchID;
	private ArrayList<BuyerFinanceVO> invoiceList;
	private ArrayList<BuyerFinanceVO> list;
	private ArrayList<BuyerFinanceVO> BuyerList;
	
	/** Excel Upload **/
	private File inputFile;
	int excelresult = 0;
	
	
	
	
	public String getMasterRefKey() {
		return MasterRefKey;
	}
	public void setMasterRefKey(String masterRefKey) {
		MasterRefKey = masterRefKey;
	}
	public ArrayList<BuyerFinanceVO> getBuyerList() {
		return BuyerList;
	}
	public void setBuyerList(ArrayList<BuyerFinanceVO> buyerList) {
		BuyerList = buyerList;
	}
	public String getBatchID() {
		return BatchID;
	}
	public void setBatchID(String batchID) {
		BatchID = batchID;
	}
	public String getInvoiceNo() {
		return InvoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		InvoiceNo = invoiceNo;
	}
	public String getInvoiceAmount() {
		return InvoiceAmount;
	}
	public void setInvoiceAmount(String invoiceAmount) {
		InvoiceAmount = invoiceAmount;
	}
	public ArrayList<BuyerFinanceVO> getList() {
		return list;
	}
	public void setList(ArrayList<BuyerFinanceVO> list) {
		this.list = list;
	}
	public ArrayList<BuyerFinanceVO> getInvoiceList() {
		return invoiceList;
	}
	public void setInvoiceList(ArrayList<BuyerFinanceVO> invoiceList) {
		this.invoiceList = invoiceList;
	}
	public int getExcelresult() {
		return excelresult;
	}
	public void setExcelresult(int excelresult) {
		this.excelresult = excelresult;
	}
	public File getInputFile() {
		return inputFile;
	}
	public void setInputFile(File inputFile) {
		this.inputFile = inputFile;
	}
	public String getRepayNo() {
		return repayNo;
	}
	public void setRepayNo(String repayNo) {
		this.repayNo = repayNo;
	}
	public String getRepayAmt() {
		return repayAmt;
	}
	public void setRepayAmt(String repayAmt) {
		this.repayAmt = repayAmt;
	}
	
	public String getOutStandingAmt() {
		return outStandingAmt;
	}
	public void setOutStandingAmt(String outStandingAmt) {
		this.outStandingAmt = outStandingAmt;
	}
	public String getCIFNo() {
		return CIFNo;
	}
	public void setCIFNo(String cIFNo) {
		CIFNo = cIFNo;
	}
	
	
}
