package in.co.invoice.action;

import in.co.invoice.businessdelegate.exception.BusinessException;
import in.co.invoice.dao.exception.ApplicationException;
import in.co.invoice.vo.AlertMessagesVO;
import in.co.invoice.vo.InvMatchingVO;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class repayment {

	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 * @throws BusinessException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public String processRepaymentWSDL(String xmlMessage) throws ApplicationException,
			BusinessException, ParserConfigurationException, SAXException,
			IOException {
		InvMatchingVO invMatchingVO = new InvMatchingVO();
		InvoiceCustomerAction in = null;
		in = InvoiceCustomerAction.getACTION();
		//String xmlMessage = null;
		//xmlMessage = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?><InvoiceFinance><invoice><progID>DFDLMAKER</progID><counterParty></counterParty><payAmount>2</payAmount><valueDate>02-11-15</valueDate><allocationType>MF</allocationType><debitParty>LCUS-00000204</debitParty><repaymentAllocationType>INV</repaymentAllocationType><paymentAccount></paymentAccount><referenceNumber></referenceNumber><status></status></invoice></InvoiceFinance>";
		System.out.println(xmlMessage);
		invMatchingVO.setXml(xmlMessage);
		invMatchingVO = in.XMLToString(invMatchingVO);
		if (invMatchingVO.getError()==null || !invMatchingVO.getError().equalsIgnoreCase("error")) {
			invMatchingVO = in.WriteXMLFileMTP(invMatchingVO);
			xmlMessage = invMatchingVO.getXml();
		}else{
			ArrayList<AlertMessagesVO> val = invMatchingVO.getErrorList();
			xmlMessage = "";
			for(int i = 0; i < val.size(); i++){
				if(i >= 1){
					xmlMessage = xmlMessage + " and ";
				}
				xmlMessage = xmlMessage + val.get(i).getErrorDetails();
			}
			xmlMessage = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?><InvoiceFinance><invoice><resultMsg>"+xmlMessage+"</resultMsg></invoice></InvoiceFinance>";
		}
		System.out.println("Result XML-------->" + xmlMessage);
		return xmlMessage;
	}

	public static void main(String args[]) throws ParserConfigurationException,
			SAXException, IOException, ApplicationException {
		InvMatchingVO invMatchingVO = new InvMatchingVO();
		InvoiceCustomerAction in = null;
		in = InvoiceCustomerAction.getACTION();
		String xmlMessage = null;
		xmlMessage = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?><InvoiceFinance><invoice><progID>PANTALOON_2015</progID><counterParty></counterParty><payAmount>2</payAmount><valueDate>28-12-15</valueDate><allocationType>MD</allocationType><debitParty>LCUS-00000204</debitParty><repaymentAllocationType>INV</repaymentAllocationType><paymentAccount>98166102052</paymentAccount><referenceNumber>12345</referenceNumber><status></status></invoice></InvoiceFinance>";
		System.out.println(xmlMessage);
		invMatchingVO.setXml(xmlMessage);
		invMatchingVO = in.XMLToString(invMatchingVO);
		if (invMatchingVO.getError()==null || !invMatchingVO.getError().equalsIgnoreCase("error")) {
			invMatchingVO = in.WriteXMLFileMTP(invMatchingVO);
			xmlMessage = invMatchingVO.getXml();
		}else{
			ArrayList<AlertMessagesVO> val = invMatchingVO.getErrorList();
			xmlMessage = "";
			for(int i = 0; i < val.size(); i++){
				if(i >= 1){
					xmlMessage = xmlMessage + " and ";
				}
				xmlMessage = xmlMessage + val.get(i).getErrorDetails();
			}
			xmlMessage = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?><InvoiceFinance><invoice><resultMsg>"+xmlMessage+"</resultMsg></invoice></InvoiceFinance>";
		}
		System.out.println("Result XML-------->" + xmlMessage);
	}

}