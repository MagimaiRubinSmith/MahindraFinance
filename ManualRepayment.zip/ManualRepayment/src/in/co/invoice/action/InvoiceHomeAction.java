package in.co.invoice.action;

import in.co.clf.util.SystemPropertiesUtil;
import in.co.invoice.businessdelegate.pricereftomanybill.InvoiceMatchingProcess;
import in.co.invoice.dao.exception.ApplicationException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.CommonMethods;
import in.co.invoice.vo.AlertMessagesVO;
import in.co.invoice.vo.InvMatchingVO;
import in.co.invoice.vo.KeyValuePair;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;

public class InvoiceHomeAction extends InvoiceBaseAction implements
		ActionConstants {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static Logger logger = Logger.getLogger(InvoiceHomeAction.class
			.getName());

	Map<String, String> getdebitParty;

	Map<String, String> scfType;
	Map<String, String> scfSubtype;
	Map<String, String> scfDisbursement;
	Map<String, String> scfExposure;
	Map<String, String> scfProductType;
	Map<String, String> scfModeOfRepayment;
	ArrayList<KeyValuePair> repaymentAllocationTypeList = null;
	InvMatchingVO invMatchingVO;
	private String paymentAmount;
	private String programme;
	private String anchor;
	private String cparty;
	private String accountNumber;
	private String excessAmount;
	private String counterPartyValue;
	private String programID;
	private String repAlloType;
	private String repayBy;
	private String virtualAccountNo;
	private String invoiceAjaxListval;
	ArrayList<InvMatchingVO> invoiceAjaxDetails = null;
	ArrayList<InvMatchingVO> accountList = null;
	Map<String, String> repayType;

	//11Feb
	public File inputFile;
	public String fileName;
	ArrayList<InvMatchingVO> invoicList;
	//14Feb
	ArrayList<AlertMessagesVO> errorList;


	public ArrayList<AlertMessagesVO> getErrorList() {
		return errorList;
	}

	public void setErrorList(ArrayList<AlertMessagesVO> errorList) {
		this.errorList = errorList;
	}

	public ArrayList<InvMatchingVO> getInvoicList() {
		return invoicList;
	}

	public void setInvoicList(ArrayList<InvMatchingVO> invoicList) {
		this.invoicList = invoicList;
	}

	public File getInputFile() {
		return inputFile;
	}

	public void setInputFile(File inputFile) {
		this.inputFile = inputFile;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getVirtualAccountNo() {
		return virtualAccountNo;
	}

	public void setVirtualAccountNo(String virtualAccountNo) {
		this.virtualAccountNo = virtualAccountNo;
	}

	public Map<String, String> getRepayType() {
		return ActionConstants.INTEREST_MODE;
	}

	public void setRepayType(Map<String, String> repayType) {
		this.repayType = repayType;
	}

	public ArrayList<InvMatchingVO> getAccountList() {
		return accountList;
	}

	public void setAccountList(ArrayList<InvMatchingVO> accountList) {
		this.accountList = accountList;
	}

	public String getExcessAmount() {
		return excessAmount;
	}

	public void setExcessAmount(String excessAmount) {
		this.excessAmount = excessAmount;
	}

	public String getProgramme() {
		return programme;
	}

	public void setProgramme(String programme) {
		this.programme = programme;
	}

	public String getAnchor() {
		return anchor;
	}

	public void setAnchor(String anchor) {
		this.anchor = anchor;
	}

	public String getCparty() {
		return cparty;
	}

	public void setCparty(String cparty) {
		this.cparty = cparty;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepayBy() {
		return repayBy;
	}

	/**
	 * 
	 * @param repayBy
	 */
	public void setRepayBy(String repayBy) {
		this.repayBy = repayBy;
	}

	/**
	 * 
	 * @return
	 */
	public String getInvoiceAjaxListval() {
		return invoiceAjaxListval;
	}

	/**
	 * 
	 * @param invoiceAjaxListval
	 */
	public void setInvoiceAjaxListval(String invoiceAjaxListval) {
		this.invoiceAjaxListval = invoiceAjaxListval;
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<InvMatchingVO> getInvoiceAjaxDetails() {
		return invoiceAjaxDetails;
	}

	/**
	 * 
	 * @param invoiceAjaxDetails
	 */
	public void setInvoiceAjaxDetails(ArrayList<InvMatchingVO> invoiceAjaxDetails) {
		this.invoiceAjaxDetails = invoiceAjaxDetails;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepAlloType() {
		return repAlloType;
	}

	/**
	 * 
	 * @param repAlloType
	 */
	public void setRepAlloType(String repAlloType) {
		this.repAlloType = repAlloType;
	}

	/**
	 * 
	 * @return
	 */
	public String getProgramID() {
		return programID;
	}

	/**
	 * 
	 * @param programID
	 */
	public void setProgramID(String programID) {
		this.programID = programID;
	}

	/**
	 * 
	 * @return
	 */
	public String getCounterPartyValue() {
		return counterPartyValue;
	}

	/**
	 * 
	 * @param counterPartyValue
	 */
	public void setCounterPartyValue(String counterPartyValue) {
		this.counterPartyValue = counterPartyValue;
	}

	/**
	 * 
	 * @return
	 */
	public String getPaymentAmount() {
		return paymentAmount;
	}

	/**
	 * 
	 * @param paymentAmount
	 */
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	/**
	 * 
	 * @return
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * 
	 * @param accountNumber
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * 
	 * @return
	 */
	public Map<String, String> getScfModeOfRepayment() {
		return scfModeOfRepayment;
	}

	/**
	 * 
	 * @param scfModeOfRepayment
	 */
	public void setScfModeOfRepayment(Map<String, String> scfModeOfRepayment) {
		this.scfModeOfRepayment = scfModeOfRepayment;
	}

	/**
	 * 
	 * @return
	 */
	public InvMatchingVO getInvMatchingVO() {
		return invMatchingVO;
	}

	/**
	 * 
	 * @param invMatchingVO
	 */
	public void setInvMatchingVO(InvMatchingVO invMatchingVO) {
		this.invMatchingVO = invMatchingVO;
	}

	public ArrayList<KeyValuePair> getRepaymentAllocationTypeList() {
		return repaymentAllocationTypeList;
	}

	public void setRepaymentAllocationTypeList(
			ArrayList<KeyValuePair> repaymentAllocationTypeList) {
		this.repaymentAllocationTypeList = repaymentAllocationTypeList;
	}

	public Map<String, String> getScfDisbursement() {
		return ActionConstants.SCF_DISBURSEMENT;
	}

	public void setScfDisbursement(Map<String, String> scfDisbursement) {
		this.scfDisbursement = scfDisbursement;
	}

	public Map<String, String> getScfSubtype() {
		return ActionConstants.SCF_SUBTYPE;
	}

	public void setScfSubtype(Map<String, String> scfSubtype) {
		this.scfSubtype = scfSubtype;
	}

	public Map<String, String> getScfType() {
		return ActionConstants.SCF_TYPE;
	}

	public void setScfType(Map<String, String> scfType) {
		this.scfType = scfType;
	}

	public Map<String, String> getScfExposure() {
		return ActionConstants.SCF_EXPOSURE;
	}

	public void setScfExposure(Map<String, String> scfExposure) {
		this.scfExposure = scfExposure;
	}

	public Map<String, String> getScfProductType() {
		return ActionConstants.SCF_PRODUCT_TYPE;
	}

	public void setScfProductType(Map<String, String> scfProductType) {
		this.scfProductType = scfProductType;
	}

	InvMatchingVO makervo;

	String allocationType;

	ArrayList<InvMatchingVO> eventList = null;

	Map<String, String> getcounterParty;

	public String getAllocationType() {
		return allocationType;
	}

	public void setAllocationType(String allocationType) {
		this.allocationType = allocationType;
	}

	public ArrayList<InvMatchingVO> getEventList() {
		return eventList;
	}

	public void setEventList(ArrayList<InvMatchingVO> eventList) {
		this.eventList = eventList;
	}

	public Map<String, String> getGetdebitParty() {
		return getdebitParty;
	}

	public void setGetdebitParty(Map<String, String> getdebitParty) {
		this.getdebitParty = REC_IND;
	}

	public Map<String, String> getGetcounterParty() {
		return getcounterParty;
	}

	public void setGetcounterParty(Map<String, String> getcounterParty) {
		this.getcounterParty = REC;
	}

	ArrayList<KeyValuePair> allocationTypeList = null;

	public ArrayList<KeyValuePair> getAllocationTypeList() {
		return allocationTypeList;
	}

	public void setAllocationTypeList(ArrayList<KeyValuePair> allocationTypeList) {
		this.allocationTypeList = allocationTypeList;
	}

	ArrayList<KeyValuePair>  repayByList = null;

	public ArrayList<KeyValuePair> getRepayByList() {
		return repayByList;
	}

	public void setRepayByList(ArrayList<KeyValuePair> repayByList) {
		this.repayByList = repayByList;
	}
	
	
	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String manualLandingPage() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess invProcess = null;
		Map session = null;
		HttpSession httpSession = null;
		String projectType = null;
		try {
			projectType = MANUAL;
			httpSession = ServletActionContext.getRequest().getSession();
			httpSession.setAttribute(SESSION_MANUAL, projectType);
			httpSession.setAttribute(SESSION_ROLE, MAKER);
			httpSession.removeAttribute(LOGINUSER);
			httpSession.removeAttribute(REJECTLIST);
			invProcess = InvoiceMatchingProcess.getBD();
			invProcess.isSessionAvailable();
			setGetcounterParty(REC);
			allocationTypeList = fetchAllocationTypeList();
			repayByList = fetchRepayByList();
			repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
			invProcess.setDate();
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
			session = ActionContext.getContext().getSession();
			session.remove(SESSION_KEY);
			session.remove(SESSION_ID);
			session.put(CLOSE_URL, SystemPropertiesUtil.fetchCloseURL());
		} catch (Exception ex) {
			throwApplicationException(ex);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return SUCCESS;

	}
	
	
	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 */
	public String interestLandingPage() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess invProcess = null;
		Map<String, Object> session = null;
		HttpSession httpSession = null;
		String projectType = null;
		try {
			projectType = MANUAL;
			httpSession = ServletActionContext.getRequest().getSession();
			httpSession.setAttribute(SESSION_MANUAL, projectType);
			httpSession.setAttribute(SESSION_ROLE, MAKER);
			httpSession.removeAttribute(LOGINUSER);
			httpSession.removeAttribute(REJECTLIST);
			invProcess = InvoiceMatchingProcess.getBD();
			invProcess.isSessionAvailable();
			invProcess.setDate();
			session = ActionContext.getContext().getSession();
			session.remove(SESSION_KEY);
			session.remove(SESSION_ID);
			
			session.put(CLOSE_URL, SystemPropertiesUtil.fetchCloseURL());
		} catch (Exception ex) {
			throwApplicationException(ex);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return SUCCESS;

	}

	/**
	 * 
	 * @return
	 */
	public String landingPage() {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess invProcess = null;
		HttpSession httpSession = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();
			httpSession = ServletActionContext.getRequest().getSession();
			httpSession.removeAttribute(SESSION_MANUAL);
			httpSession.setAttribute(SESSION_ROLE, MAKER);
			/*
			 * invoiceVO.setAllocationType(allocationType);
			 * System.out.println(invoiceVO.getAllocationType());
			 */

			/*
			 * invProcess.setDate(); Map
			 * session=ActionContext.getContext().getSession();
			 * session.remove("key"); session.remove("id");
			 */

			/*
			 * eventList = invProcess.gettingprogram(); setEventList(eventList);
			 * setGetdebitParty(REC_IND);
			 */
			setGetcounterParty(REC);
			allocationTypeList = fetchAllocationTypeList();
			repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
			invProcess.setDate();
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
			Map session = ActionContext.getContext().getSession();
			session.remove("key");
			session.remove("id");
			session.put(CLOSE_URL, SystemPropertiesUtil.fetchCloseURL());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";

	}

	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 */
	public String fetchRepaymentMode() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			/* Change */
			if (!commonMethods.isNull(paymentAmount)
					&& paymentAmount.equalsIgnoreCase(RT)) {
				accountNumber = commonMethods.getAccountNumber("%RTGS%");
			} else if (paymentAmount.equalsIgnoreCase(NT)) {
				accountNumber = commonMethods.getAccountNumber("%NEFT%");
			}else if (paymentAmount.equalsIgnoreCase(CH)) {
				accountNumber = commonMethods.getAccountNumber("%CLFCASH%");
			} else if (paymentAmount.equalsIgnoreCase(CQ)) {
				accountNumber = commonMethods.getAccountNumber("%CLFCHEQUE%");
			} else if (paymentAmount.equalsIgnoreCase(EX)) {
				accountNumber = commonMethods.getAccountNumber("%EXCESS%");
				excessAmount = commonMethods.fetchExcessBGL(programme, anchor, cparty);
			} else if (paymentAmount.equalsIgnoreCase(SD)) {
				accountNumber = commonMethods.getAccountNumber("%SD%");
				excessAmount = commonMethods.fetchSecurityAmount(programme, anchor, cparty);
			}else if (paymentAmount.equalsIgnoreCase(AD)) {//MAL-221
				accountNumber = commonMethods.getAccountNumber("%AD%");
				excessAmount = commonMethods.fetchAdvanceAmount(programme, anchor, cparty);
			}
			else {
				accountNumber = "";
			}
			
			/* Change */
		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}
	
	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 */
	public String fetchAppropriationType() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			if (!commonMethods.isNull(counterPartyValue) && !commonMethods.isNull(programID)) {
				repAlloType = commonMethods.fetchCounterPartyAppropriationType(programID.trim(),counterPartyValue.trim());
			}
				/*if(!commonMethods.isNull(rep) && !rep.equalsIgnoreCase("INV")){
					rep = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(rep);
				}else{
					rep = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(rep);
				}*/
		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}
	
	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 */
	public String fetchRepayBy() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			if (!commonMethods.isNull(counterPartyValue) && !commonMethods.isNull(programID)) {
				repayBy = commonMethods.fetchCounterPartyRepayBy(programID.trim(),counterPartyValue.trim());
			}
		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}
	public String fetchVirtualAccount() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			if (!commonMethods.isNull(counterPartyValue) && !commonMethods.isNull(programID)) {
				virtualAccountNo = commonMethods.fetchVirtualAccountNo(programID.trim(),counterPartyValue.trim());
				System.out.println("Virtual Acc No"+virtualAccountNo);
			}
		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}
	/**
	 * 
	 * @param type
	 * @return
	 * @throws ApplicationException
	 */
	private ArrayList<KeyValuePair> fetchRepaymentAllocationList(String type)
			throws ApplicationException {
		ArrayList<KeyValuePair> list = null;
		try {
			list = new ArrayList<KeyValuePair>();

			KeyValuePair temp = new KeyValuePair();
			if(type!=null && type.equalsIgnoreCase("INV")){
				temp.setKeyId("INV");
				temp.setKeyValue("INV");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("CIP");
				temp.setKeyValue("CAIP");
				list.add(temp);	
				temp = new KeyValuePair();
				temp.setKeyId("PAIC");
				temp.setKeyValue("PAIC");
				list.add(temp);	
			}else {
				temp.setKeyId("CIP");
				temp.setKeyValue("CAIP");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("INV");
				temp.setKeyValue("INV");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("PAIC");
				temp.setKeyValue("PAIC");
				list.add(temp);	
			}
			

		} catch (Exception e) {

			throwApplicationException(e);

		}
		return list;
	}

	private ArrayList<KeyValuePair> fetchRepaymentAllocationTypeList()
			throws ApplicationException {
		ArrayList<KeyValuePair> list = null;
		try {
			list = new ArrayList<KeyValuePair>();

			KeyValuePair temp = new KeyValuePair();

			temp.setKeyId("INV");
			temp.setKeyValue("INV");
			list.add(temp);
			temp = new KeyValuePair();
			temp.setKeyId("CIP");
			temp.setKeyValue("CAIP");
			/*list.add(temp);
			temp = new KeyValuePair();
			temp.setKeyId("PAIC");
			temp.setKeyValue("PAIC");
			list.add(temp);*/
		} catch (Exception e) {

			throwApplicationException(e);

		}
		return list;
	}

	private ArrayList<KeyValuePair> fetchAllocationTypeList()
			throws ApplicationException {
		ArrayList<KeyValuePair> list = null;
		try {
			list = new ArrayList<KeyValuePair>();

			KeyValuePair temp = new KeyValuePair();
			temp.setKeyId("MF");
			temp.setKeyValue("Due Date");
			list.add(temp);

			temp = new KeyValuePair();
			temp.setKeyId("MD");
			temp.setKeyValue("Due Date");
			list.add(temp);

			/*temp = new KeyValuePair();
			temp.setKeyId("U");
			temp.setKeyValue("Upload");
			list.add(temp);*/

		} catch (Exception e) {

			throwApplicationException(e);

		}
		return list;
	}
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String invoiceDetailList() throws Exception {
		InvoiceMatchingProcess invProcess = null;
		try {
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			invProcess = InvoiceMatchingProcess.getBD();
			invoiceAjaxDetails = invProcess
					.fetchDetailedBatch(invoiceAjaxListval);
			invMatchingVO = invProcess.fetchInvoiceDetails(invMatchingVO,invoiceAjaxListval);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}
	
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String fetchInvoiceMatchingValue() throws Exception {
		InvoiceMatchingProcess invProcess = null;
		try {
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			invProcess = InvoiceMatchingProcess.getBD();
			invoiceAjaxDetails = invProcess.fetchDetailedBatch(invoiceAjaxListval);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}
	/*public String fetchPenalMatchingValue() throws Exception {
		InvoiceMatchingProcess invProcess = null;
		try {
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			invProcess = InvoiceMatchingProcess.getBD();
			System.out.println("the value would be"+invoiceAjaxDetails);
			invoiceAjaxDetails = invProcess.fetchPenalDetails(invoiceAjaxListval);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}*/
	public String bankpageTC() throws ApplicationException
	{
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess bd = null;
		try {
			System.out.println("bank page TC action");
			bd = InvoiceMatchingProcess.getBD();
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			//accountList = bd.getAccountTCList( scf);
			//setAccountList(accountList);
		} catch (Exception exception) {
			throwApplicationException(exception);
			System.out.println("bank page TC action");
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}
	public String updateList() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess updatebd = null;
		CommonMethods commonMethods = new CommonMethods();
		
	/*	String mode = commonMethods.getEmptyIfNull(scf.getMode()).trim();
		String highlightedId = commonMethods.getEmptyIfNull(
				invMatchingVO.getHighlightedId()).trim();*/
	/*	String sessionId = commonMethods.getEmptyIfNull(scf.getSubkeyvalue())
				.trim();*/
	/*	Map session = ActionContext.getContext().getSession();
		if(sessionId == null || sessionId.equalsIgnoreCase("")){
			if(scf.getProgrammeidentifier() != null){
				sessionId = scf.getProgrammeidentifier();
			}
		}
		session.put("id", sessionId);
		session.put("key", highlightedId);
		scf.setModeType(modeType);*/
		try {
			updatebd = InvoiceMatchingProcess.getBD();
			invMatchingVO = updatebd.getUpdatedList(invMatchingVO);
			//setScf(invMatchingVO);
			//changeList = invMatchingVO.getChangeList();
			
			/*Visitor*/
//			scf.setBaseRate(commonMethods.fetchBaseRate().trim());
			/*if (scf.getCreditLimit() == null) {
				scf.setCreditLimit("0 INR");
			}
			interestConsolidation = ActionConstants.INTEREST_ARREAR;
			if (commonMethods.isNull(scf.getProgrammetype())
					|| scf.getProgrammetype().equalsIgnoreCase(EMPTY)) {
				scf.setProgrammetype(scf.getTempprogrammetype());
			}
			if (commonMethods.isNull(scf.getInterestType())
					|| scf.getInterestType().equalsIgnoreCase(EMPTY)) {
				scf.setInterestType(scf.getTempinterestType());
			}
			if (commonMethods.isNull(scf.getInterestConsolidation())
					|| scf.getInterestConsolidation().equalsIgnoreCase(EMPTY)) {
				scf.setInterestConsolidation(scf.getTempinterestConsolidation());
			}
			if (commonMethods.isNull(scf.getExposureOn())
					|| scf.getExposureOn().equalsIgnoreCase(EMPTY)) {
				scf.setExposureOn(scf.getTempexposureOn());
			}
			if (commonMethods.isNull(scf.getExposureOn())
					|| scf.getExposureOn().equalsIgnoreCase(EMPTY)) {
				scf.setExposureOn(scf.getTempexposureOn());
			}
			if (commonMethods.isNull(scf.getProductType())
					|| scf.getProductType().equalsIgnoreCase(EMPTY)) {
				scf.setProductType(scf.getTempproductType());
			}
			if (commonMethods.isNull(scf.getDisbursement())
					|| scf.getDisbursement().equalsIgnoreCase(EMPTY)) {
				scf.setDisbursement(scf.getTempdisbursement());
			}
			NPA
			if(CommonMethods.isNull(scf.getNpaFlag()) || scf.getNpaFlag().equalsIgnoreCase(EMPTY)){
				scf.setNpaFlag(scf.getAuditNpaFlag());
			}
			if(CommonMethods.isNull(scf.getDebitFreezeNPA()) || scf.getDebitFreezeNPA().equalsIgnoreCase(EMPTY)){
				scf.setDebitFreezeNPA(scf.getAuditDebitFreezeNPA());
			}
			if(CommonMethods.isNull(scf.getAssetClassification()) || scf.getAssetClassification().equalsIgnoreCase(EMPTY)){
				scf.setAssetClassification(scf.getAuditAssetClassification());
			}
			scfExposure = ActionConstants.SCF_EXPOSURE;
			
			Visitor
			if (!commonMethods.isNull(scf.getProgrammetype())
					&& scf.getProgrammetype().equalsIgnoreCase(S)) {
				if(!commonMethods.isNull(scf.getInterestDebitParty())
						&& scf.getInterestDebitParty().equalsIgnoreCase("ANCHOR"))
					scfModeOfIntRec = ActionConstants.MODE_OF_INT_RECOVERY_ANCHOR_DEALER;
				else if(!commonMethods.isNull(scf.getInterestDebitParty())
						&& scf.getInterestDebitParty().equalsIgnoreCase("DEALER"))
					scfModeOfIntRec = ActionConstants.MODE_OF_INT_RECOVERY_DEALER;
				else
					scfModeOfIntRec = ActionConstants.MODE_OF_INT_RECOVERY;
				
			} else if (!commonMethods.isNull(scf.getProgrammetype())
					&& scf.getProgrammetype().equalsIgnoreCase(B)) {
				if(!commonMethods.isNull(scf.getInterestDebitParty())
						&& scf.getInterestDebitParty().equalsIgnoreCase("ANCHOR"))
					scfModeOfIntRec = ActionConstants.MODE_OF_INT_RECOVERY_ANCHOR_VENDOR;
				else if(!commonMethods.isNull(scf.getInterestDebitParty())
						&& scf.getInterestDebitParty().equalsIgnoreCase("VENDOR"))
					scfModeOfIntRec = ActionConstants.MODE_OF_INT_RECOVERY_VENDOR;
				else 
					scfModeOfIntRec = ActionConstants.MODE_OF_INT_RECOVERY;
			} else {
				scfModeOfIntRec = ActionConstants.MODE_OF_INT_RECOVERY;
			}
			
			scfIntMode = ActionConstants.INTEREST_RATE_TYPE;
			scfRateIndex = new RateUtility().getRateIndex(scfRateIndex);
			if(!commonMethods.isNull(scf.getIntMode()) && !scf.getIntMode().trim().equals("FI")) {
				scf.setBaseRate(RateUtility.fetchBaseRate(scf.getRateIndex()).trim());
			}
			scfResetFreq = ActionConstants.RESET_FREQ;
			
			if(scf.getTempprogrammetype() != null && scf.getTempprogrammetype().equals("S")) {
				debitParty = ActionConstants.PARTYLIST_DEALER;
				interestRefundParty = ActionConstants.PARTYLIST_DEALER;
				penalDebitParty = ActionConstants.PARTYLIST_DEALER;
			} else if(scf.getTempprogrammetype() != null && scf.getTempprogrammetype().equals("B")) {
				debitParty = ActionConstants.PARTYLIST_VENDOR;
				interestRefundParty = ActionConstants.PARTYLIST_VENDOR;
				penalDebitParty = ActionConstants.PARTYLIST_VENDOR;
			} else {
				debitParty = ActionConstants.PARTYLIST;
				interestRefundParty = ActionConstants.PARTYLIST;
				penalDebitParty = ActionConstants.PARTYLIST;
			}
			
			logger.info("SCF_PRODUCT_TYPE IN");
			scfProductType = ActionConstants.SCF_PRODUCT_TYPE;
			if (!commonMethods.isNull(scf.getProductType())
					&& scf.getProductType().equalsIgnoreCase("BDC")) {
				fbccWorkflow = ActionConstants.FBCCWORKFLOW_BD;

			} else if (!commonMethods.isNull(scf.getProductType())
					&& scf.getProductType().equalsIgnoreCase("POF")) {
				fbccWorkflow = ActionConstants.FBCCWORKFLOW_PO;
			} else if (!commonMethods.isNull(scf.getProductType())
					&& scf.getProductType().equalsIgnoreCase("INF")) {
				fbccWorkflow = ActionConstants.FBCCWORKFLOW_IV;
			} else {
				fbccWorkflow = ActionConstants.FBCCWORKFLOW;
			}
			 apportionment = ActionConstants.APPORTIONMENT; 
			logger.info("SCF_PRODUCT_TYPE OUT");*/
		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		//
		/*if (mode.equalsIgnoreCase("update")) {
			scf.setMode(mode);
		}
		if (mode.equalsIgnoreCase("view")) {
			scf.setMode(mode);
		}
		if (mode.equalsIgnoreCase("delete")) {
			scf.setMode(mode);
		}*/
		/*
		 * if(newkeyvalue.equalsIgnoreCase("")){ scf.setProgrammeidentifier("");
		 * scf.setFlagremoval(""); scf.setMode("copy"); scf.setKey(""); }
		 */
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	
	
	public String bankSelection() throws ApplicationException
	{
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess bd = null;
		try {
			System.out.println("into the bank selection method");
			System.out.println("branch code"+invMatchingVO.getBranchCode());
			bd = InvoiceMatchingProcess.getBD();
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			System.out.println("branch code 1"+invMatchingVO.getBranchCode());
			accountList = bd.getAccountList1( invMatchingVO);
			
			setAccountList(accountList);
		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}
	public String bankTCSelection() throws ApplicationException
	{
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess bd = null;
		try {
			bd = InvoiceMatchingProcess.getBD();
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			accountList = bd.getAccountTCList( invMatchingVO);
			setAccountList(accountList);
		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}
	
	private ArrayList<KeyValuePair> fetchRepayByList()
			throws ApplicationException {
		ArrayList<KeyValuePair> list = null;
		try
		{
			list = new ArrayList<KeyValuePair>();
			
			KeyValuePair temp = new KeyValuePair();
			temp.setKeyId("A");
			temp.setKeyValue("ANCHOR");
			list.add(temp);
			
			temp = new KeyValuePair();
			temp.setKeyId("C");
			temp.setKeyValue("Counter Party");
			list.add(temp);
			
		} catch (Exception e) {

			throwApplicationException(e);

		}
		return list;
	}
	
	
	//04Feb
	public String fetchViewList() throws Exception {
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			invoiceAjaxDetails = invProcess.viewList(invoiceAjaxListval);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}
	
	
	//11Feb
	public String fetchChargesViewList() throws Exception {
		InvoiceMatchingProcess invProcess = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();
			invoiceAjaxDetails = invProcess.fetchChargesViewList(invoiceAjaxListval);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}


	//11Feb
	public String bulkUploadValidate() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess invProcess = null;
		String batchIDSeq = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();

			if (null != inputFile) {

				String ext = fileName.substring(fileName.length() - 3,
						fileName.length());

				if (ext.equalsIgnoreCase("xls") || ext.equalsIgnoreCase("csv")) {
					invMatchingVO = new InvMatchingVO();
					invMatchingVO.setInputFile(inputFile);
					invMatchingVO.setFileName(fileName);
					batchIDSeq = invProcess.bulkUploadValidate(invMatchingVO);
					invMatchingVO.setBatchIDSeq(batchIDSeq);

					invoicList = invProcess.fetchUploadDetails(batchIDSeq);
					setInvoicList(invoicList);
				} else {
					addActionError("Invalid File Format");
				}
			} else {
				addActionError("Please select file to proceed");
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return SUCCESS;
	}
	
	
	
	//13Feb
	public String bulkUploadUpdate() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess invProcess = null;
		int updateCount = 0;
		try {
			invProcess = InvoiceMatchingProcess.getBD();
			updateCount = invProcess.bulkUploadUpdate(invMatchingVO, invoicList);
			if(updateCount > 0) {
				invMatchingVO = new InvMatchingVO();
				invoicList = new ArrayList<InvMatchingVO>();
				addActionMessage("Uploaded successfully");
			} else {
				addActionError("Data have error to Upload");
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return SUCCESS;
	}

}
