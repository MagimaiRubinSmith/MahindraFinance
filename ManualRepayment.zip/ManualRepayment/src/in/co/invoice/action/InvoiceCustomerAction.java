package in.co.invoice.action;

import in.co.clf.util.SystemPropertiesUtil;
import in.co.invoice.businessdelegate.exception.BusinessException;
import in.co.invoice.businessdelegate.pricereftomanybill.InvoiceMatchingProcess;
import in.co.invoice.dao.exception.ApplicationException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.CommonMethods;
import in.co.invoice.utility.PdfGenerator;
import in.co.invoice.utility.UtilityGenerateCard;
import in.co.invoice.vo.AlertMessagesVO;
import in.co.invoice.vo.InvBatchVO;
import in.co.invoice.vo.InvMatchingDataVO;
import in.co.invoice.vo.InvMatchingVO;
import in.co.invoice.vo.KeyValuePair;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.opensymphony.xwork2.ActionContext;

public class InvoiceCustomerAction extends InvoiceBaseAction implements
		ActionConstants {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static Logger logger = Logger.getLogger(InvoiceCustomerAction.class
			.getName());

	ArrayList<InvMatchingVO> tiListDetail = null;

	ArrayList<InvMatchingDataVO> storeInvData = null;
	List<InvMatchingVO> getdebitParty = null;
	List<InvMatchingVO> getcounterParty = null;
	Map<String, String> scfModeOfRepayment;
	Map<String, String> counterParty;
	Map<String, String> viewListStatusFilter;// 04Feb
	ArrayList<InvMatchingVO> programList = null;
	ArrayList<InvMatchingVO> accountList = null;
	ArrayList<InvMatchingVO> invoiceDetails = null;
	ArrayList<InvMatchingVO> invoiceAjaxDetails = null;
	Map<String, String> scfType;
	Map<String, String> scfSubtype;
	Map<String, String> scfDisbursement;
	Map<String, String> scfExposure;
	Map<String, String> scfProductType;
	public String paymentAmount = null;
	private String accountNumber;
	private String invoiceAjaxListval;
	InvMatchingVO invMatchingVO;
	ArrayList<InvMatchingVO> dealRef = null;
	Map<String, String> repayType;
	ArrayList<InvMatchingVO> invoiceList;
	ArrayList<InvBatchVO> batchList = null;// 04Feb

	// 12Feb
	Map<String, String> chargeTypeFilter;

	public Map<String, String> getChargeTypeFilter() {
		return ActionConstants.CHARGE_TYPE;
	}

	public void setChargeTypeFilter(Map<String, String> chargeTypeFilter) {
		this.chargeTypeFilter = chargeTypeFilter;
	}

	public Map<String, String> getViewListStatusFilter() {
		return ActionConstants.VIEWLIST_STATUS_FILTER;
	}

	public void setViewListStatusFilter(Map<String, String> viewListStatusFilter) {
		this.viewListStatusFilter = viewListStatusFilter;
	}

	public ArrayList<InvBatchVO> getBatchList() {
		return batchList;
	}

	public void setBatchList(ArrayList<InvBatchVO> batchList) {
		this.batchList = batchList;
	}

	public ArrayList<InvMatchingVO> getInvoiceList() {
		return invoiceList;
	}

	public void setInvoiceList(ArrayList<InvMatchingVO> invoiceList) {
		this.invoiceList = invoiceList;
	}

	public Map<String, String> getRepayType() {
		return ActionConstants.INTEREST_MODE;
	}

	public void setRepayType(Map<String, String> repayType) {
		this.repayType = repayType;
	}

	public ArrayList<InvMatchingVO> getDealRef() {
		return dealRef;
	}

	public void setDealRef(ArrayList<InvMatchingVO> dealRef) {
		this.dealRef = dealRef;
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<InvMatchingVO> getInvoiceAjaxDetails() {
		return invoiceAjaxDetails;
	}

	/**
	 * 
	 * @param invoiceAjaxDetails
	 */
	public void setInvoiceAjaxDetails(
			ArrayList<InvMatchingVO> invoiceAjaxDetails) {
		this.invoiceAjaxDetails = invoiceAjaxDetails;
	}

	/**
	 * 
	 * @return
	 */
	public String getInvoiceAjaxListval() {
		return invoiceAjaxListval;
	}

	/**
	 * 
	 * @param invoiceAjaxListval
	 */
	public void setInvoiceAjaxListval(String invoiceAjaxListval) {
		this.invoiceAjaxListval = invoiceAjaxListval;
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<InvMatchingVO> getInvoiceDetails() {
		return invoiceDetails;
	}

	/**
	 * 
	 * @param invoiceDetails
	 */
	public void setInvoiceDetails(ArrayList<InvMatchingVO> invoiceDetails) {
		this.invoiceDetails = invoiceDetails;
	}

	/**
	 * 
	 * @return
	 */
	public String getPaymentAmount() {
		return paymentAmount;
	}

	/**
	 * 
	 * @param paymentAmount
	 */
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<InvMatchingVO> getAccountList() {
		return accountList;
	}

	/**
	 * 
	 * @param accountList
	 */
	public void setAccountList(ArrayList<InvMatchingVO> accountList) {
		this.accountList = accountList;
	}

	/**
	 * 
	 * @return
	 */
	public Map<String, String> getScfModeOfRepayment() {
		return scfModeOfRepayment;
	}

	/**
	 * 
	 * @param scfModeOfRepayment
	 */
	public void setScfModeOfRepayment(Map<String, String> scfModeOfRepayment) {
		this.scfModeOfRepayment = scfModeOfRepayment;
	}

	public Map<String, String> getCounterParty() {
		return counterParty;
	}

	public void setCounterParty(Map<String, String> counterParty) {
		this.counterParty = REC;
	}

	public Map<String, String> getScfDisbursement() {
		return ActionConstants.SCF_DISBURSEMENT;
	}

	public void setScfDisbursement(Map<String, String> scfDisbursement) {
		this.scfDisbursement = scfDisbursement;
	}

	public Map<String, String> getScfSubtype() {
		return ActionConstants.SCF_SUBTYPE;
	}

	public void setScfSubtype(Map<String, String> scfSubtype) {
		this.scfSubtype = scfSubtype;
	}

	public Map<String, String> getScfType() {
		return ActionConstants.SCF_TYPE;
	}

	public void setScfType(Map<String, String> scfType) {
		this.scfType = scfType;
	}

	public Map<String, String> getScfExposure() {
		return ActionConstants.SCF_EXPOSURE;
	}

	public void setScfExposure(Map<String, String> scfExposure) {
		this.scfExposure = scfExposure;
	}

	public Map<String, String> getScfProductType() {
		return ActionConstants.SCF_PRODUCT_TYPE;
	}

	public void setScfProductType(Map<String, String> scfProductType) {
		this.scfProductType = scfProductType;
	}

	public ArrayList<InvMatchingVO> getProgramList() {
		return programList;
	}

	public void setProgramList(ArrayList<InvMatchingVO> programList) {
		this.programList = programList;
	}

	private ArrayList<AlertMessagesVO> alertMsgArray = new ArrayList<AlertMessagesVO>();
	ArrayList<InvMatchingVO> eventList = null;

	ArrayList<AlertMessagesVO> errorList = null;
	ArrayList<AlertMessagesVO> warningList = null;

	public ArrayList<AlertMessagesVO> getWarningList() {
		return warningList;
	}

	public void setWarningList(ArrayList<AlertMessagesVO> warningList) {
		this.warningList = warningList;
	}

	private String allocationType;

	ArrayList<KeyValuePair> allocationTypeList = null;

	ArrayList<KeyValuePair> repayByList = null;

	public ArrayList<KeyValuePair> getRepayByList() {
		return repayByList;
	}

	public void setRepayByList(ArrayList<KeyValuePair> repayByList) {
		this.repayByList = repayByList;
	}

	ArrayList<KeyValuePair> repaymentAllocationTypeList = null;

	public ArrayList<KeyValuePair> getRepaymentAllocationTypeList() {
		return repaymentAllocationTypeList;
	}

	public void setRepaymentAllocationTypeList(
			ArrayList<KeyValuePair> repaymentAllocationTypeList) {
		this.repaymentAllocationTypeList = repaymentAllocationTypeList;
	}

	public ArrayList<KeyValuePair> getAllocationTypeList() {
		return allocationTypeList;
	}

	public void setAllocationTypeList(ArrayList<KeyValuePair> allocationTypeList) {
		this.allocationTypeList = allocationTypeList;
	}

	private String batchId;

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getAllocationType() {
		return allocationType;
	}

	public void setAllocationType(String allocationType) {
		this.allocationType = allocationType;
	}

	InvMatchingVO invoiceVO = null;

	public InvMatchingVO getInvoiceVO() {
		return invoiceVO;
	}

	public void setInvoiceVO(InvMatchingVO invoiceVO) {
		this.invoiceVO = invoiceVO;
	}

	public ArrayList<AlertMessagesVO> getErrorList() {
		return errorList;
	}

	public void setErrorList(ArrayList<AlertMessagesVO> errorList) {
		this.errorList = errorList;
	}

	String mode;

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public ArrayList<InvMatchingVO> getEventList() {
		return eventList;
	}

	public void setEventList(ArrayList<InvMatchingVO> eventList) {
		this.eventList = eventList;
	}

	public List<InvMatchingVO> getGetdebitParty() {
		return getdebitParty;
	}

	public void setGetdebitParty(List<InvMatchingVO> getdebitParty) {
		this.getdebitParty = getdebitParty;
	}

	public List<InvMatchingVO> getGetcounterParty() {
		return getcounterParty;
	}

	public void setGetcounterParty(List<InvMatchingVO> getcounterParty) {
		this.getcounterParty = getcounterParty;
	}

	public ArrayList<InvMatchingDataVO> getStoreInvData() {
		return storeInvData;
	}

	public void setStoreInvData(ArrayList<InvMatchingDataVO> storeInvData) {
		this.storeInvData = storeInvData;
	}

	// InvMatchingVO invMatchingVO = null;

	public ArrayList<InvMatchingVO> getTiListDetail() {
		return tiListDetail;
	}

	public void setTiListDetail(ArrayList<InvMatchingVO> tiListDetail) {
		this.tiListDetail = tiListDetail;
	}

	public InvMatchingVO getInvMatchingVO() {
		return invMatchingVO;
	}

	public void setInvMatchingVO(InvMatchingVO invMatchingVO) {
		this.invMatchingVO = invMatchingVO;
	}

	// PDF download (Aug 7 2019) starts

	String contentDisposition;
	ByteArrayInputStream inputStream;

	public String getContentDisposition() {
		return contentDisposition;
	}

	public void setContentDisposition(String contentDisposition) {
		this.contentDisposition = contentDisposition;
	}

	public ByteArrayInputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(ByteArrayInputStream inputStream) {
		this.inputStream = inputStream;
	}

	// PDF download (Aug 7 2019) ends

	/**
	 * 
	 * @return
	 */
	public static InvoiceCustomerAction getACTION() {
		InvoiceCustomerAction bd = null;
		if (bd == null) {
			bd = new InvoiceCustomerAction();
		}
		return bd;
	}

	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 */
	public String landingPage() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		allocationTypeList = fetchAllocationTypeList();
		repayByList = fetchRepayByList();
		repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
		scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
		logger.info(ActionConstants.EXITING_METHOD);
		return SUCCESS;
	}

	public String lookUp() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess invProcess = null;
		InvMatchingVO invoiceVO = null;
		CommonMethods commonMethods = new CommonMethods();
		String programType = null;
		String repaymentAllocationType = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();
			invoiceVO = new InvMatchingVO();
			allocationTypeList = fetchAllocationTypeList();
			repayByList = fetchRepayByList();
			repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
			String invPrgId = invMatchingVO.getProgId();
			System.out.println("PROGRAM NO " + invPrgId);

			if (!commonMethods.isNull(invPrgId)) {
				invoiceVO.setProgId(invPrgId);
				invoiceVO = invProcess.gettingprogramId(invMatchingVO);
				invMatchingVO.setDebitPartyFullName(invoiceVO
						.getAnchorFullName().trim());
				invoiceVO.setProgId(invPrgId);
				getcounterParty = invProcess.gettingcounterId(invoiceVO);
				setGetcounterParty(getcounterParty);
				programType = invProcess.getProgramType(invPrgId);
				allocationTypeList = fetchAllocationTypeList(programType);
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(
									invPrgId.trim(), invMatchingVO
											.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invPrgId.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
				invoiceVO.setRepaymentAllocationType(repaymentAllocationType);
				// allocationTypeList=fetchAllocationTypeList();
			}

			// allocationTypeList = fetchAllocationTypeList();
			setCounterParty(REC);
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
			/*
			 * bd=new MakerHomeBD(); makervo=bd.getPrgID(makervo);
			 * System.out.println(makervo.getProgID());
			 */
		} catch (Exception e) {
			throwApplicationException(e);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings("static-access")
	public String accountUp() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess invProcess = null;
		InvMatchingVO invoiceVO = null;
		CommonMethods commonMethods = new CommonMethods();
		String programType = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();
			invoiceVO = new InvMatchingVO();
			allocationTypeList = fetchAllocationTypeList();
			repayByList = fetchRepayByList();
			repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
			String invPrgId = invMatchingVO.getProgId();
			System.out.println("PROGRAM NO " + invPrgId);
			if (commonMethods.isNull(invMatchingVO.getRepaymentTC())) {
				invMatchingVO.setRepaymentTC("HBU");
			}
			if (!commonMethods.isNull(invPrgId)) {
				invoiceVO.setProgId(invPrgId);
				getcounterParty = invProcess.gettingcounterId(invMatchingVO);
				setGetcounterParty(getcounterParty);
				programType = invProcess.getProgramType(invPrgId);
				if (programType != null && programType.equalsIgnoreCase("S")) {
					invMatchingVO
							.setDueDateFilter(invProcess.fetchTXNDueDate());
				} else {
					// invMatchingVO.setRepayType("FC");
				}
				allocationTypeList = fetchAllocationTypeList(programType);
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(
									invPrgId.trim(), invMatchingVO
											.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invPrgId.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
			}
			String virtualNo = commonMethods.fetchVirtualAccountNo(invPrgId,
					invMatchingVO.getCounterParty().trim());
			invMatchingVO.setVirtualAccount(virtualNo);
			setCounterParty(REC);
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
		} catch (Exception e) {
			throwApplicationException(e);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return SUCCESS;
	}

	public String custListCancel() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess updatebd = null;
		InvMatchingVO invoiceVO = null;
		CommonMethods commonMethods = new CommonMethods();
		String programType = null;
		try {
			invoiceVO = new InvMatchingVO();
			updatebd = InvoiceMatchingProcess.getBD();
			scfExposure = ActionConstants.SCF_EXPOSURE;
			allocationTypeList = fetchAllocationTypeList();
			repayByList = fetchRepayByList();
			repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();

			String invPrgId = invMatchingVO.getProgId();
			System.out.println("PROGRAM NO " + invPrgId);

			if (!commonMethods.isNull(invPrgId)
					&& !invPrgId.equalsIgnoreCase("")) {
				invoiceVO.setProgId(invPrgId);
				getcounterParty = updatebd.gettingcounterId(invoiceVO);
				setGetcounterParty(getcounterParty);
				programType = updatebd.getProgramType(invPrgId);
				allocationTypeList = fetchAllocationTypeList(programType);
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(
									invPrgId.trim(), invMatchingVO
											.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invPrgId.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
			} else {
				getcounterParty = updatebd.gettingcounterId(invoiceVO);
				setGetcounterParty(getcounterParty);
				setCounterParty(REC);
			}
			scfProductType = ActionConstants.SCF_PRODUCT_TYPE;
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	public String accountListCancelMaker() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess updatebd = null;
		InvMatchingVO invoiceVO = null;
		CommonMethods commonMethods = new CommonMethods();
		String programType = null;
		try {
			invoiceVO = new InvMatchingVO();
			updatebd = InvoiceMatchingProcess.getBD();
			scfExposure = ActionConstants.SCF_EXPOSURE;
			allocationTypeList = fetchAllocationTypeList();
			repayByList = fetchRepayByList();
			repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();

			String invPrgId = invMatchingVO.getProgId();
			System.out.println("PROGRAM NO " + invPrgId);

			if (!commonMethods.isNull(invPrgId)) {
				invoiceVO.setProgId(invPrgId);
				getcounterParty = updatebd.gettingcounterId(invoiceVO);
				setGetcounterParty(getcounterParty);
				programType = updatebd.getProgramType(invPrgId);
				allocationTypeList = fetchAllocationTypeList(programType);
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(
									invPrgId.trim(), invMatchingVO
											.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invPrgId.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
			} else {
				getcounterParty = updatebd.gettingcounterId(invoiceVO);
				setGetcounterParty(getcounterParty);
				setCounterParty(REC);
			}

			scfProductType = ActionConstants.SCF_PRODUCT_TYPE;
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	private ArrayList<KeyValuePair> fetchRepayByList()
			throws ApplicationException {
		ArrayList<KeyValuePair> list = null;
		try {
			list = new ArrayList<KeyValuePair>();

			KeyValuePair temp = new KeyValuePair();
			temp.setKeyId("A");
			temp.setKeyValue("ANCHOR");
			list.add(temp);

			temp = new KeyValuePair();
			temp.setKeyId("C");
			temp.setKeyValue("Counter Party");
			list.add(temp);

		} catch (Exception e) {

			throwApplicationException(e);

		}
		return list;
	}

	private ArrayList<KeyValuePair> fetchAllocationTypeList()
			throws ApplicationException {
		ArrayList<KeyValuePair> list = null;
		try {
			list = new ArrayList<KeyValuePair>();

			KeyValuePair temp = new KeyValuePair();
			temp.setKeyId("MF");
			temp.setKeyValue("Due Date");
			list.add(temp);

			temp = new KeyValuePair();
			temp.setKeyId("MD");
			temp.setKeyValue("Due Date");
			list.add(temp);

			/*
			 * temp = new KeyValuePair(); temp.setKeyId("U");
			 * temp.setKeyValue("Upload"); list.add(temp);
			 */

		} catch (Exception e) {

			throwApplicationException(e);

		}
		return list;
	}

	private ArrayList<KeyValuePair> fetchAllocationTypeList(String programType)
			throws ApplicationException {
		ArrayList<KeyValuePair> list = null;
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			list = new ArrayList<KeyValuePair>();

			KeyValuePair temp = new KeyValuePair();
			if (!commonMethods.isNull(programType)
					&& programType.equals(ActionConstants.S)) {
				temp.setKeyId("MF");
				temp.setKeyValue("Due Date");
				list.add(temp);
			}
			if (!commonMethods.isNull(programType)
					&& programType.equals(ActionConstants.B)) {
				temp = new KeyValuePair();
				temp.setKeyId("MD");
				temp.setKeyValue("Due Date");
				list.add(temp);
			}
			if (commonMethods.isNull(programType)) {
				temp.setKeyId("MF");
				temp.setKeyValue("Due Date");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("MD");
				temp.setKeyValue("Due Date");
				list.add(temp);
			}
			/*
			 * temp = new KeyValuePair(); temp.setKeyId("U");
			 * temp.setKeyValue("Upload"); list.add(temp);
			 */

		} catch (Exception e) {

			throwApplicationException(e);

		}
		return list;
	}

	private ArrayList<KeyValuePair> fetchRepaymentAllocationTypeList()
			throws ApplicationException {
		ArrayList<KeyValuePair> list = null;
		try {
			list = new ArrayList<KeyValuePair>();

			KeyValuePair temp = new KeyValuePair();

			temp.setKeyId("INV");
			temp.setKeyValue("INV");
			list.add(temp);
			temp = new KeyValuePair();
			temp.setKeyId("CIP");
			temp.setKeyValue("CIP");
			list.add(temp);
			temp = new KeyValuePair();
			temp.setKeyId("PAIC");
			temp.setKeyValue("PAIC");
			list.add(temp);
		} catch (Exception e) {

			throwApplicationException(e);

		}
		return list;
	}

	private ArrayList<KeyValuePair> fetchRepaymentAllocationList(String type)
			throws ApplicationException {
		ArrayList<KeyValuePair> list = null;
		try {
			list = new ArrayList<KeyValuePair>();

			KeyValuePair temp = new KeyValuePair();
			if (type != null && type.equalsIgnoreCase("INV")) {
				temp.setKeyId("INV");
				temp.setKeyValue("INV");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("CIP");
				temp.setKeyValue("CAIP");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("PAIC");
				temp.setKeyValue("PAIC");
				list.add(temp);
			} else if (type != null && type.equalsIgnoreCase("CAIP")) {
				temp.setKeyId("CIP");
				temp.setKeyValue("CAIP");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("INV");
				temp.setKeyValue("INV");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("PAIC");
				temp.setKeyValue("PAIC");
				list.add(temp);
			} else {
				temp.setKeyId("");
				temp.setKeyValue("<------>");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("INV");
				temp.setKeyValue("INV");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("CIP");
				temp.setKeyValue("CAIP");
				list.add(temp);
				temp = new KeyValuePair();
				temp.setKeyId("PAIC");
				temp.setKeyValue("PAIC");
				list.add(temp);
			}

		} catch (Exception e) {

			throwApplicationException(e);

		}
		return list;
	}

	/**
	 * 
	 * @throws ApplicationException
	 * @throws IOException
	 */
	public String fetchDebitParty() throws ApplicationException, IOException {

		InvoiceMatchingProcess invProcess = null;
		InvMatchingVO invoiceVO = null;
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			invoiceVO = new InvMatchingVO();
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}

			String invPrgId = invMatchingVO.getProgId();
			System.out.println("PROGRAM NO " + invPrgId);

			if (!commonMethods.isNull(invPrgId)) {
				invoiceVO.setProgId(invPrgId);

				invoiceVO = invProcess.gettingprogramId(invoiceVO);

				invoiceVO.setProgId(invMatchingVO.getProgId());
				invMatchingVO.setDebitParty(invoiceVO.getAnchorName());
				invMatchingVO.setAnchorName(invoiceVO.getAnchorName());
				invMatchingVO.setDebitPartyFullName(invoiceVO
						.getAnchorFullName());
				// setGetdebitParty(getdebitParty);

				getcounterParty = invProcess.gettingcounterId(invoiceVO);

				setGetcounterParty(getcounterParty);
				allocationTypeList = fetchAllocationTypeList();
				// repaymentAllocationTypeList =
				// fetchRepaymentAllocationTypeList();
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(
									invPrgId.trim(), invMatchingVO
											.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invPrgId.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
				scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
			}
			repayByList = fetchRepayByList();
		} catch (Exception e) {

			throwApplicationException(e);

		}
		return SUCCESS;
	}

	public String programmeList() {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess bd = null;
		try {
			System.out.println("Enter action");
			bd = InvoiceMatchingProcess.getBD();
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			programList = bd.getProgrammeList(invMatchingVO);
			setProgramList(programList);

		} catch (Exception e) {
			System.out.println(e);
		}

		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}

	public String accountSelection() {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingProcess bd = null;
		try {
			bd = InvoiceMatchingProcess.getBD();
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			String progId = invMatchingVO.getProgId();
			String debitparty = invMatchingVO.getDebitParty();
			String counterparty = invMatchingVO.getCounterParty();
			String mode = invMatchingVO.getRepaymentMode();
			String valueDate = invMatchingVO.getValueDate();
			String payAmount = invMatchingVO.getPayAmount();
			String allocationType = invMatchingVO.getAllocationType();
			String repaymentAllocationType = invMatchingVO
					.getRepaymentAllocationType();
			accountList = bd.getAccountList(invMatchingVO);
			setAccountList(accountList);
			invMatchingVO.setProgId(progId);
			invMatchingVO.setDebitParty(debitparty);
			
			invMatchingVO.setCounterParty(counterparty);
			
			invMatchingVO.setRepaymentMode(mode);
			
			invMatchingVO.setValueDate(valueDate);
			invMatchingVO.setPayAmount(payAmount);
			invMatchingVO.setAllocationType(allocationType);
			invMatchingVO.setRepaymentAllocationType(repaymentAllocationType);

		} catch (Exception e) {
			System.out.println(e);
		}

		logger.info(ActionConstants.EXITING_METHOD);
		return SUCCESS;
	}

	/**
	 * 
	 * @throws ApplicationException
	 * @throws IOException
	 */
	public String fetchCounterParty() throws ApplicationException, IOException {

		InvoiceMatchingProcess invProcess = null;
		InvMatchingVO invoiceVO = null;
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			invoiceVO = new InvMatchingVO();
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}

			String invPrgId = invMatchingVO.getProgId();
			String invDebit = invMatchingVO.getDebitParty();
			System.out.println("debit party " + invDebit);
			System.out.println("PROGRAM NO " + invPrgId);

			if (!commonMethods.isNull(invPrgId)) {
				invoiceVO.setProgId(invPrgId);
				invoiceVO.setDebitParty(invDebit);

				invoiceVO = invProcess.gettingprogramId(invoiceVO);
				// setGetdebitParty(getdebitParty);
				getcounterParty = invProcess.gettingcounterId(invoiceVO);
				setGetcounterParty(getcounterParty);
				allocationTypeList = fetchAllocationTypeList();
				// repaymentAllocationTypeList =
				// fetchRepaymentAllocationTypeList();
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(
									invPrgId.trim(), invMatchingVO
											.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invPrgId.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
				scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
			}
			repayByList = fetchRepayByList();
		} catch (Exception e) {

			throwApplicationException(e);

		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String getInvoiceMatchingValue() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		HttpServletRequest request = ServletActionContext.getRequest();
		System.out.println("test invoicematching");
		InvoiceMatchingProcess invProcess = null;
		String programType = null;
		CommonMethods commonMethods = null;
		HttpSession httpSession = null;
		try {
			commonMethods = new CommonMethods();
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			invProcess = InvoiceMatchingProcess.getBD();
			System.out.println(invMatchingVO.getTempPrgType());
			if (!commonMethods.isNull(invMatchingVO.getBatch_ID())) {
				httpSession = ServletActionContext.getRequest().getSession();
				String userID = (String) httpSession.getAttribute(LOGINUSER);
				commonMethods.updateApproveReject(invMatchingVO.getBatch_ID(),
						MR, userID);
			}
			invMatchingVO = invProcess.getValidate(invMatchingVO);
			errorList = invMatchingVO.getErrorList();
			warningList = invMatchingVO.getWarningList();
			if (invMatchingVO != null) {
				if (null == errorList || errorList.isEmpty()) {
					invMatchingVO = invProcess.getDataFromTI(invMatchingVO);
				}
				tiListDetail = invMatchingVO.getInvoicList();
				setGetdebitParty(getdebitParty);
				getcounterParty = invProcess.gettingcounterId(invMatchingVO);
				setGetcounterParty(getcounterParty);
				setAllocationType(invMatchingVO.getAllocationType());
				programType = invProcess.getProgramType(invMatchingVO
						.getProgId());
				allocationTypeList = fetchAllocationTypeList(programType);
				repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(invMatchingVO
									.getProgId().trim(), invMatchingVO
									.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invMatchingVO.getProgId()
									.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
				batchId = invMatchingVO.getBatchID();
			}
			repayByList = fetchRepayByList();
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String fetchInvoiceMatching() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		HttpServletRequest request = ServletActionContext.getRequest();
		System.out.println("inside invoicematching");
		
		InvoiceMatchingProcess invProcess = null;
		String programType = null;
		CommonMethods commonMethods = null;
		HttpSession httpSession = null;
		try {
			commonMethods = new CommonMethods();
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			invProcess = InvoiceMatchingProcess.getBD();
			System.out.println(invMatchingVO.getTempPrgType());
			if (!commonMethods.isNull(invMatchingVO.getBatch_ID())) {
				httpSession = ServletActionContext.getRequest().getSession();
				String userID = (String) httpSession.getAttribute(LOGINUSER);
				commonMethods.updateApproveReject(invMatchingVO.getBatch_ID(),
						MR, userID);
			}
			invMatchingVO = invProcess.getValidate(invMatchingVO);
			errorList = invMatchingVO.getErrorList();
			warningList = invMatchingVO.getWarningList();
			if (invMatchingVO != null) {
				if (null == errorList || errorList.isEmpty()) {
					invMatchingVO = invProcess.getDataFromTI(invMatchingVO);
				}
				tiListDetail = invMatchingVO.getInvoicList();
				setGetdebitParty(getdebitParty);
				getcounterParty = invProcess.gettingcounterId(invMatchingVO);
				setGetcounterParty(getcounterParty);
				setAllocationType(invMatchingVO.getAllocationType());
				programType = invProcess.getProgramType(invMatchingVO
						.getProgId());
				allocationTypeList = fetchAllocationTypeList(programType);
				repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(invMatchingVO
									.getProgId().trim(), invMatchingVO
									.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invMatchingVO.getProgId()
									.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
				batchId = invMatchingVO.getBatchID();
			}
			repayByList = fetchRepayByList();
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	public String getPenalMatchingValue() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);
			invMatchingVO = invProcess.fetchPenalDetails(invMatchingVO);
			if (invMatchingVO != null) {
				invoiceList = invMatchingVO.getTiList();
			}
			setInvoiceList(invoiceList);
			//System.out.println("After fetch virtual account"+invoiceList.get(0).getVirtualAccount());
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 12Feb
	public String chargeDetailFetch() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);
			invMatchingVO = invProcess.fetchChargePenalDetails(invMatchingVO);
			if (invMatchingVO != null) {
				invoiceList = invMatchingVO.getTiList();
			}
			setInvoiceList(invoiceList);
			errorList = new ArrayList<AlertMessagesVO>();
			setErrorList(errorList);
			warningList = new ArrayList<AlertMessagesVO>();
			setWarningList(warningList);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 04Feb
	public String getBatchListCheck() throws Exception {
		batchList = new ArrayList<InvBatchVO>();

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);

			if (invMatchingVO != null) {
				invMatchingVO = invProcess.getBatchList(invMatchingVO);
				batchList = invMatchingVO.getBatchList();
				setBatchList(batchList);
			}
			invoiceList = new ArrayList<InvMatchingVO>();
			setInvoiceList(invoiceList);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 04Feb
	public String getPenalValueCheck() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);
			invMatchingVO = invProcess.fetchPenalDetailsCheck(invMatchingVO);
			if (invMatchingVO != null) {
				invoiceList = invMatchingVO.getTiList();
			}
			setInvoiceList(invoiceList);

		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 04Feb
	public String viewList() throws Exception {
		try {
			invMatchingVO = new InvMatchingVO();
			batchList = new ArrayList<InvBatchVO>();
			invoiceList = new ArrayList<InvMatchingVO>();
		} catch (Exception e) {
		}
		return SUCCESS;
	}

	// 04Feb
	public String getBatchListView() throws Exception {
		batchList = new ArrayList<InvBatchVO>();

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);

			if (invMatchingVO != null) {
				invMatchingVO = invProcess.getBatchListView(invMatchingVO);
				batchList = invMatchingVO.getBatchList();
				setBatchList(batchList);
			}
			invoiceList = new ArrayList<InvMatchingVO>();
			setInvoiceList(invoiceList);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 11Feb
	public String chargeViewList() throws Exception {
		try {
			invMatchingVO = new InvMatchingVO();
			batchList = new ArrayList<InvBatchVO>();
			invoiceList = new ArrayList<InvMatchingVO>();
		} catch (Exception e) {
		}
		return SUCCESS;
	}

	// 11Feb
	public String getBulkUploadBatchListView() throws Exception {
		batchList = new ArrayList<InvBatchVO>();

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		InvoiceMatchingProcess invProcess = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);

			if (invMatchingVO != null) {
				invMatchingVO = invProcess
						.getBulkUploadBatchListView(invMatchingVO);
				batchList = invMatchingVO.getBatchList();
				setBatchList(batchList);
			}
			invoiceList = new ArrayList<InvMatchingVO>();
			setInvoiceList(invoiceList);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	public String confirmFetchData() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		System.out.println("test invoicematching");
		InvoiceMatchingProcess invProcess = null;
		String BatchID = "";
		int count=0;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
/*			System.out.println("Virtual Account Number" + virtualAccNo);
			System.out.println("After fetch virtual account"+invoiceList.get(0).getVirtualAccount());*/
			int size = invoiceList.size();
			System.out.println("list size" + size);
			BatchID = invProcess.insertFetchData(invoiceList, virtualAccNo);// 04Feb
			invMatchingVO.setBatchIDSeq(BatchID);
			count=invProcess.fetchBatchIdCount(BatchID);
		//	System.out.println("BatchID_Count-->" +count);
			if(count<=0)
			{
				return "error";
			}
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 12Feb
	public String confirmChargeData() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		InvoiceMatchingProcess invProcess = null;
		String BatchID = "";
		try {
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();

			int size = invoiceList.size();
			System.out.println("list size" + size);
			BatchID = invProcess.confirmChargeData(invoiceList, virtualAccNo);
			invMatchingVO.setBatchIDSeq(BatchID);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 04Feb
	public String confirmDataChecker() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		System.out.println("test invoicematching");
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);

			int size = invoiceList.size();
			System.out.println("list size" + size);

			String batchIDSeq = invMatchingVO.getBatchIDSeq();
			System.out.println("Batch ID Sequence " + batchIDSeq);
			if (batchIDSeq != null && batchIDSeq.trim().length() > 0)
				invProcess.confirmDataChecker(invoiceList, batchIDSeq);

		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 04Feb
	public String rejectDataChecker() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		System.out.println("test invoicematching");
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);

			int size = invoiceList.size();
			System.out.println("list size" + size);

			String batchIDSeq = invMatchingVO.getBatchIDSeq();
			System.out.println("Batch ID Sequence " + batchIDSeq);
			if (batchIDSeq != null && batchIDSeq.trim().length() > 0)
				invProcess.rejectDataChecker(invoiceList, batchIDSeq);

		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 11Feb
	public String getChargesBatchListCheck() throws Exception {
		batchList = new ArrayList<InvBatchVO>();

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		System.out.println("test invoicematching");
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);

			if (invMatchingVO != null) {
				invMatchingVO = invProcess
						.getChargesBatchListCheck(invMatchingVO);
				batchList = invMatchingVO.getBatchList();
				setBatchList(batchList);
			}
			invoiceList = new ArrayList<InvMatchingVO>();
			setInvoiceList(invoiceList);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 11Feb
	public String getBulkUploadValueCheck() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		System.out.println("test invoicematching");
		InvoiceMatchingProcess invProcess = null;
		try {
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			setGetdebitParty(getdebitParty);
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);

			String virtualAccNo = invMatchingVO.getVirtualAccount();
			System.out.println("Virtual Account Number" + virtualAccNo);
			invMatchingVO = invProcess.getBulkUploadValueCheck(invMatchingVO);
			if (invMatchingVO != null) {
				invoiceList = invMatchingVO.getTiList();
			}
			setInvoiceList(invoiceList);

		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	// 11Feb
	public String bulkUploadApprove() throws Exception {
		InvoiceMatchingProcess invProcess = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();

			String batchIDSeq = invMatchingVO.getBatchIDSeq();

			if (batchIDSeq != null && batchIDSeq.trim().length() > 0)
				invProcess.bulkUploadApprove(invoiceList, batchIDSeq);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}

	// 11Feb
	public String bulkUploadReject() throws Exception {
		InvoiceMatchingProcess invProcess = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();

			String batchIDSeq = invMatchingVO.getBatchIDSeq();

			if (batchIDSeq != null && batchIDSeq.trim().length() > 0)
				invProcess.bulkUploadReject(invoiceList, batchIDSeq);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String checker() throws Exception {
		HttpSession httpSession = null;
		InvoiceMatchingProcess invProcess = null;
		Map session = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();
			httpSession = ServletActionContext.getRequest().getSession();
			httpSession.setAttribute(SESSION_ROLE, CHECKER);
			httpSession.removeAttribute(LOGINUSER);
			httpSession.removeAttribute(REJECTLIST);
			invProcess.setDate();
			invProcess.isSessionAvailable();
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			// setGetcounterParty(REC);
			allocationTypeList = fetchAllocationTypeList();
			repayByList = fetchRepayByList();
			repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
			// invProcess.setDate();
			invMatchingVO.setProgrammeidentifier("");
			invMatchingVO.setValueDate("");
			invMatchingVO.setDebitParty("");
			invMatchingVO.setPayAmount("");
			invMatchingVO.setCounterParty("");
			invMatchingVO.setAllocationType("");
			invMatchingVO.setRepaymentMode("");
			invMatchingVO.setRepaymentAllocationType("");
			invMatchingVO.setPayAccount("");
			invMatchingVO.setReferenceNumber("");
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
			session = ActionContext.getContext().getSession();
			session.remove(SESSION_KEY);
			session.remove(SESSION_ID);
			session.put(CLOSE_URL, SystemPropertiesUtil.fetchCloseURL());

		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	private int checkPaymentValidation(ArrayList<InvMatchingVO> tiListsDetail2,
			String paymentAmount) {
		// TODO Auto-generated method stub
		int flag = 1;
		int checkPayment = 0;
		int checkLoop = 0;
		BigDecimal amount = new BigDecimal(0);
		BigDecimal paymentAmt = new BigDecimal(
				CommonMethods.removeComma(paymentAmount));
		if (tiListsDetail2 != null && tiListsDetail2.size() > 0) {
			for (int i = 0; i < tiListsDetail2.size(); i++) {
				if (CommonMethods.findDouble(CommonMethods
						.removeComma(tiListsDetail2.get(i).getAllocAmt()))
						|| CommonMethods.findDouble(CommonMethods
								.removeComma(tiListsDetail2.get(i)
										.getOutAmount()))) {
					// invalid os amt
					AlertMessagesVO altMsg = new AlertMessagesVO();
					altMsg.setErrorId("Error");
					altMsg.setErrorDesc("General");
					altMsg.setErrorCode("Input");
					altMsg.setErrorDetails("Invalid Outstanding Amount");
					altMsg.setErrorMsg("");
					alertMsgArray.add(altMsg);
					flag = 0;
					break;
				} else {
					checkLoop = 1;

					BigDecimal osAmt = null;
					BigDecimal payAmt = null;
					BigDecimal tdsAmount = null;
					BigDecimal chargeAmount = null;
					System.out.println("Outstanding Amount-->"
							+ CommonMethods.nullAndTrimNumber(tiListsDetail2
									.get(i).getOutAmount()));
					osAmt = new BigDecimal(
							CommonMethods.removeComma(CommonMethods
									.nullAndTrimNumber(tiListsDetail2.get(i)
											.getOutAmount())));
					System.out.println("Allocate Amount-->"
							+ CommonMethods.nullAndTrimNumber(tiListsDetail2
									.get(i).getAllocAmt()));
					payAmt = new BigDecimal(
							CommonMethods.removeComma(CommonMethods
									.nullAndTrimNumber(tiListsDetail2.get(i)
											.getAllocAmt())));
					tdsAmount = new BigDecimal(
							CommonMethods.removeComma(CommonMethods
									.nullAndTrimNumber(tiListsDetail2.get(i)
											.getTdsAmount())));
					chargeAmount = new BigDecimal(
							CommonMethods.removeComma(CommonMethods
									.nullAndTrimNumber(tiListsDetail2.get(i)
											.getChargesOutstanding())));
					if (payAmt.compareTo(BigDecimal.ZERO) > 0) {
						/* payAmt = payAmt.add(tdsAmount); */
						paymentAmt = paymentAmt.add(tdsAmount);
						osAmt = osAmt.add(chargeAmount);
					}
					amount = amount.add(payAmt);
					// if ( < payAmt)
					if (osAmt.compareTo(payAmt) < 0) {
						checkPayment = 1;
						System.out.println(osAmt + "and " + payAmt);
					}
				}
			}
			if (checkLoop == 1
					&& !CommonMethods.bitwiseEqualsWithCanonicalNaN1(amount,
							paymentAmt)) {
				AlertMessagesVO altMsg = new AlertMessagesVO();
				altMsg.setErrorId("Error");
				altMsg.setErrorDesc("General");
				altMsg.setErrorCode("Input");
				altMsg.setErrorDetails("Payment Amount And sum of Allocated Amount are mismatched");
				altMsg.setErrorMsg("");
				alertMsgArray.add(altMsg);
				flag = 0;
			}
			if (checkPayment == 1) {
				AlertMessagesVO altMsg = new AlertMessagesVO();
				altMsg.setErrorId("Error");
				altMsg.setErrorDesc("General");
				altMsg.setErrorCode("Input");
				altMsg.setErrorDetails("Allocated Amount should not be greater than Outstanding amount");
				altMsg.setErrorMsg("");
				alertMsgArray.add(altMsg);
				flag = 0;
			}
			errorList = alertMsgArray;
		} else {
			flag = 0;
		}
		return flag;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String checkerefresh() throws Exception {
		InvoiceMatchingProcess invProcess = null;
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			invProcess = InvoiceMatchingProcess.getBD();
			invoiceDetails = invProcess.fetchInvoiceBatches(invMatchingVO);
			invMatchingVO.setTempRemarks("");
			invMatchingVO.setProgrammeidentifier("");
			invMatchingVO.setDebitParty("");
			invMatchingVO.setCounterParty("");
			invMatchingVO.setRepaymentMode("");
			invMatchingVO.setPayAmount("");
			invMatchingVO.setPayAccount("");
			invMatchingVO.setValueDate("");
			invMatchingVO.setAllocationType("");
			invMatchingVO.setRepaymentAllocationType("");
			invMatchingVO.setReferenceNumber("");
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	/*
	 * public String invoiceDetailList() throws Exception {
	 * InvoiceMatchingProcess invProcess = null; CommonMethods commonMethods =
	 * null; try { commonMethods = new CommonMethods(); if (invMatchingVO ==
	 * null) { invMatchingVO = new InvMatchingVO(); } invProcess =
	 * InvoiceMatchingProcess.getBD(); invoiceAjaxDetails = invProcess
	 * .fetchDetailedBatch(invoiceAjaxListval); } catch (Exception e) {
	 * throwApplicationException(e); } return SUCCESS; }
	 */
	public String confirmPenalFetch() throws Exception {
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		InvoiceMatchingProcess invProcess = null;
		HttpSession httpSession = null;
		String projectType = null;
		try {

			httpSession = ServletActionContext.getRequest().getSession();
			projectType = (String) httpSession.getAttribute(SESSION_MANUAL);
			setTiListDetail(tiListDetail);

		} catch (Exception e) {
			throwApplicationException(e);
		}
		return "success";
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String confirmRepayment() throws Exception {
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		InvoiceMatchingProcess invProcess = null;
		int checkVal = 0;
		HttpSession httpSession = null;
		String projectType = null;
		String programType = null;
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			invProcess = InvoiceMatchingProcess.getBD();
			if (invMatchingVO != null) {
				invMatchingVO = invProcess.getConfirmValidate(invMatchingVO);
				errorList = invMatchingVO.getErrorList();
				repayByList = fetchRepayByList();
				setErrorList(errorList);
				httpSession = ServletActionContext.getRequest().getSession();
				projectType = (String) httpSession.getAttribute(SESSION_MANUAL);
				setTiListDetail(tiListDetail);
				setGetdebitParty(getdebitParty);
				getcounterParty = invProcess.gettingcounterId(invMatchingVO);
				setGetcounterParty(getcounterParty);
				setAllocationType(invMatchingVO.getAllocationType());
				programType = invProcess.getProgramType(invMatchingVO
						.getProgId());
				allocationTypeList = fetchAllocationTypeList(programType);
				repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(invMatchingVO
									.getProgId().trim(), invMatchingVO
									.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invMatchingVO.getProgId()
									.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
				scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
				if (null == errorList || errorList.isEmpty()) {
					if (projectType != null
							&& projectType.equalsIgnoreCase(MANUAL)) {
						if (invMatchingVO.getPayAmount() != null
								&& !invMatchingVO.getPayAmount().equals("")) {
							invMatchingVO = invProcess.getDealRefValidate(
									invMatchingVO, tiListDetail);
							errorList = invMatchingVO.getErrorList();
							setErrorList(errorList);
							if (null == errorList || errorList.isEmpty()) {
								invMatchingVO = invProcess
										.updateInvoicePayment(invMatchingVO,
												tiListDetail, getBatchId());
								String warningDetail = warningList.get(0)
										.getErrorDetails();
								if (warningDetail != null
										&& warningDetail.length() > 10) {
									warningDetail = warningDetail.substring(0,
											10);
								}
								if (!warningDetail
										.equalsIgnoreCase("Excess Amo")
										&& !warningDetail
												.equalsIgnoreCase("Warning - ")) {
									invMatchingVO = invProcess
											.getDealRefWarning(invMatchingVO,
													tiListDetail);
									warningList = invMatchingVO
											.getWarningList();
									errorList = invMatchingVO.getErrorList();
									setErrorList(errorList);
									if (null == errorList
											|| errorList.isEmpty()) {
										if (checkPaymentValidation(
												tiListDetail,
												invMatchingVO.getPayAmount()) == 1) {
											if (invMatchingVO != null) {
												invMatchingVO = invProcess
														.updateInvoicePayment(
																invMatchingVO,
																tiListDetail,
																getBatchId());
												if (null == warningList
														|| warningList
																.isEmpty()) {
													checkVal = 1;
												} else {
													checkVal = 0;
												}
											}
										}
									} else {
										checkVal = 0;
									}

								} else {
									warningList = null;
									checkPaymentValidation(tiListDetail,
											invMatchingVO.getPayAmount());
									if (invMatchingVO != null) {
										invMatchingVO = invProcess
												.updateInvoicePayment(
														invMatchingVO,
														tiListDetail,
														getBatchId());
										if (null == errorList
												|| errorList.isEmpty()) {
											checkVal = 1;
										} else {
											checkVal = 0;
										}

									}
								}
							} else {
								warningList = null;
							}

						}

						if (checkVal == 1) {
							tiListDetail = invMatchingVO.getInvoicList();
						} else {
							return "error";
						}

					}
					if (!commonMethods.isNull(invMatchingVO.getBatch_ID())) {
						String userID = (String) httpSession
								.getAttribute(LOGINUSER);
						commonMethods.updateApproveReject(
								invMatchingVO.getBatch_ID(), MA, userID);
						invProcess.insertMakerConfirm(invMatchingVO,
								getBatchId());
						return "maker";
					}

				}
			}
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */

	// thread

	public String approveRepayment() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);

		InvoiceMatchingProcess invProcess = null;
		CommonMethods commonMethods = null;
		String result = "threadSuccess";
		// String batchId = invMatchingVO.getBatchId();
		System.out.println("entered");
		try {
			commonMethods = new CommonMethods();

			invProcess = InvoiceMatchingProcess.getBD();
			String remarks = commonMethods.getEmptyIfNull(
					invMatchingVO.getTempRemarks()).trim();
			HttpSession httpSession = ServletActionContext.getRequest()
					.getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			invMatchingVO.setAppuserid(userID);
			invMatchingVO.setAppremark(remarks);
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}

			// HttpSession session = ServletActionContext.getRequest()
			// .getSession();
			// String userId = (String) session.getAttribute(LOGINUSER);

			Thread t = new Thread(new Runnable() {
				public void run() {

					try {

						checkerrepayment(invMatchingVO);

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			});
			t.start();
			return result;

		} catch (Exception exception) {
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return SUCCESS;
	}

	// thread

	public String checkerrepayment(InvMatchingVO invMatchingVO)
			throws Exception {
		InvoiceMatchingProcess invProcess = null;
		CommonMethods commonMethods = null;
		try {

			commonMethods = new CommonMethods();
			invProcess = InvoiceMatchingProcess.getBD();
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			invMatchingVO = invProcess.getCheckerValidate(invMatchingVO);
			errorList = invMatchingVO.getErrorList();
			setErrorList(errorList);
			if (null == errorList || errorList.isEmpty()) {
				String remarks = commonMethods.getEmptyIfNull(
						invMatchingVO.getTempRemarks()).trim();
				// HttpSession httpSession =
				// ServletActionContext.getRequest().getSession();
				String userID = invMatchingVO.getAppuserid();
				int i = commonMethods.updateApproveRejectRemark(batchId, CA,
						remarks, userID);
				if (i > 0) {
					invMatchingVO = invProcess.approveRePayment(batchId,
							invMatchingVO);
					// thread
					// tiListDetail = invMatchingVO.getInvoicList();
					// thread
				}
				/*
				 * invMatchingVO = invProcess.approveRePayment(batchId,
				 * invMatchingVO); String remarks =
				 * commonMethods.getEmptyIfNull(
				 * invMatchingVO.getTempRemarks()).trim(); HttpSession
				 * httpSession = ServletActionContext.getRequest().getSession();
				 * String userID = (String) httpSession.getAttribute(LOGINUSER);
				 * commonMethods.updateApproveRejectRemark(batchId,
				 * CA,remarks,userID); tiListDetail =
				 * invMatchingVO.getInvoicList();
				 */
			} else {
				invoiceDetails = invProcess.fetchInvoiceBatches(invMatchingVO);
			}
		} catch (BusinessException e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String rejectRepayment() throws Exception {
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			HttpSession httpSession = ServletActionContext.getRequest()
					.getSession();
			String userID = (String) httpSession.getAttribute(LOGINUSER);
			String remarks = commonMethods.getEmptyIfNull(
					invMatchingVO.getTempRemarks()).trim();
			commonMethods.updateApproveRejectRemark(batchId, CR, remarks,
					userID);
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String rejectedList() throws Exception {
		HttpSession httpSession = null;
		try {
			invMatchingVO = new InvMatchingVO();
			tiListDetail = null;
			httpSession = ServletActionContext.getRequest().getSession();
			httpSession.setAttribute(REJECTLIST, REJECT);
			httpSession.setAttribute(SESSION_ROLE, CHECKER);
			System.out.println(httpSession.getAttribute(LOGINUSER));
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String rejectedProgramList() throws Exception {
		HttpSession httpSession = null;
		try {
			if (invMatchingVO == null) {
				invMatchingVO = new InvMatchingVO();
			}
			invMatchingVO.setTempRemarks("");
			invMatchingVO.setProgrammeidentifier("");
			invMatchingVO.setDebitParty("");
			invMatchingVO.setCounterParty("");
			invMatchingVO.setRepaymentMode("");
			invMatchingVO.setPayAmount("");
			invMatchingVO.setPayAccount("");
			invMatchingVO.setValueDate("");
			invMatchingVO.setAllocationType("");
			invMatchingVO.setRepaymentAllocationType("");
			invMatchingVO.setReferenceNumber("");
			httpSession = ServletActionContext.getRequest().getSession();
			httpSession.setAttribute(REJECTLIST, REJECT);
			httpSession.setAttribute(SESSION_ROLE, CHECKER);
			System.out.println(httpSession.getAttribute(LOGINUSER));
		} catch (Exception e) {
			throwApplicationException(e);
		}
		return SUCCESS;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String processRepayment() throws Exception {

		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html");
		HttpServletRequest request = ServletActionContext.getRequest();

		// int i=0;
		InvoiceMatchingProcess invProcess = null;
		int checkVal = 0;
		HttpSession httpSession = null;
		String projectType = null;
		String programType = null;
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			System.out.println("entered");
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);

			invProcess = InvoiceMatchingProcess.getBD();
			if (invMatchingVO != null) {

				httpSession = ServletActionContext.getRequest().getSession();
				projectType = (String) httpSession.getAttribute(SESSION_MANUAL);

				if (projectType != null && projectType.equalsIgnoreCase(MANUAL)) {
					/* Manual */
					if (invMatchingVO.getPayAmount() != null
							&& !invMatchingVO.getPayAmount().equals("")) {
						if (checkPaymentValidation(tiListDetail,
								invMatchingVO.getPayAmount()) == 1) {
							if (invMatchingVO != null) {
								invMatchingVO = invProcess
										.updateInvoicePayment(invMatchingVO,
												tiListDetail, getBatchId());
								invMatchingVO = invProcess.processRePayment(
										batchId, invMatchingVO);
								checkVal = 1;
							}
						}
					}
					/* Manual */
					if (checkVal == 1) {
						tiListDetail = invMatchingVO.getInvoicList();
					} else {
						setTiListDetail(tiListDetail);
					}
				} else {
					invMatchingVO = invProcess.processRePayment(batchId,
							invMatchingVO);
					tiListDetail = invMatchingVO.getInvoicList();
				}

				setGetdebitParty(getdebitParty);
				getcounterParty = invProcess.gettingcounterId(invMatchingVO);
				setGetcounterParty(getcounterParty);
				setAllocationType(invMatchingVO.getAllocationType());
				programType = invProcess.getProgramType(invMatchingVO
						.getProgId());
				allocationTypeList = fetchAllocationTypeList(programType);
				repayByList = fetchRepayByList();
				repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(invMatchingVO
									.getProgId().trim(), invMatchingVO
									.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invMatchingVO.getProgId()
									.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
				scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
			}
		} catch (BusinessException e) {

			throwApplicationException(e);
		}

		return SUCCESS;

	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 */
	public InvMatchingVO processRepaymentWSDL1(InvMatchingVO invMatchingVO) {
		InvoiceMatchingProcess invProcess = null;
		String prgID = null;
		String programType = null;
		try {
			invProcess = InvoiceMatchingProcess.getBD();
			if (invMatchingVO != null) {
				prgID = invMatchingVO.getProgId().trim();
				programType = invProcess.getProgramType(prgID);
				invMatchingVO = invProcess.getWSDLValidate(invMatchingVO);
				errorList = invMatchingVO.getErrorList();
				if (null != errorList) {
					invMatchingVO.setError("error");
					return invMatchingVO;
				}
				/*
				 * if (programType != null && programType.equalsIgnoreCase("S"))
				 * { if (invMatchingVO.getCounterParty() == null ||
				 * invMatchingVO.getCounterParty() .equalsIgnoreCase("")) {
				 * invMatchingVO
				 * .setXml("Counter Party is mandatory for dealer finance");
				 * invMatchingVO.setError("error"); return invMatchingVO; } }
				 */
				// invMatchingVO = invProcess.getDataFromTI(invMatchingVO);
				invMatchingVO.setProjectType("WSDL");
				invMatchingVO = invProcess.getDataFromTI(invMatchingVO);
				invMatchingVO = invProcess.processRePayment(
						invMatchingVO.getBatchID(), invMatchingVO);

			}

		} catch (BusinessException e) {
			e.printStackTrace();
		}
		return invMatchingVO;
	}

	public String validateInvoiceMatchingData() throws ApplicationException {
		InvoiceMatchingProcess invProcess = null;
		CommonMethods commonMethods = null;
		Date sysdate = null;
		try {
			commonMethods = new CommonMethods();

			SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yy");

			Date date = new Date();
			Date valDate = null;
			System.out.println("System date " + date);
			invoiceVO = new InvMatchingVO();
			invProcess = InvoiceMatchingProcess.getBD();
			eventList = invProcess.gettingprogram();
			setEventList(eventList);
			String invPrgId = invMatchingVO.getProgId();
			String invDebit = invMatchingVO.getDebitParty();
			String invCounter = invMatchingVO.getCounterParty();
			String valueDate = invMatchingVO.getValueDate();
			String paymentAmt = invMatchingVO.getPayAmount();
			System.out.println("debit party " + invDebit);
			System.out.println("PROGRAM NO " + invPrgId);
			System.out.println("Counter Party" + invCounter);
			System.out.println("valueDate " + valueDate);
			System.out.println("paymentAmt " + paymentAmt);
			repayByList = fetchRepayByList();
			if (!commonMethods.isNull(invPrgId)) {
				invoiceVO.setProgId(invPrgId);
				invoiceVO.setDebitParty(invDebit);
				invoiceVO.setCounterParty(invCounter);
				invoiceVO.setValueDate(valueDate);
				invoiceVO.setPayAmount(paymentAmt);

				invoiceVO = invProcess.gettingprogramId(invoiceVO);
				// setGetdebitParty(getdebitParty);
				getcounterParty = invProcess.gettingcounterId(invoiceVO);
				setGetcounterParty(getcounterParty);
				allocationTypeList = fetchAllocationTypeList();
				repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
				String repaymentAllocationType = null;
				if (!commonMethods.isNull(invMatchingVO.getCounterParty())) {
					repaymentAllocationType = commonMethods
							.fetchCounterPartyAppropriationType(
									invPrgId.trim(), invMatchingVO
											.getCounterParty().trim());
				} else {
					repaymentAllocationType = commonMethods
							.fetchAppropriationType(invPrgId.trim());
				}
				if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("CAIP")) {
					repaymentAllocationType = "CIP";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else if (!commonMethods.isNull(repaymentAllocationType)
						&& repaymentAllocationType.equalsIgnoreCase("INV")) {
					repaymentAllocationType = "INV";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				} else {
					repaymentAllocationType = "";
					repaymentAllocationTypeList = fetchRepaymentAllocationList(repaymentAllocationType);
				}
			}
			if (alertMsgArray != null) {
				if (alertMsgArray.size() > 0) {
					alertMsgArray.clear();
				}
			}
			if (commonMethods.isNull(invoiceVO.getProgId())
					|| invoiceVO.getProgId().equalsIgnoreCase("-1")) {
				String errormsg = UtilityGenerateCard.getErrorDesc("INV01",
						"N140");
				Object arg[] = { 0, "E", errormsg, "Input" };
				setErrorvalues(arg);
			}
			/*
			 * if(commonMethods.isNull(invoiceVO.getDebitParty()) ||
			 * invoiceVO.getDebitParty().equalsIgnoreCase("-1")){ String
			 * errormsg=UtilityGenerateCard.getErrorDesc("INV02","N140"); Object
			 * arg[]={0,"E",errormsg,"Input"}; setErrorvalues(arg); }
			 */
			if (commonMethods.isNull(invoiceVO.getCounterParty())
					|| invoiceVO.getCounterParty().equalsIgnoreCase("-1")) {
				String errormsg = UtilityGenerateCard.getErrorDesc("INV03",
						"N140");
				Object arg[] = { 0, "E", errormsg, "Input" };
				setErrorvalues(arg);
			}
			if (commonMethods.isNull(invoiceVO.getPayAmount())) {
				String errormsg = UtilityGenerateCard.getErrorDesc("INV05",
						"N140");
				Object arg[] = { 0, "E", errormsg, "Input" };
				setErrorvalues(arg);
			}
			if (commonMethods.isNull(valueDate)
					|| commonMethods.isNull(invoiceVO.getValueDate())) {
				String errormsg = UtilityGenerateCard.getErrorDesc("INV04",
						"N140");
				Object arg[] = { 0, "E", errormsg, "Input" };
				setErrorvalues(arg);
			} else {
				valDate = format1.parse(valueDate);
				System.out.println("Value Date to validate " + valDate);
			}
			if (commonMethods.isNull(valueDate)) {
			} else {
				if (valDate.after(date)) {
					String errormsg = UtilityGenerateCard.getErrorDesc("INV06",
							"N140");
					Object arg[] = { 0, "E", errormsg, "Input" };
					setErrorvalues(arg);
				}
			}
			if (alertMsgArray.size() > 0) {
				invoiceVO.setErrorList(alertMsgArray);
				errorList = invoiceVO.getErrorList();
			}
		} catch (Exception e) {

			throwApplicationException(e);

		}
		return SUCCESS;
	}

	public void setErrorvalues(Object[] arg) {
		CommonMethods commonMethods = new CommonMethods();
		AlertMessagesVO altMsg = new AlertMessagesVO();
		altMsg.setErrorId("Error");
		altMsg.setErrorDesc("General");
		altMsg.setErrorCode(commonMethods.getEmptyIfNull(arg[3]));
		altMsg.setErrorDetails(commonMethods.getEmptyIfNull(arg[2]));
		altMsg.setErrorMsg("");
		alertMsgArray.add(altMsg);
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws ApplicationException
	 */
	public InvMatchingVO XMLToString(InvMatchingVO invMatchingVO)
			throws ParserConfigurationException, SAXException, IOException,
			ApplicationException {

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource is = new InputSource();
		String xmlMessage = invMatchingVO.getXml();
		is.setCharacterStream(new StringReader(xmlMessage));
		Document doc = db.parse(is);
		NodeList nodes = doc.getElementsByTagName("invoice");
		for (int i = 0; i < nodes.getLength(); i++) {
			Element element = (Element) nodes.item(i);
			String progID = element.getElementsByTagName("progID").item(0)
					.getTextContent();
			System.out.println("progID is " + progID);
			String counterParty = element.getElementsByTagName("counterParty")
					.item(0).getTextContent();
			System.out.println("counterParty is " + counterParty);

			String payAmount = element.getElementsByTagName("payAmount")
					.item(0).getTextContent();
			System.out.println("payAmount is " + payAmount);

			String valueDate = element.getElementsByTagName("valueDate")
					.item(0).getTextContent();
			System.out.println("valueDate is " + valueDate);

			String allocationType = element
					.getElementsByTagName("allocationType").item(0)
					.getTextContent();
			System.out.println("allocationType is " + allocationType);

			String debitParty = element.getElementsByTagName("debitParty")
					.item(0).getTextContent();
			System.out.println("debitParty is " + debitParty);

			String repaymentAllocationType = element
					.getElementsByTagName("repaymentAllocationType").item(0)
					.getTextContent();
			System.out.println("repaymentAllocationType is "
					+ repaymentAllocationType);

			String paymentAccount = element
					.getElementsByTagName("paymentAccount").item(0)
					.getTextContent();
			System.out.println("paymentAccount is " + paymentAccount);

			String referenceNumber = element
					.getElementsByTagName("referenceNumber").item(0)
					.getTextContent();
			System.out.println("referenceNumber is " + referenceNumber);

			invMatchingVO.setProgId(progID);
			invMatchingVO.setValueDate(valueDate);
			invMatchingVO.setDebitParty(debitParty);
			invMatchingVO.setPayAmount(payAmount);
			invMatchingVO.setCounterParty(counterParty);
			invMatchingVO.setAllocationType(allocationType);
			invMatchingVO.setRepaymentAllocationType(repaymentAllocationType);
			invMatchingVO.setPayAccount(paymentAccount);
			invMatchingVO.setReferenceNumber(referenceNumber);
			element.getElementsByTagName("status").item(0)
					.setTextContent("Success");

		}

		invMatchingVO = processRepaymentWSDL1(invMatchingVO);
		return invMatchingVO;
	}

	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 * @throws ParserConfigurationException
	 */
	public InvMatchingVO WriteXMLFileMTP(InvMatchingVO invMatchingVO)
			throws ParserConfigurationException {

		DocumentBuilderFactory docFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

		Document doc = docBuilder.newDocument();

		CommonMethods commonMethods = null;

		commonMethods = new CommonMethods();
		ArrayList<InvMatchingVO> val = invMatchingVO.getInvoicList();
		Element rootElement = doc.createElement("InvoiceFinance");
		doc.appendChild(rootElement);

		for (int i = 0; i < val.size(); i++) {
			Element rootElement1 = doc.createElement("invoice");
			rootElement.appendChild(rootElement1);

			Element loan_master_ref = doc.createElement("loan_master_ref");
			loan_master_ref.appendChild(doc.createTextNode(commonMethods
					.getEmptyIfNull(
							commonMethods.getEmptyIfNull(val.get(i)
									.getMasterRef())).trim()));
			rootElement1.appendChild(loan_master_ref);

			Element invoice_no = doc.createElement("invoice_no");
			invoice_no.appendChild(doc.createTextNode(commonMethods
					.getEmptyIfNull(val.get(i).getInvNumber()).trim()));
			rootElement1.appendChild(invoice_no);

			Element disbursement_date = doc.createElement("disbursement_date");
			disbursement_date.appendChild(doc.createTextNode(commonMethods
					.getEmptyIfNull(val.get(i).getDisburseDate()).trim()));
			rootElement1.appendChild(disbursement_date);

			Element due_date = doc.createElement("due_date");
			due_date.appendChild(doc.createTextNode(commonMethods
					.getEmptyIfNull(val.get(i).getDueDate()).trim()));
			rootElement1.appendChild(due_date);

			Element prc_allc_amount = doc.createElement("prc_allc_amount");
			prc_allc_amount.appendChild(doc.createTextNode(commonMethods
					.getEmptyIfNull(val.get(i).getAllocAmt()).trim()));
			rootElement1.appendChild(prc_allc_amount);

			Element os_amount = doc.createElement("os_amount");
			os_amount.appendChild(doc.createTextNode(commonMethods
					.getEmptyIfNull(val.get(i).getOutAmount()).trim()));
			rootElement1.appendChild(os_amount);

			String status = commonMethods.getEmptyIfNull(
					val.get(i).getGwStatus()).trim();
			if (status.equalsIgnoreCase("S")) {
				status = "Success";
			} else {
				status = "Failed";
			}
			Element gw_status = doc.createElement("gw_status");
			gw_status.appendChild(doc.createTextNode(status));
			rootElement1.appendChild(gw_status);

		}
		System.out.println("RESULTS SET" + convertDocumentToString(doc));
		invMatchingVO.setXml(convertDocumentToString(doc));
		return invMatchingVO;

	}

	/**
	 * 
	 * @param doc
	 * @return
	 */
	private static String convertDocumentToString(Document doc) {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer;
		try {
			transformer = tf.newTransformer();
			StringWriter writer = new StringWriter();
			transformer.transform(new DOMSource(doc), new StreamResult(writer));
			String output = writer.getBuffer().toString();
			return output;
		} catch (TransformerException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * 
	 * @return
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * 
	 * @param accountNumber
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String execute() {
		try {
			System.out.println("banklist" + invMatchingVO.getBankList());
			InvoiceMatchingProcess invProcess = InvoiceMatchingProcess.getBD();
			getcounterParty = invProcess.gettingcounterId(invMatchingVO);
			setGetcounterParty(getcounterParty);
			allocationTypeList = fetchAllocationTypeList();
			repayByList = fetchRepayByList();
			repaymentAllocationTypeList = fetchRepaymentAllocationTypeList();
			scfModeOfRepayment = ActionConstants.SCF_MODE_OF_REPAYMENT;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}

	@SuppressWarnings("static-access")
	public String fetchInvoiceDetails() {
		InvoiceMatchingProcess invProcess = InvoiceMatchingProcess.getBD();
		try {
			String invoice = invMatchingVO.getInvoiceNumber();
			String refDate = invMatchingVO.getRefDate();
			System.out.println("invoiceNumber " + invoice);
			System.out.println("ref date " + refDate);
			invoiceList = invProcess.fetchInvoiceDetails(invoice, refDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "success";
	}

	// PDF download (Aug 7 2019) starts
	public String downloadPdf() throws ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		ByteArrayOutputStream baos = null;
		PdfGenerator generator = null;
		String invoice = null;
		String refDate = null;
		try {
			InvoiceMatchingProcess invProcess = InvoiceMatchingProcess.getBD();
			generator = new PdfGenerator();
			invoice = invMatchingVO.getInvoiceNumber();
			refDate = invMatchingVO.getRefDate();
			logger.debug("Invoice Number : " + invoice);
			logger.debug("Date : " + refDate);
			// to fetch invoice details
			invoiceList = invProcess.fetchInvoiceDetails(invoice, refDate);
			baos = new ByteArrayOutputStream();
			// to write in pdf
			generator.writePdf(invoiceList, baos, invoice);
			String pdfFileName = "RepaymentSchedule(" + invoice + ")";
			inputStream = new ByteArrayInputStream(baos.toByteArray());
			setContentDisposition("attachment; filename=\"" + pdfFileName
					+ ".pdf\"");

		} catch (Exception e) {
			logger.error("Exception in downloadPdf method :" + e);
		} finally {
			try {
				if (baos != null) {
					baos.flush();
					baos.close();
				}

			} catch (Exception e) {
				logger.error("Exception in closing output stream :" + e);
			}

		}
		logger.info(ActionConstants.EXITING_METHOD);
		return SUCCESS;
	}
	// PDF download (Aug 7 2019) ends
}
