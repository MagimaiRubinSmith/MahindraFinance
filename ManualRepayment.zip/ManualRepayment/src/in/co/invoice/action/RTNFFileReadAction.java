package in.co.invoice.action;

import in.co.invoice.businessdelegate.exception.BusinessException;
import in.co.invoice.dao.exception.ApplicationException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.CommonMethods;
import in.co.invoice.vo.FileReadVO;
import in.co.stp.businessdelegate.RTNFFileReadBD;

import java.util.ArrayList;

import org.apache.log4j.Logger;

public class RTNFFileReadAction extends InvoiceBaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

	private static Logger logger = Logger.getLogger(RTNFFileReadAction.class
			.getName());
	
	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 */
	public String processInward() throws ApplicationException{
		ArrayList<FileReadVO> repayList = null;
		RTNFFileReadBD bd = null;
		String result = null;
		try {
			bd = new RTNFFileReadBD();
			repayList = new ArrayList<FileReadVO>();
			repayList = bd.fetchRepayList(result); 
			//bd.process(repayList);
		} catch (Exception exception) {
			exception.printStackTrace();
			throwApplicationException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return "success";
	}
	
	public String execute() throws BusinessException, ApplicationException {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods commonMethods = null;
		RTNFFileReadBD bd = null;
		try {
			bd = new RTNFFileReadBD();
			commonMethods = new CommonMethods();
			bd.postingCall();
			logger.info(ActionConstants.EXITING_METHOD);
		} catch (Exception exception) {
			throwApplicationException(exception);
		}

		return "success";

	}
	

}
