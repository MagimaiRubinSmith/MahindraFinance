package in.co.invoice.action;




import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import in.co.invoice.dao.exception.ApplicationException;
import in.co.invoice.utility.LogHelper;

import org.apache.log4j.Logger;

import com.opensymphony.xwork2.ActionSupport;

public class InvoiceBaseAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(InvoiceBaseAction.class
			.getName());
	
	
	
	/**
	 * 
	 * @param exception
	 * @throws ApplicationException
	 */
	public void throwApplicationException(Exception exception)
			throws ApplicationException {
		logger.error(exception.fillInStackTrace());
		LogHelper.logError(logger, exception);
		throw new ApplicationException(exception.getMessage(), exception);
	}
	
	public static final Map<String, String> REC_IND = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("1", "<---->");
				}
			});
	public static final Map<String, String> REC = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					//put("1", "<---->");
				}
			});
}
