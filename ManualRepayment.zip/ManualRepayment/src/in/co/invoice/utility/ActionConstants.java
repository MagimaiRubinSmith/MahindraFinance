package in.co.invoice.utility;

import in.co.clf.util.SystemPropertiesUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public interface ActionConstants {
	
	
	//NOSTRO Starts //
	String KEY="KEY97";
	String CUSTOMER="CUSTOMER";
	String PROGRAMME_NAME="DESCR";
	String PROGRAMME_IDENTIFIER="ID";
	String PROGRAMME_TYPE="PROG_TYPE";
	String SUB_TYPE="SUBTYPECAT";
	String AVAILABLE_AMOUNT="AVAIL_AMT";
	String FLAG_REMOVAL="OBSOLETE";
	String SANCLIM="SANLIM";
	String SANDATE="SANDATE";
	String ADHOC="ADHOC";
	String ADPELIM="ADPELIM";
	String ADHOCDA="ADHOCDA";
	String SANLIMS="SANLIMS";
	String DISBURSE="DISBURSE";
	String EXPOSURE="EXPANC";
	String EXPANC = "EXPANC";
	String DISBUR = "DISBUR";
	String SALUTATION="SALUTATION";
	String RT = "RT";
	String NT = "NT";
	String CH = "CH";
	String CQ = "CQ";
	String EX = "EX";
	String SD = "SD";
	String AD = "AD";//mal-221
	String MA = "MA";
	String MR = "MR";
	String CA = "CA";
	String CR = "CR";
	String MT_103="103";
	String IN0001="IN0001";
	String N128 = "N128";
	String MT_202="202";
	String MT_940="940";
	String MT_192="192";
	String MT_292="292";
	String AutoMapping="A";
	String SYSTEM="SYSTEM";
	String ManualMapping="M";
	String To_BE_MANUAL_MAPPING ="TM";
	String Reserved ="R";
	String PENDING="P";
	String TR = "TR";
	String TP = "TP";
	String APPROVE = "approve";
	String REJECT = "reject";
	String REJECTLIST = "RejectList";
	String REJECT1 = "REJECTED";
	String ENTERING_METHOD = "Entering Method";
	String EXITING_METHOD = "Exiting Method";
	String Y = "Y";
	String N = "N";
	String FALSE = "false";
	String initialFileLocation="C:/nostro_files/first";
	String tempFileLocation="C:/nostro_files/second";
	String t1FileLocation="C:/nostro_files/third";
	String LOGINUSER = "loginedUserName";
	String EMPTY="";
	
	String GENERAL = "General";
	String WARNING = "Warning";
	String ERROR = "Error";
	String INPUT = "Input";
	String W = "W";
	String E = "E";	
	
	String RECORDINDICATORH = "RECORDINDICATOR_H";
	String PROCESSINGDATE = "PROCESSING_DATE";
	String RECORDINDICATORT = "RECORDINDICATOR_T";
	String TRANS_COUNT = "TRANS_COUNT";
	String FILENAME = "FILENAME";
	/*String initialFileLocation="D:/nostro/first";
	String tempFileLocation="D:/nostro/second";
	String t1FileLocation="D:/nostro/third/";*/
	CharSequence TABLE_NAME = "TABLE_NAME";
	CharSequence COLUMN_NAME1 = "COLUMN_NAME1";
	CharSequence COLUMN_NAME2 = "COLUMN_NAME2";
	
	String TABLE_ETT_NOSTRO_UTILITY_MT103="ETT_NOSTRO_UTILITY_MT103";
	String TABLE_ETT_NOSTRO_UTILITY_MT940="ETT_NOSTRO_UTILITY_MT940";
	String TABLE_ETT_NOSTRO_UTILITY_MT202="ETT_NOSTRO_UTILITY_MT202";
	String TABLE_NOSTRO_UTILITY_MATCH="NOSTRO_UTILITY_MATCH";
	
	String TIPLUS = "TF";
	double AMOUNT =200000;
	String MSG_TYPE1 = "N06";
	String MSG_TYPE2 = "R41";
	String UPLDTYPE= "MDMC";
	String JNO = "000000000";
	String REMACCNO= "00000000000000000";
	String AUDIT_ACTION_ZERO="0";
	
	String NEFT_INPUT= SystemPropertiesUtil.getNEFTPath();
	String RTGS_INPUT= SystemPropertiesUtil.getRTGSPath();
	String BACKUP_INPUT= SystemPropertiesUtil.getBackupPath();

	
	String COLUMN_FILE_NAME="FILE_NAME";
	String COLUMN_STATUS="STATUS";
	String COLUMN_REFERENCE_NUMBER="REFERENCE_NUMBER";
	String S="S";
	String F = "F";
	String B="B";
	String COLUMN_SWIFT_NUMBER ="SWIFT_NUMBER";
	String FAIL="fail";
	String NOS_MAKER = "NostroMaker";
	String NOS_CHECKER = "NostroChecker";
	String MAKER = "maker";
	String CHECKER = "checker";
	String AUDIT_ACTION_ONE="1";
	String AUDIT_ACTION_TWO = "2";
	String AUDIT_ACTION_THREE ="3";
	String AUDIT_ACTION_FOUR ="4";
	String AUDIT_ACTION_FIVE ="5";
	String AUDIT_ACTION_SIX ="6";
	String AUDIT_ACTION_SEVEN ="7";
	String AUDIT_ACTION_EIGHT ="8";
	String AUDIT_ACTION_NINE ="9";
	String AUDIT_ACTION_TEN ="10";
	String AUDIT_ACTION_ELEVAN ="11";
	String AUDIT_ACTION_TEWLE ="12";
	String AUDIT_ACTION_THEIRTEEN ="13";
	
	
	String LOAN_MASTER_REF = "LOAN_MASTER_REF";
	String INVOICE_NO = "INVOICE_NO";
	String DISBURSEMENT_DATE = "DISBURSEMENT_DATE";
	String DUE_DATE = "DUE_DATE";
	String PRC_ALLC_AMOUNT ="PRC_ALLC_AMOUNT";
	String OS_AMOUNT = "OS_AMOUNT";
	String GW_STATUS = "GW_STATUS";
	String SQL_AND=" AND";
	String BATCH_ID = "BATCH_ID";
	String INVOICE_AMT = "INVOICE_AMT";
	String MASTER_REF_KEY = "LOAN_MASTER_REF";
	String ACCT_KEY = "BO_ACCTNO";
	String BRCH_MNM = "BRCH_MNM";
	String CUS_MNM = "CUS_MNM";
	String ACC_TYPE = "ACC_TYPE";
	String CATEGORY = "CATEGORY";
	String SHORTNAME = "SHORTNAME";
	
	String USERTEAM_VAL = "ALL TRADE TEAM";
	String SESSION_KEY = "key";
	String SESSION_ID = "id";
	String MANUAL = "MANUAL";
	String SESSION_MANUAL = "manual";
	String SESSION_ROLE = "userRole";
	String CLOSE_URL = "closeURL";
	public static final Map<String, String> ALLOC_TYPE = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("R", "Vendor Centric Finance");
					put("D", "Dealer Centric Finance");
				}
			});
	
	public static final Map<String, String> SCF_TYPE = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("B", "Vendor Finance");
					put("S", "Dealer Finance");
				}
			});
	
	public static final Map<String, String> SCF_PRODUCT_TYPE=Collections.unmodifiableMap(new HashMap<String, String>() {
		private static final long serialVersionUID=1L;
		{
			put("BP","BOE-Payable");
			put("IP","Invoice Payable");
			put("PP","PO Payable");
			put("BR","BOE-Receivable");
			put("IR","Invoice Receivable");
			put("PR","PO Receivable");
			put("PO","PO");
			put("IN","Invoice");
		}
	});
	public static final Map<String, String> SCF_PRODUCT_TYPE_VENDOR=Collections.unmodifiableMap(new HashMap<String, String>() {
		private static final long serialVersionUID=1L;
		{
			put("BR","BOE-Receivable");
			put("IR","Invoice Receivable");
			put("PR"," PO Receivable");
		}
	});
	public static final Map<String, String> SCF_PRODUCT_TYPE_ANCHOR=Collections.unmodifiableMap(new HashMap<String, String>() {
		private static final long serialVersionUID=1L;
		{
			put("BP","BOE-Payable");
			put("IP","Invoice Payable");
			put("PP","PO Payable");
		}
	});
	public static final Map<String, String> SCF_PRODUCT_TYPE_DEALER=Collections.unmodifiableMap(new HashMap<String, String>() {
		private static final long serialVersionUID=1L;
		{
			put("PO","PO");
			put("IN","Invoice");
		}
	});
	public static final Map<String, String> SCF_SUBTYPE = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("R", "Vendor Centric Finance");
					put("D", "Dealer Centric Finance");
				}
			});
	public static final Map<String, String> SCF_BUYERSELLER_STATUS = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("A", "Active");
					put("R", "Referred");
					put("B", "Blocked");
				}
			});
	
	public static final Map<String, String> SCF_DISBURSEMENT = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("PULL", "Pull");
					put("PUSH", "Push");
					put("PPC","Pre-printed cheque book");
					put("IB","Indent based");
				}
			});
	
	public static final Map<String, String> SCF_EXPOSURE = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("A","Anchor");
					put("D", "Dealer");
					put("V", "Vendor");
				}
			});
	
	public static final Map<String, String> SCF_EXPOSURE_DEALER = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("D", "Dealer");
				}
			});
	public static final Map<String, String> SCF_EXPOSURE_VENDOR = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("A","Anchor");
					put("V", "Vendor");
				}
			});
	
	public static final Map<String, String> SCF_MODE_OF_REPAYMENT = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("CQ", "Cheque");
					put("RT", "RTGS");
					put("NT", "NEFT");
					put("EX", "Excess BGL");
					//MAH-863
					//put("SD", "Security Deposit");
					put("SD", "Control A/C");
					//put("AD", "Advance"); //mal-221
				}
			});
	
	public static final Map<String, String> INTEREST_MODE = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("FC", "Force Capitalization");
				}
			});
	
	public static final Map<String, String> VIEWLIST_STATUS_FILTER = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					put("", "ERROR DATA");
					put("MA", "MAKER APPROVED");
					put("CA", "CHECKER APPROVED");
					put("CR", "CHECKER REJECTED");
				}
			});
	
	
	public static final Map<String, String> CHARGE_TYPE = Collections
			.unmodifiableMap(new HashMap<String, String>() {
				private static final long serialVersionUID = 1L;
				{
					Connection con = null;
					PreparedStatement ps = null;
					ResultSet rs = null;
					try {
						con = DBConnectionUtility.getConnection();
						ps = con.prepareStatement("SELECT CHARGE_CODE, CHARGE_TYPE FROM ETT_CHARGE_TYPES");
						rs = ps.executeQuery();
						while (rs.next()) {
							put(rs.getString("CHARGE_CODE"),
									rs.getString("CHARGE_TYPE"));
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBConnectionUtility.surrenderDB(rs, ps, con);
					}
				}
			});
	
	
	//NOSTRO Ends
}
