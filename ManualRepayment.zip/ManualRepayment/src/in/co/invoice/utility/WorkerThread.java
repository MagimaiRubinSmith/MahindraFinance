package in.co.invoice.utility;

import java.sql.Connection;
import java.util.ArrayList;

import in.co.invoice.dao.STPProcessDAO;

import com.bs.theme.migration.loader.tiplus.pojos.TiattdocExtra;
import com.misys.tiplus2.services.control.ServiceRequest;

public class WorkerThread implements Runnable {
  
	ArrayList<TiattdocExtra> financeFinalList ;
	String batchID;
	Connection con;
	ServiceRequest serReq;
    public WorkerThread(ArrayList<TiattdocExtra> financeFinalList,String batchID,Connection con,ServiceRequest serReq){
        this.financeFinalList = financeFinalList;
        this.batchID = batchID;
        this.con = con;
        this.serReq = serReq;
    }
    
    @Override
    public void run() {
    	try {
			processCommand();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

    /**
     * 
     * @throws Exception
     */
    private void processCommand() throws Exception {
    	STPProcessDAO stpProcess = new STPProcessDAO();
        //System.out.println("Thread pool Invoice No -------->"+financeFinalList.get(0).getInvoiceNumber());
    		stpProcess.processSTPBuyerFinance(financeFinalList,
				"root", null, "", "Y", batchID,serReq);
		System.out.println("Thread Step");
    }

    @Override
    public String toString(){
        return this.batchID;
    }
}