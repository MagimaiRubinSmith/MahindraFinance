package in.co.invoice.utility;

import in.co.clf.util.SystemPropertiesUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class DBConnectionUtility {

	private static Logger logger = Logger.getLogger(DBConnectionUtility.class
			.getName());
	public static Boolean isJNDIConn;
	public static String JNDIContext;
	public static String JNDIZONE;

	/**
	 * 
	 * @return
	 * @throws SQLException
	 */
	public static Connection getConnection() throws SQLException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection connection = null;
		Context ctx = null;
		try {
			System.out.println( "block 1");
			isJNDIConn = Boolean.parseBoolean(SystemPropertiesUtil
					.getisJNDIConn());
			System.out.println( isJNDIConn);
			if (isJNDIConn == true) {
				String lookupName = SystemPropertiesUtil.getJNDIZONE();
				try {
					Properties param = new Properties();
					param.put(Context.INITIAL_CONTEXT_FACTORY,
							"com.ibm.websphere.naming.WsnInitialContextFactory");
					Context initialContext = new InitialContext(param);
					DataSource dataSource = (DataSource) initialContext
							.lookup(lookupName);
					connection = dataSource.getConnection();
				} catch (NamingException e) {
					e.printStackTrace();
				}
			} else {
				String driver = SystemPropertiesUtil.getDriver();
				String url = SystemPropertiesUtil.getUrl();
				String userName = SystemPropertiesUtil.getUserName();
				String password = SystemPropertiesUtil.getPassword();
				Class.forName(driver);
				connection = DriverManager.getConnection(url, userName,
						password);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return connection;
	}

	/**
	 * 
	 * @param res
	 * @param stmt
	 * @param con
	 */
	public static void surrenderDB(ResultSet res, Statement stmt, Connection con) {
		try {
			if (res != null)
				res.close();
			if (stmt != null)
				stmt.close();

			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param stmt
	 * @param res
	 */
	public static void surrenderStatement(ResultSet res, Statement stmt) {
		try {

			if (res != null) {
				res.close();
			}
			if (stmt != null) {
				stmt.close();
			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
		}
	}

}
