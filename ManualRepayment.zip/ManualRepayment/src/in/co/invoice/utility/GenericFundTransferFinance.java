package in.co.invoice.utility;

import in.co.invoice.dao.AbstractDAO;
import in.co.invoice.dao.exception.DAOException;

import java.sql.Connection;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;

import java.math.BigDecimal;

/**
 * 
 * @author
 * 
 */
public class GenericFundTransferFinance extends AbstractDAO implements
		ActionConstantsQuery, ActionConstants {

	static GenericFundTransferFinance gft;

	private static Logger logger = Logger
			.getLogger(GenericFundTransferFinance.class.getName());

	/**
	 * 
	 * @return
	 */
	public static GenericFundTransferFinance getDAO() {
		if (gft == null) {
			gft = new GenericFundTransferFinance();
		}
		return gft;
	}

	/**
	 * 
	 * @param exposureOn
	 * @param programeId
	 * @param Cparty
	 * @throws DAOException
	 */
	public void doGenericFundTransfer(String batchID, String exposureOn,
			String programeId, String customer, String referenceNumber,
			Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		String limitAccountNumber = null;
		String financeAmount = null;
		try {
			if (null != exposureOn) {
				if (exposureOn.equalsIgnoreCase("A")) {
					limitAccountNumber = getAnchorLimitAccount(programeId, con);
					financeAmount = getAnchorFinanceAmount(batchID, programeId,
							con);
					// batchID = batchID +"_"+referenceNumber;
					if (financeAmount == null
							|| financeAmount.equalsIgnoreCase("")) {
						financeAmount = "0";
					}

					String requestTransactionDate = getRequestTransactionDate();
					String referenceNumb = getReferenceNumber(con);
					String source = fetchSource("LIMITREV", con);
					String customerID = getCustomer(programeId, con);
					String facilityID = fetchFacility(customerID, limitAccountNumber, con);
					FundTransferPost.fundPosting(limitAccountNumber,
							financeAmount, customerID, batchID, facilityID,
							requestTransactionDate, referenceNumb, source,
							programeId, con);
				} else {
					processCpartyFund(batchID, programeId, customer,
							referenceNumber, con);
					// limitAccountNumber =
					// getCpartyLimitAccount(programeId,Cparty);
				}
			}

			if (null != limitAccountNumber) {

			}
		} catch (Exception exception) {
			throwDAOException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	
	/**
	 * 
	 * @param programeId
	 * @return
	 * @throws DAOException
	 */
	public String fetchFacility(String cifID,String limitNo,Connection con) throws DAOException  {
		logger.info(ActionConstants.ENTERING_METHOD);
		/*Connection con = null;*/
		ResultSet rs = null;
		LoggableStatement ps = null;
		String result = null;
		/*Connection con = null;*/
		try {
			if(con == null){
			con = DBConnectionUtility.getConnection();
			}
			if(limitNo != null){
				limitNo = limitNo.trim();
			}
			if(cifID != null){
				cifID = cifID.trim();
			}
			ps = new LoggableStatement(con,"SELECT distinct FACILITY_ID FROM ett_clf_limit WHERE TRIM(cif_id) like '%"+cifID+"%' AND TRIM(line_no) like '%"+limitNo+"%' AND ROWNUM=1  ");
			rs = ps.executeQuery();
			System.out.println("Fetch Facility Query---->"+ps.getQueryString());
			if (rs.next()) {
				result = rs.getString(1).trim();
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs,ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return result;
	}
	
	/**
	 * 
	 * @param programeId
	 * @return
	 * @throws DAOException
	 */
	public String fetchSource(String keyID, Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		/* Connection con = null; */
		ResultSet rs = null;
		LoggableStatement ps = null;
		String result = null;
		// Connection con = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT VAL FROM ETT_CLF_PROPERTIES WHERE KEYID='" + keyID
							+ "' ");
			rs = ps.executeQuery();
			if (rs.next()) {
				result = rs.getString(1).trim();
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return result;
	}

	/**
	 * 
	 * @return
	 */
	public String getRequestTransactionDate() {
		String transactionDate = null;
		String date = null;
		String monthFull = null;
		String hourFull = null;
		String minuteFull = null;
		String secondFull = null;
		try {
			Calendar now = Calendar.getInstance();
			int year = now.get(Calendar.YEAR);
			int month = now.get(Calendar.MONTH) + 1; // Note: zero based!
			if (month < 10) {
				NumberFormat f = new DecimalFormat("00");
				monthFull = String.valueOf(f.format(month));
			} else {
				monthFull = String.valueOf(month);
			}
			int day = now.get(Calendar.DAY_OF_MONTH);
			if (day < 10) {
				NumberFormat f = new DecimalFormat("00");
				date = String.valueOf(f.format(day));
			} else {
				date = String.valueOf(day);
			}
			int hour = now.get(Calendar.HOUR_OF_DAY);
			if (hour < 10) {
				NumberFormat f = new DecimalFormat("00");
				hourFull = String.valueOf(f.format(hour));
			} else {
				hourFull = String.valueOf(hour);
			}
			int minute = now.get(Calendar.MINUTE);
			if (minute < 10) {
				NumberFormat f = new DecimalFormat("00");
				minuteFull = String.valueOf(f.format(minute));
			} else {
				minuteFull = String.valueOf(minute);
			}
			int second = now.get(Calendar.SECOND);
			if (second < 10) {
				NumberFormat f = new DecimalFormat("00");
				secondFull = String.valueOf(f.format(second));
			} else {
				secondFull = String.valueOf(second);
			}
			transactionDate = String.valueOf(year) + monthFull + date
					+ hourFull + minuteFull + secondFull;
			System.out.println(transactionDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return transactionDate;
	}

	/**
	 * 
	 * @param programeId
	 * @return
	 * @throws DAOException
	 */
	public String getCustomer(String programeId, Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String expOn = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"select CUSTM from ett_clf_programparameters where proiden='"
							+ programeId + "'");
			rs = ps.executeQuery();
			if (rs.next()) {
				expOn = rs.getString(1).trim();
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return expOn;
	}

	/**
	 * 
	 * @param programeId
	 * @return
	 * @throws DAOException
	 */
	public String getReferenceNumber(Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement ps = null;
		String result = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT SEQ_REF_NUM.NEXTVAL FROM DUAL");
			rs = ps.executeQuery();
			if (rs.next()) {
				result = rs.getString(1).trim();
			}
		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return result;
	}

	/**
	 * 
	 * @param batchId
	 * @param programeId
	 * @return
	 * @throws DAOException
	 */
	private String processCpartyFund(String batchId, String programeId,
			String customer, String referenceNumber, Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);

		LoggableStatement ps = null;
		ResultSet rs = null;
		String limitNumber = null;
		String financeAmount = null;
		String Cparty = null;
		String batchID = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "select sum(PRIN_ALLC_AMT) PRC_ALLC_AMOUNT,TRIM(COUNTER_PARTY) AS COUNTER_PARTY from ett_stp_repayment where "
					+ "BATCH_ID='"
					+ batchId
					+ "' "
					+ "and TRIM(PROGRAM_ID)='"
					+ programeId
					+ "' "
					+ "and GW_STATUS='S' AND PRIN_ALLC_AMT > 0 group by COUNTER_PARTY";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			System.out.println(ps.getQueryString());
			rs = ps.executeQuery();
			batchID = batchId;
			// batchId = batchId+"_"+referenceNumber;
			while (rs.next()) {
				financeAmount = rs.getString("PRC_ALLC_AMOUNT");
				Cparty = rs.getString("COUNTER_PARTY");
				limitNumber = getCpartyLimitAccount(programeId, Cparty, con);
				if (financeAmount == null || financeAmount.equalsIgnoreCase("")) {
					financeAmount = "0";
				} else {
					BigDecimal financeAmt = new BigDecimal(financeAmount);
					if (financeAmt.compareTo(BigDecimal.ZERO) <= 0) {
						financeAmount = "0";
					} 
					/*BigDecimal financeAmt = new BigDecimal(financeAmount);
					if (financeAmt.compareTo(BigDecimal.ZERO) <= 0) {
						financeAmount = "0";
					} else {
						BigDecimal cipAmount = new BigDecimal(fetchCIPAmount(
								batchID, Cparty));
						if (cipAmount.compareTo(BigDecimal.ZERO) <= 0) {

						} else {
							financeAmt = financeAmt.subtract(cipAmount);
							financeAmount = String.valueOf(financeAmt);
						}
					}*/
				}
				if (!financeAmount.equalsIgnoreCase("0")) {
					String requestTransactionDate = getRequestTransactionDate();
					String referenceNumb = getReferenceNumber(con);
					String source = fetchSource("LIMITREV", con);
					String facilityID = fetchFacility(Cparty, limitNumber, con);
					FundTransferPost.fundPosting(limitNumber, financeAmount,
							Cparty, batchID, facilityID,
							requestTransactionDate, referenceNumb, source,
							programeId, con);
				}
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return limitNumber;

	}

	private String processCpartyFundLimit(String batchId, String programeId)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String limitNumber = null;
		String financeAmount = null;
		String Cparty = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "SELECT SUM(I.INVOICE_INDENT_AMOUNT) AS FINANCE_AMOUNT,ETT_CPARTY(ID.PROGRM,DEALER_SELLER_CODE,CLFACCNO) "
					+ "AS DEALER_SELLER_CODE FROM"
					+ "  ETT_STP_INVOICES I,ETT_STP_INVOICE_DETAILS ID WHERE ID.BATCHID=I.BATCHID  AND I.BATCHID='"
					+ batchId
					+ "' AND ID.USER_STATUS='CA' "
					+ "AND I.STATUS='S' GROUP BY I.DEALER_SELLER_CODE,ID.PROGRM";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			while (rs.next()) {
				financeAmount = rs.getString("FINANCE_AMOUNT");
				Cparty = rs.getString("DEALER_SELLER_CODE").trim();
				limitNumber = getCpartyLimitAccount(programeId, Cparty, con);
				// FundTransferPost.fundPosting(limitNumber, financeAmount);
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return limitNumber;

	}

	/**
	 * 
	 * @param programeId
	 * @return
	 * @throws DAOException
	 */
	private String getAnchorLimitAccount(String programeId, Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String limitNumber = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "select distinct PROG_NOR_LMNO AS PROG_NOR_LMNO from ETT_PROG_CP_LM where PROG_ID='"
					+ programeId + "'";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				limitNumber = rs.getString("PROG_NOR_LMNO");
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return limitNumber;

	}

	/**
	 * 
	 * @param batchId
	 * @param programeId
	 * @return
	 * @throws DAOException
	 */
	private String getAnchorFinanceAmount(String batchId, String programeId,
			Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String financeAmount = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "select sum(PRC_ALLC_AMOUNT) As Amount from ett_stp_repayment where BATCH_ID='"
					+ batchId
					+ "'"
					+ " and PROGRAM_ID='"
					+ programeId
					+ "' and GW_STATUS='S'";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				financeAmount = rs.getString("Amount");
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return financeAmount;

	}

	/**
	 * 
	 * @param programeId
	 * @param cParty
	 * @return
	 * @throws DAOException
	 */
	private String getCpartyLimitAccount(String programeId, String cParty,
			Connection con) throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		// Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String limitNumber = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "select PROG_CP_NOR_LMNO AS PROG_CP_NOR_LMNO from ETT_PROG_CP_LM where PROG_ID='"
					+ programeId + "' AND PROG_CP='" + cParty + "'";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				limitNumber = rs.getString("PROG_CP_NOR_LMNO");
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return limitNumber;

	}

	/**
	 * 
	 * @param batchId
	 * @param programeId
	 * @return
	 * @throws DAOException
	 */
	private String fetchCIPAmount(String batchId, String cparty)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String financeAmount = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			String query = "SELECT nvl(sum(financeamt),0) as financeamt FROM ETT_EOD_TEMP WHERE trim(batchid)=trim('"
					+ batchId + "') AND trim(CUSTOMER)=trim('" + cparty + "') ";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				financeAmount = rs.getString("financeamt");
			}

		} catch (Exception exception) {
			throwDAOException(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return financeAmount;

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BigDecimal financeAmt = new BigDecimal("-1");
		if (financeAmt.compareTo(BigDecimal.ZERO) <= 0) {
			System.out.println(financeAmt);
		}

	}

}
