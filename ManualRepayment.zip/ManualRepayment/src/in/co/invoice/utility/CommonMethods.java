package in.co.invoice.utility;

import in.co.clf.util.SystemPropertiesUtil;
import in.co.invoice.dao.exception.DAOException;
import in.co.invoice.vo.BankLimitVO;
import in.co.invoice.vo.InvMatchingVO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.ett.themebridge.gateway.InvokeService;
import com.misys.tiplus2.service.access.ejb.EnigmaServiceAccess;
import com.misys.tiplus2.service.access.ejb.EnigmaServiceAccessHome;

/**
 * This helper class and contains common methods used by all other classes.
 * 
 * 
 * 
 */
public class CommonMethods {
	private static Logger logger = Logger.getLogger(CommonMethods.class
			.getName());

	public boolean moveFile(String source, String destination)
			throws InterruptedException {
		InputStream inStream = null;
		OutputStream outStream = null;
		boolean result = false;
		try {

			File afile = new File(source);
			File bfile = new File(destination);
			if (afile != null && afile.exists()) {
				inStream = new FileInputStream(afile);
				outStream = new FileOutputStream(bfile);

				byte[] buffer = new byte[1024];

				int length;
				// copy the file content in bytes
				while ((length = inStream.read(buffer)) > 0) {

					outStream.write(buffer, 0, length);

				}

				inStream.close();
				outStream.close();

				afile.setWritable(true);
				// delete the original file
				System.gc();
				Thread.sleep(2000);
				afile.delete();

				// FileDeleteStrategy.FORCE.delete(afile);
				result = true;
				// System.out.println("File is copied successful!");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * This method concatenate the error string & passes the error string back
	 * to function.
	 * 
	 * @param errorString
	 * @param currentError
	 * @return String
	 */
	public String setErrorString(String errorString, String currentError) {
		if (errorString.length() > 0)
			errorString += ",";
		errorString = errorString + currentError;
		return errorString;
	}

	/**
	 * This method checks the value passed & sets it to empty if it is null.
	 * 
	 * @param value
	 * @return String
	 */
	public String checkForNullvalue(String value) {
		if (null != value)
			return value;
		else
			return "";
	}

	/**
	 * This helper method is to insert comma to the value given. it is used to
	 * put comma to the Rupees value in the Indian format.
	 * 
	 * @param amount
	 * @return String
	 */
	public int retrieveNoOfErrors(String errorString) {
		StringTokenizer stringTokenizer = new StringTokenizer(errorString, ",");
		int n = stringTokenizer.countTokens();
		return n;
	}

	public static String removeComma(String amount) {
		String output = null;
		if (amount != null) {
			amount = amount.trim();
			String number = amount;
			output = number.replace(",", "");
			return output;
		} else
			return "0";

	}

	public String doubleComma(String amount) {
		String output = null;
		String splitString[] = null;
		String amountProcess = "";
		String backUpString = "";
		String minus = "";
		if (amount != null) {
			if (amount.length() > 0) {
				if (amount.charAt(0) == '-') {
					amount = amount.substring(1);
					minus = "-";
				}
				splitString = amount.split("\\.");
				if (splitString.length == 2) {
					amountProcess = splitString[0];
					backUpString = "." + splitString[1];
				} else {
					amountProcess = splitString[0];
					backUpString = ".00";
				}

				String number = amountProcess;
				int len = number.length();
				output = number;
				if (len > 3) {
					for (int i = len; i > 0; i = i - 2) {
						if (i == len) {
							i = i - 3;
							String temp = output.substring(0, i);
							String temp1 = output.substring(i);
							output = temp + "," + temp1;
						} else {
							String temp = output.substring(0, i);
							String temp1 = output.substring(i);
							output = temp + "," + temp1;
						}
					}
				}

			}
			return minus + output + backUpString;
		} else
			return "0";

	}

	public String getCurrentDate(String value) throws ParseException {
		if (value != null) {
			//System.out.println("value" + value);
			Timestamp ts = Timestamp.valueOf(value);
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			return dateFormat.format(ts);
		}
		return "";
	}

	/**
	 * This helper method is used to get the current URL
	 * 
	 * 
	 * @param value
	 * @return boolean
	 */

	public static String findRequestUrl(String sentence) {
		String retval = null;
		String[] tokens = null;
		String splitPattern = "/ats";
		tokens = sentence.split(splitPattern);
		retval = tokens[0];
		return retval;
	}

	/**
	 * This helper method is used to check whether he given value is NULL or
	 * not.
	 * 
	 * @param value
	 * @return boolean
	 */
	public boolean isNull(String value) {
		boolean result = false;
		if (value == null || value.equalsIgnoreCase("")) {
			result = true;
		}
		return result;
	}

	public String getDateFormat(String tempDate) {
		String delimiter = "-";
		String month, year, date;
		try {
			if (tempDate != null) {
				String str = tempDate;
				String[] temp = str.split(delimiter);
				if (null != temp) {
					int len = temp.length;
					if (len == 3) {
						year = temp[2];
						month = temp[1];
						date = temp[0];
						tempDate = year + "-" + month + "-" + date;
					} else {
						tempDate = null;
					}
				}

			}
		} catch (Exception e) {
			tempDate = null;
		}
		return tempDate;
	}

	/**
	 * This helper method used to set comma for the numbers.
	 * 
	 * @param amount
	 * @return
	 */
	public String comma(String amount) {
		String output = null;
		if (amount != null) {
			String number = amount;
			int len = number.length();
			output = number;
			if (len > 3) {
				for (int i = len; i > 0; i = i - 2) {
					if (i == len) {
						i = i - 3;
						String temp = output.substring(0, i);
						String temp1 = output.substring(i);
						output = temp + "," + temp1;
					} else {
						String temp = output.substring(0, i);
						String temp1 = output.substring(i);
						output = temp + "," + temp1;
					}
				}
			}
			return output;
		} else
			return "0";
	}

	public boolean isNumeric(String quantity) {
		try {
			Integer.parseInt(quantity);
		} catch (NumberFormatException e) {
			return false;
		}
		return true;
	}

	public static String convertTimestampToUIDateFormat(Timestamp timestamp) {
		if (timestamp != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"dd-MMM-yyyy hh:mm:ss a");
			// dateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
			return dateFormat.format(timestamp);
		}
		return null;
	}

	/**
	 * This method returns an empty string if the string passed is null
	 * otherwise returns the same string
	 * 
	 * @param sourceStr
	 *            the string to be checked for null
	 * @return empty string if str is null, otherwise returns str
	 */
	public String getEmptyIfNull(Object sourceStr) {
		return convertIfNull(sourceStr, "");
	}// end of method getEmptyIfNull()

	/**
	 * This method returns the second string if the first string is either empty
	 * or is null. This method can be used for default_value built-in in forms
	 * 
	 * @param sourceStr
	 *            The string to be checked for null
	 * @param toConvert
	 *            The string to be returned if the first string is either null
	 *            or empty
	 * @return toConvert if sourceStr is null or empty
	 */
	public static String convertIfNull(Object sourceStr, Object toConvert) {
		return isNullValue(sourceStr) ? toConvert.toString() : sourceStr
				.toString();
	}// end of method convertIfNull()

	public static boolean isNullValue(Object obj) {
		if (obj == null) {
			return true;
		} else if (obj instanceof String) {
			return (((String) obj).trim().length() == 0);
		} else if (obj instanceof Collection) {
			return (((Collection) obj).size() == 0);
		} else {
			return false;
		}
	}

	public double toDouble(Object str) {
		double tempVal = 0.00;
		if (isNullValue(str)) {
			return tempVal;
		} else {
			try {
				tempVal = Double.parseDouble(getEmptyIfNull(str).trim());
			} catch (NumberFormatException e) {
				tempVal = 0.00;
			}
			return tempVal;
		}
	}

	/**
	 * This method returns true if the object obj is not null
	 * 
	 * @param obj
	 *            The object which has to be checked if it's not null
	 * @return true if the obj is not null
	 */
	public static boolean isNotNull(Object obj) {
		return (!isNullValue(obj));
	}

	public String getUserviewableUtilDateFormat(java.util.Date dateValue)
			throws Exception {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		try {
			String formatValue = "";
			if (isNotNull(dateValue)) {
				formatValue = formatter.format(dateValue);
			}
			return formatValue;
		} catch (Exception e) {
			throw e;
		}
	}

	public static boolean bitwiseEqualsWithCanonicalNaN(double x, double y) {
		return Double.doubleToLongBits(x) == Double.doubleToLongBits(y);
	}

	public static boolean bitwiseEqualsWithCanonicalNaN(BigDecimal x,
			BigDecimal y) {
		System.out.println(x.compareTo(y));
		if (x.compareTo(y) == 0) {
			return true;
		} else if (x.compareTo(y) == 1) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean bitwiseEqualsWithCanonicalNaN1(BigDecimal x,
			BigDecimal y) {
		System.out.println(x.compareTo(y));
		if (x.compareTo(y) == 0) {
			return true;
		} else if (x.compareTo(y) == -1) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean findDouble(String value) {
		boolean result = false;
		try {
			double amt = Double.parseDouble(value);
		} catch (NumberFormatException e) {
			return true;
		}
		// TODO Auto-generated method stub
		return result;
	}

	public static String nullAndTrimString(String value) {
		if (value == null) {
			value = "";
			return value;
		}
		return value.trim();

	}

	public static String nullAndTrimNumber(String value) {
		if (value == null) {
			value = "0.00";
			return value;
		}
		return value.trim();

	}

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public String getAccountNumber(String shortName) throws Exception {
		String result = null;
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT VAL FROM ETT_CLF_PROPERTIES WHERE KEYID LIKE UPPER('"
					+ shortName + "')";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				result = rs.getString("VAL").trim();
			}
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return result;
	}

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public String fetchExcessBGL(String programme, String anchor, String cparty)
			throws Exception {
		String result = null;
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		try {
			System.out.println(programme);
			System.out.println(anchor);
			System.out.println(cparty);
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT NVL(SUM((NVL(AMT,0)-NVL(REPAIDAMT,0))),0)AMT FROM ETT_PROG_RELATION_CAP,ETT_INT_REFUND WHERE "
					+ "TRIM(MASTER_REF)=TRIM(DEALREF) AND TRIM(PROGIDN) = TRIM('"
					+ programme
					+ "') AND "
					+ "TRIM(ANCHID) = TRIM('"
					+ anchor
					+ "') AND TRIM(CPARTYID) = DECODE(TRIM('"
					+ cparty
					+ "'), '-1', TRIM(CPARTYID),TRIM('"
					+ cparty
					+ "'))"
					+ " AND UPPER(RE_TYPE)='MANUAL' AND PURPOSE = 'EX' HAVING NVL(SUM((NVL(AMT,0)-NVL(REPAIDAMT,0))),0)>0";
			//MAL-231
			/*
			 * query ="SELECT NVL(SUM((NVL(AMT,0)-NVL(REPAIDAMT,0))),0)AMT" +
			 * "  FROM ETT_PROG_RELATION_CAP A,ETT_INT_REFUND B,ETT_PROG_CP_LM C " +
			 * "WHERE  " + "  TRIM(A.PROGIDN(+)) = TRIM(C.PROG_ID)" +
			 * " AND TRIM(A.CPARTYID(+)) = TRIM(C.PROG_CP) " +
			 * "AND TRIM(TRIM(C.PROG_ID)) = TRIM('"+programme+"') " +
			 * "and TRIM(C.PROG_ANCH) = TRIM('"+anchor+"') AND " +
			 * "  TRIM(C.PROG_CP) = DECODE(TRIM('"+cparty+"'), '-1', TRIM(C.PROG_CP),TRIM('"
			 * +cparty+"')) " + "AND TRIM(A.DEALREF(+))    = TRIM(B.MASTER_REF) " +
			 * "AND (TRIM(A.DEALREF) = TRIM(B.MASTER_REF)" +
			 * "OR TRIM(corporate_code1)=TRIM(B.MASTER_REF) OR TRIM(corporate_code2)  =TRIM(B.MASTER_REF)"
			 * +
			 * " OR TRIM(corporate_code3)  =TRIM(B.MASTER_REF) OR TRIM(corporate_code4)  =TRIM(B.MASTER_REF)"
			 * +
			 * " OR TRIM(corporate_code5)  =TRIM(B.MASTER_REF)  OR TRIM(corporate_code6)  =TRIM(B.MASTER_REF)"
			 * +
			 * "OR TRIM(corporate_code7)  =TRIM(B.MASTER_REF) OR TRIM(corporate_code8)  =TRIM(B.MASTER_REF)"
			 * +
			 * " OR TRIM(corporate_code9)  =TRIM(B.MASTER_REF)  OR TRIM(CORPORATE_CODE10) =TRIM(B.MASTER_REF)) "
			 * +
			 * "  AND UPPER(B.RE_TYPE)='MANUAL' AND B.PURPOSE = 'EX' HAVING NVL(SUM((NVL(B.AMT,0)-NVL(B.REPAIDAMT,0))),0)>0"
			 * ;
			 */
			
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			logger.info("Excess GL --->"+query);
			while (rs.next()) {
				result = rs.getString("AMT").trim();
			}
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return result;
	}
	
	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public String fetchSecurityAmount(String programme, String anchor, String cparty)
			throws Exception {
		String result = null;
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		try {
			System.out.println(programme);
			System.out.println(anchor);
			System.out.println(cparty);
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT NVL(SUM((NVL(SDAMT,0)-NVL(REPAYAMT,0))),0)AMT FROM ETT_PROG_RELATION_CAP A,ETT_SD_POST B WHERE "
					+ "TRIM(A.DEALREF)=TRIM(B.DEALREF) AND TRIM(PROGIDN) = TRIM('"+programme+"') AND TRIM(CPARTYID) = "
					+ "DECODE(TRIM('"+cparty+"'), '-1', TRIM(CPARTYID),TRIM('"+cparty+"'))  HAVING NVL(SUM((NVL(SDAMT,0)-NVL(REPAYAMT,0))),0)>0";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				result = rs.getString("AMT").trim();
			}
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return result;
	}
	
	//MAL-221
		public String fetchAdvanceAmount(String programme, String anchor, String cparty) throws Exception {
			String result = null;
			Connection con = null;
			ResultSet rs = null;
			LoggableStatement pst = null;
			String query = null;
			try {
				
				if (con == null) {
					con = DBConnectionUtility.getConnection();
				}
	;
				query ="SELECT NVL(SUM((NVL(AMT,0)-NVL(REPAIDAMT,0))),0)AMT"
						+ "  FROM ETT_PROG_RELATION_CAP A,ETT_INT_REFUND B,ETT_PROG_CP_LM C "
						+ "WHERE  TRIM(A.DEALREF(+)) = TRIM(B.MASTER_REF)"
						+ " AND TRIM(A.PROGIDN(+)) = TRIM(C.PROG_ID)"
						+ " AND TRIM(A.CPARTYID(+)) = TRIM(C.PROG_CP) "
						+ "AND TRIM(TRIM(C.PROG_ID)) = TRIM('"+programme+"') "
						+ "and TRIM(C.PROG_ANCH) = TRIM('"+anchor+"') AND "
						+ "  TRIM(C.PROG_CP) = DECODE(TRIM('"+cparty+"'), '-1', TRIM(C.PROG_CP),TRIM('"+cparty+"')) "
						+ "AND (TRIM(A.DEALREF) = TRIM(B.MASTER_REF) OR TRIM(corporate_code1)=TRIM(B.MASTER_REF) OR TRIM(corporate_code2)  =TRIM(B.MASTER_REF)"
						+ " OR TRIM(corporate_code3)  =TRIM(B.MASTER_REF) OR TRIM(corporate_code4)  =TRIM(B.MASTER_REF)"
						+ " OR TRIM(corporate_code5)  =TRIM(B.MASTER_REF)  OR TRIM(corporate_code6)  =TRIM(B.MASTER_REF)"
						+ "OR TRIM(corporate_code7)  =TRIM(B.MASTER_REF) OR TRIM(corporate_code8)  =TRIM(B.MASTER_REF)"
						+ " OR TRIM(corporate_code9)  =TRIM(B.MASTER_REF)  OR TRIM(CORPORATE_CODE10) =TRIM(B.MASTER_REF)) "
						+ "  AND UPPER(B.RE_TYPE)='MANUAL' AND B.PURPOSE = 'AD' HAVING NVL(SUM((NVL(B.AMT,0)-NVL(B.REPAIDAMT,0))),0)>0";
				pst = new LoggableStatement(con, query);
				rs = pst.executeQuery();
				logger.info("Advance GL --->"+query);
				while (rs.next()) {
					result = rs.getString("AMT").trim();
				}
			} catch (Exception e) {
				throw (e);
			} finally {
				DBConnectionUtility.surrenderDB(rs, pst, con);
			}
			return result;
		}	

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public String fetchAppropriationType(String progID) throws Exception {
		String result = null;
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT APPORTIONMENT FROM ETT_CLF_PROGRAMPARAMETERS WHERE PROIDEN='"
					+ progID + "'";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				result = rs.getString("APPORTIONMENT").trim();
			}
			if (result == null) {
				result = "";
			}
		} catch (Exception e) {
			result = "";
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return result;
	}

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public String fetchCounterPartyAppropriationType(String progID,
			String customer) throws Exception {
		String result = null;
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT APPORTIONMENT FROM ETT_CLF_SELLERBUYERRELATION WHERE PROGIDN='"
					+ progID + "' AND CUSTOMR='" + customer + "'";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				result = rs.getString("APPORTIONMENT").trim();
			}
			if (result == null) {
				result = "";
			}
		} catch (Exception e) {
			result = "";
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return result;
	}

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public String fetchCounterPartyRepayBy(String progID, String customer)
			throws Exception {
		String result = null;
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT REPAY_BY FROM ETT_CLF_SELLERBUYERRELATION WHERE PROGIDN='"
					+ progID + "' AND CUSTOMR='" + customer + "'";
			
			/*query = "SELECT REPAY_BY FROM ETT_CLF_SELLERBUYERRELATION WHERE PROGIDN='"
					+ progID + "'";*/
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				result = rs.getString("REPAY_BY").trim();
			}
			if (result == null) {
				result = "";
			}
		} catch (Exception e) {
			result = "";
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return result;
	}
	public String fetchVirtualAccountNo(String progID, String customer)
			throws Exception {
		String result = null;
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT REPAY_ACCT_NO FROM ETT_CLF_SELLERBUYERRELATION WHERE PROGIDN='"
					+ progID + "' AND CUSTOMR='" + customer + "'";
			
			/*query = "SELECT REPAY_BY FROM ETT_CLF_SELLERBUYERRELATION WHERE PROGIDN='"
					+ progID + "'";*/
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			System.out.println("Virtual Account Num"+pst.getQueryString());
			while (rs.next()) {
				result = rs.getString("REPAY_ACCT_NO").trim();
			}
			if (result == null) {
				result = "";
			}
		} catch (Exception e) {
			result = "";
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return result;
	}
	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public void updateApproveReject(String batchID, String flagStatus,
			String userID) throws Exception {
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			/*
			 * query = "UPDATE ETT_STP_REPAYMENT SET STATUS_FLAG ='" + flagStatus +
			 * "',MAKER_ID='" + userID + "'," +
			 * "MAKER_TSTAMP = CAST(SYSDATE AS TIMESTAMP) WHERE BATCH_ID='" + batchID +
			 * "' ";
			 */
			//Duplicate Upload
			query = "UPDATE ETT_STP_REPAYMENT SET STATUS_FLAG ='"
					+ flagStatus
					+ "',MAKER_ID='"
					+ userID
					+ "',"
					+ "MAKER_TSTAMP = CAST(SYSDATE AS TIMESTAMP) WHERE BATCH_ID='"
					+ batchID + "' AND NVL(STATUS_FLAG, 'X')<>'CA'";//CHANGES 
			pst = new LoggableStatement(con, query);
			System.out.println("sysout" + pst.getQueryString());
			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw (e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
	}

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public void updateAllocationAmount(String batchID, Connection con) throws Exception {
		//Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "UPDATE ETT_STP_REPAYMENT SET PRC_ALLC_AMOUNT=0 WHERE BATCH_ID='"
					+ batchID + "' ";
			pst = new LoggableStatement(con, query);
			System.out.println("sysout" + pst.getQueryString());
			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw (e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
	}
	
	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	/*
	 * public void updateApproveRejectRemark(String batchID, String flagStatus,
	 * String remarks) throws Exception { Connection con = null; ResultSet rs =
	 * null; LoggableStatement pst = null; String query = null; try {
	 * if(con==null){ con = DBConnectionUtility.getConnection(); } query =
	 * "UPDATE ETT_STP_REPAYMENT SET STATUS_FLAG ='" + flagStatus +
	 * "', REMARKS='"+remarks+"' WHERE BATCH_ID='" + batchID + "' "; pst = new
	 * LoggableStatement(con, query); pst.executeUpdate(); } catch (Exception e)
	 * { throw (e); } finally { DBConnectionUtility.surrenderDB(con, pst, rs); }
	 * }
	 */

	/**
	 * 
	 * @param batchID
	 * @param flagStatus
	 * @param remarks
	 * @param userID
	 * @throws Exception
	 */
	public int updateApproveRejectRemark(String batchID, String flagStatus,
			String remarks, String userID) throws Exception {
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		int i = 0;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			/*
			 * query = "UPDATE ETT_STP_REPAYMENT SET STATUS_FLAG ='" + flagStatus +
			 * "',CHECKER_ID='" + userID + "'," +
			 * "CHECKER_TSTAMP = CAST(SYSDATE AS TIMESTAMP), REMARKS='" + remarks +
			 * "' WHERE trim(BATCH_ID)='" + batchID + "' AND TRIM(STATUS_FLAG)='MA' ";
			 */
			//Duplicate issue approve twice at checker
			query = "UPDATE ETT_STP_REPAYMENT SET STATUS_FLAG ='" + flagStatus
					+ "',CHECKER_ID='" + userID + "',"
					+ "CHECKER_TSTAMP = CAST(SYSDATE AS TIMESTAMP), REMARKS='"
					+ remarks + "' WHERE trim(BATCH_ID)='" + batchID
					+ "' AND TRIM(STATUS_FLAG)='MA' AND NVL(STATUS_FLAG, 'X')<>'CA'";//changes
			pst = new LoggableStatement(con, query);
			i = pst.executeUpdate();
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return i;
	}

	/**
	 * 
	 * @param batchID
	 * @param DealRef
	 * @return
	 * @throws Exception
	 */
	public int insertAuditTrail(String batchID, String DealRef, Connection con)
			throws Exception {
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		int i = 0;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "INSERT INTO ETT_CLF_AUDITTRAIL (ID,SCREEN_NAME,MESSAGE,STATUS) VALUES (?,?,?,?) ";
			pst = new LoggableStatement(con, query);
			pst.setString(1, batchID);
			pst.setString(2, "MANUALREPAY");
			pst.setString(3, DealRef);
			pst.setString(4, "ACTIVE");
			i = pst.executeUpdate();
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		return i;
	}

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public String fetchPayAccount(String batchID, Connection con)
			throws Exception {
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		String result = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT DISTINCT REPAYMENT_ACCOUNT_NO FROM ETT_STP_REPAYMENT WHERE BATCH_ID='"
					+ batchID + "' ";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			if (rs.next()) {
				result = rs.getString("REPAYMENT_ACCOUNT_NO").trim();
			}
			if (result == null) {
				result = "";
			}
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		return result;
	}

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public String fetchCounterPartyName(String mnemonic) throws Exception {
		Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		String result = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT GFCUN FROM GFPF WHERE TRIM(GFCUS1)='"
					+ mnemonic.trim() + "'";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			if (rs.next()) {
				result = rs.getString("GFCUN").trim();
			}
			if (result == null) {
				result = "";
			}
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return result;
	}

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public int checkDealRef(String dealReference,Connection con) throws Exception {
		//Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		int result = 0;
		ArrayList<InvMatchingVO> dealRef = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT COUNT(*) AS COUNT FROM ETT_STP_REPAYMENT WHERE "
					+ "TRIM(LOAN_MASTER_REF)='"
					+ dealReference.trim()
					+ "'"
					+ " AND PRC_ALLC_AMOUNT > 0 AND STATUS_FLAG = 'MA' AND GW_STATUS IS NULL";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			if (rs.next()) {
				result = rs.getInt("COUNT");
			}
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		return result;
	}
	
	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public int checkDealRefAlreadyPending(String batchid,Connection con) throws Exception {
		//Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		int result = 0;
		ArrayList<InvMatchingVO> dealRef = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT COUNT(*) AS COUNT FROM ETT_STP_REPAYMENT WHERE TRIM(LOAN_MASTER_REF) IN "
					+ "(SELECT LOAN_MASTER_REF FROM ETT_STP_REPAYMENT WHERE batch_id='"+batchid.trim()+"' ) "
					+ " AND PRC_ALLC_AMOUNT > 0 AND STATUS_FLAG = 'MA' AND GW_STATUS IS NULL";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			if (rs.next()) {
				result = rs.getInt("COUNT");
			}
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		return result;
	}
	
	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public int checkValueDate(String dealReference,Connection con,String batchID) throws Exception {
		//Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		int result = 0;
		ArrayList<InvMatchingVO> dealRef = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT COUNT(*) AS COUNT FROM ETT_STP_REPAYMENT WHERE batch_id='"+batchID.trim()+"' and TRIM(LOAN_MASTER_REF)='"+dealReference.trim()+"' "
					+ "AND TO_DATE(VALUE_DATE,'DD-MM-YY') < TO_DATE(DISBURSEMENT_DATE,'DD-MM-YY') AND GW_STATUS IS NULL";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			if (rs.next()) {
				result = rs.getInt("COUNT");
			}
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		return result;
	}
	
	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public int checkValueDateDisbursement(Connection con,String batchID) throws Exception {
		//Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		int result = 0;
		ArrayList<InvMatchingVO> dealRef = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT COUNT(*) AS COUNT FROM ETT_STP_REPAYMENT WHERE batch_id='"+batchID.trim()+"' "
					+ "AND TO_DATE(VALUE_DATE,'DD-MM-YY') < TO_DATE(DISBURSEMENT_DATE,'DD-MM-YY') AND GW_STATUS IS NULL AND PRC_ALLC_AMOUNT > 0";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			if (rs.next()) {
				result = rs.getInt("COUNT");
			}
		} catch (Exception e) {
			throw (e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		return result;
	}

	/**
	 * 
	 * @param shortName
	 * @return
	 * @throws Exception
	 */
	public int checkDealandReference(String dealReference,
			String referenceNumber, double paymentAmount, Date sqlDate,
			Connection con) throws Exception {
		// Connection con = null;
		ResultSet rs = null;
		LoggableStatement pst = null;
		String query = null;
		int result = 0;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			query = "SELECT COUNT(*) AS COUNT FROM ETT_STP_REPAYMENT WHERE "
					+ "TRIM(LOAN_MASTER_REF)='"
					+ dealReference.trim()
					+ "' AND  TRIM(PRC_ALLC_AMOUNT) = "
					+ paymentAmount
					+ " AND STATUS_FLAG = 'CA' "
					+ "AND GW_STATUS = 'S' AND TO_CHAR(TO_DATE(VALUE_DATE,'DD-MM-YYYY'),'DD-MM-YY') ="
					+ " TO_CHAR(TO_DATE('" + sqlDate
					+ "','YYYY-MM-DD'),'DD-MM-YY') ";
			pst = new LoggableStatement(con, query);
			System.out.println("Warning Query---->" + query
					+ " -------->and sqlDate" + sqlDate);
			rs = pst.executeQuery();
			if (rs.next()) {
				result = rs.getInt("COUNT");
			}
		} catch (Exception e) {
			System.out.println("Warning e----->" + e.getMessage());
			throw (e);
		} finally {
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		return result;
	}

	/**
	 * EJB Implementation
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String fetchEJBResponse(String xmlToPost) throws Exception {
		String result = null;
		String ejbUrl = SystemPropertiesUtil.getEJBURL();
		try {
			/* FOR WEBSPHERE */
			logger.info("EJB Step1");
			System.getProperties().put("java.naming.factory.initial",
					"com.ibm.websphere.naming.WsnInitialContextFactory");
			logger.info("EJB Step2");
			System.getProperties().put("java.naming.provider.url", ejbUrl);
			logger.info("EJB Step3");
			Context ctx = new InitialContext();
			Object ejbObject = ctx.lookup("ejb/EnigmaServiceAccess");
			logger.info("EJB Step4");
			EnigmaServiceAccessHome accessBeanHome = (EnigmaServiceAccessHome) javax.rmi.PortableRemoteObject
					.narrow(ejbObject, EnigmaServiceAccessHome.class);
			logger.info("EJB Step5");
			EnigmaServiceAccess accessB = accessBeanHome.create();
			logger.info("EJB Step6");
			result = accessB.process(xmlToPost);
			logger.info("EJB Step7");
			/* FOR WEBLOGIC */
			/*
			 * logger.info("Request XML------>"+xmlToPost); Hashtable env = new
			 * Hashtable(5); logger.info("EJB Step1");
			 * env.put(Context.INITIAL_CONTEXT_FACTORY,
			 * "weblogic.jndi.WLInitialContextFactory");
			 * logger.info("EJB Step2"); env.put(Context.PROVIDER_URL, ejbUrl);
			 * logger.info("EJB Step3"); Context ctx = new InitialContext(env);
			 * logger.info("EJB Step4"); Object ejbObject =
			 * ctx.lookup("ejb/EnigmaServiceAccess"); logger.info("EJB Step5");
			 * EnigmaServiceAccessHome accessBeanHome =
			 * (EnigmaServiceAccessHome) javax.rmi.PortableRemoteObject
			 * .narrow(ejbObject, EnigmaServiceAccessHome.class);
			 * logger.info("EJB Step6"); EnigmaServiceAccess accessB =
			 * accessBeanHome.create(); logger.info("EJB Step7"); result =
			 * accessB.process(xmlToPost);
			 */
			// result = "SUCCEEDED";
			logger.debug("Response from EJB CLient -> \n" + result);
		} catch (Exception e) {
			logger.info("EJB Exception----->" + e.getMessage());
			throw (e);
		}
		return result;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String updateAPISERVER(String response, String sequence,
			Connection con) throws Exception {
		// Connection con = null;
		LoggableStatement pst = null;
		String query = null;
		String status = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			DocumentBuilder builder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();
			InputSource src = new InputSource();
			src.setCharacterStream(new StringReader(response));
			Document doc = builder.parse(src);
			status = doc.getElementsByTagName("Status").item(0)
					.getTextContent();
			// status = "FAILED";
			response = response.replaceAll("'", "\"");
			logger.info("EJB Status for APISequence- " + sequence + "----->"
					+ status);
			query = "UPDATE ETT_CLF_APISERVER SET STATUS='" + status
					+ "',RESPONSE='" + response
					+ "',UPLOADED=SYSDATE WHERE SEQUENCE='" + sequence + "'";
			logger.info("EJB Update Query--->" + query);
			pst = new LoggableStatement(con, query);
			pst.executeUpdate();
		} catch (Exception e) {
			logger.info("EJB catching status Exception----->" + e.getMessage());
			throw (e);
		} finally {
			//Connection Leak
			DBConnectionUtility.surrenderStatement(null, pst);
			//DBConnectionUtility.surrenderDB(null, pst, con);
			//Connection Leak
		}
		return status;
	}

	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String updateAPISequence(String Batchid, String sequence,
			Connection con, String masterRef) throws Exception {
		LoggableStatement pst = null;
		String query = null;
		String status = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			if(masterRef != null ) {
				masterRef = masterRef.trim();
			}
			query = "UPDATE ETT_STP_REPAYMENT SET APISERVER_SEQ_NO='"
					+ sequence + "',GW_STATUS='W' WHERE BATCH_ID='" + Batchid
					+ "'  AND trim(LOAN_MASTER_REF) ='" + masterRef + "'";
			pst = new LoggableStatement(con, query);
			System.out.println("update stp repayment Api sequence --------------->"+query);
			pst.executeUpdate();
		} catch (Exception e) {
			System.out.println("Exception while update stp repayment Api sequence --------------->");
			e.printStackTrace();
		} finally {
			
			DBConnectionUtility.surrenderStatement(null, pst);
			
			
		}
		return status;
	}
	
	// ** RTGNS NEFT
	/**
	 * 
	 * @param sourceStr
	 * @return
	 */
	public String getDataSign(Object sourceStr) {
		return convertSign(sourceStr, "-");
	}

	/**
	 * 
	 * @param sourceStr
	 * @param toConvert
	 * @return
	 */
	public static String convertSign(Object sourceStr, Object toConvert) {
		return signValue(sourceStr) ? toConvert.toString() : sourceStr
				.toString();
	}// end of method convertIfNull()

	/**
	 * 
	 * @param obj
	 * @return
	 */
	public static boolean signValue(Object obj) {
		if (obj == null) {
			return true;
		} else if (obj instanceof String) {
			return (((String) obj).trim().length() == 0);
		} else if (obj instanceof Collection) {
			return (((Collection) obj).size() == 0);
		} else {
			return false;
		}
	}

	/**
	 * 
	 * @return
	 * @throws DAOException
	 */
	public Map<String, String> fetchEmailDetails(String emailType) {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		String query = null;
		Map<String, String> map = new HashMap<String, String>();
		try {
			con = DBConnectionUtility.getConnection();
			query = "select * from ETT_AUTO_EMAIL where TRIM(EMAIL_TYPE)='"
					+ emailType + "' ";
			ps = new LoggableStatement(con, query);
			logger.info("Executing Query->" + ps.getQueryString());
			rs = ps.executeQuery();
			if (rs.next()) {
				map.put("RPT_NAME", rs.getString("RPT_NAME"));
				map.put("RPT_IN", rs.getString("RPT_IN"));
				map.put("RPT_OUT", rs.getString("RPT_OUT"));
				map.put("T0_ADDR", rs.getString("T0_ADDR"));
				map.put("CC_ADDR", rs.getString("CC_ADDR"));
				map.put("MAIL_BODY", rs.getString("MAIL_BODY"));
				map.put("MAIL_SUBJECT", rs.getString("MAIL_SUBJECT"));
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return map;
	}

	/**
	 * @throws Exception
	 * 
	 */
	public void generateEmail(String programID, String batchID, String cifID,
			String rptName, String emailType, String toEmail, String ccEmail,
			String subject, String Body, String rptFolder, String rptOutFolder)
			throws Exception {
		GenPDFSendMail mail = new GenPDFSendMail();
		List<BankLimitVO> lbvl = new ArrayList<BankLimitVO>();
		BankLimitVO bvo = new BankLimitVO();
		Connection con = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			bvo.setPROGRAM_ID(getEmptyIfNull(programID));
			bvo.setBATCH_ID(getEmptyIfNull(batchID));
			bvo.setFROM_DATE(getTIDate());
			bvo.setTO_DATE(getTIDate());
			bvo.setCUSTOMER_ID(getEmptyIfNull(cifID));
			bvo.setRPT_FILENAME(getEmptyIfNull(rptName));
			// String metaData = getTiplusSubject(emailType);
			// LinkedHashMap<String, String> emailText = getMetaMap(metaData);
			bvo.setTO_EMAIL(getEmptyIfNull(toEmail));
			bvo.setCC_EMAIL(getEmptyIfNull(ccEmail));
			bvo.setSUBJECT_EMAIL(getEmptyIfNull(subject));
			bvo.setBODY_EMAIL(getEmptyIfNull(Body));
			System.out.println("fromdate" + getTIDate());
			System.out.println("todate" + getTIDate());
			lbvl.add(bvo);
			ConnObj cob = new ConnObj();
			cob.setCon(con);
			cob.setDB_DRIVER("");
			cob.setDB_SERVERNAME("");
			cob.setDB_PORT("");
			cob.setDB_ORACLENAME("");
			cob.setDB_USERNAME("");
			cob.setDB_PASSWORD("");
			cob.setDB_NAME("");
			// PropertyUtils.newInstance().getContextPath();
			cob.setRPT_FOLDERLOC(getEmptyIfNull(rptFolder));
			cob.setRPT_OPFOLDERLOC(getEmptyIfNull(rptOutFolder));
			String XMLRequest = mail.genAdvFormat(lbvl, cob);
			/*
			 * String XMLRequest = mail.sendEmailWithAttachments(null,
			 * getEmptyIfNull(toEmail), getEmptyIfNull(ccEmail),
			 * getEmptyIfNull(subject), getEmptyIfNull(Body), "REPAYMENT",
			 * programID, cifID);
			 */
			logger.info("Email Request-------->" + XMLRequest);
			InvokeService limitCheck = new InvokeService();
			String responseXML = limitCheck.processRequest(XMLRequest);
			String SMSRequest = mail.fetchSMSRequest("9940840129",
					getEmptyIfNull(Body));
			String SMSResponse = limitCheck.processRequest(SMSRequest);
			System.out.println("EMAIL responseXML-->" + responseXML);
			System.out.println("SMS responseXML-->" + SMSResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
		//Connection Leak
		
		finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}
		//Connection Leak
	}

	public void generateEmail(Connection con, String programID, String batchID,
			String cifID, String rptName, String emailType, String toEmail,
			String ccEmail, String subject, String Body, String rptFolder,
			String rptOutFolder, String smsContent) throws Exception {
		GenPDFSendMail mail = new GenPDFSendMail();
		List<BankLimitVO> lbvl = new ArrayList<BankLimitVO>();
		BankLimitVO bvo = new BankLimitVO();
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			bvo.setPROGRAM_ID(getEmptyIfNull(programID));
			bvo.setBATCH_ID(getEmptyIfNull(batchID));
			bvo.setFROM_DATE(getTIDate());
			bvo.setTO_DATE(getTIDate());
			bvo.setCUSTOMER_ID(getEmptyIfNull(cifID));
			bvo.setRPT_FILENAME(getEmptyIfNull(rptName));
			// String metaData = getTiplusSubject(emailType);
			// LinkedHashMap<String, String> emailText = getMetaMap(metaData);
			bvo.setTO_EMAIL(getEmptyIfNull(toEmail));
			bvo.setCC_EMAIL(getEmptyIfNull(ccEmail));
			bvo.setSUBJECT_EMAIL(getEmptyIfNull(subject));
			bvo.setBODY_EMAIL(getEmptyIfNull(Body));
			System.out.println("fromdate" + getTIDate());
			System.out.println("todate" + getTIDate());
			lbvl.add(bvo);
			ConnObj cob = new ConnObj();
			cob.setCon(con);
			cob.setDB_DRIVER("");
			cob.setDB_SERVERNAME("");
			cob.setDB_PORT("");
			cob.setDB_ORACLENAME("");
			cob.setDB_USERNAME("");
			cob.setDB_PASSWORD("");
			cob.setDB_NAME("");
			// PropertyUtils.newInstance().getContextPath();
			cob.setRPT_FOLDERLOC(getEmptyIfNull(rptFolder));
			cob.setRPT_OPFOLDERLOC(getEmptyIfNull(rptOutFolder));
			String XMLRequest = mail.genAdvFormat(lbvl, cob);
			logger.info("Email Request-------->" + XMLRequest);
			InvokeService limitCheck = new InvokeService();
			String responseXML = limitCheck.processRequest(XMLRequest);
			String SMSRequest = mail.fetchSMSRequest("9940840129",
					getEmptyIfNull(smsContent));
			String SMSResponse = limitCheck.processRequest(SMSRequest);
			System.out.println("EMAIL responseXML-->" + responseXML);
			System.out.println("SMS responseXML-->" + SMSResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @return
	 * @throws DAOException
	 */
	private String getTIDate() {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement pst = null;
		ResultSet rs = null;
		Connection con = null;
		String tiDate = null;
		try {
			CommonMethods commonMethods = null;
			commonMethods = new CommonMethods();
			con = DBConnectionUtility.getConnection();
			String query = "SELECT TO_CHAR(TO_DATE(PROCDATE, 'dd-mm-yy'),'dd-MM-yyyy') as PROCDATE FROM dlyprccycl";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				tiDate = commonMethods.getEmptyIfNull(rs.getString("PROCDATE"))
						.trim();
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return tiDate;
	}

	/**
	 * 
	 * @return
	 * @throws DAOException
	 */
	public void insertEmailAndSMSTrigger(String batchID, String programID,
			String customer, String cparty, String emailType, String UTRReceived,Connection con)
			throws DAOException {
		logger.info(ActionConstants.ENTERING_METHOD);
		LoggableStatement pst = null;
		ResultSet rs = null;
		//Connection con = null;
		CommonMethods commonMethods = null;
		try {
			commonMethods = new CommonMethods();
			if(con == null){
			con = DBConnectionUtility.getConnection();
			}
			String query = "INSERT INTO ETT_AUTO_EMAIL_TRIG (SNO,BATCH_ID,CUSTOMER,CUSTOMER_PROCESS,CPARTY,"
					+ "CPARTY_PROCESS,ADVICE_PROCESS,ADVICE_EOD,PROCDATE,PRGRMID,UTR_RECEIVED,EMAIL_TYPE) "
					+ "VALUES (EMAIL_SEQUENCE.NEXTVAL,'"
					+ commonMethods.getEmptyIfNull(batchID).trim()
					+ "',"
					+ "'"
					+ commonMethods.getEmptyIfNull(customer).trim()
					+ "','N','"
					+ commonMethods.getEmptyIfNull(cparty).trim()
					+ "',"
					+ "'N','N','N',(SELECT PROCDATE FROM DLYPRCCYCL),'"
					+ commonMethods.getEmptyIfNull(programID).trim()
					+ "',(SELECT CASE WHEN COUNT(BATCHNO)=0 THEN 'Y' ELSE 'N' END  COUNT FROM THEMEBRIDGE.ETT_RTNF_OUTWARD WHERE trim(BATCHNO)=trim('"
					+ batchID + "')),'" + emailType + "')";
			pst = new LoggableStatement(con, query);
			pst.executeUpdate();
		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderStatement(rs,pst);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}
	
	
	public String limitRevFlag(Connection con){
		logger.info(ActionConstants.ENTERING_METHOD);
		String result = null;
		//Connection con = null;
		LoggableStatement pst = null;
		ResultSet rs = null;
		try{
			if(con==null){
				con = DBConnectionUtility.getConnection();
			}
			String FETCH_QUERY = "SELECT VAL FROM ETT_CLF_PROPERTIES WHERE KEYID='LIMITREVFLAG' ";
			pst = new LoggableStatement(con,FETCH_QUERY);
			rs = pst.executeQuery();
			System.out.println("Limit Check Flag Query--->"+pst.getQueryString());
		while(rs.next()){
			result = getEmptyIfNull(rs.getString("VAL")).trim();
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnectionUtility.surrenderStatement(rs, pst);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		
		return result;
	}	
	
}