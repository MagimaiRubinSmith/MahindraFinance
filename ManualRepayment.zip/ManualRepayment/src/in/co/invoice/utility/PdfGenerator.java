package in.co.invoice.utility;

import in.co.invoice.vo.InvMatchingVO;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;

//PDF download (Aug 7 2019) starts
public class PdfGenerator {
	private static Logger logger = Logger.getLogger(PdfGenerator.class
			.getName());

	public void writePdf(ArrayList<InvMatchingVO> invoiceList,
			ByteArrayOutputStream baos, String invoice) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		try {
			Document document = new Document(
					new Rectangle(PageSize.A4.rotate()));
			PdfWriter writer = PdfWriter.getInstance(document, baos);
			HeaderFooterPageEvent event = new HeaderFooterPageEvent();
			writer.setPageEvent(event);

			Font fontlet = new Font(FontFactory.getFont("Arial", 11, Font.BOLD,
					BaseColor.BLACK));
			Font fontList = new Font(FontFactory.getFont("Arial", 10,
					Font.NORMAL, BaseColor.BLACK));

			PdfPTable tableList = new PdfPTable(12); // 12 columns
			tableList.setSpacingBefore(5f);
			tableList.setSpacingAfter(5f);
			tableList.setWidthPercentage(100);

			PdfPCell cell1 = new PdfPCell(new Phrase("Period", fontlet));
			cell1.setPadding(5);
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell1);

			PdfPCell cell2 = new PdfPCell(new Phrase(
					"Invoice Reference Number", fontlet));
			cell2.setPadding(5);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell2);

			PdfPCell cell3 = new PdfPCell(new Phrase("Pay date", fontlet));
			cell3.setPadding(5);
			cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell3);

			PdfPCell cell4 = new PdfPCell(new Phrase("End date", fontlet));
			cell4.setPadding(5);
			cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell4);

			PdfPCell cell5 = new PdfPCell(new Phrase("Opening", fontlet));
			cell5.setPadding(5);
			cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell5);

			PdfPCell cell6 = new PdfPCell(new Phrase("Payment", fontlet));
			cell6.setPadding(5);
			cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell6);

			PdfPCell cell7 = new PdfPCell(new Phrase("Interest", fontlet));
			cell7.setPadding(5);
			cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell7);

			PdfPCell cell8 = new PdfPCell(new Phrase("Principal", fontlet));
			cell8.setPadding(5);
			cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell8);

			PdfPCell cell9 = new PdfPCell(new Phrase("Closing", fontlet));
			cell9.setPadding(5);
			cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell9);

			PdfPCell cell10 = new PdfPCell(new Phrase("Start Date", fontlet));
			cell10.setPadding(5);
			cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell10);

			PdfPCell cell11 = new PdfPCell(new Phrase("End date", fontlet));
			cell11.setPadding(5);
			cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell11);

			PdfPCell cell12 = new PdfPCell(new Phrase("DPD", fontlet));
			cell12.setPadding(5);
			cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableList.addCell(cell12);

			for (int k = 0; k < invoiceList.size(); k++) {
				InvMatchingVO invList = invoiceList.get(k);
				PdfPCell columnCell1 = new PdfPCell(new Phrase(
						invList.getPeriod(), fontList));
				columnCell1.setPadding(5);
				columnCell1.setHorizontalAlignment(Element.ALIGN_RIGHT);
				tableList.addCell(columnCell1);

				PdfPCell columnCell2 = new PdfPCell(new Phrase(
						invList.getInvRefNo(), fontList));
				columnCell2.setPadding(5);
				columnCell2.setHorizontalAlignment(Element.ALIGN_CENTER);
				tableList.addCell(columnCell2);

				PdfPCell columnCell3 = new PdfPCell(new Phrase(
						invList.getPayDate(), fontList));
				columnCell3.setPadding(5);
				columnCell3.setHorizontalAlignment(Element.ALIGN_CENTER);
				tableList.addCell(columnCell3);

				PdfPCell columnCell4 = new PdfPCell(new Phrase(
						invList.getEndDate(), fontList));
				columnCell4.setPadding(5);
				columnCell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				tableList.addCell(columnCell4);

				PdfPCell columnCell5 = new PdfPCell(new Phrase(
						invList.getOpening(), fontList));
				columnCell5.setPadding(5);
				columnCell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
				tableList.addCell(columnCell5);

				PdfPCell columnCell6 = new PdfPCell(new Phrase(
						invList.getPayment(), fontList));
				columnCell6.setPadding(5);
				columnCell6.setHorizontalAlignment(Element.ALIGN_RIGHT);
				tableList.addCell(columnCell6);

				PdfPCell columnCell7 = new PdfPCell(new Phrase(
						invList.getInterest(), fontList));
				columnCell7.setPadding(5);
				columnCell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
				tableList.addCell(columnCell7);

				PdfPCell columnCell8 = new PdfPCell(new Phrase(
						invList.getPrincipal(), fontList));
				columnCell8.setPadding(5);
				columnCell8.setHorizontalAlignment(Element.ALIGN_RIGHT);
				tableList.addCell(columnCell8);

				PdfPCell columnCell9 = new PdfPCell(new Phrase(
						invList.getClosing(), fontList));
				columnCell9.setPadding(5);
				columnCell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
				tableList.addCell(columnCell9);

				PdfPCell columnCell10 = new PdfPCell(new Phrase(
						invList.getStartDate(), fontList));
				columnCell10.setPadding(5);
				columnCell10.setHorizontalAlignment(Element.ALIGN_CENTER);
				tableList.addCell(columnCell10);

				PdfPCell columnCell11 = new PdfPCell(new Phrase(
						invList.getEnd_date(), fontList));
				columnCell11.setPadding(5);
				columnCell11.setHorizontalAlignment(Element.ALIGN_CENTER);
				tableList.addCell(columnCell11);

				PdfPCell columnCell12 = new PdfPCell(new Phrase(
						invList.getDpd(), fontList));
				columnCell12.setPadding(5);
				columnCell12.setHorizontalAlignment(Element.ALIGN_RIGHT);
				tableList.addCell(columnCell12);

				float[] tableListColumnWidths = new float[] { 25f, 45f, 25f,
						25f, 25f, 25f, 25f, 25f, 25f, 30f, 25f, 25f };
				tableList.setWidths(tableListColumnWidths);

			}

			float[] tableColumnWidth = { 20f };
			PdfPTable table = new PdfPTable(tableColumnWidth);
			table.setSpacingBefore(5f);
			table.setSpacingAfter(5f);
			table.setWidthPercentage(100);
			table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);

			Phrase firstLineLeft = new Phrase("Reference Number : " + invoice,
					fontlet);
			table.addCell(firstLineLeft);

			document.open();

			Chunk linebreak = new Chunk(new LineSeparator());
			document.add(linebreak);
			document.add(table);
			document.add(tableList);

			document.close();

		} catch (Exception e) {
			logger.error("Exception in Writing Pdf" + e);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public class HeaderFooterPageEvent extends PdfPageEventHelper {
		// adding header
		@Override
		public void onStartPage(PdfWriter writer, Document document) {
			logger.info(ActionConstants.ENTERING_METHOD);
			try {
				Font fontTitle = new Font(FontFactory.getFont("Arial", 16,
						Font.BOLD, BaseColor.BLACK));
				Font fontBold = new Font(FontFactory.getFont("Arial", 11,
						Font.BOLD, BaseColor.BLACK));
				Font fontNormal = new Font(FontFactory.getFont("Arial", 11,
						Font.NORMAL, BaseColor.BLACK));

				HttpServletRequest request = ServletActionContext.getRequest();
				Image headerLogo = null;

				String contextPath = request.getContextPath();
				String splitPath[] = contextPath.split("/");
				contextPath = request.getServletContext().getRealPath(
						splitPath[0]);

				String headerLogoPath = "/images/MF_HeaderLogo.png";

				headerLogo = Image.getInstance(contextPath + headerLogoPath);
				headerLogo.scaleToFit(100, 100);

				float[] headerTableColumnWidths = { 20f, 20f, 25f };
				PdfPTable headerTable = new PdfPTable(headerTableColumnWidths);
				headerTable.setSpacingAfter(10f);
				headerTable.setWidthPercentage(100);
				headerTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

				headerTable.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_LEFT);
				headerTable.addCell(headerLogo);
				headerTable.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_CENTER);
				PdfPCell titleHeader = new PdfPCell(new Phrase(
						"     Repayment Schedule", fontTitle));
				titleHeader.setBorder(Rectangle.NO_BORDER);
				titleHeader.setVerticalAlignment(Element.ALIGN_BOTTOM);
				headerTable.addCell(titleHeader);
				headerTable.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_RIGHT);
				Phrase datePhrase = new Phrase();
				datePhrase.add(new Chunk(
						"Mahindra and Mahindra Financial Service Limited"
								+ "\n", fontBold));
				datePhrase.add(new Chunk("Mahindra Towers, 4th Floor," + "\n"
						+ "Dr. G. M. Bhosale Marg, Worli," + "\n"
						+ "Mumbai 400 018 India" + "\n" + "\n"
						+ "Tel: +91 22 66526000" + "\n"
						+ "Direct: +91 22 66526107", fontNormal));
				PdfPCell headerAddress = new PdfPCell(datePhrase);
				headerAddress.setBorder(Rectangle.NO_BORDER);
				headerAddress.setVerticalAlignment(Element.ALIGN_RIGHT);
				headerTable.addCell(headerAddress);

				document.add(headerTable);
			} catch (Exception e) {
				logger.error("Exception in onStartPage ->" + e);
			}
			logger.info(ActionConstants.EXITING_METHOD);
		}

		// adding footer
		@Override
		public void onEndPage(PdfWriter writer, Document document) {
			logger.info(ActionConstants.ENTERING_METHOD);
			try {
				Font fontNormal = new Font(FontFactory.getFont("Arial", 12,
						Font.NORMAL, BaseColor.BLACK));
				HttpServletRequest request = ServletActionContext.getRequest();

				Image footerLogo = null;
				String contextPath = request.getContextPath();
				String splitPath[] = contextPath.split("/");
				contextPath = request.getServletContext().getRealPath(
						splitPath[0]);

				String footerLogoPath = "/images/MF_FooterLogo.png";

				footerLogo = Image.getInstance(contextPath + footerLogoPath);
				footerLogo.scaleToFit(100, 100);

				float[] footerTablecolumnWidths = { 25f, 20f };
				PdfPTable footerTable = new PdfPTable(footerTablecolumnWidths);
				footerTable.setSpacingBefore(10f);
				footerTable.setTotalWidth(PageSize.A4.rotate().getWidth() - 45);
				footerTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				footerTable.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_LEFT);
				PdfPCell footerAddress = new PdfPCell(
						new Phrase(
								"Regd.office: Gateway Building, Apollo Bunder, Mumbai 400 001 India"
										+ "\n"
										+ "Tel: +91 22 2202 1031 | Fax: +91 22 2287 5485 | www.mahindrafinance.com"
										+ "\n"
										+ "CIN - L65921MH1991PLC059642"
										+ "\n"
										+ "Serivce Tax Registration No. : AAACM2931RST001",
								fontNormal));
				footerAddress.setBorder(Rectangle.NO_BORDER);
				footerAddress.setVerticalAlignment(Element.ALIGN_RIGHT);
				footerTable.addCell(footerAddress);
				footerTable.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_CENTER);
				footerTable.addCell(footerLogo);
				footerTable.writeSelectedRows(0, -1, PageSize.A4.rotate()
						.getLeft() + 20, PageSize.A4.rotate().getBottom() + 20
						+ footerTable.getTotalHeight(), writer
						.getDirectContent());

			} catch (Exception e) {
				logger.error("Exception in onEndPage ->" + e);
			}
			logger.info(ActionConstants.EXITING_METHOD);
		}
	}
}
// PDF download (Aug 7 2019) ends