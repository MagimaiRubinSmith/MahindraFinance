package in.co.invoice.utility;


import in.co.invoice.vo.InvMatchingVO;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class SmithThreadConcept implements Runnable {
	ArrayList<InvMatchingVO> XMLList;
	Connection con;
	int invoiceCount;
	String batchID1;
	public SmithThreadConcept(ArrayList<InvMatchingVO> XMLThreadList,	Connection conn,int invoiceTotal,String batchID1){
		this.XMLList = XMLThreadList;
		this.con = conn;
		this.invoiceCount = invoiceTotal;
		this.batchID1 = batchID1;
	}
	
    public void run()
    {
        try
        {
        	//Thread.sleep(10000);
            System.out.println ("Thread " +Thread.currentThread().getId() +" is running----->Request"+XMLList.get(0).getXmlRequest());
            threadImplementForEjb();
        }
        catch (Exception e)
        {
            System.out.println ("Exception is caught while thread run");
			e.printStackTrace();
        }
    }

	public void threadImplementForEjb() throws InterruptedException {
		CommonMethods comm = new CommonMethods();
		try {
			try {
				Thread.sleep(1000);
				System.out.println("Thread Sleep for 1000 ms"+(XMLList.get(0).getXmlRequest()));
				String xmlResponse = comm.fetchEJBResponse(XMLList.get(0)
						.getXmlRequest());
				System.out.println("TIRESPONSE SEQUENCE--->"+ XMLList.get(0).getXmlSequence());
				comm.updateAPISERVER(xmlResponse, XMLList.get(0)
						.getXmlSequence(), con);
				System.out.println("TIRESPONSE MASTER REFERENCE--->"+ XMLList.get(0).getMasterReference());
				comm.updateAPISequence(batchID1, XMLList.get(0).getXmlSequence(), con,XMLList.get(0).getMasterReference());
			} catch (Exception e) {
				System.out.println("EJB EXCEPTION FOUND AT EJB RESPONSE"+XMLList.get(0).getXmlRequest());
				e.printStackTrace();
			}
		} catch (Exception e) {
			System.out
					.println("Exception is caught while ejb thread execution");
			e.printStackTrace();
		}
	}
    
}