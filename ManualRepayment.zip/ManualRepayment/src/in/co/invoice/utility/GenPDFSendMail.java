package in.co.invoice.utility;


import in.co.invoice.vo.BankLimitVO;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import com.crystaldecisions.sdk.occa.report.application.ReportClientDocument;
import com.crystaldecisions.sdk.occa.report.data.ConnectionInfo;
import com.crystaldecisions.sdk.occa.report.data.Fields;
import com.crystaldecisions.sdk.occa.report.data.IFilter;
import com.crystaldecisions.sdk.occa.report.data.IParameterField;
import com.crystaldecisions.sdk.occa.report.data.ITable;
import com.crystaldecisions.sdk.occa.report.data.Tables;
import com.crystaldecisions.sdk.occa.report.document.IPrintOptions;
import com.crystaldecisions.sdk.occa.report.document.PrintOptions;
import com.crystaldecisions.sdk.occa.report.exportoptions.ReportExportFormat;
import com.crystaldecisions.sdk.occa.report.lib.PropertyBag;
import com.crystaldecisions.sdk.occa.report.lib.ReportSDKException;
//import in.co.nostro.vo.bankLimit.BankLimitVO;

public class GenPDFSendMail {
	
	private String inputFilePath = "";
	private String outputFilePath = "";
	private String reportName = "";
	private String whereClause = "";
	private static Logger logger = Logger.getLogger(BankLimitVO.class
			.getName());
	
	ArrayList<String> folderfilenames = new ArrayList<String>();
	BankLimitVO vo=new BankLimitVO();

	public static void main(String[] args) throws Exception {
		GenPDFSendMail pdf = new GenPDFSendMail();
		pdf.checkGetAdvFormat();
	}
	
	public void checkGetAdvFormat() throws Exception
	{
		Connection con = null;
		try {
			List<BankLimitVO> lbvl = new ArrayList<BankLimitVO>();
			// for(int i=0;i<1;i++){

			BankLimitVO bvo = new BankLimitVO();
			// IDFC CLOUD PARAMS
			bvo.setPROGRAM_ID("");
			bvo.setBATCH_ID("4721");
			bvo.setFROM_DATE("");
			bvo.setTO_DATE("");
			bvo.setCUSTOMER_ID("");

			// IDFC CLF PARAMS
			/*
			 * bvo.setPROGRAM_ID("TEST_DFDL"); bvo.setBATCH_ID("DF-010118-TEST-1333");
			 * bvo.setFROM_DATE("01-01-2018"); bvo.setTO_DATE("01-03-2018");
			 * bvo.setCUSTOMER_ID("1000075933");
			 */
			// bvo.setBATCH_ID("VF-100717-VFAL-744");
			bvo.setRPT_FILENAME("repay_advice.rpt");

			bvo.setTO_EMAIL("JANMANCHI.BALACHANDAR@mahindra.com;");
			bvo.setCC_EMAIL("");
			bvo.setSUBJECT_EMAIL("Advice for Customer" + bvo.getCUSTOMER_ID());
			bvo.setBODY_EMAIL("Attached herewith are the advices for Program" + bvo.getPROGRAM_ID());
			/*
			 * bvo.setFROM_DATE("22-08-2016"); bvo.setTO_DATE("22-08-2016");
			 * bvo.setCUSTOMER_ID("custid"+i); bvo.setRPT_FILENAME("VFAL-Disb adv to
			 * Anchor-IA-Net);;
			 */
			lbvl.add(bvo);
			// }
			ConnObj cob = new ConnObj();
			cob.setDB_DRIVER("oracle.jdbc.driver.OracleDriver");
			cob.setDB_SERVERNAME("172.30.9.12");
			cob.setDB_PORT("1555");
			cob.setDB_ORACLENAME("MISYSUAT");
			cob.setDB_USERNAME("TIZONE");
			cob.setDB_PASSWORD("theme123");
			cob.setDB_NAME("TIZONE");
			con = DBConnectionUtility.getConnection();
			cob.setCon(con);
			cob.setRPT_FOLDERLOC("D:/WAS_HOME/SCF/rpt" + File.separator);
			cob.setRPT_OPFOLDERLOC("D:/WAS_HOME/SCF/rpt" + File.separator);
			genAdvFormat(lbvl, cob);
		}
		// Connection Leak
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnectionUtility.surrenderDB(null, null, con);
			
		}
		// Connection Leak
	}
	// the method genAdvFormat(List<BankLimitVO> adviceListVO,ConnObj cobj ) in class GenPDFSendMail
	//  will be part of a jar file usage of this can be like ,if you intend to Create set of reports(predefined) and specify the type of format
	//For this jar to perform and trigger reports it needs connection to a DB,So pass the connection parameters as a an Object<ConnObj> and Report parameters like
	//name of the .rpt file and it's parameters can be passed through another Object<BankLimitVO>, So this jar also needs where to Pick the .rpt 
	//i.e file location of the RPT and after the report is generated it has to be saved in a Physical location and that location too has to 
	// be specified via ConnObj,This can send email as well
	//pseudocode to use this jar is provided in checkGetAdvFormat()
	
	public static Connection getConnection() throws SQLException {
		Connection connection = null;
			try {
				String driver = "oracle.jdbc.driver.OracleDriver";
				String url = "jdbc:oracle:thin:@172.30.9.12:1555/MISYSUAT";
				String userName = "TIZONE";
				String password = "theme123";
				Class.forName(driver);
				connection = DriverManager.getConnection(url, userName,password);
				
				/*Context ctx = null;
				String providerURL = "t3://172.19.36.107";
				String contextPort = "7007";
				String lookupName = "jdbc/zone";
				Hashtable<String, String> ht = new Hashtable<String, String>();
				ht.put(Context.INITIAL_CONTEXT_FACTORY,
						"weblogic.jndi.WLInitialContextFactory");
				ht.put(Context.PROVIDER_URL, providerURL + ":"+ contextPort);
				ctx = new InitialContext(ht);
				javax.sql.DataSource ds = (javax.sql.DataSource) ctx.lookup(lookupName);
				connection = ds.getConnection();*/

			} catch (Exception e) {
				System.out.println("Error is " + e.getMessage());
			}
		return connection;
	}
	
	//Generating Auto Advice in the format specified, however we call Crystal Reports and pass in  an .RPT and pass the arguments
	// and specify the format like PDF,excel etc. 
	public String genAdvFormat(List<BankLimitVO> adviceListVO,ConnObj cobj ) throws Exception
	{
		
		String outputfilename="";
		String requestAuto = null;
		String whereCondition = "";
		String whereCondition1 = "";
		if(adviceListVO.size() != 0 && !adviceListVO.equals(null)){
		for(BankLimitVO list :adviceListVO){
				list.getTO_EMAIL();
				if (list.getFILE_PATH() != null
						&& !list.getFILE_PATH().isEmpty()) {
					inputFilePath = list.getFILE_PATH();
				}
				if (list.getRPT_FILENAME() != null
						&& !list.getRPT_FILENAME().isEmpty()) {
					reportName = list.getRPT_FILENAME();
				}
				whereClause = "";
				//forming where clause
				if (reportName != null && reportName.equalsIgnoreCase("batch_utr_disb.rpt")) {
					int m = 0;
					int k = 0;
					int j = 0;
					if (list.getCUSTOMER_ID() != null
							&& !list.getCUSTOMER_ID().isEmpty()) {
						if (k > 0 || m > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(MF_EMAIL_BATCHDISB_UTR.CPARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ "  TRIM(MF_EMAIL_BATCHDISB_UTR.CPARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						}
						j = j + 1;
					}
					if (list.getBATCH_ID() != null
							&& !list.getBATCH_ID().isEmpty()) {
						if (j > 0 || k > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(MF_EMAIL_BATCHDISB_UTR.BATCHID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ " TRIM(MF_EMAIL_BATCHDISB_UTR.BATCHID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						}
					}
					if (list.getPROGRAM_ID() != null
							&& !list.getPROGRAM_ID().isEmpty()) {
						whereCondition = whereCondition + " AND TRIM(MF_EMAIL_BATCHDISB_UTR.PROGRAM_ID) =  "
								+ "'" + list.getPROGRAM_ID().trim() + "'";
					}
				}else if (reportName != null && reportName.equalsIgnoreCase("validation_fail.rpt")) {
					int m = 0;
					int k = 0;
					int j = 0;
					if (list.getCUSTOMER_ID() != null
							&& !list.getCUSTOMER_ID().isEmpty()) {
						if (k > 0 || m > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(MF_EMAIL_FAILUREVALIDATION.CPARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ "  TRIM(MF_EMAIL_FAILUREVALIDATION.CPARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						}
						j = j + 1;
					}
					if (list.getBATCH_ID() != null
							&& !list.getBATCH_ID().isEmpty()) {
						if (j > 0 || k > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(MF_EMAIL_FAILUREVALIDATION.BATCHID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ " TRIM(MF_EMAIL_FAILUREVALIDATION.BATCHID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						}
					}
					if (list.getPROGRAM_ID() != null
							&& !list.getPROGRAM_ID().isEmpty()) {
						whereCondition = whereCondition + " AND TRIM(MF_EMAIL_FAILUREVALIDATION.PROGRAM_ID) =  "
								+ "'" + list.getPROGRAM_ID().trim() + "'";
					}
				}else if (reportName != null && reportName.equalsIgnoreCase("accep_validation.rpt")) {
					int m = 0;
					int k = 0;
					int j = 0;
					if (list.getCUSTOMER_ID() != null
							&& !list.getCUSTOMER_ID().isEmpty()) {
						if (k > 0 || m > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(MF_EMAIL_APPROVEDVALIDATION.CPARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ "  TRIM(MF_EMAIL_APPROVEDVALIDATION.CPARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						}
						j = j + 1;
					}
					if (list.getBATCH_ID() != null
							&& !list.getBATCH_ID().isEmpty()) {
						if (j > 0 || k > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(MF_EMAIL_APPROVEDVALIDATION.BATCHID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ " TRIM(MF_EMAIL_APPROVEDVALIDATION.BATCHID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						}
					}
					if (list.getPROGRAM_ID() != null
							&& !list.getPROGRAM_ID().isEmpty()) {
						whereCondition = whereCondition + " AND TRIM(MF_EMAIL_APPROVEDVALIDATION.PROGRAM_ID) =  "
								+ "'" + list.getPROGRAM_ID().trim() + "'";
					}
				}else if (reportName != null && reportName.equalsIgnoreCase("repay_advice.rpt")) {
					int m = 0;
					int k = 0;
					int j = 0;
					if (list.getCUSTOMER_ID() != null
							&& !list.getCUSTOMER_ID().isEmpty()) {
						if (k > 0 || m > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(mf_repayment_advices.COUNTER_PARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ "  TRIM(mf_repayment_advices.COUNTER_PARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						}
						j = j + 1;
					}
					if (list.getBATCH_ID() != null
							&& !list.getBATCH_ID().isEmpty()) {
						if (j > 0 || k > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(mf_repayment_advices.BATCH_ID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ " TRIM(mf_repayment_advices.BATCH_ID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						}
					}
					if (list.getPROGRAM_ID() != null
							&& !list.getPROGRAM_ID().isEmpty()) {
						whereCondition = whereCondition + " AND TRIM(mf_repayment_advices.PROGRAM_ID) =  "
								+ "'" + list.getPROGRAM_ID().trim() + "'";
					}
				}else if (reportName != null && reportName.equalsIgnoreCase("disburs_advice.rpt")) {
					int m = 0;
					int k = 0;
					int j = 0;
					if (list.getCUSTOMER_ID() != null
							&& !list.getCUSTOMER_ID().isEmpty()) {
						if (k > 0 || m > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(mf_disbursement_advices.CPARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ "  TRIM(mf_disbursement_advices.CPARTY) =  "
									+ "'" + list.getCUSTOMER_ID().trim() + "'";
						}
						j = j + 1;
					}
					if (list.getBATCH_ID() != null
							&& !list.getBATCH_ID().isEmpty()) {
						if (j > 0 || k > 0) {
							whereCondition = whereCondition
									+ " AND TRIM(mf_disbursement_advices.BATCHID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						} else {
							whereCondition = whereCondition
									+ " TRIM(mf_disbursement_advices.BATCHID) =  "
									+ "'" + list.getBATCH_ID().trim() + "'";
						}
					}
					if (list.getPROGRAM_ID() != null
							&& !list.getPROGRAM_ID().isEmpty()) {
						whereCondition = whereCondition + " AND TRIM(mf_disbursement_advices.PRGRMID) =  "
								+ "'" + list.getPROGRAM_ID().trim() + "'";
					}
				}
				
				inputFilePath = cobj.getRPT_FOLDERLOC();
				System.out.println("rpt FilePath" + inputFilePath);

				File directory = new File(inputFilePath);
				File[] fList = directory.listFiles();

				for (File file : fList) {

					if (file.isFile()) {

						folderfilenames.add(file.getName());

					}
				}
				
				
				
				//Connection Leak
				Connection conn=cobj.getCon();
				Statement stmt=null;
				ResultSet rs=null;
				//Connection Leak
        for(int i = 0;i<folderfilenames.size();i++)
           {

           	if(folderfilenames.get(i).equals(reportName))
           	{
       	
           	 ByteArrayInputStream byteArrayInputStream = null;
                ReportClientDocument reportClientDocument = new ReportClientDocument();
                
                		
        		try {
        	            //code by singh
        			inputFilePath=cobj.getRPT_FOLDERLOC();
					System.out.println("rpt FilePath"+inputFilePath);
        			reportClientDocument.open(inputFilePath+reportName, 0);
        			//Replace database connection
        			//replaceDatabaseConnection(reportClientDocument,cobj.getDB_DRIVER(),cobj.getDB_SERVERNAME(),cobj.getDB_PORT(),cobj.getDB_ORACLENAME(),cobj.getDB_USERNAME(),cobj.getDB_PASSWORD(),cobj.getDB_NAME());
        			
        			
        			//Connection  Leak
        			//Connection conn = cobj.getCon();
        			 //conn = cobj.getCon();
        			//Connection  Leak
        			Map<String, ResultSet> results = new HashMap<String, ResultSet>();
				    Tables tables = reportClientDocument.getDatabaseController().getDatabase().getTables();
				    
	       			
		            for (int i1 = 0; i1 < tables.size(); i1++) {
		                String tableAlias = reportClientDocument.getDatabaseController().getDatabase().getTables().getTable(i1).getAlias();
		    			
		                //Connection Leak
		                //Statement stmt = conn.createStatement();
		                 stmt = conn.createStatement();
		                 //Connection Leak
		                 
	        			String query = null;
	        			if(tables.getTable(i1).getName().equalsIgnoreCase("MF_EMAIL_BATCHDISB_UTR"))
	        			{
	        				if(whereCondition != null && !whereCondition.equalsIgnoreCase("")){
	        					query = "select * from " + tables.getTable(i1).getName() +" where " +whereCondition;
	        					//query = "select * from " + tables.getTable(i1).getName();
	        				}else{
	        					//query = "select * from " + tables.getTable(i1).getName() + " where ROWNUM = 1";
	        					query = "select * from " + tables.getTable(i1).getName();
	        				}
	        				System.out.println(query);
	        			}else if(tables.getTable(i1).getName().equalsIgnoreCase("MF_EMAIL_FAILUREVALIDATION")){
	        				if(whereCondition != null && !whereCondition.equalsIgnoreCase("")){
	        					query = "select * from " + tables.getTable(i1).getName() +" where " +whereCondition;
	        					//query = "select * from " + tables.getTable(i1).getName();
	        				}else{
	        					query = "select * from " + tables.getTable(i1).getName();
	        					//query = "select * from " + tables.getTable(i1).getName() + " where ROWNUM = 1";
	        				}
	        				System.out.println(query);
	        			}else if(tables.getTable(i1).getName().equalsIgnoreCase("MF_EMAIL_APPROVEDVALIDATION")){
	        				if(whereCondition != null && !whereCondition.equalsIgnoreCase("")){
	        					query = "select * from " + tables.getTable(i1).getName() +" where " +whereCondition;
	        					//query = "select * from " + tables.getTable(i1).getName();
	        				}else{
	        					query = "select * from " + tables.getTable(i1).getName();
	        					//query = "select * from " + tables.getTable(i1).getName() + " where ROWNUM = 1";
	        				}
	        				System.out.println(query);
	        			} else if(tables.getTable(i1).getName().equalsIgnoreCase("mf_disbursement_advices")){
	        				if(whereCondition != null && !whereCondition.equalsIgnoreCase("")){
	        					query = "select * from " + tables.getTable(i1).getName() +" where " +whereCondition;
	        					//query = "select * from " + tables.getTable(i1).getName();
	        				}else{
	        					query = "select * from " + tables.getTable(i1).getName();
	        					//query = "select * from " + tables.getTable(i1).getName() + " where ROWNUM = 1";
	        				}
	        				System.out.println(query);
	        			}else if(tables.getTable(i1).getName().equalsIgnoreCase("mf_repayment_advices")){
	        				if(whereCondition != null && !whereCondition.equalsIgnoreCase("")){
	        					query = "select * from " + tables.getTable(i1).getName() +" where " +whereCondition;
	        					//query = "select * from " + tables.getTable(i1).getName();
	        				}else{
	        					query = "select * from " + tables.getTable(i1).getName();
	        					//query = "select * from " + tables.getTable(i1).getName() + " where ROWNUM = 1";
	        				}
	        				System.out.println(query);
	        			}else{
	        				query = "select * from " + tables.getTable(i1).getName() ;
	        			}
	        			 //Connection Leak
		                //ResultSet rs = stmt.executeQuery(query);
	        			 rs = stmt.executeQuery(query);
		                //Connection Leak
		                System.out.println("Query------>"+i1+"--->"+query);
		                results.put(tableAlias, rs);
		            }
		            
		            final Enumeration<String> aliasEnumeration = Collections.enumeration(results.keySet());
		            int count = 0;
		            while(aliasEnumeration.hasMoreElements()) {
		                String oldAlias = aliasEnumeration.nextElement();
		                
		                //Connection Leak
		                //ResultSet rs = results.get(oldAlias);
		                 rs = results.get(oldAlias);
		                
		                //Connection Leak
		                count = count + 1;
		                System.out.println("Collection Query------>"+count+" oldAlias--->"+oldAlias);
		                reportClientDocument.getDatabaseController().setDataSource(rs, oldAlias, oldAlias + " ");
		            }
		            
		            
		            Fields<IParameterField> fields1= reportClientDocument.getDataDefinition().getParameterFields();
		            Fields<IParameterField> fields = new Fields<IParameterField>();
	        		System.out.println("After connecting DB"+fields);
	   				
	        		if(fields.isEmpty())
	       			{
	       				if ((whereClause != null) && (!"".equals(whereClause))) {
	       					logger.info("Before setting filter");
	       					System.out.println("Before setting filter");
	       					IFilter filter = reportClientDocument.getDataDefinition().getRecordFilter();
	       					logger.info("filter == " + filter.getText());
	       					if ((filter.getText() != null) && (!"".equals(filter.getText())))
	       					{
	       						whereClause = filter.getText() + " AND " + whereClause;
	       					}
	       					filter.setFreeEditingText(whereClause);
							//System.out.println("Framed Where Clause"+whereClause);
	       					reportClientDocument.getDataDefController().getRecordFilterController().modify(filter);
	       				}
	       			}
        			
        			
        			// @fieldStartDate
       			//setFormula("BookingDate123", "\"" + vo.getFROM_DATE() + "\"", reportClientDocument);
       			// @fieldStartDate
       			//reportClientDocument.getPrintOutputController().modifyUserPaperSize(50000, 50000);
				//C1145 modifying the printoptions and pagesizes
	        		
	        		
				IPrintOptions ipo = reportClientDocument.getPrintOutputController().getPrintOptions();
				ipo.setDissociatePageSizeAndPrinterPaperSize(true);
				IPrintOptions newPrintOptions = (PrintOptions)((PrintOptions)ipo).clone(true);
				newPrintOptions.setDissociatePageSizeAndPrinterPaperSize(true);
				newPrintOptions.setPaperSize(ipo.getPaperSize());
				System.out.println("Paper size from old ipo"+ipo.getPaperSize());
				System.out.println("Paper size from new ipo"+newPrintOptions.getPaperSize());
				reportClientDocument.getPrintOutputController().modifyPrintOptions(newPrintOptions);
				
				//byteArrayInputStream = (ByteArrayInputStream)reportClientDocument.getPrintOutputController().export(ReportExportFormat.PDF);
        	    
				
        	  //  System.out.println("Paper size from IprintSize"+ipo.getPaperSize());
				//System.out.println("int Paper size from IprintSize "+ipo.getPaperSize().value());
				//System.out.println("to string Paper size from IprintSize "+ipo.getPaperSize().toString());
			//System.out.println("PageSize"+reportClientDocument.getPrintOutputController().getPrintOptions().getPaperSize().toString());
			
        	    byteArrayInputStream = (ByteArrayInputStream)reportClientDocument.getPrintOutputController().export(ReportExportFormat.PDF);
        	    //byteArrayInputStream = (ByteArrayInputStream)reportClientDocument.getPrintOutputController().export(ReportExportFormat.recordToMSExcel);
        	    /*if(conn != null){
        	    conn.close();
        	    }*/
        	    
        	    reportClientDocument.close();
        		
        		
        		//saving the file
        		//generate filename
				
        		/*Visitor*/
        		outputfilename= reportName.substring(0, reportName.length()-4)+new SimpleDateFormat("yyyy"+"MM"+"dd"+"HHmmss", Locale.ENGLISH).format(new Date());;
      			String zipfilePath="";
				File dirCreate= new File(cobj.getRPT_OPFOLDERLOC()+File.separator+new SimpleDateFormat("dd-MM-yy").format(new Date()));
				if (!dirCreate.exists())
					{
					dirCreate.mkdir();
					System.out.println("folder created"+dirCreate.getAbsolutePath());
					outputFilePath = dirCreate+File.separator+outputfilename+".pdf";
					//outputFilePath = dirCreate+File.separator+outputfilename+".xls";
					 zipfilePath = dirCreate+File.separator+outputfilename+"z"+".zip";
					}
				else if(dirCreate.exists())
					{
					dirCreate.exists();
					System.out.println("folder exists already"+dirCreate.getAbsolutePath());
					outputFilePath = dirCreate+File.separator+outputfilename+".pdf";
					//outputFilePath = dirCreate+File.separator+outputfilename+".xls";
					 zipfilePath = dirCreate+File.separator+outputfilename+"z"+".zip";
					}

				//outputFilePath = cobj.getRPT_OPFOLDERLOC()+File.separator+outputfilename+".pdf";
        		//String zipfilePath = cobj.getRPT_OPFOLDERLOC()+File.separator+outputfilename+"z"+".zip";
        		InputStream in = byteArrayInputStream;
        		OutputStream out = new FileOutputStream(outputFilePath);
       		byte[] buf = new byte[1024];
       		int len;
               
       		while ((len = in.read(buf)) > 0) {
       		    out.write(buf, 0, len);
       		}
       		in.close();
       		out.close();


        		FileOutputStream fos = new FileOutputStream(zipfilePath);
        		ZipOutputStream zos = new ZipOutputStream(fos);
        		ZipEntry ze= new ZipEntry(outputfilename);
        		zos.putNextEntry(ze);
        		FileInputStream in1 = new FileInputStream(outputFilePath);
        		byte[] buffer = new byte[1024];
        		int len1;
        		while ((len1 = in1.read(buffer)) > 0) {
        			zos.write(buffer, 0, len1);
        		}

        		in1.close();
        		zos.closeEntry();

        		//remember close it
        		zos.close();

        		
        		} 

        		catch (ReportSDKException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        			
        		}
        		
        		
           }
           }  
        //Connection Leak
        if(rs!=null || stmt!=null ||conn!=null)
        {
        	DBConnectionUtility.surrenderDB(rs, stmt, conn);
        }
        //Connection Leak
    	String advReports[] = new String[1];
        advReports[0]=outputfilename+".pdf";
        
        requestAuto = sendEmailWithAttachments(advReports,list.getTO_EMAIL(),list.getCC_EMAIL(),list.getSUBJECT_EMAIL(),list.getBODY_EMAIL(),list.getREPORT_NAME_DESC(),list.getPROGRAM_ID(),list.getCUSTOMER_ID());
        //requestAuto = sendEmailWithAttachments(advReports,list.getTO_EMAIL(),list.getCC_EMAIL(),list.getSUBJECT_EMAIL(),list.getBODY_EMAIL(),list.getREPORT_NAME_DESC(),list.getPROGRAM_ID(),list.getCUSTOMER_ID());

		}//forloop banklimitVO
		}
        
		return requestAuto;
	}
	

	public String genAdvFormat1(List<BankLimitVO> adviceListVO,ConnObj cobj ) throws Exception
	{
		
	String outputfilename="";
	String requestAuto = null;
	String whereCondition = "";
	String whereCondition1 = "";
	if(adviceListVO.size() != 0 && !adviceListVO.equals(null)){
	for(BankLimitVO list :adviceListVO){
			list.getTO_EMAIL();
			if (list.getFILE_PATH() != null
					&& !list.getFILE_PATH().isEmpty()) {
				inputFilePath = list.getFILE_PATH();
			}
			if (list.getRPT_FILENAME() != null
					&& !list.getRPT_FILENAME().isEmpty()) {
				reportName = list.getRPT_FILENAME();
			}
			whereClause = "";
			//forming where clause
			/*if (reportName != null && reportName.equalsIgnoreCase("batch_utr_disb.rpt")) {
				if (list.getBATCH_ID() != null
						&& !list.getBATCH_ID().isEmpty()) {

					whereClause = whereClause
							+ " {MF_EMAIL_BATCHDISB_UTR.BATCHID} =  "
							+ "'" + list.getBATCH_ID() + "'";
					
				}
				
			}*/
			
			inputFilePath = cobj.getRPT_FOLDERLOC();
			System.out.println("rpt FilePath" + inputFilePath);

			File directory = new File(inputFilePath);
			File[] fList = directory.listFiles();

			for (File file : fList) {

				if (file.isFile()) {

					folderfilenames.add(file.getName());

				}
			}
    for(int i = 0;i<folderfilenames.size();i++)
       {

       	if(folderfilenames.get(i).equals(reportName))
       	{
   	
       	 ByteArrayInputStream byteArrayInputStream = null;
            ReportClientDocument reportClientDocument = new ReportClientDocument();
            
            		
    		try {
    	            //code by singh
    			inputFilePath=cobj.getRPT_FOLDERLOC();
				System.out.println("rpt FilePath"+inputFilePath);
    			reportClientDocument.open(inputFilePath+reportName, 0);
    			//Replace database connection
    			replaceDatabaseConnection(reportClientDocument,cobj.getDB_DRIVER(),cobj.getDB_SERVERNAME(),cobj.getDB_PORT(),cobj.getDB_ORACLENAME(),cobj.getDB_USERNAME(),cobj.getDB_PASSWORD(),cobj.getDB_NAME());
    			
    			/*Connection conn = cobj.getCon();
    			Map<String, ResultSet> results = new HashMap<String, ResultSet>();
			    Tables tables = reportClientDocument.getDatabaseController().getDatabase().getTables();
			    
       			
	            for (int i1 = 0; i1 < tables.size(); i1++) {
	                String tableAlias = reportClientDocument.getDatabaseController().getDatabase().getTables().getTable(i1).getAlias();
	    			Statement stmt = conn.createStatement();
        			String query = null;
        			if(tables.getTable(i1).getName().equalsIgnoreCase("MF_EMAIL_BATCHDISB_UTR"))
        			{
        				if(whereCondition != null && !whereCondition.equalsIgnoreCase("")){
        					query = "select * from " + tables.getTable(i1).getName() +" where " +whereCondition;
        					//query = "select * from " + tables.getTable(i1).getName();
        				}else{
        					//query = "select * from " + tables.getTable(i1).getName() + " where ROWNUM = 1";
        					query = "select * from " + tables.getTable(i1).getName();
        				}
        				System.out.println(query);
        			}else if(tables.getTable(i1).getName().equalsIgnoreCase("ETT_PROG_CP_LM_ADVISES")){
        				if(whereCondition != null && !whereCondition.equalsIgnoreCase("")){
        					query = "select * from " + tables.getTable(i1).getName() +" where " +whereCondition1;
        					//query = "select * from " + tables.getTable(i1).getName();
        				}else{
        					query = "select * from " + tables.getTable(i1).getName();
        					//query = "select * from " + tables.getTable(i1).getName() + " where ROWNUM = 1";
        				}
        				System.out.println(query);
        			}else if(tables.getTable(i1).getName().equalsIgnoreCase("ETT_PROCEEDS")){
        				if(whereCondition != null && !whereCondition.equalsIgnoreCase("")){
        					query = "select * from " + tables.getTable(i1).getName() +" where PRCD_MASTER_REF in " +
        							"(select PRG_DEALREF from ETT_PROG_CP_ADVISES where" +whereCondition+")";
        					//query = "select * from " + tables.getTable(i1).getName();
        				}else{
        					query = "select * from " + tables.getTable(i1).getName();
        					//query = "select * from " + tables.getTable(i1).getName() + " where ROWNUM = 1";
        				}
        			}else{
        				query = "select * from " + tables.getTable(i1).getName() ;
        			}
	                ResultSet rs = stmt.executeQuery(query);
	                System.out.println("Query------>"+i1+"--->"+query);
	                results.put(tableAlias, rs);
	            }*/
	            
	            /*final Enumeration<String> aliasEnumeration = Collections.enumeration(results.keySet());
	            int count = 0;
	            while(aliasEnumeration.hasMoreElements()) {
	                String oldAlias = aliasEnumeration.nextElement();
	                ResultSet rs = results.get(oldAlias);
	                count = count + 1;
	                System.out.println("Collection Query------>"+count+" oldAlias--->"+oldAlias);
	                reportClientDocument.getDatabaseController().setDataSource(rs, oldAlias, oldAlias + " ");
	            }*/
	            
	            
	            Fields<IParameterField> fields1= reportClientDocument.getDataDefinition().getParameterFields();
	            Fields<IParameterField> fields = new Fields<IParameterField>();
        		System.out.println("After connecting DB"+fields);
   				
        		if(fields.isEmpty())
       			{
       				if ((whereClause != null) && (!"".equals(whereClause))) {
       					logger.info("Before setting filter");
       					System.out.println("Before setting filter");
       					IFilter filter = reportClientDocument.getDataDefinition().getRecordFilter();
       					logger.info("filter == " + filter.getText());
       					if ((filter.getText() != null) && (!"".equals(filter.getText())))
       					{
       						whereClause = filter.getText() + " AND " + whereClause;
       					}
       					filter.setFreeEditingText(whereClause);
						//System.out.println("Framed Where Clause"+whereClause);
       					reportClientDocument.getDataDefController().getRecordFilterController().modify(filter);
       				}
       			}
    			
    			
    			// @fieldStartDate
   			//setFormula("BookingDate123", "\"" + vo.getFROM_DATE() + "\"", reportClientDocument);
   			// @fieldStartDate
   			//reportClientDocument.getPrintOutputController().modifyUserPaperSize(50000, 50000);
			//C1145 modifying the printoptions and pagesizes
        		
        		
			IPrintOptions ipo = reportClientDocument.getPrintOutputController().getPrintOptions();
			ipo.setDissociatePageSizeAndPrinterPaperSize(true);
			IPrintOptions newPrintOptions = (PrintOptions)((PrintOptions)ipo).clone(true);
			newPrintOptions.setDissociatePageSizeAndPrinterPaperSize(true);
			newPrintOptions.setPaperSize(ipo.getPaperSize());
			System.out.println("Paper size from old ipo"+ipo.getPaperSize());
			System.out.println("Paper size from new ipo"+newPrintOptions.getPaperSize());
			reportClientDocument.getPrintOutputController().modifyPrintOptions(newPrintOptions);
			
			//byteArrayInputStream = (ByteArrayInputStream)reportClientDocument.getPrintOutputController().export(ReportExportFormat.PDF);
    	    
			
    	  //  System.out.println("Paper size from IprintSize"+ipo.getPaperSize());
			//System.out.println("int Paper size from IprintSize "+ipo.getPaperSize().value());
			//System.out.println("to string Paper size from IprintSize "+ipo.getPaperSize().toString());
		//System.out.println("PageSize"+reportClientDocument.getPrintOutputController().getPrintOptions().getPaperSize().toString());
		
    	    byteArrayInputStream = (ByteArrayInputStream)reportClientDocument.getPrintOutputController().export(ReportExportFormat.PDF);
    	    //byteArrayInputStream = (ByteArrayInputStream)reportClientDocument.getPrintOutputController().export(ReportExportFormat.recordToMSExcel);
    	    /*if(conn != null){
    	    conn.close();
    	    }*/
    	    
    	    reportClientDocument.close();
    		
    		
    		//saving the file
    		//generate filename
			
    		/*Visitor*/
    		outputfilename= reportName.substring(0, reportName.length()-4)+new SimpleDateFormat("yyyy"+"MM"+"dd"+"HHmmss", Locale.ENGLISH).format(new Date());;
  			String zipfilePath="";
			File dirCreate= new File(cobj.getRPT_OPFOLDERLOC()+File.separator+new SimpleDateFormat("dd-MM-yy").format(new Date()));
			if (!dirCreate.exists())
				{
				dirCreate.mkdir();
				System.out.println("folder created"+dirCreate.getAbsolutePath());
				outputFilePath = dirCreate+File.separator+outputfilename+".pdf";
				//outputFilePath = dirCreate+File.separator+outputfilename+".xls";
				 zipfilePath = dirCreate+File.separator+outputfilename+"z"+".zip";
				}
			else if(dirCreate.exists())
				{
				dirCreate.exists();
				System.out.println("folder exists already"+dirCreate.getAbsolutePath());
				outputFilePath = dirCreate+File.separator+outputfilename+".pdf";
				//outputFilePath = dirCreate+File.separator+outputfilename+".xls";
				 zipfilePath = dirCreate+File.separator+outputfilename+"z"+".zip";
				}

			//outputFilePath = cobj.getRPT_OPFOLDERLOC()+File.separator+outputfilename+".pdf";
    		//String zipfilePath = cobj.getRPT_OPFOLDERLOC()+File.separator+outputfilename+"z"+".zip";
    		InputStream in = byteArrayInputStream;
    		OutputStream out = new FileOutputStream(outputFilePath);
   		byte[] buf = new byte[1024];
   		int len;
           
   		while ((len = in.read(buf)) > 0) {
   		    out.write(buf, 0, len);
   		}
   		in.close();
   		out.close();


    		FileOutputStream fos = new FileOutputStream(zipfilePath);
    		ZipOutputStream zos = new ZipOutputStream(fos);
    		ZipEntry ze= new ZipEntry(outputfilename);
    		zos.putNextEntry(ze);
    		FileInputStream in1 = new FileInputStream(outputFilePath);
    		byte[] buffer = new byte[1024];
    		int len1;
    		while ((len1 = in1.read(buffer)) > 0) {
    			zos.write(buffer, 0, len1);
    		}

    		in1.close();
    		zos.closeEntry();

    		//remember close it
    		zos.close();


    		} 

    		catch (ReportSDKException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    			
    		}
       }
       }  
	String advReports[] = new String[1];
    advReports[0]=outputfilename+".pdf";
    
    requestAuto = sendEmailWithAttachments(advReports,list.getTO_EMAIL(),list.getCC_EMAIL(),list.getSUBJECT_EMAIL(),list.getBODY_EMAIL(),list.getREPORT_NAME_DESC(),list.getPROGRAM_ID(),list.getCUSTOMER_ID());
    //requestAuto = sendEmailWithAttachments(advReports,list.getTO_EMAIL(),list.getCC_EMAIL(),list.getSUBJECT_EMAIL(),list.getBODY_EMAIL(),list.getREPORT_NAME_DESC(),list.getPROGRAM_ID(),list.getCUSTOMER_ID());

	}//forloop banklimitVO
	}
    
	return requestAuto;
}

	private ReportClientDocument replaceDatabaseConnection(ReportClientDocument doc, String driver, String ip, String port, String dbname, String username, String passwort, String userOrSchemaName) 
	{
		
	    try 
	    {
	        for (int i = 0; i < doc.getDatabaseController().getDatabase().getTables().size(); i++) 
	        {

	        	
	            ITable table = doc.getDatabaseController().getDatabase().getTables().get(i);
	            String original_qualifiedName = table.getQualifiedName();
	            String new_qualifierName = original_qualifiedName;
	            String tableName = StringUtils.substringAfterLast(original_qualifiedName, ".").toUpperCase();
                new_qualifierName = userOrSchemaName.toUpperCase()+"."+tableName;
	            String jdbcConnectionString = null;
	            String preQEServerName = null;
                jdbcConnectionString = "!"+driver+"!jdbc:oracle:thin:@"+ip+":"+port+":"+dbname;
                preQEServerName = "jdbc:oracle:thin:@"+ip+":"+port+":"+dbname;
			    table.setQualifiedName(new_qualifierName);
			    PropertyBag boPropertyBag1 = new PropertyBag();
			    boPropertyBag1.put("JDBC Connection String", jdbcConnectionString);
			    boPropertyBag1.put("PreQEServerName",   preQEServerName);
			    boPropertyBag1.put("Server Type", "JDBC (JNDI)");
			    boPropertyBag1.put("Database DLL", "crdb_jdbc.dll");
			    boPropertyBag1.put("Database", dbname);
			    boPropertyBag1.put("Database Class Name", driver);
			    boPropertyBag1.put("Use JDBC", "true");
			    boPropertyBag1.put("Database Name", dbname);
			    boPropertyBag1.put("Server Name", preQEServerName);
			    boPropertyBag1.put("Connection URL", preQEServerName);
			    boPropertyBag1.put("Server", null);
			    ConnectionInfo newConnectionInfo = new ConnectionInfo();
			    newConnectionInfo.setAttributes(boPropertyBag1);
			    newConnectionInfo.setUserName(username);
			    newConnectionInfo.setPassword(passwort);
			    table.setConnectionInfo(newConnectionInfo);
			    System.out.println(table.getName());
			    doc.getDatabaseController().setTableLocation(table, doc.getDatabaseController().getDatabase().getTables().get(i));
				System.out.println("connected Db or not"+doc);

	        }
	        return doc;
	        
	    } catch (Exception ex) {
	        logger.info(ExceptionUtils.getFullStackTrace(ex));
			ex.printStackTrace();
	    }
	    return doc;
	}	
	
	
	
	public  String  sendEmailWithAttachments( String[] attachFiles,String toEmail,String ccEmail,String subjectEmail,String bodyEmail,String reportNameDescription,String programName,String customerId ) throws AddressException, MessagingException, RemoteException 
		     {
		      
		//code by singh
		 //String listOfPathTag = "";
	     //  for(String attachFile : attachFiles){
	    	   //outputFilePath="";
	    	   
			   String attachPath = "<Attachment>"+outputFilePath.toString()+attachFiles[0]+"</Attachment>";
		
	    	   /*listOfPathTag += attachPath;
	       }
 */
	//TODO Validate the DOM Document POJO for the GatewayEmail.xsd,ignore the Prefix XML part and suffix XML part
	 System.out.println("outputFilePath"+outputFilePath);
	       String xmlToPost = "<?xml version=\"1.0\" standalone=\"yes\"?>"+
		          "<ns2:ServiceRequest  xmlns:ns2=\"urn:control.services.tiplus2.misys.com\">"+
	        		 	"<ns2:RequestHeader>"+
	        				"<ns2:Service>Gateway</ns2:Service>"+
	        				"<ns2:Operation>Email</ns2:Operation>"+
	        				"<ns2:Credentials>"+
	        				"<ns2:Name>SUPERVISOR</ns2:Name>"+
	        				"</ns2:Credentials>"+
	        				"<ns2:SourceSystem>Z2</ns2:SourceSystem>"+
	        				"<ns2:CorrelationId>CorrelationId</ns2:CorrelationId>"+
	        			 "</ns2:RequestHeader>"+
						 "<GatewayEmailRequests>"+
	        			 "<GatewayEmailRequest>"+
	        			 	"<MasterReference>MasterReference</MasterReference>"+
	        				"<EventReference>EventReference</EventReference>"+
	        				"<Customer>"+customerId+"</Customer>"+
							"<ReportName>"+reportNameDescription+"</ReportName>"+
                            "<ProgramName>"+programName+"</ProgramName>"+
	        				"<To>"+toEmail+"</To>"+
	        				"<CC>"+ccEmail+"</CC>"+
	        				"<Subject>"+subjectEmail+"</Subject>"+
	        				"<Body>"+bodyEmail+"</Body>"+
	        			"<Attachments>"+
						   "<Attachment>"+
	        			     outputFilePath+
							 "</Attachment>"+
	        			"</Attachments>"+
	        			 "</GatewayEmailRequest>"+
						 "</GatewayEmailRequests>"+
	        		     "</ns2:ServiceRequest>";
	      System.out.println("Email XML"+xmlToPost); 

	       /* BridgeGatewayImplServiceStub bs = new BridgeGatewayImplServiceStub();
	        com.bs.themebridge.server.gateway.in.BridgeGatewayImplServiceStub.Process proces = new com.bs.themebridge.server.gateway.in.BridgeGatewayImplServiceStub.Process();
       	    proces.setInput(xmlToPost);
       	    com.bs.themebridge.server.gateway.in.BridgeGatewayImplServiceStub.ProcessResponse res = bs.process(proces);
	      
		  System.out.println("com.bs.themebridge.server.gateway.in.BridgeGatewayImplServiceStub.ProcessResponse "+res.get_return());*/
		  
       	  //  System.out.println("end of send mail");	       
		  return xmlToPost;

		
		     }
	
	/**
	 * 
	 * @param mobileNumber
	 * @param text
	 * @return
	 */
	public String fetchSMSRequest(String mobileNumber,String text){
	String SMSRequest = "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' 	xmlns='urn:control.services.tiplus2.misys.com' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>"
			+ "<RequestHeader><Service>SMS</Service><Operation>Message</Operation><CorrelationId>CorrelationId</CorrelationId>"
			+ "<TransactionControl>NONE</TransactionControl><SOURCE>mf</SOURCE><REQTXNDT>REQTXNDT</REQTXNDT></RequestHeader>"
			+ "<SMSRequest>"
			+ "<MobileNo>"+mobileNumber+"</MobileNo>"
			+ "<MessageTxt>"+text+"</MessageTxt>"
			+ "<REFNO>REFNO</REFNO></SMSRequest></ServiceRequest>";
	return SMSRequest;
	}

}
