package in.co.invoice.utility;

/**
 * 
 * This Action class is used for define column names of tables.
 * 
 * 
 * 
 */
public interface ActionConstantsQuery {
			
	
		// **************************DB connection********//
	String userName = "root";
	String password = "root";
	String dbName = "demohab_myshare";
	String url = "jdbc:mysql://localhost:3306/" + dbName;
	String driver= "com.mysql.jdbc.Driver";

	String ZERO="0";
	String COLUMN_SKEY80 = "SKEY80";
	// **************************DB connection End********//
	String MSG_TYPE = "MSG_TYPE";
	String UTR_NUMBER = "UTR_NUMBER";
	String BENEF_ACCNO = "BENEF_ACCNO";
	String BENEF_ACCTYPE = "BENEF_ACCTYPE";
	String BENEF_NAME = "BENEF_NAME";
	String TRANS_AMT = "TRANS_AMT";
	String SENDER_IFSC = "SENDER_IFSC";
	String SENDER_ACCNO = "SENDER_ACCNO";
	String SENDER_NAME = "SENDER_NAME";
	String COUNT = "COUNT";
	String SUM = "SUM";
	String SUM_AMOUNT="SUM_AMOUNT";
	
	String PROGIDN = "PROGIDN";
	String CPARTY = "CPARTY";
	String PROGTYPE = "PROG_TYPE";
	String APPORTIONMENT = "APPORTIONMENT";
	String REPAYMENT_TYPE = "REPAYMENT_TYPE";
	String ALLOCATION_TYPE = "ALLOCATION_TYPE";
	
	
	String SEQUENCE = "SEQUENCE";
	String CUSTOMR = "CUSTOMR";
	
	// **************************Fields Start********//
	public static final String GET_TIPLUSLOGIN = "select skey80 from secage88 ";
	public static final String INSERT_INVOICES_TBL_EOD = "INSERT INTO TEMP_TABLE_EOD (DESCRP) VALUES (?)";
	String SELECT_FROM_ETT_RTNF_INWARD = "SELECT * FROM ETT_RTNF_INWARD ";
	String gettingPartPaymentSINumber ="SELECT PD_PART_PAY_REF FROM ETTV_BOE_PAYMENT_DETAILS WHERE PD_TXN_REF=?";
	
	String gettingDataFromTIMultiPayments ="SELECT NVL(TRIM(PD_CIF_NAME), ' '), NVL(TRIM(PD_IE_CODE), ' '), NVL(TRIM(PD_TXN_REF), ' '), NVL(TRIM(PD_PART_PAY_REF), ' '), TO_CHAR(TO_DATE(PD_TXN_DT, 'dd-mm-yy'),'dd-mm-yyyy'), NVL(TRIM(PD_TXN_CCY), ' '), NVL(TRIM(to_char(PD_FC_AMT,'999,999,999,999,999.99')), '0'),NVL(TRIM(to_char(PD_ENDORSED_AMT,'999,999,999,999,999.99')), '0'), NVL(TRIM(to_char(PD_OUTSTANDING_AMT,'999,999,999,999,999.99')), '0') FROM ETTV_BOE_PAYMENT_DETAILS WHERE PD_CIF_ID =? and PD_TXN_CCY=?";
	
	String CapQuery = "INSERT INTO ETT_EOD_TEMP(ID,LIMITNUMBER,FINANCEAMT,BATCHID,CUSTOMER,CAPDT,REQUEST,RESPONSE,PRGRMID,EXPON)VALUES(?,?,?,?,?,?,?,?,?,?)";
	//String getDataFromTI = ;
	String UPDATE_REPAY_QUERY="update ETT_STP_REPAYMENT set " +
			"PRC_ALLC_AMOUNT =?,PAID_STATUS =  CASE WHEN OS_AMOUNT= PRC_ALLC_AMOUNT THEN 'F' ELSE 'P' END where TRIM(INVOICE_NO)=? and TRIM(LOAN_MASTER_REF)=? and TRIM(BATCH_ID)=?";
	
	String INSERT_NEFT_RTGS = "INSERT INTO ETT_RTGSNEFT (PRGRMID, BUYER, SELLER, CPARTY, REFKEY, INVNUMBER, "
			+ "FINANCEAMT, CPARTYNAME, CPARTYXM, CREDITACCNO,PHONE,EMAIL,LOANACCNO,IFSCCODE,DATEIDEN,SRCAPP,REMACCNO,SENDERACCTYPE,TRANSACTIONAMT,TRANSREF,"
			+ "MSGTYPE,RELREFNO,REMACCNAME,COMMAMT,BENFNAME,BENFACC,BENFACCTYPE,BENFIFSC,CUSEMAILPHON,PRGTYPE,ROWLEN,BATCHID,REMADD1,REMADD2,REMADD3,REMADD4,BENFADD1,BENFADD2,DETOFPAY,RECINFO1,RECINFO2,RECINFO3,RECINFO4,RECINFO5,RECINFO6)"
				+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
}
