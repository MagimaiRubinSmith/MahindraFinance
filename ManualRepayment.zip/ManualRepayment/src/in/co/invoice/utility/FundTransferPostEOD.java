package in.co.invoice.utility;

import in.co.clf.util.SystemPropertiesUtil;
import in.co.invoice.dao.RTNFFileReadDAO;
import in.co.invoice.dao.ValidatorDAO;
import in.co.invoice.dao.exception.DAOException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

/**
 * 
 * @author
 * 
 */
public class FundTransferPostEOD {

	private static Logger logger = Logger.getLogger(RTNFFileReadDAO.class
			.getName());

	// http://localhost:8080/RESTfulExample/json/product/post
	public static void main(String[] args) throws SQLException {
		// fundPosting("10000018515","100","CUST01","","30-08-2016");

	}

	/**
	 * 
	 * @param limitNumber
	 * @param amount
	 * @throws SQLException
	 * @throws DAOException
	 */
	public static String fundPosting(String limitNumber, String amount,
			String customer, String batchId, String capDat, Connection con,
			String prgID, String expOn) throws SQLException, DAOException {

		/*
		 * Formatter fmt = new Formatter(); Calendar cal =
		 * Calendar.getInstance(); fmt = new Formatter(); fmt.format("%Tb",cal);
		 * DateFormat df = new SimpleDateFormat("yy"); // Just the year, with 2
		 * digits String formattedDate =
		 * df.format(Calendar.getInstance().getTime());
		 */
		// Connection con = null;
		LoggableStatement ps = null;
		ResultSet rs = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MMM-dd:HH:mm:ss");
		Date date = new Date();
		String CurrentDate = dateFormat.format(date);
		String CurrentDateTime = dateFormat1.format(date);
		long randomVal = generateRandom(12);
		ValidatorDAO vald = null;
		String finalStatus = null;
		String currentMonYr = null;
		try {

			// URL url = new
			// URL("http://10.5.8.98:10204/initiateGenericFundTransfer");

			URL url = new URL(
					"http://ESB.idfcbank.com/initiateGenericFundTransfer");

			String accountNumber = "98407102050"; // PRO
			// 107
			// URL url = new
			// URL("http://172.19.36.118:10062/initiateGenericFundTransfer/");

			// 127
			// URL url = new
			// URL("http://172.19.36.65:10005/initiateGenericFundTransfer/");
			// URL url = new
			// URL("	http://10.5.8.98:10204/initiateGenericFundTransfer/");
			vald = new ValidatorDAO();
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(
					con,
					"select to_char(to_date('"
							+ capDat
							+ "', 'DD-MM-YYYY'), 'MON') as monthname, to_char(to_date('"
							+ capDat
							+ "', 'DD-MM-YYYY'), 'YY') as yrname from dual");
			rs = ps.executeQuery();
			if (rs.next()) {
				String monthName = rs.getString("monthname");
				String YrName = rs.getString("yrname");
				currentMonYr = "INTCAP-" + monthName + "-" + YrName;
			}

			System.out.println(SystemPropertiesUtil.getFundTransfer());
			// URL url = new URL(SystemPropertiesUtil.getFundTransfer());

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("PUT");
			conn.setRequestProperty("Content-Type", "application/json");
			// String accountNumber = SystemPropertiesUtil.getAccountNumber();
			String input = "{\"InitiateGenericFundTransferRequest\":{\"msgHdr\":{\"msgId\":\"569919387390414\","
					+ "\"cnvId\":\"553129893347477\",\"bizObjId\":\"PCFC"
					+ randomVal
					+ "\",\"appId\":\"TF\","
					+ "\"timestamp\":\""
					+ CurrentDateTime
					+ "\"},\"msgBdy\":{\"initiateOrderReq\":{\"txnId\":\"PCFC"
					+ randomVal
					+ "\","
					+ "\"dbtrAcctId\":\""
					+ limitNumber
					+ "\",\"cdtrAcctId\":\""
					+ accountNumber
					+ "\",\"amt\":\""
					+ amount
					+ "\",\"ccy\":\"INR\","
					+ "\"txnTp\":\"IFT\",\"pmtDesc\":\""
					+ currentMonYr
					+ "\","
					+ "\"cstId\":\""
					+ customer
					+ "\",\"onDt\":\""
					+ CurrentDate + "\"}}}}";

			// 99805102050 - 127
			// 98407102050 - 107
			System.out.println("Input Json" + input);
			logger.info("Request JSON------>" + input);

			OutputStream os = conn.getOutputStream();
			os.write(input.getBytes());
			os.flush();

			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				/*
				 * throw new RuntimeException("Failed : HTTP error code : " +
				 * conn.getResponseCode());
				 */
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;
			StringBuffer totalOutput = new StringBuffer();
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
				totalOutput.append(output);
			}

			String result = totalOutput.toString();
			System.out.println("Result" + result);
			logger.info("Response JSON------>" + result);
			String seqVal = vald.sequenceEOD(con);
			vald.insertTempRecords(con, seqVal, limitNumber, amount, batchId,
					customer, capDat, input, result, prgID, expOn);
			finalStatus = json2Object(result);
			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		} finally {
			DBConnectionUtility.surrenderDB(rs, ps, con);
		}

		return finalStatus;

	}

	public static String json2Object(String input) {
		// String jsonString =
		// "{\"InitiateGenericFundTransferResponse\":{\"msgHdr\":{\"rslt\":\"ERROR\",\"error\":{\"cd\":\"CBS266\",\"rsn\":\"CBSERROR:CLEARED BAL/FUNDS/DP NOT AVAILABLE.CARE! ACCT WILL BE OVERDRAWN                               000000\"}},\"msgBdy\":{\"sts\":\"RJCT\",\"txnId\":\"5334\",\"chnlTxnId\":\"PCFC241430354342\"}}}";
		JSONObject object = (JSONObject) JSONValue.parse(input);
		Object headvalue = object.get("InitiateGenericFundTransferResponse");
		object = (JSONObject) JSONValue.parse(headvalue.toString());

		Object bodyValue = object.get("msgHdr");
		object = (JSONObject) JSONValue.parse(bodyValue.toString());
		String stsValue = (String) object.get("rslt");

		/*
		 * Object bodyValue=object.get("msgBdy"); object = (JSONObject)
		 * JSONValue.parse(bodyValue.toString()); String stsValue=(String)
		 * object.get("sts");
		 */
		System.out.println(stsValue);
		return stsValue;
	}

	public static long generateRandom(int length) {
		Random random = new Random();
		char[] digits = new char[length];
		digits[0] = (char) (random.nextInt(9) + '1');
		for (int i = 1; i < length; i++) {
			digits[i] = (char) (random.nextInt(10) + '0');
		}
		return Long.parseLong(new String(digits));
	}

}
/*
 * package in.co.stp.utility;
 * 
 * import java.io.BufferedReader; import java.io.IOException; import
 * java.io.InputStreamReader; import java.io.OutputStream; import
 * java.net.HttpURLConnection; import java.net.MalformedURLException; import
 * java.net.URL; import java.util.Random;
 *//**
 * 
 * @author
 * 
 */
/*
 * public class FundTransferPost {
 * 
 * // http://localhost:8080/RESTfulExample/json/product/post public static void
 * main(String[] args) { fundPosting("10000038122","100"); }
 *//**
 * 
 * @param limitNumber
 * @param amount
 */
/*
 * public static void fundPosting(String limitNumber,String amount) {
 * 
 * 
 * try {
 * 
 * URL url = new URL("http://172.19.36.118:10062/initiateGenericFundTransfer/");
 * HttpURLConnection conn = (HttpURLConnection) url.openConnection();
 * conn.setDoOutput(true); conn.setRequestMethod("PUT");
 * conn.setRequestProperty("Content-Type", "application/json");
 * 
 * String input =
 * "{\"InitiateGenericFundTransferRequest\":{\"msgHdr\":{\"msgId\":\"569919387390414\","
 * + "\"cnvId\":\"553129893347477\",\"bizObjId\":\"PCFC"+generateRandom(12)+
 * "\",\"appId\":\"TF\"," +
 * "\"timestamp\":\"2015-Sep-14:11:36:59\"},\"msgBdy\":{\"initiateOrderReq\":{\"txnId\":\"PCFC"
 * +generateRandom(12)+"\"," +
 * "\"dbtrAcctId\":\""+limitNumber+"\",\"cdtrAcctId\":\"99805102050\",\"amt\":\""
 * +amount+"\",\"ccy\":\"INR\",\"txnTp\":\"IFT\"," +
 * "\"cstId\":\"35590\",\"onDt\":\"2015-09-14\"}}}}";
 * 
 * System.out.println("Input Json"+ input);
 * 
 * OutputStream os = conn.getOutputStream(); os.write(input.getBytes());
 * os.flush();
 * 
 * if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) { throw new
 * RuntimeException("Failed : HTTP error code : " + conn.getResponseCode()); }
 * 
 * BufferedReader br = new BufferedReader(new InputStreamReader(
 * (conn.getInputStream())));
 * 
 * String output; System.out.println("Output from Server .... \n"); while
 * ((output = br.readLine()) != null) { System.out.println(output); }
 * 
 * conn.disconnect();
 * 
 * } catch (MalformedURLException e) {
 * 
 * e.printStackTrace();
 * 
 * } catch (IOException e) {
 * 
 * e.printStackTrace();
 * 
 * }
 * 
 * 
 * 
 * }
 * 
 * public static long generateRandom(int length) { Random random = new Random();
 * char[] digits = new char[length]; digits[0] = (char) (random.nextInt(9) +
 * '1'); for (int i = 1; i < length; i++) { digits[i] = (char)
 * (random.nextInt(10) + '0'); } return Long.parseLong(new String(digits)); }
 * 
 * }
 */
