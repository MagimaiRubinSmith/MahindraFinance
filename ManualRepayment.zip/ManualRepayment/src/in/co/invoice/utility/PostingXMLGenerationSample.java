package in.co.invoice.utility;

import in.co.invoice.dao.exception.DAOException;

import java.io.FileOutputStream;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.aspectj.weaver.patterns.TypePatternQuestions.Question;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.misys.tiplus2.apps.ti.service.messages.BulkServiceRequest;
import com.misys.tiplus2.apps.ti.service.messages.EQ3Posting;
import com.misys.tiplus2.apps.ti.service.messages.ObjectFactory;
import com.misys.tiplus2.services.control.ServiceRequest;




/**
 * 
 * @author Encore
 *
 */
public class PostingXMLGenerationSample {
	
	
	public static ServiceRequest generateXML() {


		String returnXML = "";
		ServiceRequest serReq = new ServiceRequest();

		List<JAXBElement<?>> bulkServiceRequests = serReq.getRequest();
		
		

		ObjectFactory of = new ObjectFactory();

		BulkServiceRequest batchRequest = new BulkServiceRequest();

		/*for (ServiceRequest s : sRequestItems) {

			s.setRequestHeader(getRequestHeader("TI", serviceName,
					userName, "FULL", "N", "N", s.getRequestHeader()
							.getCorrelationId()));
			batchRequest.getServiceRequest().add(s);

		}*/
		// batchRequest.setServiceRequest(sRequestItems);

		JAXBElement<BulkServiceRequest> itemsServiceRequest = of
				.createItemRequest(batchRequest);

		bulkServiceRequests.add(itemsServiceRequest);

		

		return serReq;
	
	}
	
	public static void main(String[] args) throws Exception{  
	    JAXBContext contextObj = JAXBContext.newInstance(Question.class);  
	  
	    Marshaller marshallerObj = contextObj.createMarshaller();  
	    marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);  
	  
	    /*Answer ans1=new Answer(101,"java is a programming language","ravi");  
	    Answer ans2=new Answer(102,"java is a platform","john");  
	      
	    ArrayList<Answer> list=new ArrayList<Answer>();  
	    list.add(ans1);  
	    list.add(ans2);  
	      
	    Question que=new Question(1,"What is java?",list); */
	    
	    marshallerObj.marshal(generateXML(), new FileOutputStream("D:/postings.xml"));  
	       
	}  

	public String getTIDateForPosting() throws DAOException {
		LoggableStatement pst = null;
		ResultSet rs = null;
		Connection con = null;
		String tiDate = null;
		try {
			CommonMethods commonMethods = null;
			commonMethods = new CommonMethods();
			if(con == null){
			con = DBConnectionUtility.getConnection();}
			String query = "SELECT TO_CHAR(TO_DATE(PROCDATE, 'dd-mm-yy'),'yyyy-MM-dd') as PROCDATE FROM dlyprccycl";
			pst = new LoggableStatement(con, query);
			rs = pst.executeQuery();
			while (rs.next()) {
				tiDate = commonMethods.getEmptyIfNull(rs.getString("PROCDATE"))
						.trim();
			}
		} catch (Exception exception) {
			System.out.println(exception);
		} finally {
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return tiDate;
	}
	
	@SuppressWarnings("unused")
	public String generatePostingTag(EQ3Posting eq3Posting) throws TransformerConfigurationException, ParserConfigurationException, DAOException{
		
		 DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
		    DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
		    Document document = documentBuilder.newDocument();
		    String datePosting = getTIDateForPosting();
			Element root = document.createElement("ServiceRequest");
		    document.appendChild(root); 	
		    
		    
		    Element rocdoc0 = document.createElement("RequestHeader");
		    root.appendChild(rocdoc0);
	      
		          
	        Element ps = document.createElement("Service");
	        ps.appendChild(document.createTextNode("BackOffice"));
	        rocdoc0.appendChild(ps);
	        
	        ps = document.createElement("Operation");
	        ps.appendChild(document.createTextNode("Posting"));
	        rocdoc0.appendChild(ps);
	        
	        
	        Element psc = document.createElement("Credentials");
	        rocdoc0.appendChild(psc);
	        
	        ps = document.createElement("Name");
	        ps.appendChild(document.createTextNode("SUPERVISOR"));
	        psc.appendChild(ps);
	        
	       
	        
	        
	        ps = document.createElement("ReplyFormat");
	        ps.appendChild(document.createTextNode("FULL"));
	        rocdoc0.appendChild(ps);
	        
	        
	        ps = document.createElement("SourceSystem");
	        ps.appendChild(document.createTextNode("Z2"));
	        rocdoc0.appendChild(ps);
	        
	        ps = document.createElement("NoRepair");
	        ps.appendChild(document.createTextNode("Y"));
	        rocdoc0.appendChild(ps);
	        
	        ps = document.createElement("NoOverride");
	        ps.appendChild(document.createTextNode("Y"));
	        rocdoc0.appendChild(ps);

	        ps = document.createElement("CorrelationId");
	        ps.appendChild(document.createTextNode("2be60153-f4cc-47a1-a7fd-3c3749ed3f58--1"));
	        rocdoc0.appendChild(ps);

	        ps = document.createElement("TransactionControl");
	        ps.appendChild(document.createTextNode("NONE"));
	        rocdoc0.appendChild(ps);

	        ps = document.createElement("CreationDate");
	        ps.appendChild(document.createTextNode(datePosting));
	        rocdoc0.appendChild(ps);		
			
		    
		    
	        Element rocdoc1 = document.createElement("ns2:Posting");
	        root.appendChild(rocdoc1);
	        		    
	        String transactionID = eq3Posting.getTransactionId();
	        if(transactionID == null){
	        	Element pc = document.createElement("ns2:TransactionId");
		        pc.appendChild(document.createTextNode(""));
		        rocdoc1.appendChild(pc);
	        }else{
	        	Element pc = document.createElement("ns2:TransactionId");
		        pc.appendChild(document.createTextNode(transactionID));
		        rocdoc1.appendChild(pc);
	        }
	        String TransactionSeqNo = String.valueOf(eq3Posting.getTransactionSeqNo());
	        if(TransactionSeqNo == null){
	        	 Element et = document.createElement("ns2:TransactionSeqNo");
				 et.appendChild(document.createTextNode(""));
				 rocdoc1.appendChild(et);
	        }else{
	        	 Element et = document.createElement("ns2:TransactionSeqNo");
				 et.appendChild(document.createTextNode(TransactionSeqNo));
				 rocdoc1.appendChild(et);
	        }
	       
	        String MasterKey = String.valueOf(eq3Posting.getMasterKey());
	        if(MasterKey == null){
	        	Element ri = document.createElement("ns2:MasterKey");
			    ri.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(ri);
	        }else{
	        	Element ri = document.createElement("ns2:MasterKey");
			    ri.appendChild(document.createTextNode(MasterKey));
			    rocdoc1.appendChild(ri);
	        }
	   	    
	        String EventKey = String.valueOf(eq3Posting.getEventKey());
	        if(EventKey == null){
	        	 Element sbn = document.createElement("ns2:EventKey");
			     sbn.appendChild(document.createTextNode(""));
			     rocdoc1.appendChild(sbn);
	        }else{
	        	 Element sbn = document.createElement("ns2:EventKey");
			     sbn.appendChild(document.createTextNode(EventKey));
			     rocdoc1.appendChild(sbn);
	        }
	        String PostingBranch = eq3Posting.getPostingBranch();
	        if(PostingBranch == null){
	        	Element sbd = document.createElement("ns2:PostingBranch");
		        sbd.appendChild(document.createTextNode(""));
		        rocdoc1.appendChild(sbd);
	        }else{
	        	Element sbd = document.createElement("ns2:PostingBranch");
		        sbd.appendChild(document.createTextNode(PostingBranch));
		        rocdoc1.appendChild(sbd);
	        }
	        
	        String InputBranch = eq3Posting.getInputBranch();
	        if(InputBranch == null){
	        	  Element fn = document.createElement("ns2:InputBranch");
				  fn.appendChild(document.createTextNode(""));
				  rocdoc1.appendChild(fn);
	        }else{
	        	  Element fn = document.createElement("ns2:InputBranch");
				  fn.appendChild(document.createTextNode(InputBranch));
				  rocdoc1.appendChild(fn);
	        }
	   	  
	        String ProductReference = eq3Posting.getProductReference();
	   	   	if(ProductReference == null){
		   	   	Element ld = document.createElement("ns2:ProductReference");
			    ld.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(ld);
	   	   	}else{
		   	   	Element ld = document.createElement("ns2:ProductReference");
			    ld.appendChild(document.createTextNode(ProductReference));
			    rocdoc1.appendChild(ld);
	   	   	}
	   	 String MasterReference = eq3Posting.getMasterReference();
	   	    if(MasterReference == null){
	   	    	Element ac = document.createElement("ns2:MasterReference");
			    ac.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(ac);
	   	    }else{
	   	    	Element ac = document.createElement("ns2:MasterReference");
			    ac.appendChild(document.createTextNode(MasterReference));
			    rocdoc1.appendChild(ac);
	   	    }
	   	 String EventReference = eq3Posting.getEventReference();
		    if(EventReference == null){
		    	  Element ic = document.createElement("ns2:EventReference");
				  ic.appendChild(document.createTextNode(""));
				  rocdoc1.appendChild(ic);	  
		    }else{
		    	  Element ic = document.createElement("ns2:EventReference");
				  ic.appendChild(document.createTextNode(EventReference));
				  rocdoc1.appendChild(ic);	  
		    }
	   	   
			 String InternalRecnRef = eq3Posting.getInternalRecnRef();
	   	  	if(InternalRecnRef == null){
		   	  	Element aea = document.createElement("ns2:InternalRecnRef");
		        aea.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(aea);
	   	  	}else{
		   	  	Element aea = document.createElement("ns2:InternalRecnRef");
		        aea.appendChild(document.createTextNode(InternalRecnRef));
			    rocdoc1.appendChild(aea);
	   	  	}
	   	 String PostingSeqNo = String.valueOf(eq3Posting.getPostingSeqNo());
	   	    if(PostingSeqNo == null){
	   	    	Element dd = document.createElement("ns2:PostingSeqNo");
			    dd.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(dd);
	   	    }else{
	   	    	Element dd = document.createElement("ns2:PostingSeqNo");
			    dd.appendChild(document.createTextNode(PostingSeqNo));
			    rocdoc1.appendChild(dd);
	   	    }
	   	  	
	   	 String AccountNumber = eq3Posting.getAccountNumber();
		       if(AccountNumber == null){
		    	   Element abn = document.createElement("ns2:AccountNumber");
				   abn.appendChild(document.createTextNode(""));
				   rocdoc1.appendChild(abn);
		       }else{
		    	   Element abn = document.createElement("ns2:AccountNumber");
				   abn.appendChild(document.createTextNode(AccountNumber));
				   rocdoc1.appendChild(abn);
		       }
		  	 String BackOfficeAccountNo = eq3Posting.getBackOfficeAccountNo();
		       if(BackOfficeAccountNo == null){
		    	   Element dn = document.createElement("ns2:BackOfficeAccountNo");
				   dn.appendChild(document.createTextNode(""));
				   rocdoc1.appendChild(dn); 
		       }else{
		    	   Element dn = document.createElement("ns2:BackOfficeAccountNo");
				   dn.appendChild(document.createTextNode(BackOfficeAccountNo));
				   rocdoc1.appendChild(dn); 
		       }   				       
		  	 String ExternalAccountNo = eq3Posting.getExternalAccountNo();
		       if(ExternalAccountNo == null){
			   	   	Element ld = document.createElement("ns2:ExternalAccountNo");
				    ld.appendChild(document.createTextNode(""));
				    rocdoc1.appendChild(ld);
		   	   	}else{
			   	   	Element ld = document.createElement("ns2:ExternalAccountNo");
				    ld.appendChild(document.createTextNode(ExternalAccountNo));
				    rocdoc1.appendChild(ld);
		   	   	}
		  	 String CustomerMnemonic = eq3Posting.getCustomerMnemonic();
		   	    if(CustomerMnemonic == null){
		   	    	Element ac = document.createElement("ns2:CustomerMnemonic");
				    ac.appendChild(document.createTextNode(""));
				    rocdoc1.appendChild(ac);
		   	    }else{
		   	    	Element ac = document.createElement("ns2:CustomerMnemonic");
				    ac.appendChild(document.createTextNode(CustomerMnemonic));
				    rocdoc1.appendChild(ac);
		   	    }
		   	 String AccountType = eq3Posting.getAccountType();
		   	 if(AccountType == null){
	        	 Element sbn = document.createElement("ns2:AccountType");
			     sbn.appendChild(document.createTextNode(""));
			     rocdoc1.appendChild(sbn);
	        }else{
	        	 Element sbn = document.createElement("ns2:AccountType");
			     sbn.appendChild(document.createTextNode(AccountType));
			     rocdoc1.appendChild(sbn);
	        }
			 String SPSKMnemonic = eq3Posting.getSPSKMnemonic();
	        if(SPSKMnemonic == null){
	        	Element sbd = document.createElement("ns2:SPSKMnemonic");
		        sbd.appendChild(document.createTextNode(""));
		        rocdoc1.appendChild(sbd);
	        }else{
	        	Element sbd = document.createElement("ns2:SPSKMnemonic");
		        sbd.appendChild(document.createTextNode(SPSKMnemonic));
		        rocdoc1.appendChild(sbd);
	        }
	   	 String SPSKCategoryCode = eq3Posting.getSPSKCategoryCode();
	        if(SPSKCategoryCode == null){
	        	  Element fn = document.createElement("ns2:SPSKCategoryCode");
				  fn.appendChild(document.createTextNode(""));
				  rocdoc1.appendChild(fn);
	        }else{
	        	  Element fn = document.createElement("ns2:SPSKCategoryCode");
				  fn.appendChild(document.createTextNode(SPSKCategoryCode));
				  rocdoc1.appendChild(fn);
	        }
	   	 String Application = eq3Posting.getApplication();
	   	   	if(Application == null){
		   	   	Element ld = document.createElement("ns2:Application");
			    ld.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(ld);
	   	   	}else{
		   	   	Element ld = document.createElement("ns2:Application");
			    ld.appendChild(document.createTextNode(Application));
			    rocdoc1.appendChild(ld);
	   	   	}
	   	 String DebitCreditFlag = eq3Posting.getDebitCreditFlag();
	   	    if(DebitCreditFlag == null){
	   	    	Element ac = document.createElement("ns2:DebitCreditFlag");
			    ac.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(ac);
	   	    }else{
	   	    	Element ac = document.createElement("ns2:DebitCreditFlag");
			    ac.appendChild(document.createTextNode(DebitCreditFlag));
			    rocdoc1.appendChild(ac);
	   	    }
	   	 String TransactionCode = eq3Posting.getTransactionCode();
		    if(TransactionCode == null){
		    	  Element ic = document.createElement("ns2:TransactionCode");
				  ic.appendChild(document.createTextNode(""));
				  rocdoc1.appendChild(ic);	  
		    }else{
		    	  Element ic = document.createElement("ns2:TransactionCode");
				  ic.appendChild(document.createTextNode(TransactionCode));
				  rocdoc1.appendChild(ic);	  
		    }
		       
			 String PostingAmount = String.valueOf(eq3Posting.getPostingAmount());
		    if(PostingAmount == null){
	        	 Element sbn = document.createElement("ns2:PostingAmount");
			     sbn.appendChild(document.createTextNode(""));
			     rocdoc1.appendChild(sbn);
	        }else{
	        	 Element sbn = document.createElement("ns2:PostingAmount");
			     sbn.appendChild(document.createTextNode(PostingAmount));
			     rocdoc1.appendChild(sbn);
	        }
			 String PostingCcy = eq3Posting.getPostingCcy();
	        if(PostingCcy == null){
	        	Element sbd = document.createElement("ns2:PostingCcy");
		        sbd.appendChild(document.createTextNode(""));
		        rocdoc1.appendChild(sbd);
	        }else{
	        	Element sbd = document.createElement("ns2:PostingCcy");
		        sbd.appendChild(document.createTextNode(PostingCcy));
		        rocdoc1.appendChild(sbd);
	        }
	    
	        
	   	 	String ValueDate = String.valueOf(eq3Posting.getValueDate());
	        if(ValueDate == null){
	        	  Element fn = document.createElement("ns2:ValueDate");
				  fn.appendChild(document.createTextNode(datePosting));
				  rocdoc1.appendChild(fn);
	        }else{
	        	  Element fn = document.createElement("ns2:ValueDate");
				  fn.appendChild(document.createTextNode(ValueDate));
				  rocdoc1.appendChild(fn);
	        }
	   	 String RelatedParty = eq3Posting.getRelatedParty();
	   	   	if(RelatedParty == null){
		   	   	Element ld = document.createElement("ns2:RelatedParty");
			    ld.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(ld);
	   	   	}else{
		   	   	Element ld = document.createElement("ns2:RelatedParty");
			    ld.appendChild(document.createTextNode(RelatedParty));
			    rocdoc1.appendChild(ld);
	   	   	}
	   	 String BeneficiaryName = eq3Posting.getBeneficiaryName();
	   	    if(BeneficiaryName == null){
	   	    	Element ac = document.createElement("ns2:BeneficiaryName");
			    ac.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(ac);
	   	    }else{
	   	    	Element ac = document.createElement("ns2:BeneficiaryName");
			    ac.appendChild(document.createTextNode(BeneficiaryName));
			    rocdoc1.appendChild(ac);
	   	    }
	   	 String IssueOrContractDate = "";
		    if(IssueOrContractDate == null){
		    	  Element ic = document.createElement("ns2:IssueOrContractDate");
				  ic.appendChild(document.createTextNode(datePosting));
				  rocdoc1.appendChild(ic);	  
		    }else{
		    	  Element ic = document.createElement("ns2:IssueOrContractDate");
				  ic.appendChild(document.createTextNode(datePosting));
				  rocdoc1.appendChild(ic);	  
		    }
			 String BankCode1 = eq3Posting.getBankCode1();
		    if(BankCode1 == null){
		   	   	Element ld = document.createElement("ns2:BankCode1");
			    ld.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(ld);
	   	   	}else{
		   	   	Element ld = document.createElement("ns2:BankCode1");
			    ld.appendChild(document.createTextNode(BankCode1));
			    rocdoc1.appendChild(ld);
	   	   	}
			 String SettlementAccountUsed = eq3Posting.getSettlementAccountUsed();
	   	    if(SettlementAccountUsed == null){
	   	    	Element ac = document.createElement("ns2:SettlementAccountUsed");
			    ac.appendChild(document.createTextNode(""));
			    rocdoc1.appendChild(ac);
	   	    }else{
	   	    	Element ac = document.createElement("ns2:SettlementAccountUsed");
			    ac.appendChild(document.createTextNode(SettlementAccountUsed));
			    rocdoc1.appendChild(ac);
	   	    }
	   	 String AddMntDelFlag = "";
		    if(AddMntDelFlag == null){
		    	  Element ic = document.createElement("ns2:AddMntDelFlag");
				  ic.appendChild(document.createTextNode(""));
				  rocdoc1.appendChild(ic);	  
		    }else{
		    	  Element ic = document.createElement("ns2:AddMntDelFlag");
				  ic.appendChild(document.createTextNode(AddMntDelFlag));
				  rocdoc1.appendChild(ic);	  
		    }
	        
		    Element ic = document.createElement("ns2:ExtraData");
		    rocdoc1.appendChild(ic);

		    Element po = document.createElement("ns4:POSTA");
		    ic.appendChild(po);
		   								
			
		   
			
		    	
		    
		    /******* Convert XML Document to String File *************/
		    
		    String str = convertDocumentToString(document);
		    
	        System.out.println("XML File-------->"+str);
	        return str;
	}
	
	 private static String convertDocumentToString(Document doc) {
	        TransformerFactory tf = TransformerFactory.newInstance();
	        Transformer transformer;
	        try {
	            transformer = tf.newTransformer();
	            // below code to remove XML declaration
	            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	            StringWriter writer = new StringWriter();
	            transformer.transform(new DOMSource(doc), new StreamResult(writer));
	            String output = writer.getBuffer().toString();
	            return output;
	        } catch (TransformerException e) {
	            e.printStackTrace();
	        }
	         
	        return null;
	    }
}
