package in.co.invoice.utility;

import java.sql.Connection;

public class ConnObj {
	private String DB_DRIVER;
	private String DB_SERVERNAME;
	private String DB_PORT;
	private String DB_ORACLENAME;
	private String DB_USERNAME;
	private String DB_PASSWORD;
	private String DB_NAME;
	private String RPT_FOLDERLOC;
	private String RPT_OPFOLDERLOC;
	private Connection con;
	
	/**
	 * 
	 * @return
	 */
	public Connection getCon() {
		return con;
	}
	
	/**
	 * 
	 * @param con
	 */
	public void setCon(Connection con) {
		this.con = con;
	}
	public String getDB_DRIVER() {
		return DB_DRIVER;
	}
	public void setDB_DRIVER(String dB_DRIVER) {
		DB_DRIVER = dB_DRIVER;
	}
	public String getRPT_FOLDERLOC() {
		return RPT_FOLDERLOC;
	}
	public void setRPT_FOLDERLOC(String rPT_FOLDERLOC) {
		RPT_FOLDERLOC = rPT_FOLDERLOC;
	}
	public String getRPT_OPFOLDERLOC() {
		return RPT_OPFOLDERLOC;
	}
	public void setRPT_OPFOLDERLOC(String rPT_OPFOLDERLOC) {
		RPT_OPFOLDERLOC = rPT_OPFOLDERLOC;
	}
	public String getDB_SERVERNAME() {
		return DB_SERVERNAME;
	}
	public void setDB_SERVERNAME(String dB_SERVERNAME) {
		DB_SERVERNAME = dB_SERVERNAME;
	}
	public String getDB_PORT() {
		return DB_PORT;
	}
	public void setDB_PORT(String dB_PORT) {
		DB_PORT = dB_PORT;
	}
	public String getDB_ORACLENAME() {
		return DB_ORACLENAME;
	}
	public void setDB_ORACLENAME(String dB_ORACLENAME) {
		DB_ORACLENAME = dB_ORACLENAME;
	}
	public String getDB_USERNAME() {
		return DB_USERNAME;
	}
	public void setDB_USERNAME(String dB_USERNAME) {
		DB_USERNAME = dB_USERNAME;
	}
	public String getDB_PASSWORD() {
		return DB_PASSWORD;
	}
	public void setDB_PASSWORD(String dB_PASSWORD) {
		DB_PASSWORD = dB_PASSWORD;
	}
	public String getDB_NAME() {
		return DB_NAME;
	}
	public void setDB_NAME(String dB_NAME) {
		DB_NAME = dB_NAME;
	}

}
