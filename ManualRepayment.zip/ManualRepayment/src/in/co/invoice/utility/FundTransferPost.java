package in.co.invoice.utility;

import in.co.clf.util.SystemPropertiesUtil;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.ett.themebridge.gateway.InvokeService;

/**
 * 
 * @author
 * 
 */
public class FundTransferPost {

	// http://localhost:8080/RESTfulExample/json/product/post
	public static void main(String[] args) throws SQLException {
		fundPosting("10000038122", "100", "CUST01", "");
	}

	/**
	 * 
	 * @param limitNumber
	 * @param amount
	 * @throws ParserConfigurationException
	 */
	public static String fundPosting(String limitNumber, String amount,
			String customer, String batchId, String facilityID,
			String requestTransactionDate, String referenceNumber,
			String source, String programeId,Connection con)
			throws ParserConfigurationException {
		System.out.println("ENTERING INTO FUND POSTING"+batchId);
		String finalStatus = null;
		DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MMM-dd:HH:mm:ss");
		Date date = new Date();
		String CurrentDateTime = dateFormat1.format(date);
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource is = new InputSource();
		String availBalance = "";
		String status = "";
		String programID = null;
		String cifID = null;
		String rptName = null;
		String emailType = null;
		String toEmail = null;
		String ccEmail = null;
		String subject = null;
		String body = null;
		String rptFolder = null;
		String rptOutFolder = null;
	//	Connection con = null;
		Map<String, String> fetchedEmailDetails = new HashMap<String, String>();
		CommonMethods comm = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			comm = new CommonMethods();
			InvokeService limitCheck = new InvokeService();
			String requestXML = fetchLimitUtlizationXML(limitNumber, customer,
					facilityID, requestTransactionDate, referenceNumber,
					source, amount);
			String responseXML = limitCheck.processRequest(requestXML);
			System.out.println("Response XML -------->" + responseXML);
			is.setCharacterStream(new StringReader(responseXML));
			Document doc = db.parse(is);
			NodeList nodes = doc.getElementsByTagName("ResponseHeader");
			Element element = null;
			for (int i = 0; i < nodes.getLength(); i++) {
				element = (Element) nodes.item(i);
				status = element.getElementsByTagName("Status").item(0)
						.getTextContent();
				System.out.println("Statttt------>" + status);
			}
			if (status != null) {
				status = status.toUpperCase();
			}
			String seqVal = sequenceEOD(con);
			insertTempRecords(seqVal, limitNumber, amount, batchId, customer,
					requestXML, responseXML, CurrentDateTime, "Limit Reversal",
					con);
			emailType = "REPAYMENT_ADVICE";
			comm.insertEmailAndSMSTrigger(batchId, programeId, "", customer,
					"REPAYMENT", "N", con);
		} catch (Exception e1) {
			System.out.println("Exception----------->" + e1.getMessage());
			e1.printStackTrace();
		}
		return finalStatus;
	}

	/**
	 * 
	 * @return
	 */
	public static String fetchLimitUtlizationXML(String lineNumber,
			String cifID, String facilityID, String requestTransactionDate,
			String referenceNumber, String source, String amount) {
		String XML = "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest xmlns:m=\"urn:messages.service.ti.apps.tiplus2.misys.com\" "
				+ "xmlns=\"urn:control.services.tiplus2.misys.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><RequestHeader><Service>Limit</Service>"
				+ "<Operation>ReservationsAndReversal</Operation><CorrelationId>CorrelationId</CorrelationId><TransactionControl>NONE</TransactionControl>	</RequestHeader>";
		try {
			XML = XML
					+ "<ReservationsAndReversalRequest><REFNO>"
					+ referenceNumber
					+ "</REFNO><REQTXNDT>"
					+ requestTransactionDate
					+ "</REQTXNDT><SIGNATURE>SIGNATURE</SIGNATURE>"
					+ "<SOURCE>"
					+ source
					+ "</SOURCE><LINE_NO>"
					+ lineNumber
					+ "</LINE_NO><APPROVED_LIMIT></APPROVED_LIMIT>"
					+ "<SANCTION_AMOUNT></SANCTION_AMOUNT><RELEASED_AMOUNT></RELEASED_AMOUNT>"
					+ "<UTILIZED_AMOUNT>"
					+ amount
					+ "</UTILIZED_AMOUNT><BALANCE></BALANCE>"
					+ "<AVAILABLE_LIMIT></AVAILABLE_LIMIT><CIF_ID>"
					+ cifID
					+ "</CIF_ID><CLUSTER_ID></CLUSTER_ID>"
					+ "<FACILITY_ID>"
					+ facilityID
					+ "</FACILITY_ID><FACILITY_NAME></FACILITY_NAME>"
					+ "<VIRTUAL_AC_NUMBER>VIRTUAL_AC_NUMBER</VIRTUAL_AC_NUMBER><PRODUCT_CAP_LIMIT></PRODUCT_CAP_LIMIT>"
					+ "<REVOLVING></REVOLVING><SECURED></SECURED><MODE>R</MODE>"
					+ "</ReservationsAndReversalRequest></ServiceRequest>";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return XML;
	}

	/**
	 * 
	 * @param limitNumber
	 * @param amount
	 * @throws SQLException
	 */
	public static String fundPosting(String limitNumber, String amount,
			String customer, String batchId) throws SQLException {

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MMM-dd:HH:mm:ss");
		Date date = new Date();
		String CurrentDate = dateFormat.format(date);
		String CurrentDateTime = dateFormat1.format(date);
		long randomVal = generateRandom(12);
		String finalStatus = null;
		Connection con = null;
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}

			System.out.println(SystemPropertiesUtil.getFundTransfer());
			URL url = new URL(SystemPropertiesUtil.getFundTransfer());

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("PUT");
			conn.setRequestProperty("Content-Type", "application/json");
			String accountNumber = SystemPropertiesUtil.getAccountNumber();
			String input = "{\"InitiateGenericFundTransferRequest\":{\"msgHdr\":{\"msgId\":\"569919387390414\","
					+ "\"cnvId\":\"553129893347477\",\"bizObjId\":\"PCFC"
					+ randomVal
					+ "\",\"appId\":\"TF\","
					+ "\"timestamp\":\""
					+ CurrentDateTime
					+ "\"},\"msgBdy\":{\"initiateOrderReq\":{\"txnId\":\"PCFC"
					+ randomVal
					+ "\","
					+ "\"dbtrAcctId\":\""
					+ accountNumber
					+ "\",\"cdtrAcctId\":\""
					+ limitNumber
					+ "\",\"amt\":\""
					+ amount
					+ "\",\"ccy\":\"INR\","
					+ "\"txnTp\":\"IFT\",\"pmtDesc\":\""
					+ batchId
					+ "\","
					+ "\"cstId\":\""
					+ customer
					+ "\",\"onDt\":\""
					+ CurrentDate + "\"}}}}";

			// 99805102050 - 127
			// 98407102050 - 107

			System.out.println("Input Json" + input);

			OutputStream os = conn.getOutputStream();
			os.write(input.getBytes());
			os.flush();

			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				/*
				 * throw new RuntimeException("Failed : HTTP error code : " +
				 * conn.getResponseCode());
				 */
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;
			StringBuffer totalOutput = new StringBuffer();
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
				totalOutput.append(output);
			}

			String result = totalOutput.toString();
			System.out.println("Result" + result);
			finalStatus = json2Object(result);
			String seqVal = sequenceEOD(con);
			insertTempRecords(seqVal, limitNumber, amount, batchId, customer,
					input, result, CurrentDateTime, "Limit Release", con);
			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		} finally {
			DBConnectionUtility.surrenderDB(null, null, con);
		}

		return finalStatus;

	}

	/**
	 * 
	 * @return
	 * @throws DAOException
	 */
	public static String sequenceEOD(Connection con) {
		ResultSet rs = null;
		// Connection con = null;
		LoggableStatement ps = null;
		String vals = "";
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con,
					"SELECT ETT_STP_AUDIT_TRAIL_SEQ.nextval FROM dual");
			rs = ps.executeQuery();
			if (rs.next()) {
				vals = rs.getString("nextval");
			}
		} catch (Exception exception) {
			System.out.println("Exception in sequenceEOD------>"
					+ exception.getMessage());
		} finally {
			DBConnectionUtility.surrenderStatement(rs, ps);
		}
		return vals;
	}

	/**
	 * 
	 * @param seqVal
	 * @param limitNo
	 * @param finAmt
	 * @param batchId
	 * @param custmr
	 * @param capDt
	 * @param request
	 * @param response
	 * @param prgrmId
	 * @param expOn
	 * @throws DAOException
	 */
	public static void insertTempRecords(String seqVal, String limitNo,
			String finAmt, String batchId, String custmr, String request,
			String response, String CurrentDateTime, String service,
			Connection con) {
		LoggableStatement ps = null;
		// Connection con = null;
		String CapQuery = "INSERT INTO ETT_STP_AUDIT_TRAIL(ID,LIMITNUMBER,FINANCEAMT,BATCHID,CUSTOMER,REQUEST,RESPONSE,PROCESS_TIME,SERVICE) VALUES (?,?,?,?,?,?,?,?,?)";
		try {
			if (con == null) {
				con = DBConnectionUtility.getConnection();
			}
			ps = new LoggableStatement(con, CapQuery);
			ps.setString(1, seqVal);
			ps.setString(2, limitNo);
			ps.setString(3, finAmt);
			ps.setString(4, batchId);
			ps.setString(5, custmr);
			ps.setString(6, request);
			ps.setString(7, response);
			ps.setString(8, CurrentDateTime);
			ps.setString(9, service);
			System.out.println("Result Query - " + ps.getQueryString());
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println("Exception in insertTempRecords------>"
					+ e.getMessage());
		} finally {
			DBConnectionUtility.surrenderStatement(null, ps);
		}
	}

	public static String json2Object(String input) {
		// String jsonString =
		// "{\"InitiateGenericFundTransferResponse\":{\"msgHdr\":{\"rslt\":\"ERROR\",\"error\":{\"cd\":\"CBS266\",\"rsn\":\"CBSERROR:CLEARED BAL/FUNDS/DP NOT AVAILABLE.CARE! ACCT WILL BE OVERDRAWN                               000000\"}},\"msgBdy\":{\"sts\":\"RJCT\",\"txnId\":\"5334\",\"chnlTxnId\":\"PCFC241430354342\"}}}";
		JSONObject object = (JSONObject) JSONValue.parse(input);
		Object headvalue = object.get("InitiateGenericFundTransferResponse");
		object = (JSONObject) JSONValue.parse(headvalue.toString());

		Object bodyValue = object.get("msgHdr");
		object = (JSONObject) JSONValue.parse(bodyValue.toString());
		String stsValue = (String) object.get("rslt");

		/*
		 * Object bodyValue=object.get("msgBdy"); object = (JSONObject)
		 * JSONValue.parse(bodyValue.toString()); String stsValue=(String)
		 * object.get("sts");
		 */
		System.out.println(stsValue);
		return stsValue;
	}

	public static long generateRandom(int length) {
		Random random = new Random();
		char[] digits = new char[length];
		digits[0] = (char) (random.nextInt(9) + '1');
		for (int i = 1; i < length; i++) {
			digits[i] = (char) (random.nextInt(10) + '0');
		}
		return Long.parseLong(new String(digits));
	}

}
/*
 * package in.co.stp.utility;
 * 
 * import java.io.BufferedReader; import java.io.IOException; import
 * java.io.InputStreamReader; import java.io.OutputStream; import
 * java.net.HttpURLConnection; import java.net.MalformedURLException; import
 * java.net.URL; import java.util.Random;
 *//**
 * 
 * @author
 * 
 */
/*
 * public class FundTransferPost {
 * 
 * // http://localhost:8080/RESTfulExample/json/product/post public static void
 * main(String[] args) { fundPosting("10000038122","100"); }
 *//**
 * 
 * @param limitNumber
 * @param amount
 */
/*
 * public static void fundPosting(String limitNumber,String amount) {
 * 
 * 
 * try {
 * 
 * URL url = new URL("http://172.19.36.118:10062/initiateGenericFundTransfer/");
 * HttpURLConnection conn = (HttpURLConnection) url.openConnection();
 * conn.setDoOutput(true); conn.setRequestMethod("PUT");
 * conn.setRequestProperty("Content-Type", "application/json");
 * 
 * String input =
 * "{\"InitiateGenericFundTransferRequest\":{\"msgHdr\":{\"msgId\":\"569919387390414\","
 * + "\"cnvId\":\"553129893347477\",\"bizObjId\":\"PCFC"+generateRandom(12)+
 * "\",\"appId\":\"TF\"," +
 * "\"timestamp\":\"2015-Sep-14:11:36:59\"},\"msgBdy\":{\"initiateOrderReq\":{\"txnId\":\"PCFC"
 * +generateRandom(12)+"\"," +
 * "\"dbtrAcctId\":\""+limitNumber+"\",\"cdtrAcctId\":\"99805102050\",\"amt\":\""
 * +amount+"\",\"ccy\":\"INR\",\"txnTp\":\"IFT\"," +
 * "\"cstId\":\"35590\",\"onDt\":\"2015-09-14\"}}}}";
 * 
 * System.out.println("Input Json"+ input);
 * 
 * OutputStream os = conn.getOutputStream(); os.write(input.getBytes());
 * os.flush();
 * 
 * if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) { throw new
 * RuntimeException("Failed : HTTP error code : " + conn.getResponseCode()); }
 * 
 * BufferedReader br = new BufferedReader(new InputStreamReader(
 * (conn.getInputStream())));
 * 
 * String output; System.out.println("Output from Server .... \n"); while
 * ((output = br.readLine()) != null) { System.out.println(output); }
 * 
 * conn.disconnect();
 * 
 * } catch (MalformedURLException e) {
 * 
 * e.printStackTrace();
 * 
 * } catch (IOException e) {
 * 
 * e.printStackTrace();
 * 
 * }
 * 
 * 
 * 
 * }
 * 
 * public static long generateRandom(int length) { Random random = new Random();
 * char[] digits = new char[length]; digits[0] = (char) (random.nextInt(9) +
 * '1'); for (int i = 1; i < length; i++) { digits[i] = (char)
 * (random.nextInt(10) + '0'); } return Long.parseLong(new String(digits)); }
 * 
 * }
 */

/*
 * package in.co.invoice.utility;
 * 
 * import java.io.BufferedReader; import java.io.IOException; import
 * java.io.InputStreamReader; import java.io.OutputStream; import
 * java.net.HttpURLConnection; import java.net.MalformedURLException; import
 * java.net.URL; import java.text.DateFormat; import java.text.SimpleDateFormat;
 * import java.util.Date; import java.util.Random;
 *//**
 * 
 * @author
 * 
 */
/*
 * public class FundTransferPost {
 * 
 * // http://localhost:8080/RESTfulExample/json/product/post public static void
 * main(String[] args) {
 * 
 * }
 *//**
 * 
 * @param limitNumber
 * @param amount
 */
/*
 * public static void fundPosting(String limitNumber,String amount, String
 * customer, String batchId) {
 * 
 * 
 * DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); DateFormat
 * dateFormat1 = new SimpleDateFormat("yyyy-MMM-dd:HH:mm:ss");
 * 
 * Date date = new Date(); String CurrentDate = dateFormat.format(date); String
 * CurrentDateTime = dateFormat1.format(date); long randomVal =
 * generateRandom(12); try {
 * 
 * URL url = new URL("http://172.19.36.118:10062/initiateGenericFundTransfer/");
 * HttpURLConnection conn = (HttpURLConnection) url.openConnection();
 * conn.setDoOutput(true); conn.setRequestMethod("PUT");
 * conn.setRequestProperty("Content-Type", "application/json");
 * 
 * String input =
 * "{\"InitiateGenericFundTransferRequest\":{\"msgHdr\":{\"msgId\":\"569919387390414\","
 * +
 * "\"cnvId\":\"553129893347477\",\"bizObjId\":\"PCFC411011700290\",\"appId\":\"TF\","
 * +
 * "\"timestamp\":\"2015-Sep-14:11:36:59\"},\"msgBdy\":{\"initiateOrderReq\":{\"txnId\":\"PCFC411011700290\","
 * +
 * "\"dbtrAcctId\":\"99805102050\",\"cdtrAcctId\":\""+limitNumber+"\",\"amt\":\""
 * +amount+"\",\"ccy\":\"INR\",\"txnTp\":\"IFT\"," +
 * "\"cstId\":\"35590\",\"onDt\":\"2015-09-14\"}}}}";
 * 
 * String input =
 * "{\"InitiateGenericFundTransferRequest\":{\"msgHdr\":{\"msgId\":\"569919387390414\","
 * + "\"cnvId\":\"553129893347477\",\"bizObjId\":\"PCFC"+randomVal+
 * "\",\"appId\":\"TF\"," + "\"timestamp\":\""+CurrentDateTime+
 * "\"},\"msgBdy\":{\"initiateOrderReq\":{\"txnId\":\"PCFC"+randomVal+"\"," +
 * "\"dbtrAcctId\":\"98407102050\",\"cdtrAcctId\":\""
 * +limitNumber+"\",\"amt\":\""+amount+"\",\"ccy\":\"INR\",\"txnTp\":\"IFT\"," +
 * "\"cstId\":\""+customer+"\",\"onDt\":\""+CurrentDate+"\"}}}}";
 * 
 * OutputStream os = conn.getOutputStream(); os.write(input.getBytes());
 * os.flush();
 * 
 * if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) { throw new
 * RuntimeException("Failed : HTTP error code : " + conn.getResponseCode()); }
 * 
 * BufferedReader br = new BufferedReader(new InputStreamReader(
 * (conn.getInputStream())));
 * 
 * String output; System.out.println("Output from Server .... \n"); while
 * ((output = br.readLine()) != null) { System.out.println(output); }
 * 
 * conn.disconnect();
 * 
 * } catch (MalformedURLException e) {
 * 
 * e.printStackTrace();
 * 
 * } catch (IOException e) {
 * 
 * e.printStackTrace();
 * 
 * }
 * 
 * 
 * 
 * }
 * 
 * public static long generateRandom(int length) { Random random = new Random();
 * char[] digits = new char[length]; digits[0] = (char) (random.nextInt(9) +
 * '1'); for (int i = 1; i < length; i++) { digits[i] = (char)
 * (random.nextInt(10) + '0'); } return Long.parseLong(new String(digits)); }
 * 
 * }
 */