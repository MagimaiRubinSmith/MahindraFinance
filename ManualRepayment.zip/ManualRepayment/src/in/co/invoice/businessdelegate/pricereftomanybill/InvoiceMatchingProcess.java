package in.co.invoice.businessdelegate.pricereftomanybill;

import in.co.invoice.businessdelegate.BaseBusinessDelegate;
import in.co.invoice.businessdelegate.exception.BusinessException;
import in.co.invoice.dao.customername.InvoiceMatchingDAO;
import in.co.invoice.dao.exception.ApplicationException;
import in.co.invoice.utility.ActionConstants;
import in.co.invoice.utility.ActionConstantsQuery;
import in.co.invoice.vo.AlertMessagesVO;
import in.co.invoice.vo.InvMatchingDataVO;
import in.co.invoice.vo.InvMatchingVO;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;


public class InvoiceMatchingProcess extends BaseBusinessDelegate implements ActionConstants,ActionConstantsQuery {
	
	private static Logger logger = Logger.getLogger(InvoiceMatchingProcess.class
			.getName());

	static InvoiceMatchingProcess bd;

	/**
	 * 
	 * @return PaymentAdviceBD object
	 */
	public static InvoiceMatchingProcess getBD() {
		if (bd == null) {
			bd = new InvoiceMatchingProcess();
		}
		return bd;
	}
	@SuppressWarnings("static-access")
	public ArrayList<InvMatchingVO> fetchInvoiceDetails(String invoice,String refDate){
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> invoiceList=new ArrayList<InvMatchingVO>();
	
		try{
			dao = InvoiceMatchingDAO.getDAO();
			invoiceList=dao.fetchInvoiceDetails(invoice,refDate);
			//System.out.println("list"+invoiceList.get(0).getPeriod());
		}catch(Exception e){
			e.printStackTrace();
		}
		return  invoiceList;
	}
	
	/**
	 * 
	 * @return
	 * @throws ApplicationException
	 * @throws BusinessException 
	 */
	public void isSessionAvailable() throws BusinessException {
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			dao.isSessionAvailable();
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}
	public InvMatchingVO getUpdatedList(InvMatchingVO scf)
			throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);

		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			scf = dao.getUpdatedList(scf);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return scf;
	}
	
	
	public ArrayList<InvMatchingVO> getProgrammeList(InvMatchingVO invMatchingVO) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> programList = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			programList = dao.getProgrammeList(invMatchingVO);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return programList;
	}
	
	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 */
	public ArrayList<InvMatchingVO> fetchInvoiceBatches(InvMatchingVO invMatchingVO) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> batchList = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			batchList = dao.fetchInvoiceBatches(invMatchingVO);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return batchList;
	}
	
	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 */
	public ArrayList<InvMatchingVO> fetchDetailedBatch(String batchID) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> batchList = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			batchList = dao.fetchDetailedBatch(batchID);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return batchList;
	}
	public InvMatchingVO fetchPenalDetails(InvMatchingVO invMatchingVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invMatchingVo = dao.fetchPenalDetailedBatch(invMatchingVo);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVo;
	}
	
	//12Feb
	public InvMatchingVO fetchChargePenalDetails(InvMatchingVO invMatchingVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invMatchingVo = dao.fetchChargePenalDetails(invMatchingVo);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVo;
	}
	
	//04Feb
	public InvMatchingVO fetchPenalDetailsCheck(InvMatchingVO invMatchingVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invMatchingVo = dao.fetchPenalListCheck(invMatchingVo);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVo;
	}
	
	//04Feb
	public InvMatchingVO getBatchList(InvMatchingVO invMatchingVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invMatchingVo = dao.getBatchList(invMatchingVo);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVo;
	}
	
	//04Feb
	public ArrayList<InvMatchingVO> viewList(String batchIdSeq) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> invoicList = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invoicList = dao.viewList(batchIdSeq);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoicList;
	}
	
	//11Feb
	public ArrayList<InvMatchingVO> fetchChargesViewList(String invoiceAjaxListval) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> invoicList = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invoicList = dao.fetchChargesViewList(invoiceAjaxListval);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoicList;
	}
	
	//04Feb
	public InvMatchingVO getBatchListView(InvMatchingVO invMatchingVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invMatchingVo = dao.getBatchListView(invMatchingVo);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVo;
	}
	
	
	//11Feb
	public InvMatchingVO getBulkUploadBatchListView(InvMatchingVO invMatchingVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invMatchingVo = dao.getBulkUploadBatchListView(invMatchingVo);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVo;
	}
	
	/* * 
	 * @param invMatchingVO
	 * @return
	 */
	public ArrayList<InvMatchingVO> fetchInvoiceList(String batchID) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> batchList = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			batchList = dao.fetchInvoiceList(batchID);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return batchList;
	}
	
	
	
	/**
	 * 
	 * @param invMatchingVO
	 * @return
	 * @throws BusinessException 
	 */
	public ArrayList<InvMatchingVO> getAccountList(InvMatchingVO invMatchingVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> accountList = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			accountList = dao.getAccountList(invMatchingVO);
		} catch (Exception exception) {
		exception.printStackTrace();
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountList;
	}
	public ArrayList<InvMatchingVO> getAccountList1(InvMatchingVO invMatchingVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> accountList = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			accountList = dao.getAccountList1(invMatchingVO);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountList;
	}
	
	/**
	 * 
	 * @param invMatchingVO
	 * @param tiListsDetail
	 * @param batchId
	 * @return
	 * @throws BusinessException
	 */
	public InvMatchingVO fetchInvoiceDetails(InvMatchingVO invMatchingVO, String batchID) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		 try {
			invProcess = InvoiceMatchingDAO.getDAO();
			invMatchingVO=invProcess.fetchInvoiceDetails(invMatchingVO,batchID);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVO;
	}
	
	public InvMatchingVO updateInvoicePayment(InvMatchingVO invMatchingVO,
			ArrayList<InvMatchingVO> tiListsDetail, String batchId) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		 try {
			invProcess = InvoiceMatchingDAO.getDAO();
			invMatchingVO=invProcess.updateRepayment(invMatchingVO,tiListsDetail,batchId);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVO;
	}
	
	/**
	 * 
	 * @param invoiceVO
	 * @return
	 * @throws BusinessException
	 */
	public InvMatchingVO getValidate(InvMatchingVO invoiceVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invoiceVO = dao.getValidate(invoiceVO);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoiceVO;
	}
	
	/**
	 * 
	 * @param invoiceVO
	 * @return
	 * @throws BusinessException
	 */
	public InvMatchingVO getConfirmValidate(InvMatchingVO invoiceVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invoiceVO = dao.getConfirmValidate(invoiceVO);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoiceVO;
	}
	
	/**
	 * 
	 * @param invoiceVO
	 * @return
	 * @throws BusinessException
	 */
	public InvMatchingVO getCheckerValidate(InvMatchingVO invoiceVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invoiceVO = dao.getCheckerValidate(invoiceVO);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoiceVO;
	}
	/**
	 * 
	 * @param invoiceVO
	 * @return
	 * @throws BusinessException
	 */
	public InvMatchingVO getDealRefValidate(InvMatchingVO invoiceVO,ArrayList<InvMatchingVO> tiListsDetail) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invoiceVO = dao.getDealRefValidate(invoiceVO,tiListsDetail);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoiceVO;
	}
	
	/**
	 * 
	 * @param invoiceVO
	 * @return
	 * @throws BusinessException
	 */
	public InvMatchingVO getDealRefWarning(InvMatchingVO invoiceVO,ArrayList<InvMatchingVO> tiListsDetail) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invoiceVO = dao.getDealRefWarning(invoiceVO,tiListsDetail);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoiceVO;
	}
	
	public InvMatchingVO getWSDLValidate(InvMatchingVO invoiceVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invoiceVO = dao.getWSDLValidate(invoiceVO);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoiceVO;
	}
	
	public InvMatchingVO gettingprogramId(InvMatchingVO invoiceVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
	    InvMatchingVO  customerName = null;
	
		try {
			
			
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				customerName = invProcess.gettingDebitParty(invoiceVO);
			}

		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return  customerName;
	}
	
	public List<InvMatchingVO> gettingcounterId(InvMatchingVO invoiceVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
	    List<InvMatchingVO>  counterParty = null;
	
		try {
			
			
			invProcess = InvoiceMatchingDAO.getDAO();
			
			if (null != invProcess) {
		
				counterParty = invProcess.gettingCounterParty(invoiceVO);
			}

		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return  counterParty;
	}
	
	public String getProgramType(String programId) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		String  programType = null;
	
		try {
			System.out.println("enterbd");
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				programType = invProcess.getProgramType(programId);
			}

		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return  programType;
	}
	
	public ArrayList<InvMatchingVO> gettingprogram() throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		ArrayList<InvMatchingVO>  customerName = null;
	
		try {
			System.out.println("enterbd");
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				customerName = invProcess.getProgram();
			}

		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return  customerName;
	}
	
	public InvMatchingVO getDataFromTI(InvMatchingVO invoiceVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		
		InvoiceMatchingDAO invProcess = null;
		
	    InvMatchingVO invMatchingVO = null;
		try {
			
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				invMatchingVO = invProcess.fetchDataFromTI(invoiceVO);
			}

		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return  invMatchingVO;
	}
	
	public InvMatchingVO processRePayment(String batchId, InvMatchingVO invoiceVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		
		InvoiceMatchingDAO invProcess = null;
		
	    InvMatchingVO invMatchingVO = null;
		try {
			
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				invMatchingVO = invProcess.processRePayment(batchId,invoiceVO);
			}

		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return  invMatchingVO;
	}
	
	/**
	 * 
	 * @param batchId
	 * @param invoiceVO
	 * @return
	 * @throws BusinessException
	 */
	public InvMatchingVO approveRePayment(String batchId, InvMatchingVO invoiceVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		
		InvoiceMatchingDAO invProcess = null;
		
	    InvMatchingVO invMatchingVO = null;
		try {
			
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				invMatchingVO = invProcess.approveRePayment(batchId,invoiceVO);
			}

		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return  invMatchingVO;
	}
	
	public void setDate() throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			dao.setDate();
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		
	}
	
	public String fetchTXNDueDate() throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		String result = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			result = dao.fetchTXNDueDate();
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return result;
	}
	
	public InvMatchingDataVO getStoreInvoiceData(InvMatchingDataVO invMatchingData,int lst) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		 InvMatchingDataVO  invMatchingDataVO = null;
	
		try {
			//invMatchingDataVO = new InvMatchingDataVO();
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				invMatchingDataVO = invProcess.getStoreInvoiceData(invMatchingData,lst);
				
			}

		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingData;
	}
	
	
	/*public ArrayList<InvMatchingVO> getAccountList(InvMatchingVO scf) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> accountList = null;
		try {
			dao = SCFAddEditDAO.getDAO();
			accountList = dao.getAccountList(scf);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountList;
	}*/
	public ArrayList<InvMatchingVO> getAccountTCList(InvMatchingVO invMatchingVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		ArrayList<InvMatchingVO> accountList = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			accountList = dao.getAccountTCList(invMatchingVO);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return accountList;
	}

	public void insertMakerConfirm(InvMatchingVO invMatchingVO, String batchId) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		 InvMatchingDataVO  invMatchingDataVO = null;
	
		try {
			//invMatchingDataVO = new InvMatchingDataVO();
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				invProcess.getStoreInvoiceData(invMatchingVO,batchId);
				
			}

		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		//return invMatchingData;
		
	}

	//04Feb
	public String insertFetchData(ArrayList<InvMatchingVO> invoiceList, String virtualAccNo) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		String BatchID = "";
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				BatchID = invProcess.insertFetchData(invoiceList, virtualAccNo);
			}
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return BatchID;
	}
	//17 sept 2019
	
	public int fetchBatchIdCount(String BatchID) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		int BatchID_Count=0;
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				BatchID_Count = invProcess.fetchBatchIdCountDAO(BatchID);
			}
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return BatchID_Count;
	}
	//12Feb
	public String confirmChargeData(ArrayList<InvMatchingVO> invoiceList, String virtualAccNo) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		String BatchID = "";
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				BatchID = invProcess.confirmChargeData(invoiceList, virtualAccNo);
			}
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return BatchID;
	}

	//04Feb
	public void confirmDataChecker(ArrayList<InvMatchingVO> invoiceList, String batchIDSeq) throws BusinessException {
		InvoiceMatchingDAO invProcess = null;
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				invProcess.confirmDataChecker(invoiceList, batchIDSeq);
			}
		} catch(Exception e) {
			throwBDException(e);
		}
	}
	
	
	//04Feb
	public void rejectDataChecker(ArrayList<InvMatchingVO> invoiceList, String batchIDSeq) throws BusinessException {
		InvoiceMatchingDAO invProcess = null;
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				invProcess.rejectDataChecker(invoiceList, batchIDSeq);
			}
		} catch(Exception e) {
			throwBDException(e);
		}
	}
	
	
	//11Feb
	public String bulkUploadValidate(InvMatchingVO invMatchingVO) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		String batchIDSeq = null;
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			batchIDSeq = invProcess.bulkUploadValidate(invMatchingVO);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return batchIDSeq;
	}
	
	
	//11Feb
	public ArrayList<InvMatchingVO> fetchUploadDetails(String batchID) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		ArrayList<InvMatchingVO> invoicList = null;
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			invoicList = invProcess.fetchUploadDetails(batchID);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invoicList;
	}
	
	
	//11Feb
	public String bulkUploadSubmit(InvMatchingVO invMatchingVO,
			ArrayList<InvMatchingVO> invoicList) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		String batchID = null;
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			batchID = invProcess.bulkUploadSubmit(invMatchingVO, invoicList);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return batchID;
	}
	
	
	//13Feb
	public int bulkUploadUpdate(InvMatchingVO invMatchingVO,
			ArrayList<InvMatchingVO> invoicList) throws BusinessException {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO invProcess = null;
		int updateCount = 0;
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			updateCount = invProcess.bulkUploadUpdate(invMatchingVO, invoicList);
		} catch (Exception exception) {
			throwBDException(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return updateCount;
	}
	
	
	//11Feb
	public InvMatchingVO getChargesBatchListCheck(InvMatchingVO invMatchingVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invMatchingVo = dao.getChargesBatchListCheck(invMatchingVo);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVo;
	}
	
	
	//11Feb
	public InvMatchingVO getBulkUploadValueCheck(InvMatchingVO invMatchingVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		InvoiceMatchingDAO dao = null;
		try {
			dao = InvoiceMatchingDAO.getDAO();
			invMatchingVo = dao.getBulkUploadValueCheck(invMatchingVo);
		} catch (Exception exception) {
			System.out.println(exception);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return invMatchingVo;
	}
	
	
	//11Feb
	public void bulkUploadApprove(ArrayList<InvMatchingVO> invoiceList, String batchIDSeq) throws BusinessException {
		InvoiceMatchingDAO invProcess = null;
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				invProcess.bulkUploadApprove(invoiceList, batchIDSeq);
			}
		} catch(Exception e) {
			throwBDException(e);
		}
	}
	
	
	//11Feb
	public void bulkUploadReject(ArrayList<InvMatchingVO> invoiceList, String batchIDSeq) throws BusinessException {
		InvoiceMatchingDAO invProcess = null;
		try {
			invProcess = InvoiceMatchingDAO.getDAO();
			if (null != invProcess) {
				invProcess.bulkUploadReject(invoiceList, batchIDSeq);
			}
		} catch(Exception e) {
			throwBDException(e);
		}
	}
	

}
