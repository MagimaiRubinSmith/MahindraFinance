package in.co.invoice.businessdelegate.exception;

/**
 * 
 * @author Admin
 * 
 */
public class BusinessException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * default constructor used to handle exception.
	 */
	public BusinessException() {
		super();
	}

	/**
	 * constructor with one argument to handle user defined exception.
	 * 
	 * @param msg
	 * 
	 * 
	 */
	public BusinessException(String msg) {
		super(msg);
	}

	/**
	 * constructor with two argument to handle user defined exception.
	 * 
	 * @param msg
	 * @param exception
	 */
	public BusinessException(String msg, Throwable exception) {
		super(msg, exception);
	}
}
