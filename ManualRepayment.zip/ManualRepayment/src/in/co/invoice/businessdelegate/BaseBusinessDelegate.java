package in.co.invoice.businessdelegate;

import in.co.invoice.businessdelegate.exception.BusinessException;
import in.co.invoice.utility.LogHelper;

import org.apache.log4j.Logger;



public class BaseBusinessDelegate {
	private static Logger logger = Logger.getLogger(BaseBusinessDelegate.class
			.getName());

	/**
	 * This helper method is used to catch the Exceptions from all
	 * BusinessDelegate classes & throw it to BusinessException class.
	 * 
	 * @param exception
	 * @throws BusinessException
	 */
	public void throwBDException(Exception exception) throws BusinessException {
		logger.error(exception.fillInStackTrace());
		LogHelper.logError(logger, exception);
		throw new BusinessException(exception.getMessage());
	}
	
	
	
	

}
