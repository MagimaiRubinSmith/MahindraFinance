package com.bs.theme.migration.loader.data.handler;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bs.theme.migration.loader.tiplus.pojos.TiattdocExtra;
import com.bs.theme.migration.loader.utility.MessageUtil;
import com.misys.tiplus2.apps.ti.service.common.GatewayContext;
import com.misys.tiplus2.apps.ti.service.messages.ObjectFactory;
import com.misys.tiplus2.apps.ti.service.messages.TFATTDOC;
import com.misys.tiplus2.services.control.ServiceRequest;

public class TFattdtoHandler {
	
		 private static final Logger logger = LoggerFactory.getLogger(TFattdtoHandler.class);
		    
	     public ServiceRequest createTFattdtoRequest(List<TiattdocExtra> list) {
		
		        ServiceRequest sRequestItems = new ServiceRequest();
		
		        for (TiattdocExtra lst : list) {
		
		            ServiceRequest tfinvdtoRequest = MessageUtil.getServiceRequest(
		                    "TI", "TFATTDOC", "SUPERVISOR", "FULL", "N", "N",lst.getTicorrid());
		            List<JAXBElement<?>> tfil = tfinvdtoRequest.getRequest();
		
		            ObjectFactory of = new ObjectFactory();
		            com.misys.tiplus2.apps.ti.service.common.ObjectFactory objFactory = new com.misys.tiplus2.apps.ti.service.common.ObjectFactory();
             
            		     TFATTDOC tfat= new TFATTDOC();
            		     GatewayContext gc= new GatewayContext();
            		     gc.setBehalfOfBranch(lst.getBehalfofbranch());
            		     gc.setBranch(lst.getBranch());
            		     gc.setCustomer(lst.getCustomer());
            		     gc.setProduct(lst.getProduct());
            		     gc.setEvent(lst.getEvent());
            		     gc.setTheirReference(lst.getTheirreference());
            		     gc.setOurReference(lst.getTheirreference());
            		     gc.setTeam(lst.getTeam());
            		     tfat.setContext(gc);
            		     
            		   
            		    
            		   /*ILCisiEvent ilce= new ILCisiEvent();
            		   ilce.setINSCOMNMName(lst.getInsconame());
            		   tfat.setExtraData(ilce);*/
         
            		    
            		     
            		     
            		    JAXBElement<TFATTDOC> tfattdocjaxb=of.createTFATTDOC(tfat);
        	            tfil.add(tfattdocjaxb);
        	
        	
        	            sRequestItems.getRequest().add(tfattdocjaxb);
        	            sRequestItems.setRequestHeader(MessageUtil.getRequestHeader("TI", "TFATTDOC", "SUPERVISOR", "FULL", "N", "N",lst.getTicorrid()));  
            		      
            		  
            		      
		        }
		        return sRequestItems;
		        }
	     /**
	      * 
	      * @param list
	      * @return
	      */
	     public List<ServiceRequest> createTFattdtoRequestBulk(List<TiattdocExtra> list) {
	 		
	    	 List<ServiceRequest> serviceRequestList = new ArrayList<ServiceRequest>();

		
		        for (TiattdocExtra lst : list) {
			    	 ServiceRequest sRequestItems = new ServiceRequest();
		
		            //ServiceRequest tfinvdtoRequest = MessageUtil.getServiceRequest(
		            //       "TI", "TFATTDOC", "SUPERVISOR", "FULL", "N", "N",lst.getTicorrid());
		            //List<JAXBElement<?>> tfil = tfinvdtoRequest.getRequest();
		
		            ObjectFactory of = new ObjectFactory();
		            //com.misys.tiplus2.apps.ti.service.common.ObjectFactory objFactory = new com.misys.tiplus2.apps.ti.service.common.ObjectFactory();
          
         		     TFATTDOC tfat= new TFATTDOC();
         		     GatewayContext gc= new GatewayContext();
         		     gc.setBehalfOfBranch(lst.getBehalfofbranch());
         		     gc.setBranch(lst.getBranch());
         		     gc.setCustomer(lst.getCustomer());
         		     gc.setProduct(lst.getProduct());
         		     gc.setEvent(lst.getEvent());
         		    /* gc.setTheirReference(lst.getTheirreference());*/
         		     gc.setOurReference(lst.getTheirreference());
         		     gc.setTeam(lst.getTeam());
         		     tfat.setContext(gc);
         		     
         		   
         		    
         		   /*ILCisiEvent ilce= new ILCisiEvent();
         		   ilce.setINSCOMNMName(lst.getInsconame());
         		   tfat.setExtraData(ilce);*/
      
         		    
         		     
         		     
         		    JAXBElement<TFATTDOC> tfattdocjaxb=of.createTFATTDOC(tfat);
     	            //tfil.add(tfattdocjaxb);
     	
     	
     	            sRequestItems.getRequest().add(tfattdocjaxb);
     	            sRequestItems.setRequestHeader(MessageUtil.getRequestHeader("TI", "TFATTDOC", "SUPERVISOR", "FULL", "N", "N",lst.getTicorrid()));  
     	           serviceRequestList.add(sRequestItems); 
         		  
         		      
		        }
		        return serviceRequestList;
		        }
	     }
