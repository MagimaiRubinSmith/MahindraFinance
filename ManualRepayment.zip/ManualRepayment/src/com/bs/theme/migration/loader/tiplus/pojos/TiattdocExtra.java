package com.bs.theme.migration.loader.tiplus.pojos;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="TiattdocTable")
public class TiattdocExtra {
	@Column(name = "BRANCH")
    private String branch;
	@Column(name = "CUSTOMER")
    private String customer;
	@Column(name = "PRODUCT")
    private String product;
	@Column(name = "EVENT")
    private String event;
	@Column(name = "THEIRREFERENCE")
    private String theirreference;
	@Column(name = "TEAM")
    private String team;
	@Column(name = "BEHALFOFBRANCH")
    private String behalfofbranch;
	@Column(name = "INSCONAME")
    private String insconame;
	
	
	@Id
    @Basic(optional = false)
    @Column(name = "LOGID")
    private String logid;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "ERRORDTLS")
    private String errorDtls;
    /*@Column(name = "PROCESSEDDATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date processeddate;
    @Column(name = "RCVDDATEFRMT24")
    @Temporal(TemporalType.TIMESTAMP)
    private Date rcvddatefrmt24;
    @Column(name = "PROCESSDURATION")
    private Long processduration;*/
    @Column(name = "TICORRID")
    private String ticorrid;
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getTheirreference() {
		return theirreference;
	}
	public void setTheirreference(String theirreference) {
		this.theirreference = theirreference;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getBehalfofbranch() {
		return behalfofbranch;
	}
	public void setBehalfofbranch(String behalfofbranch) {
		this.behalfofbranch = behalfofbranch;
	}
	public String getInsconame() {
		return insconame;
	}
	public void setInsconame(String insconame) {
		this.insconame = insconame;
	}
	public String getLogid() {
		return logid;
	}
	public void setLogid(String logid) {
		this.logid = logid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getErrorDtls() {
		return errorDtls;
	}
	public void setErrorDtls(String errorDtls) {
		this.errorDtls = errorDtls;
	}
	public String getTicorrid() {
		return ticorrid;
	}
	public void setTicorrid(String ticorrid) {
		this.ticorrid = ticorrid;
	}
	
	

}
