package com.bs.theme.migration.loader.utility;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.dgc.VMID;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPathExpressionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import com.misys.tiplus2.apps.ti.service.messages.BulkServiceRequest;
import com.misys.tiplus2.apps.ti.service.messages.ObjectFactory;
import com.misys.tiplus2.apps.ti.service.messages.TFATTDOC;
import com.misys.tiplus2.apps.ti.service.messages.TFILCAPP;
import com.misys.tiplus2.services.control.ReplyFormatEnum;
import com.misys.tiplus2.services.control.ServiceRequest;
import com.misys.tiplus2.services.control.ServiceRequest.RequestHeader;
import com.misys.tiplus2.services.control.ServiceRequest.RequestHeader.Credentials;
import com.misys.tiplus2.services.control.YNEnum;

public class MessageUtil {

	private static final Logger logger = LoggerFactory
			.getLogger(MessageUtil.class);

	public static Marshaller marshaller = null;
	public static JAXBContext jaxbContext ;
	public static JAXBContext getJaxbContext() throws JAXBException{
		
		 try {

				if (jaxbContext != null){
					return jaxbContext;
				} else
				{
					jaxbContext = JAXBContext.newInstance(TFATTDOC.class);
				}
		
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("JAXB Exception"+e.getMessage());
			jaxbContext = JAXBContext.newInstance(TFILCAPP.class);
		}
		return jaxbContext;
		}
	public static RequestHeader getRequestHeader(String service,
			String operation, String credentialsName, String replyFormat,
			String noRepair, String noOverride, String corrID) {

		RequestHeader requestHeader = new RequestHeader();
		requestHeader.setService(service);
		requestHeader.setOperation(operation);
		Credentials credentials = new Credentials();
		credentials.setName(credentialsName);
		requestHeader.setCredentials(credentials);
		requestHeader.setReplyFormat(ReplyFormatEnum.fromValue(replyFormat));
		requestHeader.setNoRepair(YNEnum.fromValue(noRepair));
		requestHeader.setNoOverride(YNEnum.fromValue(noOverride));

		requestHeader.setCorrelationId(corrID);

		return requestHeader;
	}

	public static ServiceRequest getServiceRequest(String service,
			String operation, String credentialsName, String replyFormat,
			String noRepair, String noOverride, String corrID) {

		ServiceRequest serviceRequest = new ServiceRequest();
		RequestHeader header = getRequestHeader(service, operation,
				credentialsName, replyFormat, noRepair, noOverride, corrID);
		serviceRequest.setRequestHeader(header);
		return serviceRequest;
	}

	public static String xmlBulkServiceRequest(List<ServiceRequest> sRequestItems,
			String serviceName, String userName) throws InterruptedException {
			Marshaller marshaller = null;
			String returnXML = "";
			ServiceRequest serReq = getServiceRequest("TIBulk", "Item",
			"SUPERVISOR", "FULL", "N", "N", new VMID().toString());

			List<JAXBElement<?>> bulkServiceRequests = serReq.getRequest();

			ObjectFactory of = new ObjectFactory();

			BulkServiceRequest batchRequest = new BulkServiceRequest();
			for (ServiceRequest s : sRequestItems) {

			s.setRequestHeader(getRequestHeader("TI", serviceName,
			userName, "FULL", "N", "N", s.getRequestHeader()
			.getCorrelationId()));
			batchRequest.getServiceRequest().add(s);

			}
			// batchRequest.setServiceRequest(sRequestItems);

			JAXBElement<BulkServiceRequest> itemsServiceRequest = of
			.createItemRequest(batchRequest);
			bulkServiceRequests.add(itemsServiceRequest);



			// File file;
			// FileOutputStream fop = null;
			try {
			//System.out.println("Result XML is :---> " + serviceName);

			// String fileAddress ="";
			// if(serviceName.equals("TFIGTDTO")){
			// fileAddress = "Guarantee.xml";
			// }else if(serviceName.equals("TFILCDTO")){
			// fileAddress = "ImportLC.xml";
			// }

			// file = new File(fileAddress);
			// fop = new FileOutputStream(file);
			//
			// if (!file.exists()) {
			// try {
			// file.createNewFile();
			// } catch (IOException ex) {
			// Logger.getLogger(MessageUtil.class.getName()).log(Level.SEVERE,
			// null, ex);
			// }
			// }

			//JAXBContext jaxbContext = JAXBContext.newInstance(TFILCAPP.class);

			if (marshaller == null) 
			{
			System.out.println(" Creating marshaller ... ");
			//marshaller = jaxbContext.createMarshaller();
		logger.info(" Creating marshaller ... ");
			marshaller = getJaxbContext().createMarshaller();
			}

			try{
			System.out.println(" Marshaller Step1... ");
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			System.out.println(" Marshaller Step2... ");
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			System.out.println(" Marshaller Step3... ");
			if(serReq != null){
			marshaller.marshal(serReq, baos);
			}
			System.out.println(" Marshaller Step4... ");
			if(baos != null){
			returnXML = baos.toString();
			}
			System.out.println(" Marshaller Step5... ");
			}catch(Exception e){
			e.printStackTrace();
			System.out.println(" Creating marshaller1 Exception ... "+e.getMessage());
			marshaller = null;
			System.out.println(" Creating marshaller1 ... ");
			//marshaller = jaxbContext.createMarshaller();
			marshaller = getJaxbContext().createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			marshaller.marshal(serReq, baos);
			returnXML = baos.toString();
			}

			
			} catch (Exception ex) {
	ex.printStackTrace();
	System.out.println("Marshaller Exception2"+ex.getMessage());
	}

	return returnXML;
	}
	
	public static String xmlServiceRequest(List<ServiceRequest> sRequestItems,
			String serviceName, String userName) {

		String returnXML = "";
		ServiceRequest serReq = getServiceRequest("TIBulk", "Item",
				"SUPERVISOR", "FULL", "N", "N", new VMID().toString());

		List<JAXBElement<?>> bulkServiceRequests = serReq.getRequest();

		ObjectFactory of = new ObjectFactory();

		BulkServiceRequest batchRequest = new BulkServiceRequest();

		for (ServiceRequest s : sRequestItems) {

			s.setRequestHeader(getRequestHeader("TI", serviceName,
					userName, "FULL", "N", "N", s.getRequestHeader()
							.getCorrelationId()));
			batchRequest.getServiceRequest().add(s);

		}
		// batchRequest.setServiceRequest(sRequestItems);

		JAXBElement<BulkServiceRequest> itemsServiceRequest = of
				.createItemRequest(batchRequest);

		bulkServiceRequests.add(itemsServiceRequest);

		// File file;
		// FileOutputStream fop = null;
		try {
			System.out.println("Result XML is :---> " + serviceName);

			// String fileAddress ="";
			// if(serviceName.equals("TFIGTDTO")){
			// fileAddress = "Guarantee.xml";
			// }else if(serviceName.equals("TFILCDTO")){
			// fileAddress = "ImportLC.xml";
			// }

			// file = new File(fileAddress);
			// fop = new FileOutputStream(file);
			//
			// if (!file.exists()) {
			// try {
			// file.createNewFile();
			// } catch (IOException ex) {
			// Logger.getLogger(MessageUtil.class.getName()).log(Level.SEVERE,
			// null, ex);
			// }
			// }

			JAXBContext jaxbContext = JAXBContext.newInstance(TFILCAPP.class);

			if (marshaller == null) {
				System.out.println(" Creating marshaller ... ");
				marshaller = jaxbContext.createMarshaller();
			}

			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			marshaller.marshal(serReq, baos);
			returnXML = baos.toString();
			System.out.println("********************************************");
			System.out.println(returnXML.toString()+"********************************************");
			return returnXML;
			
			// byte[] contentInBytes = returnXML.getBytes();
			// fop.write(contentInBytes);
			// fop.flush();
			// fop.close();

		} catch (JAXBException ex) {
			ex.printStackTrace();
		}

		return returnXML;
	}

	/*public static List<ServiceResponse> processResponse(String result)
			throws JAXBException, IOException {

		// String data =
		// readFile("C:\\PERIYASAMY\\Bank_Projects\\FBG\\Data MIgration\\BulkResponseSample.txt");
		List<ServiceResponse> serviceResponses = new ArrayList<ServiceResponse>();
		if (result.matches("(.*)" + "ItemResponse>" + "(.*)")) {

			ObjectFactory factory = new ObjectFactory();
			InputStream inStream = new ByteArrayInputStream(result.getBytes());
			JAXBContext context = JAXBInstanceInitialiser.getBackOfficeBatchRequestContext();
			Unmarshaller unmarshaller = context.createUnmarshaller();
			ServiceResponse response = (ServiceResponse) unmarshaller
					.unmarshal(inStream);

			List<JAXBElement<?>> bulkServiceResponse = response.getResponse();
			JAXBElement<BulkServiceResponse> element = (JAXBElement<BulkServiceResponse>) bulkServiceResponse
					.get(0);
			serviceResponses = element.getValue().getServiceResponse();

			System.out.println("Size ->" + serviceResponses.size());
			for (ServiceResponse serviceResponse : serviceResponses) {

				System.out.println("Service Response CorrID"
						+ serviceResponse.getResponseHeader()
								.getCorrelationId());
				System.out.println("Service Response Status"
						+ serviceResponse.getResponseHeader().getStatus());

			}

		} else {
			
			serviceResponses = MigrationUtil.processSingleResponse(result);
			
			if(serviceResponses.size() == 0){
				
				
				
				
			}
			
		}

		return serviceResponses;

	}*/

	public static String clearEmptyNodes(String xmlString)
			throws XPathExpressionException, ParserConfigurationException,
			SAXException, IOException {
		String formattedOutput = "";

		try {

			TransformerFactory tFactory = TransformerFactory.newInstance();

			Transformer transformer = tFactory.newTransformer(new StreamSource(
					"removeemptytag.xsl"));

			StreamSource xmlSource = new StreamSource(new ByteArrayInputStream(
					xmlString.getBytes()));
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			transformer.transform(xmlSource, new StreamResult(baos));

			formattedOutput = baos.toString();

		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.debug("Formatted Output ->" + formattedOutput);
		return formattedOutput;

	}

	public static void main(String[] args) throws IOException, JAXBException {
		try {
			// String data =
			// readFile("C:\\PERIYASAMY\\Bank_Projects\\FBG\\Data MIgration\\BulkResponseSample.txt");
			// processResponse(data);
			//

			clearEmptyNodes("sdsadswdsds");
		} catch (XPathExpressionException ex) {
			ex.printStackTrace();
		} catch (ParserConfigurationException ex) {
			ex.printStackTrace();
		} catch (SAXException ex) {
			ex.printStackTrace();
		}

	}

	public static String readFile(String filePath) throws IOException {

		BufferedReader reader = new BufferedReader(new FileReader(filePath));

		String line = null;
		StringBuilder stringBuilder = new StringBuilder();
		String ls = System.getProperty("line.separator");

		while ((line = reader.readLine()) != null) {

			stringBuilder.append(line);

			stringBuilder.append(ls);

		}
		reader.close();

		return stringBuilder.toString();
	}

}
