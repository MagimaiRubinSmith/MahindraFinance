package com.ett.themebridge.gateway;


import in.co.invoice.utility.DBConnectionUtility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ett.themebridge.gateway.GatewayRouterServiceStub.TiProcessRequest;
import com.ett.themebridge.gateway.GatewayRouterServiceStub.TiProcessRequestE;
import com.ett.themebridge.gateway.GatewayRouterServiceStub.TiProcessRequestResponse;
import com.ett.themebridge.gateway.GatewayRouterServiceStub.TiProcessRequestResponseE;


public class InvokeService {
	
	/**
	 * 
	 * @return
	 */
	public static String fetchWSDLURL(){
		String URL = null;
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try{
			con = DBConnectionUtility.getConnection();
			String query = "SELECT * FROM ETT_INTERFACE_CREDENTIALS";
			pst = con.prepareStatement(query);
			rs = pst.executeQuery();
			if(rs.next()){
				URL = rs.getString("URL");
				System.out.println("Interface URL------>"+URL);
				/*URL = "http://mfho-1000002253:8088/mockGatewayRouterPortBinding?WSDL";*/
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnectionUtility.surrenderDB(rs, pst, con);
		}
		return URL;
	}

	/**
	 * 
	 * @param request
	 * @return
	 */
	public String processRequest(String request){
		String TiResponseXml  = null;
		try{
			GatewayRouterServiceStub stub = new GatewayRouterServiceStub();
			TiProcessRequestE tiProcessRequest0 = new TiProcessRequestE();
			TiProcessRequest param = new TiProcessRequest();
			param.setTiRequestXml(request);
			tiProcessRequest0.setTiProcessRequest(param );
			TiProcessRequestResponseE res = stub.tiProcessRequest(tiProcessRequest0);
			TiProcessRequestResponse response = res.getTiProcessRequestResponse();
			TiResponseXml = response.getTiResponseXml();
			System.out.println("TiResponseXml " +TiResponseXml);
		}catch(Exception e){
			e.printStackTrace();
		}
		return TiResponseXml;
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		InvokeService service = new InvokeService();
		service.processRequest("<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "	xmlns='urn:control.services.tiplus2.misys.com' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>"
				+ "<RequestHeader><Service>Limit</Service><Operation>Facilities</Operation>"
				+ "<CorrelationId>CorrelationId</CorrelationId><TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader><FacilitiesCheckRequest><FacilityRequestDetails><LINE_NO>LINE_NO</LINE_NO>"
				+ "<CIF_ID>EATON</CIF_ID><FACILITY_ID>FACILITY_ID</FACILITY_ID>"
				+ "</FacilityRequestDetails>	</FacilitiesCheckRequest></ServiceRequest>");
	}
	
}